////////////////////////////////////////////////////////////////////////////////
// Implementation of CTimeoutTestApplication
////////////////////////////////////////////////////////////////////////////////

#include "TimeoutTestapp.h"
#include "TimeoutTestdocument.h"

const TUid KUidTimeoutTest = { 0x01000001 };

TUid CTimeoutTestApplication::AppDllUid() const
{
	return KUidTimeoutTest;
}

CApaDocument* CTimeoutTestApplication::CreateDocumentL()
{
	CApaDocument* document = CTimeoutTestDocument::NewL(*this);
  return document;
}
