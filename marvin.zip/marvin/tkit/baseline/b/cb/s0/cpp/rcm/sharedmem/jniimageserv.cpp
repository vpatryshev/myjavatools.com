//---------------------------------------------------------------------------

#include <windows.h>
#include <jni.h>
#include "com_borland_acmwsclient_WSCImageServer.h"
#include "com_borland_acmwsclient_MyNativeHelper.h"
#include "sharedmem.h"

#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void* lpReserved)
{
    return 1;
}

class rcmTransportClient : public TTransportClient
{
public:
    rcmTransportClient(const char *name, int size = MAX_SHMEM_SIZE)
        : TTransportClient(name, size)
    {
        Reset();
    }

    ~rcmTransportClient() { }

    jint GetImageSize(JNIEnv *env);
    jstring GetMimeType(JNIEnv *env);
    jint GetScanWidth(JNIEnv *env);
    jbyteArray GetImageDataAsBytes(JNIEnv *env);
    jintArray GetImageDataAsInts(JNIEnv *env);
    jboolean RequestModelImage(JNIEnv *env, jstring modelKey, jstring uri);
    jboolean RequestCompImage(JNIEnv *env, jstring modelKey, jstring managerKey, jstring designerKey,
        jstring compInstanceKey, int x, int y, int w, int h);
    jbyteArray SoapRequest(JNIEnv *env, jbyteArray ba);
    void Reset();

private:
    bool imageValid;
    bool bytesValid;
};

rcmTransportClient* Client()
{
    static rcmTransportClient *client = new rcmTransportClient("RCM_WXW", MAX_SHMEM_SIZE);
    return client;
}

jstring rcmTransportClient::GetMimeType(JNIEnv *env)
{
    return imageValid ?
        env->NewStringUTF(((ImageResponse*)pMem)->mimeType) :
        env->NewStringUTF("");
}

jint rcmTransportClient::GetScanWidth(JNIEnv *env)
{
    return imageValid ? ((ImageResponse*)pMem)->scanWidth : -1;
}

jint rcmTransportClient::GetImageSize(JNIEnv *env)
{
    return imageValid ? ((ImageResponse*)pMem)->size : -1;
}

jintArray rcmTransportClient::GetImageDataAsInts(JNIEnv *env)
{
    if (imageValid) {
        ImageResponse *ir = (ImageResponse*)pMem;
        int arraySize = ir->size / sizeof(int);        jintArray ia = env->NewIntArray(arraySize);        env->SetIntArrayRegion(ia, 0, arraySize, (jint *)(&(ir->data)));        return ia;
    }
    else
        return 0;
}

jbyteArray rcmTransportClient::GetImageDataAsBytes(JNIEnv *env)
{
    if (imageValid) {
        ImageResponse *ir = (ImageResponse*)pMem;        int arraySize = ir->size;        jbyteArray ba = env->NewByteArray(arraySize);        env->SetByteArrayRegion(ba, 0, arraySize, (jbyte *)(&(ir->data)));        return ba;
    }
    else
        return 0;
}

jboolean rcmTransportClient::RequestModelImage(JNIEnv *env, jstring modelKey, jstring uri)
{
    Reset();
    unsigned char isCopy;
    char *cmk = (char*)env->GetStringUTFChars(modelKey, &isCopy);    char *cu = (char*)env->GetStringUTFChars(uri, &isCopy);    ImageResponse *dummy;    if (!Lock())        return JNI_FALSE;    imageValid = TTransportClient::RequestModelImage(cmk, cu, dummy);    env->ReleaseStringUTFChars(modelKey, cmk);    env->ReleaseStringUTFChars(uri, cu);    return imageValid;}

jboolean rcmTransportClient::RequestCompImage(JNIEnv *env, jstring modelKey, jstring managerKey,
    jstring designerKey, jstring compInstanceKey, int x, int y, int w, int h)
{
    Reset();
    unsigned char isCopy;
    char *cmk = (char*)env->GetStringUTFChars(modelKey, &isCopy);    char *cmnk = (char*)env->GetStringUTFChars(managerKey, &isCopy);    char *cdk = (char*)env->GetStringUTFChars(designerKey, &isCopy);    char *cck = (char*)env->GetStringUTFChars(compInstanceKey, &isCopy);    ImageResponse *dummy;    if (!Lock())        return JNI_FALSE;    imageValid = TTransportClient::RequestCompImage(cmk, cmnk, cdk, cck, x, y, w, h, dummy);    env->ReleaseStringUTFChars(modelKey, cmk);    env->ReleaseStringUTFChars(managerKey, cmnk);    env->ReleaseStringUTFChars(designerKey, cdk);    env->ReleaseStringUTFChars(compInstanceKey, cck);    return imageValid;}

jbyteArray rcmTransportClient::SoapRequest(JNIEnv *env, jbyteArray ba)
{
    Reset();
    SoapData *data = (SoapData*)pMem;
    if (!Lock())
        return 0;

    unsigned char isCopy = JNI_FALSE;
    jsize arraySize = env->GetArrayLength(ba);
    jbyte *bytes = env->GetByteArrayElements(ba, &isCopy);
    jbyteArray newArray = 0;
    if (arraySize > 0 && bytes && Lock()) {
        data->size = arraySize;
        data->key = BYTE_DATA;
        memcpy(data->data, bytes, arraySize * sizeof(byte));
        Unlock();
        ::ResetEvent(hSoapDone);
        ::SetEvent(hSoapRequest);
        if (::WaitForSingleObject(hSoapDone, INFINITE) == WAIT_OBJECT_0
            && data->key == BYTE_DATA) {
            // Server finished processing data, handle received data
            arraySize = data->size;
            if (arraySize > 0) {
                newArray = env->NewByteArray(data->size);
                if (newArray) {
                    env->SetByteArrayRegion(newArray, 0, arraySize, data->data);
                }
            }
        }
    }
    env->ReleaseByteArrayElements(ba, bytes, JNI_ABORT);
    return newArray;
}

void rcmTransportClient::Reset()
{
    Unlock();
    imageValid = false;
    bytesValid = false;
}

JNIEXPORT jboolean JNICALL Java_com_borland_acmwsclient_WSCImageServer_nativeRequestCompImage
  (JNIEnv *env, jobject, jstring modelKey, jstring managerKey, jstring designerKey, jstring compInstanceKey, jint x, jint y, jint w, jint h)
{
    return Client()->RequestCompImage(env, modelKey, managerKey, designerKey,
        compInstanceKey, x, y, w, h);
}
JNIEXPORT jboolean JNICALL Java_com_borland_acmwsclient_WSCImageServer_nativeRequestModelImage
  (JNIEnv *env, jobject, jstring modelKey, jstring uri)
{
    return Client()->RequestModelImage(env, modelKey, uri);
}
JNIEXPORT jboolean JNICALL Java_com_borland_acmwsclient_WSCImageServer_nativeLock
  (JNIEnv *, jobject)
{
    return Client()->Lock();}
JNIEXPORT void JNICALL Java_com_borland_acmwsclient_WSCImageServer_nativeUnlock
  (JNIEnv *, jobject)
{
    Client()->Reset();}
JNIEXPORT jstring JNICALL Java_com_borland_acmwsclient_WSCImageServer_nativeGetMimeType
  (JNIEnv *env, jobject)
{
    return Client()->GetMimeType(env);
}
JNIEXPORT jint JNICALL Java_com_borland_acmwsclient_WSCImageServer_nativeGetSize
  (JNIEnv *env, jobject)
{
    return Client()->GetImageSize(env);}

JNIEXPORT jint JNICALL Java_com_borland_acmwsclient_WSCImageServer_nativeGetScanWidth
  (JNIEnv *env, jobject)
{
    return Client()->GetScanWidth(env);
}
JNIEXPORT jintArray JNICALL Java_com_borland_acmwsclient_WSCImageServer_nativeGetDataAsInts
  (JNIEnv *env, jobject)
{
    return Client()->GetImageDataAsInts(env);
}
JNIEXPORT jbyteArray JNICALL Java_com_borland_acmwsclient_WSCImageServer_nativeGetDataAsBytes
  (JNIEnv *env, jobject)
{
    return Client()->GetImageDataAsBytes(env);
}
JNIEXPORT jbyteArray JNICALL Java_com_borland_acmwsclient_MyNativeHelper_sendSoapRequestAndReadResponse
  (JNIEnv *env, jclass, jbyteArray ba)
{
    return Client()->SoapRequest(env, ba);
}
//---------------------------------------------------------------------------
