////////////////////////////////////////////////////////////////////////////////
// Implementation of CIRServerAppUi
////////////////////////////////////////////////////////////////////////////////

#include <e32std.h>
#include "IRServer.hrh"
#include "IRServerappui.h"
#include "IRServerview.h"


/**
 * Method managed by IDE to construct views
 * Please do not edit this routine as its
 * contents is regenerated upon new view creation.
 */
void CIRServerAppUi::InitViewsL()
{
  iIRServerView = CIRServerView::NewL();
  AddViewL(iIRServerView);
}

void CIRServerAppUi::ConstructL()
{
  BaseConstructL();
  InitViewsL();

  // Set default view
  SetDefaultViewL(*iIRServerView);
}

void CIRServerAppUi::HandleCommandL(TInt aCommand)
{
  switch (aCommand) {
    case EEikCmdExit:
    case EAknSoftkeyExit:
      Exit();
      break;
    default:
      break;
  }
}

