#ifdef __BORLANDC__
#include "rcmpch.h"
#endif

#include "wxwcomponentmodel.h"
#include "wxwcomponentinfo.h"
#include "wxwcomponenteditor.h"
#include "wxwdesigner.h"
#include "wxwcomponent.h"
#include "wxwcontainer.h"
#include <stdexcept>
#include "wx/wfstream.h"
#include "wx/image.h"

wxwComponentModel *model = 0;

wxwComponentModel* Model()
{
    if (!model) {
        model = new wxwComponentModel();
    }
    return model;
}

template <>
void SerializeStream<wxMemoryOutputStream*>(
	struct soap *soap,
	xsd__base64Binary *xsdb,
	wxMemoryOutputStream *stream)
{
	if (xsdb) {
		xsdb->__size = stream->GetSize();
		stream->SeekO(0);
		xsdb->__ptr = (unsigned char*)soap_malloc(soap, xsdb->__size);
		stream->CopyTo(xsdb->__ptr, xsdb->__size);
	}
}

template <typename T>
T* CreateBestDynamicClass(ClassInfos &infos, const wxClassInfo *classInfo)
{
	ClassInfos::iterator it = infos.begin();
    const wxClassInfo *candCI = 0;
    const wxClassInfo *bestCI = 0;
    const wxClassInfo *theClass = 0;
    T *result = 0;
    while (it != infos.end()) {
    	candCI = it->first;
        if (classInfo->IsKindOf(candCI)
        && (bestCI == 0 || candCI->IsKindOf(bestCI))) {
            bestCI = it->first;
			theClass = it->second;
        }
        it++;
    }
    if (theClass) {
        result = dynamic_cast<T*>(theClass->CreateObject());
    }
    return result;
}

wxwPalettePage::wxwPalettePage(const wxString &title, const wxString &description, const wxString &iconURI)
    : FTitle(title), FDesc(description), FIconURI(iconURI)
{
    KeyGen(this, FKey);
}

wxwComponentModel::wxwComponentModel()
{
	FKey = "wxw";
    FDesc = "wxFramework description";
    FDisplayName = "wxFramework";
    RegisterDesigner(wxwDesigner::GetInfo());
    RegisterDesigner(wxwUIDesigner::GetInfo());
}

CreateResult* wxwComponentModel::CreateComponent(
    rcmComponentInfo *compInfo,
    rcmDesigner *designer,
    rcmContainer *container,
    input_stream_type *stream)
{
    wxwComponent *newComp = 0;
    try {
        if (compInfo && designer && designer->CanCreate(container, compInfo)) {
            compFactories::iterator it = FCompFactories.find(compInfo->GetClassName());
            if (it != FCompFactories.end()) {
                newComp = (*it).second->Create(dynamic_cast<wxwDesigner*>(designer), dynamic_cast<wxwContainer*>(container));
                if (newComp) {
                    newComp->Init();
                }
            }
        }
        return new CreateResult(newComp);
    }
    catch (const exception &e) {
    	return new CreateResult(0, typeid(e).name(), e.what());
    }
}

wxwComponent* wxwComponentModel::CreateComponentFromInstance(
    wxwDesigner *designer,
    wxwContainer *container,
    wxObject *instance,
    const wxString &name)
{
    wxwComponent *newComp = 0;
    if (instance) {
        wxDynamicObject *dyno = dynamic_cast<wxDynamicObject*>(instance);
        if (dyno) {
            instance = dyno->GetSuperClassInstance();
        }

        compFactories::iterator it = FCompFactories.find(instance->GetClassInfo()->GetClassName());
        if (it != FCompFactories.end()) {
            newComp = (*it).second->Create(dynamic_cast<wxwDesigner*>(designer), dynamic_cast<wxwContainer*>(container));
            if (newComp) {
                // special case of dynamic objects, FInstance is a wxDynamicObject.
                newComp->SetInstance(dyno ? dyno : instance);
                newComp->SetName(name);
                designer->NotifyComponentCreated(newComp, container, true);
                if (container) {
                    container->NotifyChildInserted(newComp);
                }
            }
        }
    }
    return newComp;
}

void wxwComponentModel::RegisterDesigner(rcmDesigner::Info *info)
{
    if (info) {
        // replace currently registered designers having the same key.
        list<rcmDesigner::Info*>::iterator it = FDesignerInfos.begin();
        for (; it != FDesignerInfos.end(); ++it) {
            if ((*it)->DesignerKey() == info->DesignerKey()) {
                FDesignerInfos.erase(it);
                break;
            }
        }
        FDesignerInfos.push_front(info);
    }
}

wxwComponentInfo* wxwComponentModel::RegisterClass(const wxClassInfo *classInfo)
{
    rcmComponentInfos::iterator it = FComponentInfos.find(classInfo->GetClassName());
    if (it != FComponentInfos.end()) {
        // remove from registered component infos.
        rcmComponentInfo *oldInfo = (*it).second;
        delete oldInfo;
    }
    wxwComponentInfo *ci = new wxwComponentInfo(classInfo);
    FComponentInfos[classInfo->GetClassName()] = ci;
    return ci;
}

void wxwComponentModel::RegisterComponent(
    const wxClassInfo *classInfo,
    wxwComponentFactory *factory,
    const wxString &pageTitle,
    const wxString &description)
{
    if (!classInfo) return;
    wxwComponentInfo *newInfo = RegisterClass(classInfo);
    if (newInfo) {
        newInfo->SetDescription(description);
        newInfo->SetPalettePage(AddPage(pageTitle));
        // find corresponding component factory (if it exists)
        compFactories::iterator cfit = FCompFactories.find(classInfo->GetClassName());
        if (cfit != FCompFactories.end()) {
            delete (*cfit).second;
            FCompFactories.erase(cfit);
        }
        FCompFactories[classInfo->GetClassName()] = factory;
    }
}


wxwComponentModel::~wxwComponentModel()
{
//    if (imageStream) {
//        delete imageStream;
//        imageStream = 0;
//    }
}


void wxwComponentModel::SpinEventLoop()
{
    // while (wxTheApp->Yield(true)) { }
    // wxTheApp->Dispatch();
}

wxString wxwComponentModel::GetImageData(char *uri, wxMemoryOutputStream *&data)
{
    wxString mimeType = "";
    if (wxFileExists(uri)) {
        wxString ext;
        wxSplitPath(uri, 0, 0, &ext);
        if (ext.CmpNoCase("gif") == 0) {
            mimeType = mtGIF;
        }
        else if (ext.CmpNoCase(".jpeg") == 0 || ext.CmpNoCase(".jpg") == 0) {
            mimeType = mtJPG;
        }
        wxFileInputStream fis(uri);
        data = NewOutputStream();
        fis.Read(*data);
    }
    return mimeType;
}

void wxwComponentModel::GetImageData(char *uri, ImageResponse *ir)
{
    wxString mimeType = "";
    if (wxFileExists(uri)) {
        wxString ext;
        wxSplitPath(uri, 0, 0, &ext);
        if (ext.CmpNoCase("gif") == 0) {
            strncpy(ir->mimeType, mtGIF, min(strlen(mtGIF), sizeof(ir->mimeType)));
        }
        else if (ext.CmpNoCase(".jpeg") == 0 || ext.CmpNoCase(".jpg") == 0) {
            strncpy(ir->mimeType, mtJPG, min(strlen(mtJPG), sizeof(ir->mimeType)));
        }
        else
            return;
        wxFileInputStream fis(uri);
        fis.SeekI(0);
        wxImage i(fis);
        ir->scanWidth = i.GetWidth();
        ir->size = fis.GetSize();
        fis.SeekI(0);
        fis.Read(&ir->data, min(ir->size, MAX_DATASIZE));
    }
}

void wxwComponentModel::RegisterPainter(const wxClassInfo *objectClass, const wxClassInfo *painterClass)
{
    FPainters[objectClass] = painterClass;
}

wxPainter* wxwComponentModel::GetPainter(const wxClassInfo *componentClass)
{
	return CreateBestDynamicClass<wxPainter>(FPainters, componentClass);
}

rcmPalettePage* wxwComponentModel::AddPage(const wxString& title, const wxString &desc, const wxString &iconURI)
{
    if (title.IsEmpty())
        return 0;
    wxwPalettePage *pp = 0;
    rcmPalettePages::iterator it = find_if(FPalettePages.begin(), FPalettePages.end(), bind2nd(page_equal_to(), title));
    if (it == FPalettePages.end()) {
    	pp = new wxwPalettePage(title, desc, iconURI);
        FPalettePages[pp->Key()] = pp;
    }
    else {
        pp = dynamic_cast<wxwPalettePage*>(it->second);
        if (pp->Description() != desc) {
            pp->SetDescription(desc);
        }
        if (pp->IconURI() != iconURI) {
            pp->SetIconURI(iconURI);
        }
    }
    return pp;
}

rcmDesignerManager* wxwComponentModel::CreateDesignerManager()
{
    wxwDesignerManager *dm = new wxwDesignerManager(this);
    FDesignerManagers[dm->Key()] = dm;
    return dm;
}

void wxwComponentModel::CustomDataRequest(char *requestKey, char *data, char *&response)
{
}

Result* wxwComponentModel::DisposeDesignerManager(const wxString &key)
{
    rcmDesignerManager *manager = GetDesignerManager(key);
    if (manager) {
        FDesignerManagers.erase(key);
        delete manager;
        return new Result(true);
    }
    else
        return new Result(false);
}

rcmComponentInfo* wxwComponentModel::GetComponentInfo(const wxString &typeKey)
{
    rcmComponentInfos::iterator it = FComponentInfos.find(typeKey);
    return it != FComponentInfos.end() ? (*it).second : 0;
}

wxwComponentInfo* wxwComponentModel::GetComponentInfo(const wxClassInfo *classInfo)
{
    rcmComponentInfos::iterator it = FComponentInfos.begin();
    while (it != FComponentInfos.end()) {
        if ((*it).second->ClassInfo() == classInfo)
            return dynamic_cast<wxwComponentInfo*>((*it).second);
        it++;
    }
    return 0;
}


rcmDesigner::Info* wxwComponentModel::GetDesignerInfo(DesignerType type)
{
    list<rcmDesigner::Info*>::iterator it = FDesignerInfos.begin();
    for (; it != FDesignerInfos.end(); ++it) {
        if ((*it)->GetType() == type) {
            return *it;
        }
    }
    return 0;
}

rcmDesignerManager* wxwComponentModel::GetDesignerManager(const wxString &key)
{
    rcmDesignerManagers::iterator it = FDesignerManagers.find(key);
    return it != FDesignerManagers.end() ? (*it).second : 0;
}

void wxwComponentModel::RegisterComponentEditor(const wxClassInfo *componentClass, const wxClassInfo *editorClass)
{
    FComponentEditors[componentClass] = editorClass;
}

wxwComponentEditor* wxwComponentModel::GetComponentEditor(const wxClassInfo *componentClass)
{
    return CreateBestDynamicClass<wxwComponentEditor>(FComponentEditors, componentClass);
}

// wxwServer

extern void RegisterComponents();

class RCMEXPORT wxwServer : public rcmServer
{
public:
    wxwServer(int port = 0, bool useSharedMem = true)
        : rcmServer(Model(), port)
    {
        wxImage::AddHandler(new wxGIFHandler);
        RegisterComponents();
    }

    ~wxwServer() {
        if (model) delete model;
    }

    void Finalize() { }
    bool Initialize() { return true; }
};



#define SOAP_USE_SHAREDMEM

#ifndef SOAP_USE_SHAREDMEM
#define SOAP_PORT 5050
#else
#define SOAP_PORT 0
#endif

wxwServer *server = 0;

rcmServer& Server()
{
	if (!server) {
    	server = new wxwServer(SOAP_PORT);
    }
 	return *server;
}

// Global model-access functions defined in wxw.h

void RegisterComponent(
    const wxClassInfo *classInfo,
    wxwComponentFactory *factory,
    const wxString &pageTitle,
    const wxString &description)
{
    Model()->RegisterComponent(classInfo, factory, pageTitle, description);
}

void RegisterComponentEditor(
    const wxClassInfo *componentClass,
    const wxClassInfo *editorClass)
{
    Model()->RegisterComponentEditor(componentClass, editorClass);
}

wxwComponentInfo* RegisterClass(const wxClassInfo *classInfo)
{
    return Model()->RegisterClass(classInfo);
}

void RegisterPainter(
    const wxClassInfo *objectClass,
    const wxClassInfo *painterClass)
{
    Model()->RegisterPainter(objectClass, painterClass);

}

wxwComponentEditor* FindComponentEditor(const wxClassInfo *classInfo)
{
    return Model()->GetComponentEditor(classInfo);
}

wxPainter* FindPainter(const wxClassInfo *classInfo)
{
    return Model()->GetPainter(classInfo);
}

wxwComponent* CreateComponent(
    wxwDesigner *designer,
    wxObject *parent,
    wxObject *object,
    const wxString &name)
{
    if (!designer) return 0;
    wxwContainer *container = 0;
    if (parent) {
        container = dynamic_cast<wxwContainer*>(designer->wxManager()->FindComponentByInstance(parent));
        wxASSERT_MSG(container, "Unknown parent component");
    }
    return Model()->CreateComponentFromInstance(designer, container, object, name);
}

wxwComponentInfo* FindComponentInfo(const wxClassInfo* classInfo)
{
    return Model()->GetComponentInfo(classInfo);
}


