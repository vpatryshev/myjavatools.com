#ifndef wxwcomponenteditorH
#define wxwcomponenteditorH

#include "wxw.h"
#include "wxwcomponent.h"

class RCMEXPORT wxwComponentEditor : public wxObject, public rcmComponentEditor
{
DECLARE_DYNAMIC_CLASS(wxwComponentEditor)
public:
	wxwComponentEditor();

    virtual void Edit() { }
    virtual void UpdateMenu(MenuItems &menu, int x, int y) { }
    virtual void Init(wxwComponent *component, wxwDesigner *designer);

    wxwComponent* Component() { return FComponent; }
    wxwDesigner* Designer() { return FDesigner; }
private:
    wxwComponent *FComponent;
    wxwDesigner *FDesigner;
};

template <typename T>
class RCMEXPORT wxwComponentEditorT : public wxwComponentEditor
{
public:
	wxwComponentEditorT() : wxwComponentEditor() { }
    T* Instance()
    {
        return dynamic_cast<T*>(Component()->Instance());
    }
};

class wxFrameEditor : public wxwComponentEditorT<wxFrame>
{
DECLARE_DYNAMIC_CLASS(wxFrameEditor)
public:
	wxFrameEditor() : wxwComponentEditorT<wxFrame>() { }
    // rcmComponentEditor
    virtual void Edit() { }
    // rcmMenuServer
    virtual void UpdateMenu(MenuItems &menu, int x, int y);
    virtual void MenuItemClicked(MenuItem *item, Result *&result);
};

#endif
