#include <eikenv.h>
#include <avkon.hrh>
#include <eikbtgpc.h>
#include <Sound.rsg>

#include "sound.pan"
#include "Sound.hrh"
#include "SoundAppUi.h"
#include "SoundView.h"



CSoundAppUi::CSoundAppUi()
    {
    }

void CSoundAppUi::ConstructL()
    {
    BaseConstructL();

    iAppView = CSoundView::NewL(ClientRect());

    AddToStackL(iAppView);
    }


CSoundAppUi::~CSoundAppUi()
    {
    RemoveFromStack(iAppView);
    delete iAppView;
    iAppView = NULL;
    }


void CSoundAppUi::HandleCommandL(TInt aCommand)
    {

    // Handle menu commands
    switch (aCommand)
        {
    case EAknSoftkeyExit:
        Exit();
        break;
    case ESoundCmdPlayPlayDotWav:
        iAppView->PlayPlayL();
        break;
    case ESoundCmdPlayChimesDotWav:
        iAppView->PlayChimesL();
        break;
    case ESoundCmdStop:
        iAppView->StopL();
        break;
    default:
        __ASSERT_ALWAYS(EFalse, User::Panic(KSound, KSoundPanicUnexpectedCommand));
        break;
        }
    }

