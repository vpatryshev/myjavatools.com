#ifndef __IRSERVER_DOCUMENT_H__
#define __IRSERVER_DOCUMENT_H__

#include <akndoc.h>

// Forward references
class IRServerAppUi;
class CEikApplication;

// CIRServerDocument
class CIRServerDocument : public CAknDocument
{
public:
  /**
   * Constructs CIRServerDocument for the AVKON application aApp
   * using two phase construction, and return a pointer to the created
   * object
   * @param aApp application creating this document
   * @result a pointer to the created instance of CIRServerDocument
   */
  static CIRServerDocument* NewL(CEikApplication& aApp);

  /**
   * Constructs CIRServerDocument for the AVKON application aApp
   * using two phase construction, and return a pointer to the created
   * object
   * @param aApp application creating this document
   * @result a pointer to the created instance of CIRServerDocument
   */
  static CIRServerDocument* NewLC(CEikApplication& aApp);

  /**
   * Destroys this document object and releases all memory
   */
  ~CIRServerDocument();

  /**
   * Creates a CIRServerAppUi object and return a pointer to it
   * @result a pointer to the created instance of the AppUi created
   */
  CEikAppUi* CreateAppUiL();

private:
  /**
   * Performs second phase construction for this CIRServerDocument object
   */
  void ConstructL();

  /**
   * Private constructor
   */
  CIRServerDocument(CEikApplication& aApp);
};

#endif // __IRSERVER_DOCUMENT_H__
