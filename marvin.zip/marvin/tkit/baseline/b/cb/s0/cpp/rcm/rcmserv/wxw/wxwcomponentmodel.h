#ifndef wxwcomponentmodelH
#define wxwcomponentmodelH

#include "wxw.h"
#include <wx/dynlib.h>

class wxwDesignerManager;
class wxwComponentEditor;
class wxwComponentFactory;

class wxwPalettePage : public rcmPalettePage
{
public:
    wxwPalettePage(const wxString &title, const wxString &description = "", const wxString &iconURI = "");
    ~wxwPalettePage() { }

    void SetDescription(const wxString &value) { FDesc = value; }
    void SetIconURI(const wxString &value) { FIconURI = value; }

    virtual wxString Title() { return FTitle; }
    virtual wxString Description() { return FDesc; }
    virtual wxString IconURI() { return FIconURI; }
    virtual wxString Key() { return FKey; }

private:
    wxString FTitle;
    wxString FDesc;
    wxString FIconURI;
    wxString FKey;
};

typedef hash_map<string_type, wxwComponentFactory*, hash<string_type&> > compFactories;

class RCMEXPORT wxwComponentModel : public rcmComponentModel
{
public:
	wxwComponentModel();
    ~wxwComponentModel();

    rcmPalettePage* AddPage(const wxString& title, const wxString &desc = "", const wxString &iconURI = "");
    wxwComponent* CreateComponentFromInstance(
        wxwDesigner *designer,
        wxwContainer *container,
        wxObject *instance,
        const wxString &name);

    wxwComponentEditor* GetComponentEditor(const wxClassInfo *componentClass);
  	wxwComponentInfo* GetComponentInfo(const wxClassInfo *classInfo);
    wxPainter* GetPainter(const wxClassInfo *objectClass);
    void RegisterComponent(
        const wxClassInfo *classInfo,
        wxwComponentFactory *factory,
        const wxString &pageTitle = wxT(""),
        const wxString &description = wxT(""));
    void RegisterComponentEditor(const wxClassInfo *componentClass, const wxClassInfo *editorClass);
    wxwComponentInfo* RegisterClass(const wxClassInfo *classInfo);
    void RegisterDesigner(rcmDesigner::Info *info);
    void RegisterPainter(const wxClassInfo *objectClass, const wxClassInfo *painterClass);
    void SetImageURI(const wxString &uri) { FImageURI = uri; }
//	virtual void LoadModules();
//    virtual void UnloadModules();

	// rcmComponentModel methods
   	virtual rcmComponentInfos& ComponentInfos() { return FComponentInfos; }
    virtual CreateResult* CreateComponent(
        rcmComponentInfo *compInfo,
        rcmDesigner *designer,
        rcmContainer *container,
        input_stream_type *stream = 0);
    virtual rcmDesignerManager* CreateDesignerManager();
    virtual void CustomDataRequest(char *requestKey, char *data, char *&response);
	virtual rcmDesignerManagers& DesignerManagers() { return FDesignerManagers; }
    virtual Result* DisposeDesignerManager(const wxString &key);
  	virtual rcmComponentInfo* GetComponentInfo(const wxString &typeKey);
    virtual rcmDesigner::Info* GetDesignerInfo(DesignerType type);
    virtual rcmDesignerManager* GetDesignerManager(const wxString &key);
    virtual wxString GetImageData(char *uri, wxMemoryOutputStream *&stream);
	virtual void GetImageData(char *uri, ImageResponse *ir);
  	virtual wxString Key() { return FKey; }
    virtual rcmPalettePages& PalettePages() { return FPalettePages; }
    virtual void SpinEventLoop();
  	virtual wxString Description() { return FDesc; }
    virtual wxString DisplayName() { return FDisplayName; }
  	virtual wxString ImageURI() { return FImageURI; }

protected:
//    bool LoadModule(const wxString &filename);
private:
    wxString FDesc;
    wxString FKey;
    wxString FDisplayName;
    wxString FImageURI;
    dlist<wxDllType> FModules;
    ClassInfos FPainters;
    ClassInfos FComponentEditors;
    list<rcmDesigner::Info*> FDesignerInfos;
    rcmComponentInfos FComponentInfos;
    rcmPalettePages FPalettePages;
    rcmDesignerManagers FDesignerManagers;
    compFactories FCompFactories;
};

#endif
