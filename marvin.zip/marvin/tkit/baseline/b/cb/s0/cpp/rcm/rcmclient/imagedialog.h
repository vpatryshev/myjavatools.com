//----------------------------------------------------------------------------
#ifndef imagedialogH
#define imagedialogH
//----------------------------------------------------------------------------
#include <vcl\ExtCtrls.hpp>
#include <vcl\Buttons.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Controls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\Graphics.hpp>
#include <vcl\Classes.hpp>
#include <vcl\SysUtils.hpp>
#include <vcl\Windows.hpp>
#include <vcl\System.hpp>

#include "soapWSComponentModelServerService.nsmap"
#include "soapstub.h"
//----------------------------------------------------------------------------
class TImageDlg : public TForm
{
__published:
	TButton *OKBtn;
	TPanel *Panel1;
	TImage *Image1;
private:
public:
	virtual __fastcall TImageDlg(TComponent* AOwner);
};

//----------------------------------------------------------------------------
extern PACKAGE TImageDlg *ImageDlg;
//----------------------------------------------------------------------------
#endif    
