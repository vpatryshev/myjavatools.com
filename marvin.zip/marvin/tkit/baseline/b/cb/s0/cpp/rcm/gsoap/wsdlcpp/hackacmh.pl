if (!(-e 'acm.h')) {
	die "File acm.h not found";
}
open (ACMH, 'acm.h');
open (OUTFILE, '>acm.h.hacked');
$movedWSLiveDesigners = 0;
@wsLiveDesignerSubClasses = ();
$wsldCount = 0;
$movedWSLiveUIComponents = 0;
@wsLiveUIComponentSubClasses = ();
$wsluicCount = 0;
$convertBinaryToDimeFormat = 1;

while () {
	$line = <ACMH>;
    # set xsdBase64BinaryAsDime to append the normal xsd__Base64Binary definition in acm.h 
    # with additional fields instructing gsoap to send all xsd:base64Binary fields back to
    # the client as DIME attachments. 
	if (($convertBinaryToDimeFormat == 0) && ($line =~ m/^(class xsd__base64Binary {)$/)) {
		while (!($line =~ m/^};/)) {
			print OUTFILE $line;
			$line = <ACMH>;
		}
		print OUTFILE "char *id;\n";
		print OUTFILE "char *type;\n";
		print OUTFILE "char *options;\n";
		print OUTFILE $line;
		$convertBinaryToDimeFormat = 1;
		next;
	}
	
#	look for declarations of classes descending from impl__WSLiveDesigner which is declared later in the header
	if (($movedWSLiveDesigners == 0) && ($line =~ m/: public impl__WSLiveDesigner\s{/)) {
		while (!($line =~ m/};/)) {
			$wsLiveDesignerSubClasses[$wsldCount] = $line;
			$wsldCount++;
			$line = <ACMH>;		
		}
		$wsLiveDesignerSubClasses[$wsldCount] = $line;
		$wsldCount++;
		next;
	}
	
	# check for declaration of impl__WSLiveDesigner and write previously found subclasses after it.
	if ($line =~ m/class impl__WSLiveDesigner :/) {
		while (!($line =~ m/};/)) {
			print OUTFILE $line;
			$line = <ACMH>;
		}		
		print OUTFILE $line;
		print OUTFILE "\n";
		print OUTFILE @wsLiveDesignerSubClasses;
		$movedWSLiveDesigners = 1;
		next;
	}
	
	$inWSLiveUIContainer = 0;
	
#	look for declarations of classes descending from impl__WSLiveUIComponent which is declared later in the header
	if (($movedWSLiveUIComponents == 0) && ($line =~ m/: public impl__WSLiveUIComponent\s{/)) {
		while (!($line =~ m/};/)) {
			# bug in either gsoap where it can't handle forward references in the WSDL, causes
			# impl__WSLiveUIContainer to hide definition of WSLiveUIComponent's __size_ field.
			if (($inWSLiveUIContainer == 0) && ($line =~ m/class impl__WSLiveUIContainer :/)) {
				$inWSLiveUIContainer = 1;
			}
			if (($inWSLiveUIContainer == 1) && ($line =~ m/(^\s+int\s+)__size_;/)) {
				$line = $1 . "__size__;\n"
			}
			if (($inWSLiveUIContainer == 1) && ($line =~ m/(^\s+)class impl__WSLiveUIComponent(.*$)/)) {
				$line = $1 . "impl__WSLiveUIComponent" . $2 . "\n";
			}
			
			$WSLiveUIComponentSubClasses[$wsluicCount] = $line;
			$wsluicCount++;
			$line = <ACMH>;		
		}
		$WSLiveUIComponentSubClasses[$wsluicCount] = $line;
		$wsluicCount++;
		$inWSLiveUIContainer = 0;
		next;
	}
	
	# check for declaration of impl__WSLiveUIComponent and write previously found subclasses after it.
	if ($line =~ m/class impl__WSLiveUIComponent :/) {
		while (!($line =~ m/};/)) {
			print OUTFILE $line;
			$line = <ACMH>;
		}		
		print OUTFILE $line;
		print OUTFILE "\n";
		print OUTFILE @WSLiveUIComponentSubClasses;
		$movedWSLiveUIComponents = 1;
		next;
	}
	
	print OUTFILE $line;
	if (eof(ACMH)) { last; }
}
close(ACMH);
close(OUTFILE);