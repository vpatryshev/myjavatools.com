////////////////////////////////////////////////////////////////////////////////
// Implementation of CtcptestView
////////////////////////////////////////////////////////////////////////////////


#include <e32std.h>
#include <aknviewappui.h>
#include <aknconsts.h>
#include "tcptestview.h"
#include "tcptestcontainer.h"
#include <tcptest.rsg>

const TUid EDefaultViewId =
{
    1
};

CtcptestView* CtcptestView::NewL()
{
    CtcptestView* self = CtcptestView::NewLC();
    CleanupStack::Pop(self);
    return self;
}

CtcptestView* CtcptestView::NewLC()
{
    CtcptestView* self = new (ELeave) CtcptestView();
    CleanupStack::PushL(self);
    self->ConstructL();
    return self;
}

CtcptestView::CtcptestView()
{
}

CtcptestView::~CtcptestView()
{
}

void CtcptestView::ConstructL()
{
    BaseConstructL(R_DEFAULT_VIEW);
}

TUid CtcptestView::Id() const
{
    return EDefaultViewId;
}

void CtcptestView::DoActivateL(const TVwsViewId& aPrevViewId, TUid aCustomMessageId, const TDesC8& aCustomMessage)
{
    ASSERT(container == NULL);
    container = CtcptestContainer::NewL(ClientRect());
    container->SetMopParent(this);
    AppUi()->AddToStackL(*this, container);
}

void CtcptestView::DoDeactivate()
{
    if (container)
    {
        AppUi()->RemoveFromStack(container);
        delete container;
        container = NULL;
    }
}

void CtcptestView::HandleCommandL(TInt aCommand)
{
    AppUi()->HandleCommandL(aCommand);
    container->HandleCommandL(aCommand);
}

