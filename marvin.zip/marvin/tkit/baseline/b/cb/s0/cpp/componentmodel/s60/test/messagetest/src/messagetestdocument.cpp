////////////////////////////////////////////////////////////////////////////////
// Implementation of CmessagetestDocument
////////////////////////////////////////////////////////////////////////////////

#include "messagetestappui.h"
#include "messagetestdocument.h"


CmessagetestDocument::CmessagetestDocument(CEikApplication& aApp)
                       :CAknDocument(aApp)
{
}

CmessagetestDocument::~CmessagetestDocument()
{
}

CmessagetestDocument* CmessagetestDocument::NewL(CEikApplication& aApp)
{
  CmessagetestDocument* self = NewLC(aApp);
  CleanupStack::Pop(self);
  return self;
}

CmessagetestDocument* CmessagetestDocument::NewLC(CEikApplication& aApp)
{
  CmessagetestDocument* self = new (ELeave) CmessagetestDocument(aApp);
  CleanupStack::PushL(self);
  self->ConstructL();
  return self;
}

void CmessagetestDocument::ConstructL()
{
}

CEikAppUi* CmessagetestDocument::CreateAppUiL()
{
  return new(ELeave) CmessagetestAppUi;
}

