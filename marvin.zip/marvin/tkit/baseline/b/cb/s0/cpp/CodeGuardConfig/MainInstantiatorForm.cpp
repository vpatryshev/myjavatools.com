//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "MainInstantiatorForm.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "CodeGuardConfiguration_OCX"
#pragma resource "*.dfm"
TfrmInstantiator *frmInstantiator;
//---------------------------------------------------------------------------
__fastcall TfrmInstantiator::TfrmInstantiator(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TfrmInstantiator::cmdCancelClick(TObject *Sender)
{
  Close();    
}
//---------------------------------------------------------------------------
void __fastcall TfrmInstantiator::cmdOKClick(TObject *Sender)
{
  CodeGuardConfigDialog->Persist();
  Close();    
}
//---------------------------------------------------------------------------
