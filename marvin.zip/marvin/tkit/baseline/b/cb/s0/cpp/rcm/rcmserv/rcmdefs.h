#include <list.h>
#include <hash_map>
#include <typeinfo>
#include <stdexcept>
#include <soaph.h>
#include <soapstub.h>

template <typename T>
class dlist : public list<T>
{
public:
	~dlist()
    {
    	for(list<T>::iterator it = begin(); it != end(); ++it)
        	if (*it) delete *it;
    }
};

template <typename KEY, typename VALUE>
class dhash_map : public hash_map<KEY, VALUE, hash<KEY&> >
{
public:
	~dhash_map()
    {
    	for (hash_map<KEY, VALUE, hash<KEY&> >::iterator it = begin(); it != end(); ++it)
        	if ((*it).second) delete (*it).second;
    }
};

#ifdef __WXWIN__

#define wxUSE_EXTENDED_RTTI 1

#include "wx/wx.h"
#include "wx/mstream.h"

#define RCMEXPORT WXDLLEXPORT

#define CSTR(x) x.c_str()
#define STRLEN(x) x.Len()

typedef wxClassInfo classinfo_type;
typedef wxObject instance_type;
typedef wxString string_type;
typedef wxMemoryInputStream input_stream_type;
typedef wxMemoryOutputStream output_stream_type;
typedef exception exception_type;
typedef wxArrayString string_array;

wxMemoryInputStream* NewInputStream(xsd__base64Binary *data)
{
	if (data && data->__ptr && data->__size) {
		wxMemoryInputStream *stream = new wxMemoryInputStream(data->__ptr, data->__size);
		stream->SeekI(0);
		return stream;
	}
	return 0;
}

wxMemoryOutputStream* NewOutputStream()
{
    return new wxMemoryOutputStream();
}

template <typename T>
char* soap_strcpy(soap *soap, char *&dest, const T &str)
{
	if (str.Length() > 0)
    {
		char *s = (char*)soap_malloc(soap, str.Length()+1);
    	dest = strcpy(s, CSTR(str));
    }
    else
    	dest = NULL;
    return dest;
}


#endif



