#ifdef __BORLANDC__
#include "rcmpch.h"
#endif

#include "wxwcomponent.h"
#include "wxwcomponenteditor.h"
#include "wxwcomponentinfo.h"
#include "wxwcomponentmodel.h"
#include "wxwdesigner.h"
#include "wxwcontainer.h"

bool IsValidIdent(const char *ident)
{
    if (!ident || __iscsymf(*ident)) {
        do {
            if (*ident == 0) return true;
        }
        while ((isalnum(*ident) || *ident == '_') && ident++);
    }
    return false;
}

wxwComponent::wxwComponent(const wxClassInfo *classInfo, wxwDesigner *designer, wxwContainer *container)
	: FDesigner(designer), FComponentInfo(0), FInstance(0), FContainer(container), FStates(0)
{
    FComponentInfo = FindComponentInfo(classInfo);
	FName = wxT("Unnamed");
    KeyGen(this, FKey);
    if (FDesigner->HasState(DS_READING))
        SetState(CS_READING);
}

void wxwComponent::Init()
{
    InternalSetName(FDesigner->NewComponentName(NameSeed()));
    InternalSetParent(FContainer);
    if (FDesigner) {
    	FDesigner->NotifyComponentCreated(this, FContainer, false);
    }
}

wxString wxwComponent::NameSeed()
{
	wxString baseName(FComponentInfo->ClassInfo()->GetClassName());
    if (baseName.Length() > 2 && baseName.find_first_of("wx") == 0) {
    	baseName = baseName.erase(0, 2);
    }
    return baseName;
}


wxwComponent::~wxwComponent()
{
    if (FContainer) {
        (dynamic_cast<wxwContainer*>(FContainer))->NotifyChildRemoved(this);
    }
    FDesigner->NotifyComponentDeleted(this, false);
	if (FInstance) {
    	delete FInstance;
	}
}

void wxwComponent::NewInstance()
{
    wxASSERT_MSG(FInstance == 0, "wxwComponent already has an instance");
    wxASSERT_MSG(FComponentInfo != 0, "wxwComponent has no ClassInfo");
    // First-phase construction from the wxClassInfo. An uninitialized instance.
    wxObject *newObject = FComponentInfo->ClassInfo()->CreateObject();
    wxASSERT_MSG(newObject != 0, wxString::Format("Failed to create instance of %s. \
        Has it been declared with DECLARE_DYNAMIC_CLASS()?",
        FComponentInfo->ClassInfo()->GetClassName()));
    // Type-specific second-phase construction.
    ConstructXTIObject(newObject);
    SetInstance(newObject);
    SetState(CS_INITIALIZED);
    ObjectCreated();
}

wxObject* wxwComponent::Instance()
{
    if (!FInstance) {
        NewInstance();
    }
    return FInstance;
}

rcmComponentInfo* wxwComponent::ComponentInfo()
{
	return FComponentInfo;
}

rcmDesigner* wxwComponent::Designer()
{
	return FDesigner;
}

rcmComponentEditor* wxwComponent::Editor()
{
    wxwComponentEditor *editor = FindComponentEditor(FComponentInfo->ClassInfo());
    if (editor) {
        editor->Init(this, dynamic_cast<wxwDesigner*>(FDesigner));
    }
    return editor;
}

bool wxwComponent::IsType(rcmComponentInfo *type) const
{
    if (!type)
        return false;
    return FComponentInfo->ClassInfo()->IsKindOf(type->ClassInfo());
}

rcmContainer* wxwComponent::Container()
{
    return FContainer;
}

void wxwComponent::GetEvents(rcmEvents &events)
{
    FComponentInfo->GetEvents(events, this);
}

void wxwComponent::GetMethods(rcmMethods &methods)
{
    FComponentInfo->GetMethods(methods, this);
}

void wxwComponent::GetProperties(rcmProperties &props)
{
    FComponentInfo->GetProperties(props, this);
    if (FContainer) {
        FContainer->GetExtraProperties(this, props);
    }
}

rcmProperty* wxwComponent::GetProperty(wxArrayString &propPath)
{
    rcmProperty *p = FComponentInfo->GetProperty(propPath, this);
    if (!p && FContainer) {
        p = FContainer->GetExtraProperty(this, propPath);
    }
    return p;
}

wxString wxwComponent::GetValue(wxArrayString &propPath)
{
    rcmProperty *prop = GetProperty(propPath);
    return GetValue(prop);
}

wxString wxwComponent::GetValue(const rcmProperty *prop)
{
    return prop->GetValue();
}

void wxwComponent::PropertyChanged(const wxPropertyBase *property)
{
    bool compChange = false;
    bool recreate = false;
    while (property) {
        compChange = compChange || property->Flags() & PE_NOTIFYCOMPCHANGE;
        recreate = recreate || property->Flags() & PE_RECREATECOMP;
        property = dynamic_cast<wxPropertyBase*>(property->Parent());
    }
    if (recreate)
        Recreate();
    if (compChange)
        FDesigner->NotifyComponentChanged(this, true);
}

Result* wxwComponent::SetValue(wxArrayString &propPath, const wxString &value)
{
    try {
       	rcmProperty *prop = GetProperty(propPath);
        if (!prop) {
            return ErrorMessage(wxString::Format("Unknown property path: %s",
                StringArrayToString(propPath).c_str()));
        }
        bool set = prop->SetValue(value);
        if (set) {
            PropertyChanged(dynamic_cast<wxPropertyBase*>(prop));
        }
        return new Result(set);
    }
    catch (exception &e) {
        return ErrorMessage(e.what());
    }
}

bool wxwComponent::IsContainer()
{
	return dynamic_cast<wxwContainer*>(this);
}

void wxwComponent::Recreate()
{
    // TODO: move non-wxWindow code in wxwUIComponent::Recreate here.
}

void wxwComponent::SetInstance(wxObject *instance)
{
    if (FInstance)
        delete FInstance;
    if (!instance) {
        ClearState(CS_INITIALIZED);
    }
//    wxASSERT_MSG(instance != 0, "Cannot set proxy instance to NULL");
//    wxASSERT_MSG(FInstance == 0, "Attempting to reset proxy instance");
    FInstance = instance;
}

void wxwComponent::Reparent(wxwContainer *newContainer)
{
    // do nothing for basic components.
}

void wxwComponent::InternalSetParent(wxwContainer *newContainer)
{
    if (newContainer != FContainer && FContainer) {
        FContainer->NotifyChildRemoved(this);
    }
    if (!newContainer)
        throw error(wxString::Format("Component \"%s\" must have a parent", FName));
    if (!newContainer->CanParent(Instance())) {
        throw error(wxString::Format("Invalid parent for \"%s\"", FName));
    }
    Reparent(newContainer);
    FContainer = newContainer;
    if (FContainer) {
        FContainer->NotifyChildInserted(this);
    }
}

Result* wxwComponent::SetParent(rcmContainer *newContainer)
{
    try {
        InternalSetParent(dynamic_cast<wxwContainer*>(newContainer));
        return new Result(true);
    }
    catch (const exception &e) {
        return ErrorMessage(e.what());
    }
}

void wxwComponent::InternalSetName(const wxString &newName)
{
    if (!IsValidIdent(newName.c_str())) {
        throw error(wxString::Format("Invalid component name: %s", newName));
    }
    bool nameOk = FDesigner->Manager()->ValidateRename(newName);
    if (nameOk) {
        wxString oldName = GetName();
        FName = newName;
        FDesigner->NotifyComponentRenamed(this, oldName);
    }
    else
        throw error("Error naming component");
}

Result* wxwComponent::SetName(const wxString &newName)
{
    try {
        InternalSetName(newName);
        return new Result(true);
    }
    catch (const exception &e) {
        return new Result(0, new ResultMessage("Error", e.what()));
    }
}

wxwDesigner* wxwComponent::wxDesigner()
{
    return FDesigner;
}

wxwContainer* wxwComponent::wxContainer()
{
    return FContainer;
}

bool wxwComponent::IsType(const wxClassInfo *classInfo) const
{
    return ClassInfo()->IsKindOf(classInfo);
}

const wxClassInfo* wxwComponent::ClassInfo() const
{
    return FComponentInfo->ClassInfo();
}



