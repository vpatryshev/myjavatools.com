////////////////////////////////////////////////////////////////////////////////
// Implementation of CtimercomponentView
////////////////////////////////////////////////////////////////////////////////


#include <e32std.h>
#include <aknviewappui.h>
#include <aknconsts.h>
#include "timercomponentview.h"
#include "timercomponentcontainer.h"
#include <timercomponent.rsg>

const TUid EDefaultViewId = { 1 };

CtimercomponentView* CtimercomponentView::NewL()
{
  CtimercomponentView* self = CtimercomponentView::NewLC();
  CleanupStack::Pop(self);
  return self;
}

CtimercomponentView* CtimercomponentView::NewLC()
{
  CtimercomponentView* self = new (ELeave) CtimercomponentView();
  CleanupStack::PushL(self);
  self->ConstructL();
  return self;
}

CtimercomponentView::CtimercomponentView()
{
}

CtimercomponentView::~CtimercomponentView()
{
}

void CtimercomponentView::ConstructL()
{
  BaseConstructL(R_DEFAULT_VIEW);
}

TUid CtimercomponentView::Id() const
{
  return EDefaultViewId;
}

void CtimercomponentView::DoActivateL(const TVwsViewId& aPrevViewId,
                                   TUid aCustomMessageId,
                                   const TDesC8& aCustomMessage)
{
  ASSERT(container == NULL);
  container = CtimercomponentContainer::NewL(ClientRect());
  container->SetMopParent(this);
  AppUi()->AddToStackL(*this, container); 
}

void CtimercomponentView::DoDeactivate()
{
  if (container)
  {
    AppUi()->RemoveFromStack(container);
    delete container;
    container = NULL;
  }
}

void CtimercomponentView::HandleCommandL(TInt aCommand)
{
  AppUi()->HandleCommandL(aCommand);
}

