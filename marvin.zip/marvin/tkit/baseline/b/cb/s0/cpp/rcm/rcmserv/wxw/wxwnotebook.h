#ifndef wxwnotebookH
#define wxwnotebookH

#include "wxw.h"
#include "wxwuicontainer.h"
#include "wxwcomponenteditor.h"
#include "wx/notebook.h"

// wxNotebook construction

template <>
void ConstructWXObject(wxObject *parent, wxNotebook *o, const wxString &name)
{
    wxxVariant params[5];
    params[0] = wxxVariant(dynamic_cast<wxWindow*>(parent));
    params[1] = wxxVariant((wxWindowID)GetUniqueID());
    params[2] = wxxVariant(wxDefaultPosition);
    params[3] = wxxVariant(wxSize(200, 150));
    params[4] = wxxVariant((long)0);
    o->GetClassInfo()->Create(o, 5, params);
    o->Show();
}

// wxPanel construction

template <>
void ConstructWXObject(wxObject *parent, wxPanel *o, const wxString &name)
{
    wxxVariant params[5];
    params[0] = wxxVariant(dynamic_cast<wxWindow*>(parent));
    params[1] = wxxVariant((wxWindowID)GetUniqueID());
    params[2] = wxxVariant(wxDefaultPosition);
    params[3] = wxxVariant(wxSize(200, 130));
    params[4] = wxxVariant((long)wxTAB_TRAVERSAL);
    o->GetClassInfo()->Create(o, 5, params);
    o->Show();
}

class RCMEXPORT wxNotebookProxy : public wxWindowContainerT<wxNotebook>
{
public:
	wxNotebookProxy(wxwDesigner *designer, wxwContainer *container);

    virtual void NotifyChildInserted(wxwComponent *newChild);
    virtual void NotifyChildRemoved(wxwComponent *child);
    virtual bool NotifyChildBoundsChanging(int &x, int &y, int &w, int &h, wxwUIComponent *child);
    wxNotebook* Notebook();
    virtual void SetPageIndex(int index);
    virtual void UpdateRects();
    virtual void ObjectCreated(bool fromXRC = false);
protected:
    virtual void PaintChild(wxwUIComponent *child, wxDC &dc, int x, int y);
    virtual void ConstructXTIObject(wxObject *object)
    {
        wxWindowContainerT<wxNotebook>::ConstructXTIObject(object);
    }

};

class wxTabDesignRect : public DesignRect
{
public:
    wxTabDesignRect(wxNotebookProxy *notebook, int index);

    virtual void GetRect(int &left, int &top, int &width, int &height);
    virtual wxString Key();
    virtual void UpdateMenu(MenuItems &menu, int x, int y) { }
protected:
    virtual Result* DoClick(int x, int y);
private:
    wxNotebookProxy *FNotebook;
    int FIndex;
};

// wxNotebookEditor

class wxNotebookEditor : public wxwComponentEditorT<wxNotebook>
{
DECLARE_DYNAMIC_CLASS(wxNotebookEditor)
public:
	wxNotebookEditor() : wxwComponentEditorT<wxNotebook>() { }
    // rcmComponentEditor
    virtual void Edit() { }
    // MenuItemProvider
    virtual void UpdateMenu(MenuItems &menu, int x, int y);
protected:
    wxNotebookProxy* Proxy() { return dynamic_cast<wxNotebookProxy*>(Component()); }
};

#endif
