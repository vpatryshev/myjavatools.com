#include "app.h"

EXPORT_C CApaApplication* NewApplication()
{
    return new CApplication();
}

// dll entry point
GLDEF_C TInt E32Dll(TDllReason)
{
    return KErrNone;
}


