#ifdef __BORLANDC__
#include "rcmpch.h"
#endif

#include "wxwproped.h"
#include "wxwdesigner.h"
#include "wxwcomponent.h"
#include "wxwuicontainer.h"
#include "wx/fontenum.h"

// wxColourElementProperty

wxColourElementProperty::wxColourElementProperty(wxColourElementType type) : xtiProperty()
{
    FFlags |= PE_NESTED | PE_NOTIFYCOMPCHANGE | PE_NOTIFYONCHANGE;
    FType = type;
}

void wxColourElementProperty::Set(const wxString &value)
{
    unsigned long uCharVal;
    if (!value.ToULong(&uCharVal, 16) || uCharVal > 255) {
        throw error(wxString().Format("\"%s\" is not a valid value", value));
    }

    wxxVariant v;
    FPropInfo->GetAccessor()->GetProperty(Instance(), v);
    wxColour c = v.Get<wxColour>();
    switch (FType) {
        case wxCET_Red:
            c.Set(uCharVal, c.Green(), c.Blue());
            break;
        case wxCET_Blue:
            c.Set(c.Red(), c.Green(), uCharVal);
            break;
        case wxCET_Green:
            c.Set(c.Red(), uCharVal, c.Blue());
            break;
    }
    FPropInfo->GetAccessor()->SetProperty(Instance(), wxxVariant(c));
}

wxString wxColourElementProperty::Get() const
{
    wxxVariant v;
    FPropInfo->GetAccessor()->GetProperty(Instance(), v);
    wxColour c = v.Get<wxColour>();
    switch (FType) {
        case wxCET_Red:
            return wxString::Format("%X", c.Red());
        case wxCET_Blue:
            return wxString::Format("%X", c.Blue());
        case wxCET_Green:
            return wxString::Format("%X", c.Green());
    }
    return "???";
}

// wxColourProperty

void StringToColor(const wxString &s , wxColour &data )
{
    wxString stdColorName(s);
    stdColorName.UpperCase();
    wxColour c = wxTheColourDatabase->Find(stdColorName);
    if (c.Ok()) {
        data = c;
    }
    else {
        unsigned long tmp = 0;
        if (s.Length() != 7 || s[0u] != wxT('#') ||
            wxSscanf(s.c_str(), wxT("#%lX"), &tmp) != 1)
        {
            throw error(wxString().Format("Incorrect color specification : %s", s));
        }
	    else {
	    	data = wxColour((unsigned char) ((tmp & 0xFF0000) >> 16) ,
                (unsigned char) ((tmp & 0x00FF00) >> 8),
                (unsigned char) ((tmp & 0x0000FF)));
    	}
    }
}

void ColorToString(wxString &s , const wxColour &data )
{
    s = wxTheColourDatabase->FindName(data);
    if (!s)
	    s = wxString::Format("#%2X%2X%2X", data.Red(), data.Green(), data.Blue()) ;
}

IMPLEMENT_DYNAMIC_CLASS(wxColourProperty, xtiProperty)

wxColourProperty::wxColourProperty() : xtiProperty()
{
    FFlags |= PE_STATICVALUELIST | PE_SUBPROPS;
    // "override" wxObjectRefProperty flags.
    FFlags &= ~(PE_READONLY | PE_NOEDIT);
}

void wxColourProperty::Create(
    const wxPropertyInfo *propInfo,
    wxwDesigner *designer,
    wxObject *instance,
    wxPropertyBase *parent,
    const wxString &name)
{
    xtiProperty::Create(propInfo, designer, instance, parent, name);
    wxColourElementProperty *el = new wxColourElementProperty(wxCET_Red);
    el->Create(propInfo, designer, instance, this, "Red");
    FChildren["Red"] = el;
    el = new wxColourElementProperty(wxCET_Green);
    el->Create(propInfo, designer, instance, this, "Green");
    FChildren["Green"] = el;
    el = new wxColourElementProperty(wxCET_Blue);
    el->Create(propInfo, designer, instance, this, "Blue");
    FChildren["Blue"] = el;
}

void wxColourProperty::GetChoices(PropertyChoices &choices)
{
    for (int i=0; i<WXSIZEOF(SysColors); i++) {
        choices.push_back(new PropertyChoice(SysColors[i].name));
    }
    for (int i=0; i<WXSIZEOF(StdColors); i++) {
        choices.push_back(new PropertyChoice(StdColors[i].name));
    }
}

wxString wxColourProperty::Get() const
{
    wxASSERT_MSG(Instance(), "Instance cannot be NULL");
    wxString sValue("???");
    wxxVariant vValue;
    FPropInfo->GetAccessor()->GetProperty(Instance(), vValue);
    wxColour colour = vValue.Get<wxColour>();
    ColorToString(sValue, colour);
    return sValue;
}

void wxColourProperty::Set(const wxString &value)
{
    wxASSERT_MSG(Instance(), "Instance cannot be NULL");
    wxColour color;
    StringToColor(value, color);
    wxxVariant vValue(color);
    FPropInfo->GetAccessor()->SetProperty(Instance(), vValue);
}

// wxWindowPosProperty

IMPLEMENT_DYNAMIC_CLASS(wxWindowPosProperty, xtiProperty)

wxWindowPosProperty::wxWindowPosProperty() : xtiProperty()
{
    
}

void wxWindowPosProperty::SetAsVariant(const wxxVariant &value)
{
    wxPoint pt = value.Get<wxPoint>();
    // ask the component's container if it's okay to set the value first.
    wxwUIComponent *c = dynamic_cast<wxwUIComponent*>(wxDesigner()->FindComponentByInstance(Instance()));
    if (c) {
        wxwUIContainer *uic = dynamic_cast<wxwUIContainer*>(c->Container());
        if (uic) {
            int w, h;
            c->GetSize(w, h);
            // ui container will veto if child should not be resized.
            if (!uic->NotifyChildBoundsChanging(pt.x, pt.y, w, h, c))
                return;
        }
    }
    xtiProperty::SetAsVariant(wxxVariant(pt));
}

// wxWindowSizeProperty

IMPLEMENT_DYNAMIC_CLASS(wxWindowSizeProperty, xtiProperty)

wxWindowSizeProperty::wxWindowSizeProperty() : xtiProperty()
{

}

void wxWindowSizeProperty::SetAsVariant(const wxxVariant &value)
{
    wxSize sz = value.Get<wxSize>();
    // ask the component's container if it's okay to set the value first.
    wxwUIComponent *c = dynamic_cast<wxwUIComponent*>(wxDesigner()->FindComponentByInstance(Instance()));
    if (c) {
        wxwUIContainer *uic = dynamic_cast<wxwUIContainer*>(c->Container());
        if (uic) {
            int x, y;
            c->GetTopLeft(y, x);
            // ui container will veto if child should not be resized.
            if (!uic->NotifyChildBoundsChanging(x, y, sz.x, sz.y, c))
                return;
        }
    }
    xtiProperty::SetAsVariant(wxxVariant(sz));
}

// wxFontFaceProperty

IMPLEMENT_DYNAMIC_CLASS(wxFontFaceProperty, xtiProperty)

wxFontFaceProperty::wxFontFaceProperty() : xtiProperty()
{
    FFlags |= PE_DYNAMICVALUELIST | PE_STATICVALUELIST | PE_NOEDIT;
}

void wxFontFaceProperty::GetChoices(PropertyChoices &choices)
{
    wxFontEnumerator fe;
    fe.EnumerateFacenames();
    wxArrayString *faceNames = fe.GetFacenames();
    for (size_t i=0; i<faceNames->Count(); i++) {
        choices.push_back(new PropertyChoice(faceNames->Item(i)));
    }
}

// wxEnumAsIntProperty

IMPLEMENT_ABSTRACT_CLASS(wxIntAsEnumProperty, xtiProperty)

wxIntAsEnumProperty::wxIntAsEnumProperty() : xtiProperty()
{
    FFlags |= PE_NOEDIT | PE_DYNAMICVALUELIST | PE_STATICVALUELIST;
}

void wxIntAsEnumProperty::Create(
    const wxPropertyInfo *propInfo,
    wxwDesigner *designer,
    wxObject *instance,
    wxPropertyBase *parent,
    const wxString &name)
{
    xtiProperty::Create(propInfo, designer, instance, parent, name);
    const wxEnumTypeInfo *eti = dynamic_cast<const wxEnumTypeInfo*>(GetTypeInfo());
    wxASSERT_MSG(eti, "Not a valid enum type");
    FEnumData = eti->GetEnumData();
}

void wxIntAsEnumProperty::GetChoices(PropertyChoices &choices)
{
    if (FEnumData) {
        for (int i=0; i<FEnumData->GetEnumCount(); i++) {
            wxString enumName(FEnumData->GetEnumMemberNameByIndex(i));
            if (!enumName.empty()) {
                choices.push_back(new PropertyChoice(enumName));
            }
        }
    }
}

void wxIntAsEnumProperty::Set(const wxString &value)
{
    int intValue;
    if (FEnumData && FEnumData->HasEnumMemberValue(value, &intValue)) {
        FPropInfo->GetAccessor()->SetProperty(Instance(), wxxVariant(intValue));
    }
    else
        xtiProperty::Set(value);
}

wxString wxIntAsEnumProperty::Get() const
{
    if (FEnumData) {
        wxxVariant vValue;
        FPropInfo->GetAccessor()->GetProperty(Instance(), vValue);
        return FEnumData->GetEnumMemberName(vValue.Get<int>());
    }
    else
        return xtiProperty::Get();
}

// wxControlIdProperty

IMPLEMENT_DYNAMIC_CLASS(wxControlIdProperty, wxIntProperty)

wxControlIdProperty::wxControlIdProperty() : wxIntProperty()
{
    FFlags |= PE_READONLY;
}

// wxWindowFlagsProperty

IMPLEMENT_DYNAMIC_CLASS(wxWindowFlagsProperty, wxSetProperty)

wxWindowFlagsProperty::wxWindowFlagsProperty() : wxSetProperty()
{
    FFlags |= PE_RECREATECOMP;
}

