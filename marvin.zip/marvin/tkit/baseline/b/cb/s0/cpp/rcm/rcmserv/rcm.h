#ifndef rcmH
#define rcmH

#include "rcmdefs.h"
#include "events.h"
#include <stdsoap2.h>
#include "sharedmem.h"
#include <hash_map>
#include <map>
#include <algorithm>
#include <functional>
#include <iostream>

static const char *SOCKET_SIG = "rcmimage";
static const char *SOCKET_MODELIMAGE_CMD = "model";
static const char *SOCKET_COMPIMAGE_CMD = "comp";
static const char *mtBMP = "image/bmp";
static const char *mtJPG = "image/jpeg";
static const char *mtGIF = "image/gif";
static const char *mtRaw32 = "image/raw32";

// rcmProperty flags

#define PE_NOEDIT		        0x0001 // user may not type into inspector
#define PE_READONLY		        0x0002 // property is read-only, may not be changed
#define PE_GRAPHICAL	        0x0004 // inspector should display ellipsis and bring up a dialog when clicked
#define PE_SUBPROPS		        0x0008 // property has sub-properties
#define PE_STATICVALUELIST	    0x0020 // property has a drop-down list of choices, which never change (e.g., true & false)
#define PE_DYNAMICVALUELIST     0x0040 // property has a drop-down list of choices which will be updated every time the list is dropped
#define PE_SORTLIST		        0x0080 // sort sub-properties alphabetically
#define PE_NOTIFYONCHANGE  		0x1000 // notify the GUI designer that a property and its subproperties must be refreshed
#define PE_NOTIFYCOMPCHANGE     0x2000 // notify the GUI designer to refresh all the component's properties

// DesignRect flags

#define MOVE_VERT 				0x0001 // design rect can be moved vertically
#define MOVE_HORZ 				0x0002 // design rect can be moved horizontally

#define RESIZE_TOP 				0x0004 // design rect top edge can be resized
#define RESIZE_LEFT 			0x0008 // design rect left edge can be resized
#define RESIZE_BOTTOM 			0x0010 // design rect bottom edge can be resized
#define RESIZE_RIGHT			0x0020 // design rect right edge can be resized

// designer event types

typedef unsigned long rcmIID;

// concrete class forward declarations

class rcmServer;
class ResultOption;
class ResultMessage;
class Result;
class MenuItem;
class DesignRect;
class DesignerEvent;
class PropertyChoice;

// mixin (abstract) class forward declarations

class rcmProperty;
class rcmComponentInfo;
class rcmComponent;
class rcmContainer;
class rcmDesigner;
class rcmMethod;
class rcmPalettePage;
class rcmDesignerManager;
class rcmComponentModel;
typedef rcmProperty rcmEvent;

typedef ArrayOf_USCORE_xsd_USCORE_string xsdStringArray;
typedef list<rcmComponent*> rcmComponents;
typedef list<rcmEvent*> rcmEvents;
typedef list<rcmProperty*> rcmProperties;
typedef list<rcmMethod*> rcmMethods;
typedef list<DesignRect*> DesignRects;
typedef list<MenuItem*> MenuItems;
typedef list<PropertyChoice*> PropertyChoices;
typedef list<ResultOption*> ResultOptions;
typedef list<ResultMessage*> ResultMessages;
typedef list<DesignerEvent*> DesignerEvents;
typedef hash_map<string_type, rcmComponentInfo*, hash<string_type&> > rcmComponentInfos;
typedef hash_map<string_type, rcmPalettePage*, hash<string_type&> > rcmPalettePages;
typedef hash_map<string_type, rcmDesignerManager*, hash<string_type&> > rcmDesignerManagers;

// Drop-down list item for prop_ & propInfo_GetValueTags
class PropertyChoice
{
public:
    PropertyChoice(const string_type &displayValue, const string_type &valueAsString = "");
    PropertyChoice();

    string_type& GetDisplayIconURI() { return FDisplayIconURI; }
    string_type& GetDisplayValue() { return FDisplayValue; }
    string_type& GetValue() { return FValue; }

    void SetDisplayIconURI(const string_type &value) { FDisplayIconURI = value; }
private:
    string_type FDisplayValue;
    string_type FValue;
    string_type FDisplayIconURI;
};

class ChoiceProvider
{
public:
    ChoiceProvider() { }
    ~ChoiceProvider() { }
    virtual void GetChoices(PropertyChoices &choices) = 0;
};

typedef TEventBase<MenuItem, Result*&> TMenuClickEvent;

#define MENU_CLICK_SINK(class, method) \
    TEventT<class, MenuItem, Result*&>(this, &class::method)

class MenuItem
{
friend class rcmServer;
public:
    // "invokable" and "popup" should be decided by the serializer based on
    // subitems. Same with Key ((int)this)
	MenuItem(const string_type &caption, int id = -1, bool autoFree = true);
    virtual ~MenuItem();

    void Add(MenuItem *item);
    MenuItem* Find(MenuItem *item, bool recurse = false);
    virtual void Insert(int index, MenuItem *item);
    void Remove(MenuItem *item);
    virtual void SetCaption(string_type &value) { FCaption = value; }
    virtual void SetDescription(string_type &value) { FDescription = value; }
    virtual void SetEnabled(bool value) { FEnabled = value; }

    virtual string_type& Caption() { return FCaption; }
    virtual void Clear();
    virtual int	Count() { return FItems ? FItems->size() : 0; }
    virtual string_type Description() { return FDescription; }
    virtual string_type DisplayIconURI() { return FDisplayIconURI; }
    virtual bool Enabled() { return FEnabled; }
    int GetId() { return FId; }
    virtual MenuItems* Items();
    MenuItem* Parent() { return FParent; }

    void SetOnItemClick(TMenuClickEvent &event) { FOnItemClick = event; }
    TMenuClickEvent& GetOnItemClick() { return FOnItemClick; }

protected:
    virtual Result* DoItemClick();
    bool FAutoFree;
private:
    string_type FDescription;
    string_type FDisplayIconURI;
    string_type FCaption;
    MenuItem* FParent;
    bool FEnabled;
	MenuItems* FItems;
    TMenuClickEvent FOnItemClick;
    int FId;
};

class MenuItemProvider
{
public:
    MenuItemProvider() { }
	virtual ~MenuItemProvider() { }

    virtual void UpdateMenu(MenuItems &menu, int x, int y) = 0;
};

typedef TEventBase<DesignRect, int&, int&, Result*&> TDesignRectClickEvent;
typedef TEventBase<DesignRect, int&, int&, int&, int&> TDesignRectBoundsEvent;

#define DESIGNRECT_MOVED_SINK(class, method) \
    TEventT<class, DesignRect, int&, int&, int&, int&>(this, &class::method)

#define DESIGNRECT_RESIZED_SINK(class, method) DESIGNRECT_MOVED_SINK(class, method)

#define DESIGNRECT_CLICK_SINK(class, method) \
    TEventT<class, MenuItem, Result*&>(this, &class::method)

#define DESIGNRECT_DBLCLICK_SINK(class, method) DESIGNRECT_CLICK_SINK(class, method)

class DesignRect : public MenuItemProvider
{
friend class rcmServer;
public:
    DesignRect(int left, int top, int width, int height, int flags = 0, string_type &toolTip = string_type(""));
    virtual ~DesignRect() { }

    void SetFlags(const int value) { FFlags = value; }
    void SetToolTip(const string_type &value) { FToolTip = value; }
    void SetMoveConstraints(int x, int y, int w, int h);
    void SetResizeConstraints(int x, int y, int w, int h);

    virtual bool CanClick();
    virtual string_type Key();
	virtual int	Flags() { return FFlags; }
    virtual void GetMoveConstraints(int &x, int &y, int &w, int &h);
    virtual void GetRect(int &x, int &y, int &w, int &h);
    virtual void GetResizeConstraints(int &x, int &y, int &w, int &h);
    virtual string_type ToolTip() { return FToolTip; }

protected:
    virtual Result* DoClick(int x, int y);
    virtual Result* DoDblClick(int x, int y);
    virtual void DoMoved(int &x, int &y, int &w, int &h);
    virtual void DoResized(int &x, int &y, int &w, int &h);
    void SetRect(int x, int y, int w, int h);
private:
    string_type FToolTip;
    string_type FKey;
    int FFlags;
    int FLeft;
    int FTop;
    int FWidth;
    int FHeight;
    TDesignRectClickEvent FOnClick;
    TDesignRectClickEvent FOnDblClick;
    TDesignRectBoundsEvent FOnMoved;
    TDesignRectBoundsEvent FOnResized;
};

class DesignRectProvider
{
public:
    DesignRectProvider();
    virtual ~DesignRectProvider();
    void AddRect(DesignRect *dr);
    void RemoveRect(DesignRect *dr);

    virtual void ClearRects();
    virtual int RectCount() { return FRects ? FRects->size() : 0; }
    virtual DesignRect* FindRect(string_type &key);
    virtual DesignRects* Rects();
    virtual void UpdateRects() { /* override */ }

private:
    DesignRects* FRects;
};

class ResultOption
{
public:
	ResultOption(const string_type &text, const string_type &description, int id = -1);
	virtual ~ResultOption() { }

    virtual string_type Description() { return FDesc; }
    virtual string_type DisplayIconURI() { return ""; }
    virtual int Id() { return FId; }
    virtual string_type Text() { return FText; }
    virtual Result* Selected();
private:
	string_type FText;
    string_type FDesc;
    int FId;
};

class ResultMessage
{
public:
	enum MessageType { mtInformation = 0, mtWarning, mtCritical };

  	ResultMessage(const string_type &text, const string_type &detail, MessageType msgType = mtInformation);
    virtual ~ResultMessage() { }

    virtual string_type Detail() { return FDetail; }
    virtual string_type Key() { return FKey; }
    virtual string_type IconURI() { return ""; }
    virtual string_type Text() { return FText; }
	virtual MessageType	Type() { return FType; }

private:
    string_type FDetail;
	string_type FKey;
    string_type FText;
	MessageType	FType;
};

class Result
{
public:
	Result(bool success = true, ResultMessage *message = 0);
    Result(bool success, const string_type &msgText, const string_type &msgDetail);
    virtual ~Result();

    void AddMessage(ResultMessage *message);
	void AddOption(ResultOption *option);

    virtual ResultOption* GetOption(int id);
    virtual string_type Key() { return FKey; }
    virtual ResultMessages& Messages() { return FMessages; }
	virtual ResultOptions& Options() { return FOptions; }
    virtual bool Success() { return FSuccess; }

private:
	string_type FKey;
	ResultMessages FMessages;
	ResultOptions FOptions;
    int	FId;
    bool FSuccess;
};

class CreateResult : public Result
{
public:
	CreateResult(rcmComponent *component, ResultMessage *message = 0);
    CreateResult(rcmComponent *component, const string_type &msgText, const string_type &msgDetail);
    virtual ~CreateResult() { }

	virtual rcmComponent* Component() { return FComponent; }

private:
    rcmComponent *FComponent;
};

#define MANAGER_CHANGED 1
// The designer manager has changed in some way (reset palette, etc)
#define DESIGNER_CHANGED MANAGER_CHANGED+1
// A designer has changed in some way
#define COMPONENT_CREATED MANAGER_CHANGED+2
// A component has been created
#define COMPONENT_CHANGED MANAGER_CHANGED+3
// A component has changed in some way
#define COMPONENT_DISPOSED MANAGER_CHANGED+4
// A live component has been disposed
#define PROPERTY_CHANGED MANAGER_CHANGED+5
// A live property has been edited
#define EVENT_CHANGED MANAGER_CHANGED+6
// A live event has been hooked, unhooked, or changed
#define CUSTOM_DATA MANAGER_CHANGED+7
// Server has some custom data to send back to the code manager

class RCMEXPORT DesignerEvent
{
public:
	DesignerEvent(rcmDesigner *designer, int code);

    virtual string_type ManagerKey() { return FManagerKey; }
    virtual string_type DesignerKey() { return FDesignerKey; }
    virtual int Code() { return FCode; }
private:
    string_type FManagerKey;
    string_type FDesignerKey;
    int FCode;
};

class RCMEXPORT ComponentEvent : public DesignerEvent
{
public:
	ComponentEvent(rcmDesigner *designer, rcmComponent *comp, int code);

    virtual string_type ComponentKey() { return FComponentKey; }
private:
    string_type FComponentKey;
};

class RCMEXPORT ComponentChangedEvent : public ComponentEvent
{
public:
	ComponentChangedEvent(rcmDesigner *designer, rcmComponent *comp)
        : ComponentEvent(designer, comp, COMPONENT_CHANGED) { }
};

class RCMEXPORT ComponentDisposedEvent : public ComponentEvent
{
public:
	ComponentDisposedEvent(rcmDesigner *designer, rcmComponent *comp)
        : ComponentEvent(designer, comp, COMPONENT_DISPOSED) { }
};

class RCMEXPORT ComponentCreatedEvent : public ComponentEvent
{
public:
	ComponentCreatedEvent(rcmDesigner *designer, rcmComponent *comp)
        : ComponentEvent(designer, comp, COMPONENT_CREATED) { }
};

class RCMEXPORT PropertyChangedEvent : public ComponentEvent
{
public:
	PropertyChangedEvent(rcmDesigner *designer, rcmProperty *property, rcmComponent *comp);
    virtual const string_array& Keys() const { return FKeys; }
private:
    string_array FKeys;
};

class RCMEXPORT EventChangedEvent : public ComponentEvent
{
public:
    EventChangedEvent(rcmDesigner *designer, rcmEvent *event, rcmComponent *comp);
    virtual const string_array& Keys() const { return FKeys; }
private:
    string_array FKeys;
};

class RCMEXPORT CustomEvent : public DesignerEvent
{
public:
	CustomEvent(rcmDesigner *designer, string_type& key, string_type &data);

    virtual string_type& Key() { return FKey; }
    virtual string_type& Data() { return FData; }

private:
    string_type FKey;
    string_type FData;
};

class rcmProperty
{
public:
    virtual rcmDesigner* Designer() const = 0;
	virtual	string_type	Description() const = 0;
	virtual int	Flags() const = 0;
    virtual string_type	IconURI() const = 0;
    virtual void GetChildren(rcmProperties &subProps) = 0;
    virtual rcmProperty* GetChildProperty(const string_type &propName) = 0;
    virtual string_type	GetValue() const = 0;
	virtual bool IsModified() const = 0;
    virtual const string_array& Keys() const = 0;
	virtual string_type	Name() const = 0;
    virtual rcmProperty* Parent() const = 0;
	virtual Result* Revert() = 0;
    virtual bool SetValue(const string_type &value) = 0;
    virtual wxString Signature() = 0;
	virtual string_type TypeKey() const = 0;
};

class rcmMethod
{
public:
  virtual string_type Key() = 0;
  virtual string_type Name() = 0;
  virtual string_type Description() = 0;
  virtual string_type DisplayIconURI() = 0;
  virtual string_array& ParameterTypeKeys() = 0;
  virtual string_array& ParameterNames() = 0;
  virtual string_type ReturnTypeKey() = 0;
  virtual string_type Modifiers() = 0;
  virtual string_type Declaration() = 0;
  virtual rcmMethod* Parent() = 0;
  virtual GetChildren(rcmMethods &children) = 0;
  virtual rcmMethod* GetChild(string_type &childKey) = 0;
};

class rcmDesignerManager
{
public:
	virtual ~rcmDesignerManager() { }
	virtual void ClearEventQueue() = 0;
    virtual rcmDesigner* DefaultDesigner() = 0;
    virtual Result* Depersist(input_stream_type *stream) = 0;
    virtual rcmComponent* GetComponent(const string_type &instanceKey) = 0;
    virtual void GetComponentsOfType(rcmComponentInfo *type, rcmComponents &comps) = 0;
    virtual rcmDesigner* GetDesigner(const string_type &designerKey) = 0;
	virtual DesignerEvents& GetEvents() = 0;
	virtual bool IsModified() = 0;
	virtual string_type Key() = 0;
    virtual rcmComponentModel* Model() = 0;
    virtual int	Persist(output_stream_type *stream, rcmComponent *root = 0) = 0;
    virtual rcmDesigner* UIDesigner() = 0;
	virtual bool ValidateRename(const string_type &newName) = 0;
};

enum DesignerType { dtDefault = 0, dtUI, dtMenu, dtDB };

class rcmDesigner
{
public:
	virtual ~rcmDesigner() { }

    class Info
    {
    public:
        virtual string_type DesignerKey() = 0;
        virtual string_type DisplayName() = 0;
        virtual string_type Description() = 0;
        virtual string_type DisplayIconURI() = 0;
        virtual DesignerType GetType() = 0;
    };

    static Info* GetInfo()
    {
        return 0;
    }

    virtual Info* GetDesignerInfo() = 0;

	virtual bool CanCreate(rcmContainer *container, rcmComponentInfo *compType) = 0;
	virtual Result* DisposeComponent(const string_type &instanceKey) = 0;
	virtual rcmComponent* GetComponent(const string_type &instanceKey) = 0;
    virtual void GetRootComponents(rcmComponents &roots) = 0;
    virtual rcmDesignerManager* Manager() = 0;
    virtual rcmComponentModel* Model() = 0;
    virtual int	Persist(output_stream_type *stream, rcmComponent *root = 0) = 0;
};

class rcmUIDesigner
{
public:
	virtual ~rcmUIDesigner() { }
	virtual void ClientRect(int &x, int &y, int &w, int &h) = 0;
    virtual bool ConstrainsChildren() = 0;
	virtual string_type	GetDesignerImage(void *stream) = 0;
	virtual string_type	ImageURI() = 0;
};

class rcmComponentModel
{
public:
	virtual ~rcmComponentModel() { }
    virtual rcmComponentInfos& ComponentInfos() = 0;
    virtual CreateResult* CreateComponent(
        rcmComponentInfo *compInfo,
        rcmDesigner *designer,
        rcmContainer *container,
        input_stream_type *stream = 0) = 0;
    virtual rcmDesignerManager* CreateDesignerManager() = 0;
    virtual void CustomDataRequest(char *requestKey, char *data, char *&response) = 0;
	virtual rcmDesignerManagers& DesignerManagers() = 0;
    virtual Result* DisposeDesignerManager(const string_type &key) = 0;
  	virtual rcmComponentInfo* GetComponentInfo(const string_type &typeKey) = 0;
    virtual rcmDesigner::Info* GetDesignerInfo(DesignerType type) = 0;
    virtual rcmDesignerManager* GetDesignerManager(const string_type &key) = 0;
    virtual string_type GetImageData(char *uri, output_stream_type *&stream) = 0;
	virtual void GetImageData(char *uri, ImageResponse *ir) = 0;
  	virtual string_type Key() = 0;
    virtual rcmPalettePages& PalettePages() = 0;
    virtual void SpinEventLoop() = 0;
  	virtual string_type Description() = 0;
    virtual string_type DisplayName() = 0;
  	virtual string_type ImageURI() = 0;
};

class rcmComponentInfo
{
public:
	virtual ~rcmComponentInfo() { }
	virtual const classinfo_type* ClassInfo() = 0;
    virtual string_type GetClassName() = 0;
    virtual string_type DefaultEventKey() = 0;
	virtual string_type DefaultMethodKey() = 0;
    virtual string_type DefaultPropertyKey() = 0;
    virtual string_type	Description() = 0;
    virtual string_type Filename() = 0;
	virtual rcmEvent* GetEvent(string_array &path, rcmComponent *component = 0) = 0;
	virtual void GetEvents(rcmEvents &events, rcmComponent *component = 0) = 0;
	virtual rcmMethod* GetMethod(string_array &path, rcmComponent *component = 0) = 0;
	virtual void GetMethods(rcmMethods &methods, rcmComponent *component = 0) = 0;
    virtual string_type Name() = 0;
    virtual void GetProperties(rcmProperties &props, rcmComponent *component = 0) = 0;
    virtual rcmProperty* GetProperty(string_array &path, rcmComponent *component = 0) = 0;
    virtual string_type	IconURI() = 0;
	virtual string_type Key() = 0;
    virtual string_type	PaletteIconURI() = 0;
    virtual rcmPalettePage* PalettePage() = 0;
};


class rcmComponentEditor : public MenuItemProvider
{
public:
	virtual ~rcmComponentEditor() { }
    virtual void Edit() = 0;
};

class rcmContainer
{
public:
	virtual ~rcmContainer() { }
	virtual bool CanParent(instance_type *instance) = 0;
    virtual bool CanParentType(const classinfo_type *type) = 0;
    virtual int	ComponentCount() = 0;
	virtual rcmComponents& Components() = 0;
    virtual rcmComponent* GetComponent(const string_type &key) = 0;
	virtual Result* SetComponentIndex(rcmComponent *comp, int index) = 0;
};

class rcmComponent
{
public:
	virtual ~rcmComponent() { }
    virtual bool CanDispose() = 0;
    virtual bool CanRename() = 0;
    virtual rcmComponentInfo* ComponentInfo() = 0;
    virtual rcmContainer* Container() = 0;
    virtual rcmDesigner* Designer() = 0;
    virtual rcmComponentEditor* Editor() = 0;
	virtual void GetEvents(rcmEvents &events) = 0;
	virtual void GetMethods(rcmMethods &methods) = 0;
	virtual string_type GetName() = 0;
    virtual void GetProperties(rcmProperties &props) = 0;
    virtual rcmProperty* GetProperty(string_array &propPath) = 0;
    virtual string_type	GetValue(string_array &propPath) = 0;
    virtual string_type GetValue(const rcmProperty *p) = 0;
    virtual instance_type* Instance() = 0;
    virtual bool IsContainer() = 0;
    virtual bool IsType(rcmComponentInfo *type) const = 0;
    virtual string_type Key() = 0;
	virtual Result* SetName(const string_type &newName) = 0;
	virtual Result* SetParent(rcmContainer *newContainer) = 0;
    virtual Result* SetValue(string_array &propPath, const string_type &value) = 0;
};

class rcmUIComponent
{
public:
	virtual ~rcmUIComponent() { }
    virtual bool CanPaintChildren() = 0;
	virtual bool ConstrainChildren() = 0;
	virtual void GetClientRect(int &x, int &y, int &w, int &h) = 0;
    virtual bool IsTopLevel() = 0;
  	virtual string_type GetImageData(int x, int y, int w, int h, output_stream_type *&stream) = 0;
	virtual void GetImageData(int x, int y, int w, int h, ImageResponse *ir) = 0;
    virtual void GetRect(int &x, int &y, int &w, int &h) = 0;
    virtual void SetRect(int &x, int &y, int &w, int &h, bool testOnly = false) = 0;
    virtual void GetSize(int &w, int &h) = 0;
	virtual void SetSize(int &w, int &h) = 0;
   	virtual void GetTopLeft(int &t, int &l) = 0;
    virtual void SetTopLeft(int &t, int &l) = 0;
    virtual bool Visible() = 0;
    virtual int GetZOrderPosition() = 0;
	virtual Result* SetZOrderPosition(rcmComponent *child, int z) = 0;
};

class rcmPalettePage
{
public:
	virtual ~rcmPalettePage() { }
    virtual string_type Title() = 0;
    virtual string_type Description() = 0;
    virtual string_type IconURI() = 0;
    virtual string_type Key() = 0;
};

class rcmSocketImageServer
{
public:
    virtual void SetPort(int port) = 0;
    virtual int GetPort() = 0;
    virtual void Activate() = 0;
    virtual void Deactivate() = 0;
};

class RCMEXPORT rcmServer
{
public:
	rcmServer(rcmComponentModel *model, int port = 5050, bool useSharedMem = true);
    ~rcmServer();

    virtual void Finalize() = 0;
    int GetPort() { return FPort; }
    virtual bool Initialize() = 0;
    bool IsValidIdentifier(const char *ident);
    virtual int ProcessRequest(int timeout);

    // Utility functions
	rcmComponentModel* GetModel();
    rcmComponent* GetComponent(char *managerKey, char *designerKey, char *instanceKey);
    rcmComponentInfo* GetComponentInfo(const char *typeKey);
    rcmContainer* GetContainer(char *managerKey, char *designerKey, char *containerKey);
    rcmDesigner* GetDesigner(const char *managerKey, const char *designerKey);
    DesignRect* GetDesignRect(char *managerKey, char *designerKey, char *compInstanceKey, char *designRectKey);
    DesignRectProvider* GetDesignRectProvider(rcmComponent *c);
    DesignRectProvider* GetDesignRectProvider(rcmDesigner *d);
    rcmEvent* GetEvent(rcmComponent *comp, ArrayOf_USCORE_xsd_USCORE_string *eventKeys);
    rcmEvent* GetEvent(char *compTypeKey, ArrayOf_USCORE_xsd_USCORE_string *eventKeys);
    rcmEvent* GetEvent(char *managerKey, char *designerKey, char *componentInstanceKey, ArrayOf_USCORE_xsd_USCORE_string *eventKeys);
    rcmDesignerManager* GetManager(const char *managerKey);
    rcmPalettePage* GetPalettePage(const char *pageKey);
    rcmProperty* GetProperty(char *compTypeKey, ArrayOf_USCORE_xsd_USCORE_string *propKeys);
    rcmProperty* GetProperty(rcmComponent *comp, ArrayOf_USCORE_xsd_USCORE_string *propKeys);
    rcmProperty* GetProperty(char *managerKey, char *designerKey, char *compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string *propKeys);
    rcmUIDesigner* GetUIDesigner(const char *managerKey, const char *designerKey);
    rcmUIComponent* GetUIComponent(char *managerKey, char *designerKey, char *instanceKey);
    rcmUIComponent* GetUIContainer(char *managerKey, char *designerKey, char *instanceKey);

    // Soap Service implementation
	struct soap *soap;
	virtual int comp_GetContextTags(char *managerInstanceKey, char *designerKey, char *compInstanceKey, int x, int y, impl__comp_USCORE_GetContextTagsResponse *out);
	virtual int result_TagInvoked(char *managerInstanceKey, char *designerKey, char *compInstanceKey, char *designRectKey, char *resultKey, ArrayOf_USCORE_xsd_USCORE_string *tagKeyPath, impl__result_USCORE_TagInvokedResponse *out);
	virtual int designer_CreateComponent(char *managerInstanceKey, char *designerKey, char *containerInstanceKey, char *compTypeKey, xsd__base64Binary *persistData, impl__designer_USCORE_CreateComponentResponse *out) ;
	virtual int uicomp_GetAsContainer(char *managerInstanceKey, char *designerKey, char *compInstanceKey, impl__uicomp_USCORE_GetAsContainerResponse *out) ;
	virtual int manager_GetDefaultDesigner(char *managerInstanceKey, impl__manager_USCORE_GetDefaultDesignerResponse *out) ;
	virtual int prop_Revert(char *managerInstanceKey, char *compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string *propKeyPath, impl__prop_USCORE_RevertResponse *out) ;
	virtual int uidesignrect_ResizeCompleted(char *managerInstanceKey, char *designerKey, char *compInstanceKey, char *designRectKey, int x, int y, int width, int height, impl__uidesignrect_USCORE_ResizeCompletedResponse *out) ;
	virtual int comp_SetInstanceName(char *managerInstanceKey, char *compInstanceKey, char *name, impl__comp_USCORE_SetInstanceNameResponse *out) ;
	virtual int manager_GetUIDesigner(char *managerInstanceKey, impl__manager_USCORE_GetUIDesignerResponse *out) ;
	virtual int uidesignrect_GetContextTags(char *managerInstanceKey, char *designerKey, char *compInstanceKey, char *designRectKey, int x, int y, impl__uidesignrect_USCORE_GetContextTagsResponse *out) ;
	virtual int propinfo_GetValueTags(char *compTypeKey, ArrayOf_USCORE_xsd_USCORE_string *propKeyPath, impl__propinfo_USCORE_GetValueTagsResponse *out) ;
	virtual int comp_GetAsContainer(char *managerInstanceKey, char *designerKey, char *compInstanceKey, impl__comp_USCORE_GetAsContainerResponse *out) ;
	virtual int prop_GetValueTags(char *managerInstanceKey, char *compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string *propKeyPath, impl__prop_USCORE_GetValueTagsResponse *out) ;
	virtual int uidesignrect_MouseClick(char *managerInstanceKey, char *designerKey, char *compInstanceKey, char *designRectKey, int x, int y, int clickCount, impl__uidesignrect_USCORE_MouseClickResponse *out) ;
	virtual int server_GetComponentModels(impl__server_USCORE_GetComponentModelsResponse *out) ;
	virtual int model_GetPalettePages(impl__model_USCORE_GetPalettePagesResponse *out) ;
	virtual int eventinfo_GetHookTags(char *compTypeKey, ArrayOf_USCORE_xsd_USCORE_string *eventKeyPath, impl__eventinfo_USCORE_GetHookTagsResponse *out) ;
	virtual int comp_GetProperty(char *managerInstanceKey, char *compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string *propKeyPath, impl__comp_USCORE_GetPropertyResponse *out) ;
	virtual int comp_TestSetParentContainer(char *managerInstanceKey, char *designerKey, char *containerInstanceKey, char *compInstanceKey, impl__comp_USCORE_TestSetParentContainerResponse *out) ;
	virtual int event_GetHookTags(char *managerInstanceKey, char *compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string *eventKeyPath, impl__event_USCORE_GetHookTagsResponse *out) ;
	virtual int uidesignrect_MoveCompleted(char *managerInstanceKey, char *designerKey, char *compInstanceKey, char *designRectKey, int x, int y, int width, int height, impl__uidesignrect_USCORE_MoveCompletedResponse *out) ;
	virtual int model_GetDesignerManagers(impl__model_USCORE_GetDesignerManagersResponse *out) ;
	virtual int methodinfo_GetMethodInfos(char *compTypeKey, ArrayOf_USCORE_xsd_USCORE_string *parentMethodKeyPath, impl__methodinfo_USCORE_GetMethodInfosResponse *out) ;
	virtual int manager_GetDesignerEvents(char *managerInstanceKey, impl__manager_USCORE_GetDesignerEventsResponse *out) ;
	virtual int uidesigner_GetRootUIComponents(char *managerInstanceKey, char *designerKey, impl__uidesigner_USCORE_GetRootUIComponentsResponse *out) ;
	virtual int comp_SetParentContainer(char *managerInstanceKey, char *designerKey, char *containerInstanceKey, char *compInstanceKey, impl__comp_USCORE_SetParentContainerResponse *out) ;
	virtual int uicomp_TestUIComponentRect(char *managerInstanceKey, char *designerKey, char *compInstanceKey, int x, int y, int width, int height, int dragX, int dragY, impl__uicomp_USCORE_TestUIComponentRectResponse *out) ;
	virtual int uidesigner_CreateComponent(char *managerInstanceKey, char *designerKey, char *containerInstanceKey, char *compTypeKey, int x, int y, int width, int height, xsd__base64Binary *persistData, impl__uidesigner_USCORE_CreateComponentResponse *out) ;
	virtual int model_CreateDesignerManager(impl__model_USCORE_CreateDesignerManagerResponse *out) ;
	virtual int designer_GetContextTags(char *managerInstanceKey, char *designerKey, int x, int y, impl__designer_USCORE_GetContextTagsResponse *out) ;
	virtual int compinfo_GetEventInfos(char *compTypeKey, impl__compinfo_USCORE_GetEventInfosResponse *out) ;
	virtual int event_SetDefaultHook(char *managerInstanceKey, char *compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string *eventKeyPath, impl__event_USCORE_SetDefaultHookResponse *out) ;
	virtual int eventinfo_GetEventInfos(char *compTypeKey, ArrayOf_USCORE_xsd_USCORE_string *parentEventKeyPath, impl__eventinfo_USCORE_GetEventInfosResponse *out) ;
	virtual int designer_TagInvoked(char *managerInstanceKey, char *designerKey, ArrayOf_USCORE_xsd_USCORE_string *tagKeyPath, impl__designer_USCORE_TagInvokedResponse *out) ;
	virtual int container_SetComponentIndex(char *managerInstanceKey, char *containerInstanceKey, char *compInstanceKey, int index, impl__container_USCORE_SetComponentIndexResponse *out) ;
	virtual int designer_TestCreateComponent(char *managerInstanceKey, char *designerKey, char *containerInstanceKey, char *compTypeKey, impl__designer_USCORE_TestCreateComponentResponse *out) ;
	virtual int comp_TagInvoked(char *managerInstanceKey, char *designerKey, char *compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string *tagKeyPath, impl__comp_USCORE_TagInvokedResponse *out) ;
	virtual int prop_GetProperties(char *managerInstanceKey, char *compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string *parentPropKeyPath, impl__prop_USCORE_GetPropertiesResponse *out) ;
	virtual int palette_GetComponentInfos(char *pageKey, impl__palette_USCORE_GetComponentInfosResponse *out) ;
	virtual int comp_GetProperties(char *managerInstanceKey, char *compInstanceKey, impl__comp_USCORE_GetPropertiesResponse *out) ;
	virtual int manager_GetPersistenceData(char *managerInstanceKey, char *compInstanceKey, impl__manager_USCORE_GetPersistenceDataResponse *out) ;
	virtual int model_GetDefaultDesignerInfo(impl__model_USCORE_GetDefaultDesignerInfoResponse *out) ;
	virtual int model_DisposeDesignerManager(char *managerInstanceKey, impl__model_USCORE_DisposeDesignerManagerResponse *out) ;
	virtual int uidesignrect_TagInvoked(char *managerInstanceKey, char *designerKey, char *compInstanceKey, char *designRectKey, ArrayOf_USCORE_xsd_USCORE_string *tagKeyPath, impl__uidesignrect_USCORE_TagInvokedResponse *out) ;
	virtual int prop_SetValueAsText(char *managerInstanceKey, char *compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string *propKeyPath, char *value, impl__prop_USCORE_SetValueAsTextResponse *out) ;
	virtual int comp_GetEvents(char *managerInstanceKey, char *compInstanceKey, impl__comp_USCORE_GetEventsResponse *out) ;
	virtual int designer_CreateComponent(char *managerInstanceKey, char *designerKey, char *containerInstanceKey, char *compTypeKey, impl__designer_USCORE_CreateComponentResponse *out) ;
	virtual int manager_IsPersistenceDataModified(char *managerInstanceKey, impl__manager_USCORE_IsPersistenceDataModifiedResponse *out) ;
	virtual int uicomp_SetUIComponentRect(char *managerInstanceKey, char *designerKey, char *compInstanceKey, int x, int y, int width, int height, int dragX, int dragY, impl__uicomp_USCORE_SetUIComponentRectResponse *out) ;
	virtual int model_GetUIDesignerInfo(impl__model_USCORE_GetUIDesignerInfoResponse *out) ;
	virtual int model_CustomDataRequest(char *key, char *data, impl__model_USCORE_CustomDataRequestResponse *out) ;
	virtual int event_Unhook(char *managerInstanceKey, char *compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string *eventKeyPath, impl__event_USCORE_UnhookResponse *out) ;
	virtual int model_GetComponentInfo(char *compTypeKey, impl__model_USCORE_GetComponentInfoResponse *out) ;
	virtual int propinfo_GetPropertyInfos(char *compTypeKey, char *managerKey, char *designerKey, char *compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string *parentPropKeyPath, impl__propinfo_USCORE_GetPropertyInfosResponse *out) ;
	virtual int manager_GetComponentsOfType(char *managerInstanceKey, char *compTypeKey, impl__manager_USCORE_GetComponentsOfTypeResponse *out) ;
	virtual int event_GetEvents(char *managerInstanceKey, char *compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string *parentEventKeyPath, impl__event_USCORE_GetEventsResponse *out) ;
	virtual int manager_SetPersistenceData(char *managerInstanceKey, xsd__base64Binary *persistData, impl__manager_USCORE_SetPersistenceDataResponse *out) ;
	virtual int comp_GetEvent(char *managerInstanceKey, char *compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string *eventKeyPath, impl__comp_USCORE_GetEventResponse *out) ;
	virtual int designer_GetComponent(char *managerInstanceKey, char *designerKey, char *compInstanceKey, impl__designer_USCORE_GetComponentResponse *out) ;
	virtual int event_SetHookAsText(char *managerInstanceKey, char *compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string *eventKeyPath, char *hookText, impl__event_USCORE_SetHookAsTextResponse *out) ;
	virtual int compinfo_GetPropertyInfos(char *compTypeKey, impl__compinfo_USCORE_GetPropertyInfosResponse *out) ;
	virtual int designer_DisposeComponent(char *managerInstanceKey, char *designerKey, char *compInstanceKey, impl__designer_USCORE_DisposeComponentResponse *out) ;
	virtual int compinfo_GetMethodInfos(char *compTypeKey, impl__compinfo_USCORE_GetMethodInfosResponse *out) ;
	virtual int designer_GetRootComponents(char *managerInstanceKey, char *designerKey, impl__designer_USCORE_GetRootComponentsResponse *out) ;
	virtual int uidesigner_GetUIComponent(char *managerInstanceKey, char *designerKey, char *compInstanceKey, impl__uidesigner_USCORE_GetUIComponentResponse *out) ;
	virtual int model_GetDesignerInfoForComponent(char *compTypeKey, impl__model_USCORE_GetDesignerInfoForComponentResponse *out) ;

private:
    MenuItem* FindMenuItemInCache(const char *key);
    void ClearMenuItemCache();
    rcmComponentModel *FModel;
    int	FPort;
    bool FUseSharedMem;
    MenuItems FMenuItemCache;
};

template <typename T>
extern void SerializeStream(struct soap *soap, xsd__base64Binary *xsdb, T stream);

extern void xsdStringArrayToStringArray(const xsdStringArray *xa, string_array &sa);
extern void StringArrayToxsdStringArray(struct soap *soap, const string_array &in, xsdStringArray *out);
extern char** StringArrayToCharArray(struct soap *soap, const string_array &a, int &size);
extern void PropertyKeyArray(string_array &a, const rcmProperty *prop);

_STLP_TEMPLATE_NULL struct hash<string_type&>
{
  	size_t operator()(string_type &__s) const { _STLP_FIX_LITERAL_BUG(__s) return __stl_hash_string(CSTR(__s)); }
};

typedef pair<const string_type, rcmPalettePage*> rcmPalettePagePair;
typedef pair<const string_type, rcmComponent*> rcmComponentPair;
typedef pair<const string_type, rcmComponentInfo*> rcmComponentInfoPair;

struct page_equal_to : public binary_function<rcmPalettePagePair, string_type, bool>
{
	bool operator() (rcmPalettePagePair &__pair, string_type &__name) const
    {
    	return __pair.second && strcmp(CSTR(__pair.second->Title()), CSTR(__name)) == 0;
    }
};

struct comp_equal_to : public binary_function<rcmComponent*, string_type, bool>
{
	bool operator()(rcmComponent* __comp, string_type &__key) const
    {
    	return __comp && strcmp(CSTR(__comp->Key()), CSTR(__key)) == 0;
    }
};

extern rcmServer& Server();

template <typename T, typename S>
void KeyGen(T &ClassInst, S &Key)
{
#ifdef _DEBUG
	Key.sprintf("%s%d", typeid(*ClassInst).name(), (int)ClassInst);
#else
    Key.sprintf("%d", (int)ClassInst);
#endif
}

Result* FindResult(const string_type &resultKey);
Result* ErrorMessage(const string_type &message);
Result* ErrorMessage(const string_type &title, const string_type &message);

template <typename T>
list<T>::iterator list_get(list<T> &l, int index)
{
    list<T>::iterator it = l.begin()++;
    int i = 0;
    while (it != l.end() && i < index) {
        i++;
        it++;
    }
    return it;
}

template <typename T>
void list_bring_to_front(list<T> &l, T &val)
{
    l.remove(val);
    l.push_front(val);
}

template <typename T>
void list_bring_to_front(list<T> &l, int index)
{
    list<T>::iterator it = list_get(l, index);
    if (it != l.end()) {
        T &val = *it;
        l.erase(it);
        l.push_front(val);
    }
}

template <typename T>
void list_send_to_back(list<T> &l, T &val)
{
    l.remove(val);
    l.push_back(val);
}

template <typename T>
void list_send_to_back(list<T> &l, int index)
{
    list<T>::iterator it = list_get(l, index);
    if (it != l.end()) {
        T &val = *it;
        l.erase(it);
        l.push_back(val);
    }
}


#endif


