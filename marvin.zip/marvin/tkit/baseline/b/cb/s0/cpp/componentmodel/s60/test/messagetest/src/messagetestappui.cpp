////////////////////////////////////////////////////////////////////////////////
// Implementation of CmessagetestAppUi
////////////////////////////////////////////////////////////////////////////////

#include <e32std.h>
#ifdef WITH_TAB_GROUP
#include <eikspane.h>
#include <aknnavi.h>
#endif
#include "messagetest.hrh"
#include "messagetestappui.h"
#include "messagetestview.h"


template class CMessageServerT<int>;
template class CSmsMessageContentT<int>;
template class CSmsMessageSenderT<int>;

template class CMessageMoverT<int>;
template class CMessageBoxListenerT<int>;

template class CMmsMessageContentT<int>;
template class CMmsMessageSenderT<int>;

template class CEmailMessageContentT<int>;
template class CEmailMessageSenderT<int>;


/**
 * Method managed by IDE to construct views
 * Please do not edit this routine as its
 * contents are regenerated upon new view creation.
 */
void CmessagetestAppUi::InitViewsL()
{
  imessagetestView = CmessagetestView::NewL();
  AddViewL(imessagetestView);
}

void CmessagetestAppUi::ConstructL()
{
  BaseConstructL();
  InitViewsL();

#ifdef WITH_TAB_GROUP
  // Show tabs for main views from resources
  CEikStatusPane* sp = StatusPane();
  iNaviPane = (CAknNavigationControlContainer *)sp->ControlL(TUid::Uid(EEikStatusPaneUidNavi));
  sp->SetDimmed(ETrue);

  // Tabgroup has been read from resource and it were pushed to the navi pane.
  // Get pointer to the navigation decorator with the ResourceDecorator() function.
  // Application owns the decorator and it has responsibility to delete the object.
  iDecoratedTabGroup = iNaviPane->ResourceDecorator();

  if (iDecoratedTabGroup) {
    iTabGroup = (CAknTab Group*) iDecoratedTabGroup->DecoratedControl();
  }

  if (iTabGroup) {
    ActivateLocalViewL(TUid::Uid(iTabGroup->ActiveTabId()));
  } else { // just in case
    ActivateLocalViewL(titleView->Id());
  }
#else
  // Set default view
  SetDefaultViewL(*imessagetestView);
#endif
}

void CmessagetestAppUi::HandleCommandL(TInt aCommand)
{
  switch (aCommand) {
    case EEikCmdExit:
    case EAknSoftkeyExit:
      Exit();
      break;
    case EKeyLeftArrow:
#ifdef WITH_TAB_GROUP
      if (active > 0) {
        // Change to usual layout
        TRect cr = ClientRect();
        if (cr.iTl.iY == Kqpn_height_status_pane_idle) {
          StatusPane()->SwitchLayoutL(R_AVKON_STATUS_PANE_LAYOUT_USUAL);
          iLayout = !iLayout;
        }

        active--;
        iTabGroup->SetActiveTabByIndex(active);
        ActivateLocalViewL(TUid::Uid(iTabGroup->TabIdFromIndex(active)));
        return EKeyWasConsumed;
      }
#endif
      break;

    case EKeyRightArrow:
#ifdef WITH_TAB_GROUP
      if((active + 1) < count) {
        TRect cr = ClientRect();
        if (cr.iTl.iY == Kqpn_height_status_pane_idle) {
          StatusPane()->SwitchLayoutL(R_AVKON_STATUS_PANE_LAYOUT_USUAL);
          iLayout = !iLayout;
        }

        active++;
        iTabGroup->SetActiveTabByIndex(active);
        ActivateLocalViewL(TUid::Uid(iTabGroup->TabIdFromIndex(active)));
        return EKeyWasConsumed;
      }
#endif
      break;
    default:
      break;
  }
}

