#!/bin/sh

#
# We'll assume JDK is at default setting if it's not set
#
if [ -z "$JAVA_HOME" ]; then
JAVA_HOME=/usr/java/j2sdk1.4.1_01
fi


#
# We'll assume CBUILDER is under the HOME directory
#
if [ -z "$CBUILDER" ]; then
CBUILDER=$HOME/cbuilder
fi


echo -------------------------------------
echo CBuilder Native/JNI DLL Builder
echo -------------------------------------


$JAVA_HOME/bin/javah -classpath ../../../classes com.borland.cbuilder.env.SysEnvironment

g++ -fPIC -shared CBuilderNative.cpp -I$JAVA_HOME/include -I$JAVA_HOME/include/linux -o CBuilderNative.so

cp CBuilderNative.so ../../../lib/libCBuilderNative.so

