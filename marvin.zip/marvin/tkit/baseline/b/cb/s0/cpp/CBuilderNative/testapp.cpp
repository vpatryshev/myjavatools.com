#include <stdio.h>
//#include <dlfcn.h>

int main(int argc, char argv[])
{
  for (int i=0; i<argc; i++) 
  {
    printf("%d: %s", i, argv[i]);
  }
  return 0;
}

