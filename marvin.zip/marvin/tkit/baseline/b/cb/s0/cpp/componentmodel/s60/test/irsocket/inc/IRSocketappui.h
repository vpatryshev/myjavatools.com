#ifndef __IRSOCKET_APPUI_H__
#define __IRSOCKET_APPUI_H__

#include <aknViewAppUi.h>
#include "IRSocket.h"

class CIRSocketView;


// CIRSocketAppUi
class CIRSocketAppUi : public CAknViewAppUi
{
  /**
   * Performs view construction
   */
  void InitViewsL();

public:
  /**
   * Performs second phase construction of this AppUi Object
   */
  void ConstructL();

  /**
   * Handles user menu selection
   */
  void HandleCommandL(TInt aCommand);

private:
  CIRSocketView * iIRSocketView;
};


#endif // __IRSOCKET_APPUI_H__

