////////////////////////////////////////////////////////////////////////////////
// Implementation of CtimercomponentApplication
////////////////////////////////////////////////////////////////////////////////

#include "timercomponentapp.h"
#include "timercomponentdocument.h"

const TUid KUidtimercomponent = { 0x01005321 };

TUid CtimercomponentApplication::AppDllUid() const
{
	return KUidtimercomponent;
}

CApaDocument* CtimercomponentApplication::CreateDocumentL()
{
	CApaDocument* document = CtimercomponentDocument::NewL(*this);
  return document;
}
