#ifdef __BORLANDC__
#include "rcmpch.h"
#endif

#pragma hdrstop

#include "wxw.h"
#include "wxwcomponentmodel.h"
#include "wxwdesigner.h"
#include "wx/imaggif.h"
#include "wx/image.h"

wxSysColorEntry SysColors[wxSYS_COLOUR_MAX] = {
    { wxSYS_COLOUR_SCROLLBAR, wxT("SCROLLBAR") },
    { wxSYS_COLOUR_BACKGROUND, wxT("BACKGROUND") },
    { wxSYS_COLOUR_ACTIVECAPTION, wxT("ACTIVE CAPTION") },
    { wxSYS_COLOUR_INACTIVECAPTION, wxT("INACTIVE CAPTION") },
    { wxSYS_COLOUR_MENU, wxT("MENU") },
    { wxSYS_COLOUR_WINDOW, wxT("WINDOW") },
    { wxSYS_COLOUR_WINDOWFRAME, wxT("WINDOW FRAME") },
    { wxSYS_COLOUR_MENUTEXT, wxT("MENU TEXT") },
    { wxSYS_COLOUR_WINDOWTEXT, wxT("WINDOW TEXT") },
    { wxSYS_COLOUR_CAPTIONTEXT, wxT("CAPTION TEXT") },
    { wxSYS_COLOUR_ACTIVEBORDER, wxT("ACTIVE BORDER") },
    { wxSYS_COLOUR_INACTIVEBORDER, wxT("INACTIVE BORDER") },
    { wxSYS_COLOUR_APPWORKSPACE, wxT("APP WORKSPACE") },
    { wxSYS_COLOUR_HIGHLIGHT, wxT("HIGHLIGHT") },
    { wxSYS_COLOUR_HIGHLIGHTTEXT, wxT("HIGHLIGHT TEXT") },
    { wxSYS_COLOUR_BTNFACE, wxT("BUTTON FACE") },
    { wxSYS_COLOUR_BTNSHADOW, wxT("BUTTON SHADOW") },
    { wxSYS_COLOUR_GRAYTEXT, wxT("GRAY TEXT") },
    { wxSYS_COLOUR_BTNTEXT, wxT("BUTTON TEXT") },
    { wxSYS_COLOUR_INACTIVECAPTIONTEXT, wxT("INACTIVE CAPTION") },
    { wxSYS_COLOUR_BTNHIGHLIGHT, wxT("BUTTON HIGHLIGHT") },
    { wxSYS_COLOUR_3DDKSHADOW, wxT("DARK SHADOW") },
    { wxSYS_COLOUR_3DLIGHT, wxT("LIGHT") },
    { wxSYS_COLOUR_INFOTEXT, wxT("INFO TEXT") },
    { wxSYS_COLOUR_INFOBK, wxT("INFO BACKGROUND") },
    { wxSYS_COLOUR_LISTBOX, wxT("LISTBOX") },
    { wxSYS_COLOUR_HOTLIGHT, wxT("HOT LIGHT") },
    { wxSYS_COLOUR_GRADIENTACTIVECAPTION, wxT("ACTIVE CAPTION GRADIENT") },
    { wxSYS_COLOUR_GRADIENTINACTIVECAPTION, wxT("INACTIVE CAPTION GRADIENT") },
    { wxSYS_COLOUR_MENUHILIGHT, wxT("MENU HIGHLIGHT") },
    { wxSYS_COLOUR_MENUBAR, wxT("MENUBAR") }
};

wxStdColorEntry StdColors[STD_COLOR_MAX] = {
    {wxT("BLACK"), 0, 0, 0},
    {wxT("BLUE"), 0, 0, 255},
    {wxT("BROWN"), 165, 42, 42},
    {wxT("CYAN"), 0, 255, 255},
    {wxT("DARK GREY"), 47, 47, 47},
    {wxT("DARK GREEN"), 47, 79, 47},
    {wxT("DARK OLIVE GREEN"), 79, 79, 47},
    {wxT("GOLD"), 204, 127, 50},
    {wxT("GREY"), 128, 128, 128},
    {wxT("GREEN"), 0, 255, 0},
    {wxT("LIGHT BLUE"), 191, 216, 216},
    {wxT("LIGHT GREY"), 192, 192, 192},
    {wxT("LIME GREEN"), 50, 204, 50},
    {wxT("LIGHT MAGENTA"), 255, 0, 255},
    {wxT("MAGENTA"), 255, 0, 255},
    {wxT("MAROON"), 142, 35, 107},
    {wxT("NAVY"), 35, 35, 142},
    {wxT("ORANGE"), 204, 50, 50},
    {wxT("PURPLE"), 176, 0, 255},
    {wxT("RED"), 255, 0, 0},
    {wxT("WHITE"), 255, 255, 255},
    {wxT("YELLOW"), 255, 255, 0}
};


char* StrAlloc(char *&dest, const char *src)
{
    int len = strlen(src);
    if (len > 0)
    {
        char *s = (char*)malloc(len+1);
        dest = strcpy(s, src);
    }
    else
        dest = NULL;
    return dest;
}

wxString StringArrayToString(wxArrayString &array)
{
    wxString s;
    unsigned int i = -1;
    while (++i < array.Count()) {
        if (i > 0)
            s += wxT(".");
        s += array[i];
    }
    return s;
}

void StringArrayToxsdStringArray(struct soap *soap, const string_array &in, xsdStringArray *out)
{
    out->__ptr = (char**)soap_malloc(soap, sizeof(char*)*(in.Count()));
    out->__size = in.Count();
    for (int i=in.Count()-1; i>=0; i--) {
        soap_strcpy(soap, out->__ptr[i], in[i]);
    }
}

void PropertyKeyArray(wxArrayString &a, const rcmProperty *prop)
{
    while (prop) {
        a.Insert(prop->Name(), 0);
        prop = prop->Parent();
    }
}

void xsdStringArrayToStringArray(const xsdStringArray *xa, string_array &sa)
{
    for (int i=0; i<xa->__size; i++) {
        sa.Add(xa->__ptr[i]);
    }
}

char** StringArrayToCharArray(struct soap *soap, const string_array &a, int &size)
{
    size = a.Count();
    char **chars = (char**)soap_malloc(soap, sizeof(char*)*size);
    for (int i=0; i<size; i++) {
        soap_strcpy(soap, chars[i], a[i]);
    }
    return chars;
}


void ConstructWXControl(wxObject *parent, wxControl *c, const wxString &name)
{
    wxxVariant params[6];
    params[0] = wxxVariant(dynamic_cast<wxWindow*>(parent));
    params[1] = wxxVariant((wxWindowID)GetUniqueID());
    params[2] = wxxVariant(wxString(name));
    params[3] = wxxVariant(wxDefaultPosition);
    params[4] = wxxVariant(wxDefaultSize);
    params[5] = wxxVariant((long)0);
    c->GetClassInfo()->Create(c, 6, params);
    c->Show();
}

// specializations and macros that should be in xti.cpp, or somewhere
// in the wxWindows code.

// unsigned long (where is this coming from?)
template<> void wxStringReadValue<unsigned long>(const wxString &s, unsigned long &data)
{
	wxSscanf(s, _T("%l"), &data ) ;
}

template <> void wxStringWriteValue<unsigned long>(wxString &s, const unsigned long &data)
{
    s = wxString::Format("%l", data);
}

// bool

template <> void wxStringReadValue(const wxString &s, bool &data)
{
	if (s.CmpNoCase(wxT("false")) == 0 || s == wxT("0") || s.IsEmpty())
    	data = false;
    else if (s.CmpNoCase(wxT("true")) == 0 || s.IsNumber())
    	data = true;
    else
    	throw error(wxString().Format("Invalid boolean value : %s", s));
}

template <> void wxStringWriteValue(wxString &s, const bool &data)
{
	s = data ? wxT("true") : wxT("false");
}

// const wxPoint

template<> const wxTypeInfo* wxGetTypeInfo( const wxPoint * )
{
        assert(0) ;
        static wxBuiltInTypeInfo s_typeInfo( wxT_VOID ) ;
        return &s_typeInfo ;
}

template<> void wxStringReadValue(const wxString &s , const wxPoint &data)
{
    if (wxSscanf(s, wxT("%d,%d"), &data.x , &data.y) != 2) {
        throw new error(wxString::Format("\"%s\" is not a valid point specification", s));
    }
}

// const wxSize

template<> const wxTypeInfo* wxGetTypeInfo( const wxSize * )
{
    assert(0) ;
    static wxBuiltInTypeInfo s_typeInfo( wxT_VOID ) ;
    return &s_typeInfo ;
}

template<> void wxStringReadValue(const wxString & , const wxSize & )
{
    assert(0) ;
}

// APP INTERNALS----------------------------------------------------------------

static bool MustShutdown = false;
struct server_exception : exception
{
    const char *msg;

    server_exception(const char *s) : msg(s) {}
    virtual const char* what() { return msg; }
};

static LONG __stdcall uef(struct _EXCEPTION_POINTERS *ei)
{
    ExitProcess(2);
    return 0;
}

#if 0
/*
    Override the definition of assert support routines, so that if something
    bad happens in the server, then we don't pop a dialog, and lock up the
    designer.  Code is here in case we come back to this method of operations.
*/
void wxAssert(int cond,
              const wxChar *szFile,
              int nLine,
              const wxChar *szCond,
              const wxChar *szMsg)
{
    if ( !cond )
    {
	// Ought to format some of this information into the string.  Do that
	// after we get it actually working.
	MustShutdown = true;
	server_exception x("wxWindows API failed");
	throw x;
    }
}
#endif

#pragma argsused

class ServerApp : public wxApp
{
public:
    // override base class virtuals
    // ----------------------------
    ~ServerApp() { Server().Finalize(); }
    bool ProcessIdle();
    // this one is called on application startup and is a good place for the app
    // initialization (doing it here and not in the ctor allows to have an error
    // return: if OnInit() returns false, the application terminates)
    virtual bool OnInit();
protected:
    void InitializeColors();
};

IMPLEMENT_ABSTRACT_CLASS(wxPainter, wxObject)

IMPLEMENT_APP(ServerApp)

bool ServerApp::ProcessIdle()
{
	int soapCode = Server().ProcessRequest(50);
    // return true if more idle processing is required.
    if (soapCode < SOAP_EOF) { // we've encountered a serious fault
    	Exit();
        return false;
    }
    return true;
}

bool ServerApp::OnInit()
{
    SetUnhandledExceptionFilter(uef);
	SetExitOnFrameDelete(false);
    InitializeColors();
    return Server().Initialize();
}

void ServerApp::InitializeColors()
{
    wxColour *c;
    for (int i=0; i<wxSYS_COLOUR_MAX; i++) {
        c = new wxColour(wxSystemSettings::GetColour(SysColors[i].index));
        wxTheColourDatabase->AddColour(SysColors[i].name, c);
    }
    for (int i=0; i<WXSIZEOF(StdColors); i++) {
        c = new wxColour(StdColors[i].red, StdColors[i].green, StdColors[i].blue);
        wxTheColourDatabase->AddColour(StdColors[i].name, c);
    }
}


