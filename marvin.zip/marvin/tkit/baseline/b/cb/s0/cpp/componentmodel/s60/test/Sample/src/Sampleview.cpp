////////////////////////////////////////////////////////////////////////////////
// Implementation of CSampleView
////////////////////////////////////////////////////////////////////////////////

#include <e32std.h>
#include <aknviewappui.h>
#include <aknconsts.h>

#include "Sampleappui.h"
#include "Sampleview.h"
#include "Samplecontainer.h"
#include "Sample.hrh"
#include <Sample.rsg>

const TUid EDefaultViewId = { ESampleViewId };

CSampleView* CSampleView::NewL()
{
  CSampleView* self = CSampleView::NewLC();
  CleanupStack::Pop(self);
  return self;
}

CSampleView* CSampleView::NewLC()
{
  CSampleView* self = new (ELeave) CSampleView();
  CleanupStack::PushL(self);
  self->ConstructL();
  return self;
}

CSampleView::CSampleView()
{
}

CSampleView::~CSampleView()
{
}

void CSampleView::ConstructL()
{
  BaseConstructL(R_SAMPLE);
}

TUid CSampleView::Id() const
{
  return EDefaultViewId;
}

void CSampleView::DoActivateL(const TVwsViewId& aPrevViewId,
                                   TUid aCustomMessageId,
                                   const TDesC8& aCustomMessage)
{
  ASSERT(container == NULL);
  container = CSampleContainer::NewL(ClientRect());
  container->SetMopParent(this);
  AppUi()->AddToStackL(*this, container);
}

void CSampleView::DoDeactivate()
{
  if (container)
  {
    AppUi()->RemoveFromStack(container);
    delete container;
    container = NULL;
  }
}

void CSampleView::HandleCommandL(TInt aCommand)
{
  if (container && container->DispatchCommandEvents(aCommand))
  {
    return;
  }
  else
  {
    AppUi()->HandleCommandL(aCommand);
  }
}
