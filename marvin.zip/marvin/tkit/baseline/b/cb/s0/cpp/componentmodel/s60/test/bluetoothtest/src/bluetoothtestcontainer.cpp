////////////////////////////////////////////////////////////////////////////////
// Implementation of CbluetoothtestContainer
////////////////////////////////////////////////////////////////////////////////

#include <aknutils.h>
#include <eiklabel.h>
#include <bluetoothtest.rsg>
#include <barsread.h>
#include <eikappui.h>
#include <eikedwin.h>
#include <txtglobl.h>
#include <coeinput.h>
#include <aknlists.h>
#include <akniconarray.h>
#include <eikclbd.h>
#include <akntitle.h>
#include <aknslider.h>
#include <eikspane.h>
#include <aknnavilabel.h>
#include <eikmfne.h>
#include <aknnumseced.h>
#include <aknipfed.h>
#include <in_sock.h>
#include <eikprogi.h>
#include <AknNumEdwin.h>
#include <eikfpne.h>
#include <aknnumed.h>


#include "bluetoothtestcontainer.h"
#include "bluetoothtestappui.h"

#include "beatingheartbeat.h"

template class CBtParametersT<CBase>;
template class CBtSecurityT<CActive>;
template class CBtDiscoveryT<CActive>;
template class CBtSocketT<CClientSocketT<CActive> >;
template class CBtSdpRegistryT<CBase>;
template class CBtSdpQueryT<int>;
template class CSocketReaderT<CClientSocketT<CActive> >;
template class CSocketWriterT<CClientSocketT<CActive> >;
template class CSocketListenerT<CBtSocketT < CClientSocketT<CActive> > >;

template class CActiveObjectT<CActive>;
template class CEtelPhoneT<CBase>;
template class CEtelLineT<CBase>;
template class CEtelCallT<CBase>;

template class CCameraT<CActive>;

template class CBeatingHeartbeatT<MBeating>;



CbluetoothtestContainer* CbluetoothtestContainer::NewL(const TRect& aRect)
{
  CbluetoothtestContainer* self = CbluetoothtestContainer::NewLC(aRect);
  CleanupStack::Pop(self);
  return self;
}

CbluetoothtestContainer* CbluetoothtestContainer::NewLC(const TRect& aRect)
{
  CbluetoothtestContainer* self = new (ELeave) CbluetoothtestContainer;
  CleanupStack::PushL(self);
  self->ConstructL(aRect);
  return self;
}

CbluetoothtestContainer::~CbluetoothtestContainer()
{
  CleanupComponents();
  iCtrlArray.Reset();
  delete iSocket;
  delete iDiscovery;
  delete iSecurity;
  delete iParameters;
  delete iCamera;
}


void CbluetoothtestContainer::InitComponents()
{
  /* 1/16/04 4:32 PM */
  CEikStatusPane * StatusPane = iEikonEnv->AppUiFactory()->StatusPane();
  StatusPane->MakeVisible( ETrue );
  CAknContextPane * cAknContextPane1 =
       ( CAknContextPane * ) iEikonEnv->AppUiFactory()->StatusPane()->ControlL( TUid::Uid( EEikStatusPaneUidContext ) );
  /* FIXME CAknContextPane - Missing Property Setter snippet: "MBM file" */
  /* FIXME CAknContextPane - Missing Property Setter snippet: "Image index" */
  /* FIXME CAknContextPane - Missing Property Setter snippet: "Mask index" */
  CAknTitlePane * cAknTitlePane1 =
       ( CAknTitlePane * ) iEikonEnv->AppUiFactory()->StatusPane()->ControlL( TUid::Uid( EEikStatusPaneUidTitle ) );
  cAknTitlePane1->SetTextL( _L( "bluetooth" ) );
  /* FIXME CAknTitlePane - Missing Property Setter snippet: "MBM file" */
  /* FIXME CAknTitlePane - Missing Property Setter snippet: "Image index" */
  CAknNavigationControlContainer * cAknNavigationControlContainer1 =
       ( CAknNavigationControlContainer * )
       iEikonEnv->AppUiFactory()->StatusPane()->ControlL( TUid::Uid( EEikStatusPaneUidNavi ) );
  /* FIXME CAknNavigationControlContainer - Missing Property Setter snippet: "MBM file" */
  /* FIXME CAknNavigationControlContainer - Missing Property Setter snippet: "Image index" */
  /* FIXME CAknNavigationControlContainer - Missing Property Setter snippet: "Tab group" */
  iBackgroundColor = iEikonEnv->Color( EColorControlBackground );
  cEikLabel1 = new( ELeave )CEikLabel;
  cEikLabel1->SetContainerWindowL( * this );
  iCtrlArray.Append( cEikLabel1 );
  cEikLabel1->SetDimmed( EFalse );
  cEikLabel1->SetFocus( ETrue );
  cEikLabel1->SetExtent( TPoint( 9, 27 ), TSize( 153, 61 ) );
  cEikLabel1->SetAlignment( ( TGulAlignmentValue )( EHCenter | EVCenter ) );
  cEikLabel1->SetTextL( _L( "inactive" ) );
  cEikLabel1->SetFont( LatinBold13() );
  cEikLabel1->SetEmphasis( CEikLabel::ENoEmphasis );
  cEikLabel1->SetPixelGapBetweenLines( 1 );
  cEikLabel1->SetUnderlining( EFalse );
  cEikLabel1->SetStrikethrough( EFalse );
}

void CbluetoothtestContainer::CleanupComponents()
{
  /* 1/16/04 4:32 PM */
  delete cEikLabel1;
}

void CbluetoothtestContainer::ConstructL(const TRect& aRect)
{
  CreateWindowL();
  SetRect(aRect);
  InitComponents();

  TUid aUid = {0x12343210};
  iParameters = new (ELeave)CBtParameters();
  iParameters->SetBluetoothServiceId(aUid);
  iParameters->SetProtocolId(KSolBtL2CAP);
  iParameters->SetChannelId(0x1003);
//  iParameters->SetProtocolId(KSolBtRFCOMM);
//  iParameters->SetChannelId(3);
  iSecurity = new (ELeave) CBtSecurity(iParameters);
  TEventT<CbluetoothtestContainer, int>onSecurityEvent(this, &CbluetoothtestContainer::RegisterComplete);
  iSecurity->SetBluetoothSecurityEvent(onSecurityEvent);
  
  iDiscovery = new (ELeave) CBtDiscovery(0);
  iDiscovery->ConstructL();

  TEventT<CbluetoothtestContainer>onFound(this, &CbluetoothtestContainer::DeviceFound);
  iDiscovery->SetOnDeviceFound(onFound);
  TEventT<CbluetoothtestContainer, int>onDiscoveryError(this, &CbluetoothtestContainer::DiscoveryError);
  iDiscovery->SetOnError(onDiscoveryError);

//  iClientSocket = CTCPClientSocket::NewL(10, 10, 0);

  iSocket = CBtSocket::NewL(iParameters, 1024, 1024, 0);

  TEventT<CbluetoothtestContainer, int>onAccept(this, &CbluetoothtestContainer::AcceptComplete);
  iSocket->SetOnAcceptComplete(onAccept);

  TEventT<CbluetoothtestContainer>onConnect(this, &CbluetoothtestContainer::ConnectComplete);
  iSocket->SetOnConnect(onConnect);

  TEventT<CbluetoothtestContainer, int>onWrite(this, &CbluetoothtestContainer::SendComplete);
  iSocket->SetOnWriteComplete(onWrite);

  TEventT<CbluetoothtestContainer, int, const TDesC8&>onRecv(this, &CbluetoothtestContainer::RecvComplete);
  iSocket->SetOnRecvComplete(onRecv);

  iCamera = CCamera::NewL(0);

  TEventT<CbluetoothtestContainer, int> cameraOn(this, &CbluetoothtestContainer::CameraTurnedOn);
  iCamera->SetOnCameraOn(cameraOn);
  TEventT<CbluetoothtestContainer, CFbsBitmap &, int> pictureTaken(this, &CbluetoothtestContainer::PictureTaken);
  iCamera->SetOnPictureTaken(pictureTaken);

//	TBTDeviceClass bt(0,0,0);

  ActivateL();

}


void CbluetoothtestContainer::Draw(const TRect& aRect) const
{
  CWindowGc& gc = SystemGc();
  gc.SetPenStyle(CGraphicsContext::ENullPen);
  gc.SetBrushColor(iBackgroundColor);
  gc.SetBrushStyle(CGraphicsContext::ESolidBrush);
  gc.DrawRect(aRect);
}

TInt CbluetoothtestContainer::CountComponentControls() const
{
  return iCtrlArray.Count();
}

CCoeControl* CbluetoothtestContainer::ComponentControl(TInt aIndex) const
{
  return (CCoeControl*)iCtrlArray[aIndex];
}

TKeyResponse CbluetoothtestContainer::OfferKeyEventL(const TKeyEvent& aKeyEvent, TEventCode aType)
{
  /**
  * place code here to act on the users key event, or pass this to a child control
  * to be handled internally by that control.
  *
  * For example:
  *   return myControl->OfferKeyEventL(aKeyEvent, aType);
  */
  return EKeyWasNotConsumed; // or EKeyWasConsumed if handled in this function
}

void CbluetoothtestContainer::StartDiscovery()
{
  cEikLabel1->SetTextL(_L("discovery"));
  iDiscovery->FindDevices();
}

void CbluetoothtestContainer::DeviceFound(CBase * aDiscovery)
{
  cEikLabel1->SetTextL(_L("device found"));
  DrawNow();
}

void CbluetoothtestContainer::DiscoveryError(CBase * aDiscovery, int aErrorCode)
{
  cEikLabel1->SetTextL(_L("discovery error"));
  DrawNow();
}

void CbluetoothtestContainer::StartConnect()
{
  cEikLabel1->SetTextL(_L("connecting..."));
  DrawNow();
	iSocket->OpenL(EFalse);
	iSocket->SetPort();
	iSocket->SetAddr(iDiscovery->BDAddr());
	iSocket->ConnectL();
}

void CbluetoothtestContainer::StartAccept()
{
  cEikLabel1->SetTextL(_L("listening..."));
  DrawNow();
	iSocket->OpenL(ETrue);
	iSocket->ListenL();
}

void CbluetoothtestContainer::StartRegister()
{
  cEikLabel1->SetTextL(_L("register..."));
  DrawNow();
  iSecurity->RegisterServiceL();
}

void CbluetoothtestContainer::StartSend()
{
	iSocket->WriteL(_L8("Hello!"));
}

void CbluetoothtestContainer::StartRecv()
{
	if(iParameters->ChannelId() == KSolBtRFCOMM)
	{
		iSocket->RecvOneOrMore();
	}
	else
	{
		iSocket->Recv();
	}
}

void CbluetoothtestContainer::StartCamera()
{
	iCamera->TurnOn();
}

void CbluetoothtestContainer::TakePicture()
{
	iCamera->TakePicture();
}

void CbluetoothtestContainer::SocketStateChange(CBase * aSocket, int aState)
{
  cEikLabel1->SetTextL(_L("State Change"));
  DrawNow();
}

void CbluetoothtestContainer::SocketError(CBase * aSocket, int aErrorCode)
{
  cEikLabel1->SetTextL(_L("Socket error"));
  DrawNow();
}

void CbluetoothtestContainer::AcceptComplete(CBase * aSocket, int aErrorCode)
{
  cEikLabel1->SetTextL(_L("Accept Complete"));
  DrawNow();
}

void CbluetoothtestContainer::ConnectComplete(CBase * aSocket)
{
  cEikLabel1->SetTextL(_L("Connect Complete"));
  DrawNow();
}

void CbluetoothtestContainer::RegisterComplete(CBase * aSocket, int aErrorCode)
{
  cEikLabel1->SetTextL(_L("Register Complete"));
  DrawNow();
}

void CbluetoothtestContainer::RecvComplete(CBase * aSocket, int aErrorCode, const TDesC8& aRecvBuf)
{
	TBuf<64> buf2;
	buf2.Copy(aRecvBuf);
	TBuf<64> buf(_L("Recv: "));
	buf.Append(buf2);
  cEikLabel1->SetTextL(buf);
  DrawNow();
}

void CbluetoothtestContainer::SendComplete(CBase * aSocket, int aErrorCode)
{
  cEikLabel1->SetTextL(_L("Send Complete"));
  DrawNow();
}

void CbluetoothtestContainer::CameraTurnedOn(CBase * aCamera, int aErrorCode)
{
  cEikLabel1->SetTextL(_L("Camera Turned On"));
  DrawNow();
}



void CbluetoothtestContainer::PictureTaken(CBase * aCamera, CFbsBitmap & aBitmap, int aErrorCode)
{
	if(!aErrorCode)
	{
		TPoint p(10,10);
		TRect r(10, 10, 10+aBitmap.SizeInPixels().iWidth, 10+aBitmap.SizeInPixels().iHeight);

		CWindowGc & gc = CCoeEnv::Static()->SystemGc();
		gc.Activate(Window());
		Window().Invalidate(r);
		Window().BeginRedraw(r);

		gc.BitBlt(p, &aBitmap);

		Window().EndRedraw();
		gc.Deactivate();

		iCamera->TakePicture();
//		  cEikLabel1->SetTextL(_L("Picture taken"));
//		  DrawNow();
	}
	else
	{
	  cEikLabel1->SetTextL(_L("Picture Error"));
	  DrawNow();
	}



}

