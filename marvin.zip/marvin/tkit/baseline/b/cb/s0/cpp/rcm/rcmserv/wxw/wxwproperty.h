#ifndef wxwpropertyH
#define wxwpropertyH

#include "wxw.h"

class xtiProperty;

typedef pair<const wxString, xtiProperty*> PropertyPair;
typedef hash_map<wxString, xtiProperty*, hash<wxString&> > PropertyHash;

class RCMEXPORT wxPropertyBase : public wxObject, public ChoiceProvider, public rcmProperty
{
DECLARE_ABSTRACT_CLASS(wxPropertyBase)
public:
    wxPropertyBase();

	void Init(
	    wxwDesigner *designer = 0,
	    wxObject *instance = 0,
	    wxPropertyBase *parent = 0,
	    const wxString &name = "");

	wxObject* Instance() const { return FInstance; }
	wxwDesigner* wxDesigner() const { return FDesigner; }

    // ChoiceProvider
    virtual void GetChoices(PropertyChoices &choices) { }

	// rcmProperty
	virtual rcmDesigner* Designer() const;
	virtual	wxString Description() const;
	virtual int	Flags() const { return FFlags; }
	virtual wxString IconURI() const { return ""; }
	virtual void GetChildren(rcmProperties &subProps);
    virtual rcmProperty* GetChildProperty(const wxString &propName);
	virtual wxString GetValue() const;
	virtual bool IsModified() const { return false; } // for now.
	virtual const wxArrayString& Keys() const;
	virtual wxString Name() const { return FName; }
	virtual rcmProperty* Parent() const { return FParent; }
	virtual Result* Revert();
	virtual bool SetValue(const wxString &value);
	virtual wxString Signature() { return ""; }
	virtual wxString TypeKey() const { return FName; }
protected:
    virtual void ChildChanged(wxPropertyBase *child);
    virtual wxString Get() const = 0;
    virtual void Set(const wxString &value) = 0;
    PropertyHash FChildren;
    int FFlags;
private:
	wxString FName;
    wxString FDescription;
	wxwDesigner *FDesigner;
	wxPropertyBase *FParent;
	wxObject* FInstance;
    wxArrayString FKeys;
};

class RCMEXPORT xtiProperty : public wxPropertyBase
{
DECLARE_DYNAMIC_CLASS(xtiProperty)
public:
	xtiProperty();

	virtual void Create(
		const wxPropertyInfo *propInfo,
		wxwDesigner *designer = 0,
		wxObject *instance = 0,
		wxPropertyBase *parent = 0,
		const wxString &name = "");

	virtual wxObject* GetPropInstance();
	const wxPropertyInfo* PropInfo() const { return FPropInfo; }
	virtual const wxTypeInfo* TypeInfo() const;

	virtual	wxString Description() const;
	virtual wxString Signature() { return ""; }
	virtual wxString TypeKey() const;

protected:
	virtual wxString Get() const;
	virtual void Set(const wxString &value);
    // override for validation, etc.
    virtual wxxVariant GetAsVariant() const;
    // override for validation, etc.
    virtual void SetAsVariant(const wxxVariant &value);
	const wxPropertyInfo *FPropInfo;
};

class wxEnumProperty : public xtiProperty
{
DECLARE_DYNAMIC_CLASS(wxEnumProperty)
public:
	wxEnumProperty() : xtiProperty()
    {
        FFlags = PE_NOEDIT | PE_STATICVALUELIST;
    }
    virtual void GetChoices(PropertyChoices &choices);
};

class wxIntProperty : public xtiProperty
{
DECLARE_DYNAMIC_CLASS(wxIntProperty)
public:
	wxIntProperty() : xtiProperty() { }
protected:
	virtual wxString Get() const;
    virtual void Set(const wxString &value);
};

class wxUCharProperty : public xtiProperty
{
DECLARE_DYNAMIC_CLASS(wxUCharProperty)
public:
	wxUCharProperty() : xtiProperty() { }
protected:
    virtual void Set(const wxString &value);
};

class wxCharProperty : public xtiProperty
{
DECLARE_DYNAMIC_CLASS(wxCharProperty)
public:
	wxCharProperty() : xtiProperty() { }
protected:
    virtual void Set(const wxString &value);
};

class wxObjectProperty : public xtiProperty
{
DECLARE_DYNAMIC_CLASS(wxObjectProperty)
public:
    wxObjectProperty() : xtiProperty()
    {
        FFlags |= PE_NOEDIT;
    }

    virtual int Flags() const;
    virtual void GetChildren(rcmProperties &subProps);
    virtual rcmProperty* GetChildProperty(const wxString &name);
protected:
	bool HasProperties() const;
	virtual wxString Get() const;
};

class wxObjectRefProperty : public xtiProperty
{
DECLARE_DYNAMIC_CLASS(wxObjectRefProperty)
public:
    wxObjectRefProperty() : xtiProperty()
    {
        propInstance = NULL;
        FFlags |= PE_NOEDIT | PE_SUBPROPS;
    }
    virtual ~wxObjectRefProperty();
    virtual void GetChildren(rcmProperties &subProps);
    rcmProperty* GetChildProperty(const wxString &name);
    virtual wxObject* GetPropInstance();
    virtual void ChildChanged(wxPropertyBase *child);
protected:
	virtual wxString Get() const;
private:
    wxxVariant* propInstance;
};

class wxCollectionProperty;

class wxCollectionItem : public xtiProperty
{
public:
    wxCollectionItem(wxxVariant &value, int index);
    int GetIndex() { return FIndex; }
    virtual wxString Get() const;
    virtual void Set(const wxString &value) { /* do nothing for now */ }
	virtual wxString TypeKey() const;
private:
    wxxVariant FValue;
    int FIndex;
};

class wxCollectionProperty : public xtiProperty
{
DECLARE_DYNAMIC_CLASS(wxCollectionProperty)
public:
	wxCollectionProperty() : xtiProperty()
	{
        FFlags |= PE_NOEDIT | PE_READONLY;
	}
	virtual ~wxCollectionProperty() { }
    const wxTypeInfo* ElementType() const;
    virtual int Flags() const;
	virtual void Create(
	    const wxPropertyInfo *propInfo = 0,
	    wxwDesigner *designer = 0,
	    wxObject *instance = 0,
	    wxPropertyBase *parent = 0,
	    const wxString &name = "");

protected:
	virtual wxString Get() const;
    virtual void Set(const wxString &value) { /* this should never be called */ }
};

class wxBooleanProperty : public xtiProperty
{
DECLARE_DYNAMIC_CLASS(wxBooleanProperty)
public:
    wxBooleanProperty() : xtiProperty()
    {
        FFlags |= PE_NOEDIT | PE_STATICVALUELIST;
    }
    virtual void GetChoices(PropertyChoices &choices);
};

// Set property editor

class wxSetProperty;

class wxSetElementProperty : public wxBooleanProperty
{
public:
    wxSetElementProperty();
	virtual wxString TypeKey() const;
protected:
    virtual void Set(const wxString &value);
    virtual wxString Get() const;
    wxSetProperty* ParentSet() const;
    int Value() const;
};


class wxSetProperty : public xtiProperty
{
DECLARE_DYNAMIC_CLASS(wxSetProperty)
friend class wxSetElementProperty;
public:
    wxSetProperty() : xtiProperty()
    {
        FFlags |= PE_NOEDIT | PE_SUBPROPS;
    }

	virtual void Create(
	    const wxPropertyInfo *propInfo = 0,
	    wxwDesigner *designer = 0,
	    wxObject *instance = 0,
	    wxPropertyBase *parent = 0,
	    const wxString &name = "");

private:
	const wxEnumTypeInfo *FTypeInfo;
    const wxEnumData *FEnumData;
};

/*
	Iterate through the list of registered property classes and retrieve the
	most appropriate type based on property info, class info, and name.
*/
const wxClassInfo* GetPropertyEditorClass(const wxPropertyInfo *propInfo, wxObject *instance);

/*
	Recursively enumerate a wxObject's wxPropertyInfos, and create appropriate
	property instances based on GetPropertyEditorClass.
*/
void RecurseObjectProperties(rcmProperties &props, wxPropertyBase *parentProp,
    const wxClassInfo *classInfo, wxObject *object, wxwDesigner *designer);
#endif
