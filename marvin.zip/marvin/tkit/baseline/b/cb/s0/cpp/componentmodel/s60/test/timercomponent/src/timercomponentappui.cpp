////////////////////////////////////////////////////////////////////////////////
// Implementation of CtimercomponentAppUi
////////////////////////////////////////////////////////////////////////////////

#include <e32std.h>
#include "timercomponentappui.h"
#include "timercomponentview.h"

void CtimercomponentAppUi::ConstructL()
{
  BaseConstructL();

  itimercomponentView = CtimercomponentView::NewL();

  AddViewL(itimercomponentView);
  SetDefaultViewL(*itimercomponentView);
}

void CtimercomponentAppUi::HandleCommandL(TInt aCommand)
{
  switch (aCommand) {
    case EEikCmdExit:
    case EAknSoftkeyExit:
      Exit();
      break;
    case ETimeoutTimer:
        iTime
        break;
//    default:
//      Panic(L"Resource me");
//      break;
  }
}

