#ifndef __BLUETOOTHTEST_CONTAINER_H__
#define __BLUETOOTHTEST_CONTAINER_H__


#include <coecntrl.h>
#include <txtfmlyr.h>
#include <aknview.h>
#include <akncontext.h>
#include <akntitle.h>
#include <aknnavi.h>
#include <akntabgrp.h>
#include <aknnavide.h>
#include <eiklbo.h>

#include "btParameters.h"
#include "btSecurity.h"
#include "btDiscovery.h"
#include "btSocket.h"
#include "btSdpQuery.h"
#include "btSdpRegistry.h"


#include "activeobject.h"
#include "etelphone.h"
#include "etelline.h"
#include "etelcall.h"
#include "camera.h"

#include "beatingheartbeat.h"

class CEikEdwin;
class CEikGlobalTextEditor;
class CEikLabel;
class CAknSlider;
class CEikColumnListBox;
class CAknSingleStyleListBox;
class CEikTimeEditor;
class CAknNumericSecretEditor;
class CAknIpFieldEditor;
class CEikTimeAndDateEditor;
class CEikRangeEditor;
class CEikProgressInfo;
class CEikDateEditor;
class CEikDurationEditor;
class CAknNumericEdwin;
class CAknIntegerEdwin;
class CEikFloatingPointEditor;
class CEikFixedPointEditor;


// CbluetoothtestContainer
class CbluetoothtestContainer : public CCoeControl, public MCoeControlObserver {

  RPointerArray<CCoeControl> iCtrlArray;
  TRgb iBackgroundColor;
public :
  /**
   * Creates a CbluetoothtestContainer object
   */
  static CbluetoothtestContainer * NewL(const TRect& aRect);

  /**
   * Creates a CbluetoothtestView object
   */
  static CbluetoothtestContainer * NewLC(const TRect& aRect);


  /**
   * Performs second pahese construction of this Container
   */
  void ConstructL(const TRect & aRect);

  /**
   * Returns the number of controls contained in this compound control
   */
  TInt CountComponentControls()const;

  /**
   * Returns the component at the specified index
   * @param aIndex specifies index of component
   * @return Pointer to component control
   */
  CCoeControl * ComponentControl(TInt aIndex)const;

  /**
   * Draws this container
   */
  void Draw(const TRect& aRect) const;

  /**
   * Destroys container
   */
  ~CbluetoothtestContainer();

  void HandleControlEventL(CCoeControl * aControl, TCoeEvent aEventType){}

/**
 * Overridden function used to pass key events to child controls owned by this container
 */
  TKeyResponse OfferKeyEventL(const TKeyEvent& aKeyEvent, TEventCode aType);



CBtParameters * iParameters;
CBtSecurity * iSecurity;
CBtDiscovery * iDiscovery;
CBtSocket * iSocket;


CCamera * iCamera;


//CTCPClientSocket * iClientSocket;

	void StartDiscovery();

	void DeviceFound(CBase * aDiscovery);
	void DiscoveryError(CBase * aDiscovery, int aErrorCode);

	void StartConnect();
	void StartAccept();
	void StartRegister();
	void StartSend();
	void StartRecv();

	void StartCamera();
	void TakePicture();

	void SocketStateChange(CBase * aSocket, int aState);
	void SocketError(CBase * aSocket, int aErrorCode);

	void AcceptComplete(CBase * aSocket, int aErrorCode);
	void ConnectComplete(CBase * aSocket);
	void RegisterComplete(CBase * aSocket, int aErrorCode);
	void RecvComplete(CBase * aSocket, int aErrorCode, const TDesC8& aRecvBuf);
	void SendComplete(CBase * aSocket, int aErrorCode);

	void CameraTurnedOn(CBase * aCamera, int aErrorCode);
	void PictureTaken(CBase * aCamera, CFbsBitmap & aBitmap, int aErrorCode);

private:

  /**
   * Routine that initializes components owned by this Container
   */
  void InitComponents();

  /**
   * Routine that cleans up components owned by this container
   */
  void CleanupComponents();


private:
  //IDE-MANAGED-START
  /* 1/16/04 4:32 PM */
  CEikLabel * cEikLabel1;

  //IDE-MANAGED-END
};

#endif // __BLUETOOTHTEST_CONTAINER_H__
