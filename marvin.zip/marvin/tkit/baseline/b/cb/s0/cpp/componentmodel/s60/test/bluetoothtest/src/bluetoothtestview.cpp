////////////////////////////////////////////////////////////////////////////////
// Implementation of CbluetoothtestView
////////////////////////////////////////////////////////////////////////////////


#include <e32std.h>
#include <aknviewappui.h>
#include <aknconsts.h>
#include "bluetoothtestview.h"
#include "bluetoothtestcontainer.h"
#include <bluetoothtest.rsg>
#include "bluetoothtest.hrh"

#include "bluetoothtestappui.h"

const TUid EDefaultViewId = { 1 };

CbluetoothtestView* CbluetoothtestView::NewL()
{
  CbluetoothtestView* self = CbluetoothtestView::NewLC();
  CleanupStack::Pop(self);
  return self;
}

CbluetoothtestView* CbluetoothtestView::NewLC()
{
  CbluetoothtestView* self = new (ELeave) CbluetoothtestView();
  CleanupStack::PushL(self);
  self->ConstructL();
  return self;
}

CbluetoothtestView::CbluetoothtestView()
{
}

CbluetoothtestView::~CbluetoothtestView()
{
}

void CbluetoothtestView::ConstructL()
{
  BaseConstructL(R_DEFAULT_VIEW);
}

TUid CbluetoothtestView::Id() const
{
  return EDefaultViewId;
}

void CbluetoothtestView::DoActivateL(const TVwsViewId& aPrevViewId,
                                   TUid aCustomMessageId,
                                   const TDesC8& aCustomMessage)
{
  ASSERT(container == NULL);
  container = CbluetoothtestContainer::NewL(ClientRect());
  container->SetMopParent(this);
  AppUi()->AddToStackL(*this, container); 
}

void CbluetoothtestView::DoDeactivate()
{
  if (container)
  {
    AppUi()->RemoveFromStack(container);
    delete container;
    container = NULL;
  }
}

void CbluetoothtestView::HandleCommandL(TInt aCommand)
{
	switch(aCommand)
	{
	case EStartDiscovery:
		container->StartDiscovery();
		break;
	case EStartConnect:
		container->StartConnect();
		break;
	case EStartAccept:
		container->StartAccept();
		break;
	case EStartRegister:
		container->StartRegister();
		break;
	case EStartSend:
		container->StartSend();
		break;
	case EStartRecv:
		container->StartRecv();
		break;
	case EStartCamera:
		container->StartCamera();
		break;
	case ETakePicture:
		container->TakePicture();
		break;
	default:
	  AppUi()->HandleCommandL(aCommand);
	}
}

