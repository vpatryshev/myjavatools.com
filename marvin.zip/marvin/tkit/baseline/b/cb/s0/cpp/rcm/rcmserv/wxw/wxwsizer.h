#ifndef wxwsizerH
#define wxwsizerH

#include "wxw.h"
#include "wx/gbsizer.h"
#include "wxwuicomponent.h"
#include "wxwuicontainer.h"
#include "wxwcomponenteditor.h"

class wxGBSizerProxy;

/*
  wxSizerItemSpanProperty
  A special property editor for wxGBSizerItem::Span, since if an
  existing sizer item is in the way, wxGridBagSizer will assert.
*/

class wxSizerItemSpanProperty : public xtiProperty
{
DECLARE_DYNAMIC_CLASS(wxSizerItemSpanProperty)
protected:
    virtual void SetAsVariant(const wxxVariant &value);
    wxGBSizerItem* Item() { return dynamic_cast<wxGBSizerItem*>(Instance()); }
};

/*
  wxSizerItemPosProperty
  A special property editor for wxGBSizerItem::Pos, since if an
  existing sizer item is in the way, wxGridBagSizer will assert.
*/

class wxSizerItemPosProperty : public xtiProperty
{
DECLARE_DYNAMIC_CLASS(wxSizerItemPosProperty)
protected:
    virtual void SetAsVariant(const wxxVariant &value);
    wxGBSizerItem* Item() { return dynamic_cast<wxGBSizerItem*>(Instance()); }
};

class RCMEXPORT wxGBSizerProxy : public wxwUIComponent, public wxwUIContainer
{
public:
	wxGBSizerProxy(wxwDesigner *designer, wxwContainer *container);
    virtual ~wxGBSizerProxy();

    void ForceLayout();
    wxGBPosition GetExtent();
    void GetSize(int &w, int &h);
    wxGBPosition GetPositionFromPoint(int x, int y);
    wxGridBagSizer* Sizer() { return FSizer; }
    bool IsColumnGrowable(int col);
    bool IsRowGrowable(int row);
    void SetColGrowable(int col, bool growable);
    void SetRowGrowable(int row, bool growable);

    // wxwComponent
    virtual void GetExtraProperties(wxwComponent *child, rcmProperties &props);
    virtual rcmProperty* GetExtraProperty(wxwComponent *child, wxArrayString &propPath);
    virtual void GetProperties(rcmProperties &props);
    virtual rcmProperty* GetProperty(wxArrayString &propPath);
    virtual void ObjectCreated(bool fromXRC = false);
    virtual void PropertyChanged(const wxPropertyBase *property);
    virtual void Recreate() { wxASSERT_MSG(0, "Cannot recreate a sizer yet"); }

    // wxwContainer
	virtual bool CanParentType(const wxClassInfo *type);
    virtual void NotifyChildBoundsChanged(wxwUIComponent *child);
    virtual bool NotifyChildBoundsChanging(int &x, int &y, int &w, int &h, wxwUIComponent *child);
    virtual void NotifyChildInserted(wxwComponent *newChild);
    virtual void NotifyChildRemoved(wxwComponent *child);
    virtual wxObject* ParentInstance();
    virtual bool IsContainer() { return true; } //remove this. test.
    // rcmUIComponent
	virtual bool ConstrainChildren();
    virtual int GetZOrderPosition();
	virtual Result* SetZOrderPosition(rcmComponent *child, int z);
    virtual bool Visible();

protected:
    virtual void ConstructXTIObject(wxObject *object);
    virtual void DoGetRect(int &x, int &y, int &w, int &h);
    virtual void DoSetRect(int &x, int &y, int &w, int &h, bool testOnly = false);
    wxGBSizerItem* GetSizerItem(wxwComponent *child);
private:
	wxGBPosition CalcNewPosition(int x, int y);
    bool Valid(const wxGBPosition &pos);
    bool Valid(const wxGBSpan &span);
    wxGBPosition FindEmptyCell();
    wxGridBagSizer *FSizer;
};

class RCMEXPORT wxSizerPainter : public wxPainter
{
DECLARE_DYNAMIC_CLASS(wxSizerPainter)
public:
	wxSizerPainter() { }
    virtual void PaintObject(wxObject *object, wxDC &dc);
};

class wxGBSizerEditor : public wxwComponentEditorT<wxGridBagSizer>
{
DECLARE_DYNAMIC_CLASS(wxGBSizerEditor)
public:
 	wxGBSizerEditor() : wxwComponentEditorT<wxGridBagSizer>() { }
    virtual void UpdateMenu(MenuItems &menu, int x, int y);
protected:
    void MenuItemClicked(MenuItem *item, Result *&result);
	int CmdToId(unsigned short cmd, unsigned short data);
	wxGBSizerProxy* SizerProxy() { return dynamic_cast<wxGBSizerProxy*>(Component()); }
};

class RCMEXPORT wxGridBagSpacer : public wxwUIComponent
{
public:
	wxGridBagSpacer(wxwDesigner *designer, wxwContainer *container);
    ~wxGridBagSpacer();

protected:
    virtual void ConstructXTIObject(wxObject *object);
    virtual void DoGetRect(int &x, int &y, int &w, int &h);
    wxGBSizerItem* Item() { return dynamic_cast<wxGBSizerItem*>(Instance()); }
    virtual void DoSetRect(int &x, int &y, int &w, int &h, bool testOnly);

};

class RCMEXPORT wxGBSpacerPainter : public wxPainter
{
DECLARE_DYNAMIC_CLASS(wxGBSpacerPainter)
public:
	wxGBSpacerPainter() { }
    virtual void PaintObject(wxObject *object, wxDC &dc);
};

#endif
