#ifndef eventsH
#define eventsH

#include <stdio.h>
#include <assert.h>

class NotAType
{
private:
   NotAType(){};
};


/**
 The following approach is a little bigger - each closure is really a pointer to a dispatcher
 which in turns contains the pointer to the instance and the method.

 The big advantage of the following approach is that there's not assumption that that sinks
 are derived from a particular base class.

 Also this approach does not make any assumptions on how a compiler chooses to implement
 pointer to member function. It's definitely the most portable.


  1. The syntax is identical to native CBuilder closures from the source point of view. 
     For example:

      class TButton {
        rcmEvent FOnClick;

      public:
        void Click() {
          if (FOnClick)
            FOnClick(this);
        }
      };

  2. The syntax difference is at the sink level. To receive a click event from a button,
     a form would do the following:


          FButton1->SetOnClick(TEventT<Form1>(&form1, &Form1::Button1Click));


*/


template <typename T0, typename P1 = NotAType, typename P2 = NotAType,
	typename P3 = NotAType, typename P4 = NotAType>
class TEventBase
{
protected:
public:

	class Dispatcher0	{
	public:
		virtual void Dispatch(T0*) = 0;
	};

	class Dispatcher1 {
	public:
		virtual void Dispatch(T0*, P1) = 0;
	};

	class Dispatcher2 {
	public:
		virtual void Dispatch(T0*, P1, P2) = 0;
	};

	class Dispatcher3 {
	public:
		virtual void Dispatch(T0*, P1, P2, P3) = 0;
	};

	class Dispatcher4 {
	public:
		virtual void Dispatch(T0*, P1, P2, P3, P4) = 0;
	};

	union {
		Dispatcher0* FDispatcher0;
		Dispatcher1* FDispatcher1;
		Dispatcher2* FDispatcher2;
		Dispatcher3* FDispatcher3;
		Dispatcher4* FDispatcher4;
	};

public:
	TEventBase() : FDispatcher0(0) {}
	TEventBase(Dispatcher0* d) : FDispatcher0(d) {}
	TEventBase(Dispatcher1* d) : FDispatcher1(d) {}
	TEventBase(Dispatcher2* d) : FDispatcher2(d) {}
	TEventBase(Dispatcher3* d) : FDispatcher3(d) {}
	TEventBase(Dispatcher4* d) : FDispatcher4(d) {}

	~TEventBase() { Clear(); }

	void operator ()(T0* sender) {
		FDispatcher0->Dispatch(sender);
	}
	void operator ()(T0* sender, P1 p1) {
		FDispatcher1->Dispatch(sender, p1);
	}
	void operator ()(T0* sender, P1 p1, P2 p2) {
		FDispatcher2->Dispatch(sender, p1, p2);
	}
	void operator ()(T0* sender, P1 p1, P2 p2, P3 p3) {
		FDispatcher3->Dispatch(sender, p1, p2, p3);
	}
	void operator ()(T0* sender, P1 p1, P2 p2, P3 p3, P4 p4) {
		FDispatcher4->Dispatch(sender, p1, p2, p3, p4);
	}

	operator bool () const { return FDispatcher0 != 0; }

	TEventBase& operator=(int i) {
		assert(i==0); /* strictly for clearing out closure */
		Clear();
		return *this;
	}

	void Clear() {
		if (FDispatcher0) {
			delete FDispatcher0;
			FDispatcher0 = 0;
		}
	}

	TEventBase& operator=(TEventBase& src) {
		if (&src != this) {
			Clear();
			FDispatcher0 = src.FDispatcher0;
			src.FDispatcher0 = 0;
		}
		return *this;
	}

	TEventBase(TEventBase& src) {
		FDispatcher0 = src.FDispatcher0;
		src.FDispatcher0 = 0;
	}
};

template <class TSINK, class TSRC, typename P1 = NotAType, typename P2 = NotAType,
	typename P3 = NotAType, typename P4 = NotAType>
class TEventT : public TEventBase<TSRC, P1, P2, P3, P4>
{
public:
	typedef void (TSINK::*Method0)(TSRC*);
	typedef void (TSINK::*Method1)(TSRC*, P1);
	typedef void (TSINK::*Method2)(TSRC*, P1, P2);
	typedef void (TSINK::*Method3)(TSRC*, P1, P2, P3);
	typedef void (TSINK::*Method4)(TSRC*, P1, P2, P3, P4);

private:

	class DispatcherBase
	{
	public:
		TSINK*         Instance;
		union {
			Method0 M0;
			Method1 M1;
			Method2 M2;
			Method3 M3;
			Method4 M4;
		};
	};

	template <class TSINK>
	class DispatcherT0 : public TEventBase<TSRC, P1, P2, P3, P4>::Dispatcher0, public DispatcherBase
	{
		void Dispatch(TSRC* sender) {
			(Instance->*M0)(sender);	
		}
	};

	template <class TSINK>
	class DispatcherT1 : public TEventBase<TSRC, P1, P2, P3, P4>::Dispatcher1, public DispatcherBase
	{
		void Dispatch(TSRC* sender, P1 p1) {
			(Instance->*M1)(sender, p1);
		}
	};

	template <class TSINK>
	class DispatcherT2 : public TEventBase<TSRC, P1, P2, P3, P4>::Dispatcher2, public DispatcherBase
	{
		void Dispatch(TSRC* sender, P1 p1, P2 p2) {
			(Instance->*M2)(sender, p1, p2);
		}
	};

	template <class TSINK>
	class DispatcherT3 : public TEventBase<TSRC, P1, P2, P3, P4>::Dispatcher3, public DispatcherBase
	{
		void Dispatch(TSRC* sender, P1 p1, P2 p2, P3 p3) {
			(Instance->*M3)(sender, p1, p2, p3);
		}
	};

	template <class TSINK>
	class DispatcherT4 : public TEventBase<TSRC, P1, P2, P3, P4>::Dispatcher4, public DispatcherBase
	{
		void Dispatch(TSRC* sender, P1 p1, P2 p2, P3 p3, P4 p4) {
			(Instance->*M4)(sender, p1, p2, p3, p4);
		}
	};

public:
	TEventT(TSINK* instance, Method0 m) : TEventBase<TSRC, P1, P2, P3, P4>(new DispatcherT0<TSINK>) {
		static_cast<DispatcherT0<TSINK>*>(FDispatcher0)->Instance = instance;
		static_cast<DispatcherT0<TSINK>*>(FDispatcher0)->M0 = m;
	}
	TEventT(TSINK* instance, Method1 m) : TEventBase<TSRC, P1, P2, P3, P4>(new DispatcherT1<TSINK>) {
		static_cast<DispatcherT1<TSINK>*>(FDispatcher1)->Instance = instance;
		static_cast<DispatcherT1<TSINK>*>(FDispatcher1)->M1 = m;
	}
	TEventT(TSINK* instance, Method2 m) : TEventBase<TSRC, P1, P2, P3, P4>(new DispatcherT2<TSINK>) {
		static_cast<DispatcherT2<TSINK>*>(FDispatcher2)->Instance = instance;
		static_cast<DispatcherT2<TSINK>*>(FDispatcher2)->M2 = m;
	}
	TEventT(TSINK* instance, Method3 m) : TEventBase<TSRC, P1, P2, P3, P4>(new DispatcherT3<TSINK>) {
		static_cast<DispatcherT3<TSINK>*>(FDispatcher3)->Instance = instance;
		static_cast<DispatcherT3<TSINK>*>(FDispatcher3)->M3 = m;
	}
	TEventT(TSINK* instance, Method4 m) : TEventBase<TSRC, P1, P2, P3, P4>(new DispatcherT4<TSINK>) {
		static_cast<DispatcherT4<TSINK>*>(FDispatcher4)->Instance = instance;
		static_cast<DispatcherT4<TSINK>*>(FDispatcher4)->M4 = m;
	}
#if defined(__BORLANDC__)
    operator TEventBase<TSRC>()
    {
        return *(reinterpret_cast< TEventBase<TSRC> *>(this));
    }
    operator TEventBase<TSRC, P1>()
    {
        return *(reinterpret_cast< TEventBase<TSRC, P1> *>(this));
    }
    operator TEventBase<TSRC, P1, P2>()
    {
        return *(reinterpret_cast< TEventBase<TSRC, P1, P2> *>(this));
    }
        operator TEventBase<TSRC, P1, P2, P3>()
    {
        return *(reinterpret_cast< TEventBase<TSRC, P1, P2, P3> *>(this));
    }
    operator TEventBase<TSRC, P1, P2, P3, P4>()
    {
        return *(reinterpret_cast< TEventBase<TSRC, P1, P2, P3, P4> *>(this));
    }
#endif

};

#endif 


