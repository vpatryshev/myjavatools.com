#ifndef frmSetDefaultOptionsH
#define frmSetDefaultOptionsH

#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>

class TfrmSetDefaultFunctionOptions : public TForm
{
__published:
  TButton *btnOK;
  TButton *btnCancel;
  TPanel *pnlFunctionOptions;
    TCheckBox *cbxDisableFunctionTracking;
    TCheckBox *cbxMemoryAccessErrors;
    TCheckBox *cbxLogEachCall;
    TCheckBox *cbxWarnings;
    TCheckBox *cbxFunctionResultErrors;
    TCheckBox *cbxInvalidHandleOrResourceParameters;
public:
  __fastcall TfrmSetDefaultFunctionOptions(TComponent* Owner);
};

extern PACKAGE TfrmSetDefaultFunctionOptions *frmSetDefaultFunctionOptions;

#endif

