////////////////////////////////////////////////////////////////////////////////
// Implementation of CIRServerApplication
////////////////////////////////////////////////////////////////////////////////

#include "IRServerapp.h"
#include "IRServerdocument.h"

const TUid KUidIRServer = { 0x010000A0 };

TUid CIRServerApplication::AppDllUid() const
{
	return KUidIRServer;
}

CApaDocument* CIRServerApplication::CreateDocumentL()
{
	CApaDocument* document = CIRServerDocument::NewL(*this);
  return document;
}
