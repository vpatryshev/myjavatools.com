#include <stdio.h>
#include <stdlib.h>

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

static void usage(void)
{
    puts("usage: winpauseprogram pid");
    exit(1);
}

static void die(char const *msg)
{
    fprintf(stderr, "tgc fatal: %s: GetLastError() %d\n",
	    msg, GetLastError());
    exit(1);
}

int main(int argc, char **argv)
{
    DWORD pid;
    HANDLE hproc;
    HANDLE hthread;
    void *start_addr;;

    if (argc != 2 || sscanf(argv[1], "%lu", &pid) != 1)
	usage();

    /*
     * get the address of IsBadCodePtr in our process, and hope that
     * it's the same in the target process.  this function is
     * essentially:
     *
     * BOOL WINAPI IsBadCodePtr(LPVOID addr)
     * {
     *     BOOL rc = addr != 0;
     *     if (rc) {
     *         try {
     *             c = *(char *)addr;
     *         }
     *         __except (1) {
     *             rc = FALSE;
     *         }
     *     }
     *     return rc;
     * }
     * 
     * we'll create a thread at that function with a non-zero but bogus
     * param (1) that will trigger the exception and wake up any
     * watching debugger.
     */
    start_addr = GetProcAddress(GetModuleHandle("kernel32"), "IsBadCodePtr");
    if (start_addr == 0) {
	/*
	 * don't try to jump to address 0, this will kill the target
	 * process.
	 */
	die("can't get address of kernel32.IsBadCodePtr");
    }

    hproc = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
    if (!hproc)
	die("OpenProcess failed");

    hthread = CreateRemoteThread(hproc, NULL, 16384,
	    (LPTHREAD_START_ROUTINE) start_addr,
	    (LPVOID) 1,
	    0, NULL);

    if (!hthread)
	die("CreateRemoteThread failed");

    return 0;
}