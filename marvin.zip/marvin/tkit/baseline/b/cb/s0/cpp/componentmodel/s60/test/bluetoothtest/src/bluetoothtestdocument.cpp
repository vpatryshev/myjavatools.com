////////////////////////////////////////////////////////////////////////////////
// Implementation of CbluetoothtestDocument
////////////////////////////////////////////////////////////////////////////////

#include "bluetoothtestappui.h"
#include "bluetoothtestdocument.h"


CbluetoothtestDocument::CbluetoothtestDocument(CEikApplication& aApp)
                       :CAknDocument(aApp)
{
}

CbluetoothtestDocument::~CbluetoothtestDocument()
{
}

CbluetoothtestDocument* CbluetoothtestDocument::NewL(CEikApplication& aApp)
{
  CbluetoothtestDocument* self = NewLC(aApp);
  CleanupStack::Pop(self);
  return self;
}

CbluetoothtestDocument* CbluetoothtestDocument::NewLC(CEikApplication& aApp)
{
  CbluetoothtestDocument* self = new (ELeave) CbluetoothtestDocument(aApp);
  CleanupStack::PushL(self);
  self->ConstructL();
  return self;
}

void CbluetoothtestDocument::ConstructL()
{
}

CEikAppUi* CbluetoothtestDocument::CreateAppUiL()
{
  return new(ELeave) CbluetoothtestAppUi;
}

