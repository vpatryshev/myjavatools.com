#ifndef __MAIN_VIEW_CONTAINER_H__
#define __MAIN_VIEW_CONTAINER_H__


#include <coecntrl.h>
#include <coecobs.h>
#include <agmmodel.h>
#include "AgendaEntryModel.h"
#include "AgendaInstanceModel.h"





class CMainViewContainer : public CCoeControl, public MCoeControlObserver 
{

public :
	/**
	* Creates a CMainViewContainer object
	*/
	static CMainViewContainer * NewL(const TRect& aRect);

	/**
	* Creates a CMainViewContainer object
	*/
	static CMainViewContainer * NewLC(const TRect& aRect);


	/**
	* Performs second pahese construction of this Container
	*/
	void ConstructL(const TRect & aRect);

	/**
	* Returns the number of controls contained in this compound control
	*/
	TInt CountComponentControls()const;

	/**
	* Returns the component at the specified index
	* @param aIndex specifies index of component
	* @return Pointer to component control
	*/
	CCoeControl * ComponentControl(TInt aIndex)const;

	/**
	* Draws this container
	*/
	void Draw(const TRect& aRect) const;

	/**
	* Destroys container
	*/
	~CMainViewContainer();

	void HandleControlEventL(CCoeControl * aControl, TCoeEvent aEventType);

	/**
	* Overridden function used to pass key events to child controls owned by this container
	*/
	TKeyResponse OfferKeyEventL(const TKeyEvent& aKeyEvent, TEventCode aType);

    static TInt DoStartTest(TAny* aThis);
    void MyStateCallback(CBase * aAgnThing, CAgnEntryModel::TState aState);


private:

	/**
	* Routine that initializes components owned by this Container
	*/
	void InitComponents();

	/**
	* Routine that cleans up components owned by this container
	*/
	void CleanupComponents();

	void RunContactTest();
    void RunAgendaInstanceTest();
    void RunAgendaEntryTest();

private:
    CPeriodic* iStartTest;
    CAgendaInstanceModel* iAgnInstanceModel;
    CAgendaEntryModel* iAgnEntryModel;
    CAgnEntryModel::TState iModelState;
};

#endif // __MAIN_VIEW_CONTAINER_H__
