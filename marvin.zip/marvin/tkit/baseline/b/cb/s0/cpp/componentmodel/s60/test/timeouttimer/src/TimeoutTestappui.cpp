////////////////////////////////////////////////////////////////////////////////
// Implementation of CTimeoutTestAppUi
////////////////////////////////////////////////////////////////////////////////

#include <e32std.h>
#include "TimeoutTest.hrh"
#include "TimeoutTestappui.h"
#include "TimeoutTestview.h"


/**
 * Method managed by IDE to construct views
 * Please do not edit this routine as its
 * contents is regenerated upon new view creation.
 */
void CTimeoutTestAppUi::InitViewsL()
{
  iTimeoutTestView = CTimeoutTestView::NewL();
  AddViewL(iTimeoutTestView);
}

void CTimeoutTestAppUi::ConstructL()
{
  BaseConstructL();
  InitViewsL();

  // Set default view
  SetDefaultViewL(*iTimeoutTestView);
}

void CTimeoutTestAppUi::HandleCommandL(TInt aCommand)
{
  switch (aCommand) {
    case EEikCmdExit:
    case EAknSoftkeyExit:
      Exit();
      break;
    default:
      break;
  }
}

