#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>

DIR * procDir;
char * dirBuf = NULL;
int dirBufSize = 0;

// Get the next process id
long getNextPid()
{
  struct dirent * dirStruct = NULL;
  long pid = 0;
  // We screen on user ID
  uid_t uid = geteuid();
  while ( ( dirStruct = readdir( procDir ) ) != NULL )
  {
    // Try to get the process id
    char * namePtr = dirStruct->d_name;
    pid = strtol( dirStruct->d_name, & namePtr, 10 );
    if ( * namePtr == '\0' ) {
      // Screen on user  ID
      if( uid != ~0U ) {
        struct stat st;
        // Resize dirBuf
        int len = sizeof("/proc/") + strlen(dirStruct->d_name) + 1;
        if (dirBufSize < len) {
          free(dirBuf);
          dirBufSize *= 2;
          dirBuf = (char*)malloc(dirBufSize);
          if (dirBuf == NULL) {
            dirBufSize = 0;
            return -1;
          }
        }
        sprintf(dirBuf, "/proc/%s", dirStruct->d_name);
        if (-1 == stat(dirBuf, &st))
          continue;
        if( st.st_uid != uid )
          continue;
      }
      break;
    }
    pid = 0;
  }
  return pid;
}

char * pathBuf = NULL;

int pathBufSize = 0;

int printPifAndPath( long pid )
{
  char exeBuf[sizeof( "/proc//exe" ) + 16];
  int size = 0;
  sprintf( exeBuf, "/proc/%d/exe", pid );
  while ( 1 )
  {
    size = readlink( exeBuf, pathBuf, pathBufSize );
    if ( size < 0 )
      return 0;
    if (size >= pathBufSize) {
      free(pathBuf);
      pathBufSize *= 2;
      pathBuf = (char*)malloc(pathBufSize);
      if (pathBuf == NULL)
      	return -1;
      continue;
    }
    break;
  }
  pathBuf[size] = '\0';
  printf( "%d  %s\n", pid, pathBuf );
  return 0;
}

int main()
{
  procDir = opendir( "/proc" );
  if ( procDir == NULL )
    return -1;
  pathBufSize = 50;
  pathBuf = (char*)malloc( pathBufSize );
  if ( pathBuf == NULL )
    return -1;
  dirBufSize = 50;
  dirBuf = (char*)malloc( dirBufSize );
  if (dirBuf == NULL) {
    free( pathBuf );
    return -1;
  }
  while ( 1 )
  {
    long pid = getNextPid();
    if ( pid <= 0 )
      break;
    if (printPifAndPath( pid ) < 0)
      break;
  }
  if (pathBuf != NULL)
    free( pathBuf );
  if (dirBuf != NULL)
    free( dirBuf);
  return 0;
}
