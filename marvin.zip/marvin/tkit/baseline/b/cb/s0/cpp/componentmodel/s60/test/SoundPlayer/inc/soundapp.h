#ifndef __SOUNDAPP_H__
#define __SOUNDAPP_H__

#include <aknapp.h>

/*! 
  class CSoundApplication
  
*/

class CSoundApplication : public CAknApplication
    {
public: // from CAknApplication
/*! 
  AppDllUid
  
  Returns the application DLL UID value
  returns the UID of this Application/Dll
*/
    TUid AppDllUid() const;

protected: // from CAknApplication

/*! 
  CreateDocumentL
  
  Create a CApaDocument object and return a pointer to it
  returns a pointer to the created document
*/
    CApaDocument* CreateDocumentL();
    };

#endif // __SOUNDAPP_H__

