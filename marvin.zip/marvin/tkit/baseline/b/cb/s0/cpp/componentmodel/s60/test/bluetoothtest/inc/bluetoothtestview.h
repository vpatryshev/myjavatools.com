#ifndef __BLUETOOTHTEST_VIEW_H__
#define __BLUETOOTHTEST_VIEW_H__

#include <aknview.h>

// Forward ref. to container class
class CbluetoothtestContainer;


// CbluetoothtestView
class CbluetoothtestView : public CAknView
{
  public:

    /**
     * Creates a CbluetoothtestView object
     */
    static CbluetoothtestView* NewL();

    /**
     * Creates a CbluetoothtestView object
     */
    static CbluetoothtestView* NewLC();

    /**
     * Identify of this view to the system
     */
    TUid Id() const;

    /**
     * Command Handler
     */
    void HandleCommandL(TInt aCommand);


    /**
     * Activates this View
     */
    void DoActivateL(const TVwsViewId &PrevViewId, TUid  aCustomMessageId, const TDesC8& aCustomMessage);

    /**
     * Deactivate this view
     */
    void DoDeactivate();

  private:
    CbluetoothtestView();
   ~CbluetoothtestView();

    /**
     * Performs second phase construction of this view
     */
    void ConstructL();

    /**
     * Container for this view
     */
    CbluetoothtestContainer* container;

    /**
     * Identifier for this view
     */
    TUid iIdentifier;
};


#endif // __BLUETOOTHTEST_VIEW_H__

