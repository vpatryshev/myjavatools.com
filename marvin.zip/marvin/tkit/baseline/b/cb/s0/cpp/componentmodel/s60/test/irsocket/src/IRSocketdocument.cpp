////////////////////////////////////////////////////////////////////////////////
// Implementation of CIRSocketDocument
////////////////////////////////////////////////////////////////////////////////

#include "IRSocketappui.h"
#include "IRSocketdocument.h"


CIRSocketDocument::CIRSocketDocument(CEikApplication& aApp)
                       :CAknDocument(aApp)
{
}

CIRSocketDocument::~CIRSocketDocument()
{
}

CIRSocketDocument* CIRSocketDocument::NewL(CEikApplication& aApp)
{
  CIRSocketDocument* self = NewLC(aApp);
  CleanupStack::Pop(self);
  return self;
}

CIRSocketDocument* CIRSocketDocument::NewLC(CEikApplication& aApp)
{
  CIRSocketDocument* self = new (ELeave) CIRSocketDocument(aApp);
  CleanupStack::PushL(self);
  self->ConstructL();
  return self;
}

void CIRSocketDocument::ConstructL()
{
}

CEikAppUi* CIRSocketDocument::CreateAppUiL()
{
  return new(ELeave) CIRSocketAppUi;
}

