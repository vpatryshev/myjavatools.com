//---------------------------------------------------------------------------

#ifndef sizedialogH
#define sizedialogH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TPSDlg : public TForm
{
__published:	// IDE-managed Components
    TLabeledEdit *LabeledEdit1;
    TLabeledEdit *LabeledEdit2;
    TLabeledEdit *LabeledEdit3;
    TLabeledEdit *LabeledEdit4;
    TPanel *Panel1;
    TButton *Button1;
private:	// User declarations
public:		// User declarations
    __fastcall TPSDlg(TComponent* Owner);
    bool __fastcall GetSize(TRect &r);
};
//---------------------------------------------------------------------------
extern PACKAGE TPSDlg *PSDlg;
//---------------------------------------------------------------------------
#endif
