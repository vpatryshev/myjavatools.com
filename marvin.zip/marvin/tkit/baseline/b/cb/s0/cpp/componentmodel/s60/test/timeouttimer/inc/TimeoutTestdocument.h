#ifndef __TIMEOUTTEST_DOCUMENT_H__
#define __TIMEOUTTEST_DOCUMENT_H__

#include <akndoc.h>

// Forward references
class TimeoutTestAppUi;
class CEikApplication;

// CTimeoutTestDocument
class CTimeoutTestDocument : public CAknDocument
{
public:
  /**
   * Constructs CTimeoutTestDocument for the AVKON application aApp
   * using two phase construction, and return a pointer to the created
   * object
   * @param aApp application creating this document
   * @result a pointer to the created instance of CTimeoutTestDocument
   */
  static CTimeoutTestDocument* NewL(CEikApplication& aApp);

  /**
   * Constructs CTimeoutTestDocument for the AVKON application aApp
   * using two phase construction, and return a pointer to the created
   * object
   * @param aApp application creating this document
   * @result a pointer to the created instance of CTimeoutTestDocument
   */
  static CTimeoutTestDocument* NewLC(CEikApplication& aApp);

  /**
   * Destroys this document object and releases all memory
   */
  ~CTimeoutTestDocument();

  /**
   * Creates a CTimeoutTestAppUi object and return a pointer to it
   * @result a pointer to the created instance of the AppUi created
   */
  CEikAppUi* CreateAppUiL();

private:
  /**
   * Performs second phase construction for this CTimeoutTestDocument object
   */
  void ConstructL();

  /**
   * Private constructor
   */
  CTimeoutTestDocument(CEikApplication& aApp);
};

#endif // __TIMEOUTTEST_DOCUMENT_H__
