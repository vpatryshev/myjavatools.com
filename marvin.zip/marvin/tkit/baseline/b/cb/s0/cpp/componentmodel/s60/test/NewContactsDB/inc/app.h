#ifndef __APP_H__
#define __APP_H__

#include <aknapp.h>

// CtimercomponentApplication
class CApplication : public CAknApplication
{
private:

  /**
   * Create document object for this Application
   */
  CApaDocument* CreateDocumentL();

  /**
   * Returns application's UID
   */
  TUid AppDllUid() const;
};


#endif // __APP_H__

