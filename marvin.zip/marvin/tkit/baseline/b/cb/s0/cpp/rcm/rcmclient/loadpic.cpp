//---------------------------------------------------------------------------


#pragma hdrstop

#include "loadpic.h"
#include "assert.h"
#include "ole2.h"
#include "olectl.h"
#include "ocidl.h"
//---------------------------------------------------------------------------

void LoadPictureFile(LPCTSTR szFile)
{
	// open file
	HANDLE hFile = CreateFile(szFile, GENERIC_READ, 0, NULL, OPEN_EXISTING, 0, NULL);
	assert(INVALID_HANDLE_VALUE != hFile);

	// get file size
	DWORD dwFileSize = GetFileSize(hFile, NULL);
	assert(-1 != dwFileSize);

	LPVOID pvData = NULL;
	// alloc memory based on file size
	HGLOBAL hGlobal = GlobalAlloc(GMEM_MOVEABLE, dwFileSize);
	assert(NULL != hGlobal);

	pvData = GlobalLock(hGlobal);
	assert(NULL != pvData);

	DWORD dwBytesRead = 0;
	// read file and store in global memory
	BOOL bRead = ReadFile(hFile, pvData, dwFileSize, &dwBytesRead, NULL);
	assert(FALSE != bRead);
	GlobalUnlock(hGlobal);
	CloseHandle(hFile);

	LPSTREAM pstm = NULL;
	// create IStream* from global memory
	HRESULT hr = CreateStreamOnHGlobal(hGlobal, TRUE, &pstm);
	assert(SUCCEEDED(hr) && pstm);

	// Create IPicture from image file
    LPPICTURE gpPicture;
	hr = ::OleLoadPicture(pstm, dwFileSize, FALSE, IID_IPicture, (LPVOID *)&gpPicture);
	assert(SUCCEEDED(hr) && gpPicture);
	pstm->Release();



	if (gpPicture)
		gpPicture->Release();

}

#pragma package(smart_init)
