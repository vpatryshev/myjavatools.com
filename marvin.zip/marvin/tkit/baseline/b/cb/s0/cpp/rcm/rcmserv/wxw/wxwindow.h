#ifndef wxwindowH
#define wxwindowH

#include "wxw.h"
#include "wxwproperty.h"
#include "wxwuicomponent.h"

class RCMEXPORT wxWindowComponent : public wxwUIComponent
{
public:
	wxWindowComponent(const wxClassInfo *classInfo, wxwDesigner *designer, wxwContainer *container);
    virtual void GetClientRect(int &x, int &y, int &w, int &h);
    virtual bool IsTopLevel();
    virtual void ObjectCreated(bool fromXRC);
    virtual void Paint(wxDC &dc, int x, int y);
    virtual void Recreate();
    virtual bool Visible();
    wxWindow* Window();
    
protected:
    virtual void DoGetRect(int &x, int &y, int &w, int &h);
    virtual void DoSetRect(int &x, int &y, int &w, int &h, bool testOnly);
};

template <typename T>
class wxWindowComponentT : public wxWindowComponent
{
public:
	wxWindowComponentT(wxwDesigner *designer, wxwContainer *container)
        : wxWindowComponent(CLASSINFO(T), designer, container) { }

protected:
    virtual void ConstructXTIObject(wxObject *object)
    {
        wxASSERT_MSG(wxContainer(), "UI components must have a container");
        wxObject *trueParent = wxContainer()->ParentInstance();
        ConstructWXObject(trueParent, (T*)object, GetName());
    }
};

class RCMEXPORT wxWindowPainter : public wxPainter
{
DECLARE_DYNAMIC_CLASS(wxWindowPainter)
public:
	wxWindowPainter() { }
    virtual void PaintObject(wxObject *object, wxDC &dc);
};

class RCMEXPORT wxBevelWindowPainter : public wxWindowPainter
{
DECLARE_DYNAMIC_CLASS(wxBevelWindowPainter)
public:
	wxBevelWindowPainter() : wxWindowPainter() { }
    virtual void PaintObject(wxObject *object, wxDC &dc);
};


#endif
