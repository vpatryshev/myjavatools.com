////////////////////////////////////////////////////////////////////////////////
// Implementation of CAppUi
////////////////////////////////////////////////////////////////////////////////

#include <e32std.h>
#include "appui.h"
#include "MainView.h"

void CAppUi::ConstructL()
{
	BaseConstructL();
	CMainView* view = CMainView::NewL();
	AddViewL(view);
}

void CAppUi::HandleCommandL(TInt aCommand)
{
	switch (aCommand) 
	{
		case EEikCmdExit:
		case EAknSoftkeyExit:
			Exit();
			break;
		default:
			break;
	}
}

