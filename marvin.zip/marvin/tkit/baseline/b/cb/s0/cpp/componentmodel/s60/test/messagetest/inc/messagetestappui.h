#ifndef __MESSAGETEST_APPUI_H__
#define __MESSAGETEST_APPUI_H__

#include <aknViewAppUi.h>
#ifdef WITH_TAB_GROUP
#include <akntabgrp.h>
#include <aknnavide.h>
#endif
#include "messagetest.h"

#include "MessageServer.h"
#include "MessageMover.h"
#include "MessageBoxListener.h"

#include "SmsMessageContent.h"
#include "SmsMessageSender.h"

#include "MmsMessageContent.h"
#include "MmsMessageSender.h"

#include "EmailMessageContent.h"
#include "EmailMessageSender.h"

// View classes forward references
class CmessagetestView;

// CmessagetestAppUi
class CmessagetestAppUi : public CAknViewAppUi
{
  /**
   * Performs view construction
   */
  void InitViewsL();

public:
  /**
   * Performs second phase construction of this AppUi Object
   */
  void ConstructL();

  /**
   * Handles user menu selection
   */
  void HandleCommandL(TInt aCommand);

private:
  CmessagetestView * imessagetestView;
#ifdef WITH_TAB_GROUP
  CAknNavigationControlContainer* iNaviPane;
  CAknTabGroup* iTabGroup;
  CAknNavigationDecorator* iDecoratedTabGroup;
#endif
};


#endif // __MESSAGETEST_APPUI_H__

