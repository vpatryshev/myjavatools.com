#include "IRSocketapp.h"

EXPORT_C CApaApplication* NewApplication()
{
    return new CIRSocketApplication();
}

// dll entry point
GLDEF_C TInt E32Dll(TDllReason)
{
    return KErrNone;
}


