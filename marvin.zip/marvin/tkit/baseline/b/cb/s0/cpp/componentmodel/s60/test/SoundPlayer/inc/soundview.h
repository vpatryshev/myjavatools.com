#ifndef __SOUNDVIEW_H__
    #define __SOUNDVIEW_H__

    #include <coecntrl.h>
    #include <coeccntx.h>
    #include "Soundplayer.h"

class CEikLabel;
class CSoundDocument;



/*! CSoundView

An instance of the Application View object for the Sound example application */
class CSoundView : public CCoeControl, public MCoeControlBrushContext
{
public:
    /*! NewL

    Create a CSoundView object, which will draw itself to aRect Params - aRect the rectangle this view will be drawn to
    - aMessage the text to use for the label Returns a pointer to the created instance of CSoundView */
    static CSoundView * NewL( const TRect & aRect );

    /*! NewLC

    Create a CSoundView object, which will draw itself to aRect Params - aRect the rectangle this view will be drawn to
    - aMessage the text to use for the label Returns a pointer to the created instance of CSoundView */
    static CSoundView * NewLC( const TRect & aRect );

    /*! ~CSoundView

    Destroy the object and release all memory objects */
    ~CSoundView();

    /*! PlayL

    Call PlayL on CSoundPlayer */
    void PlayPlayL();
    void PlayChimesL();
    /*! StopL

    Call StopL on CSoundPlayer */
    void StopL();

public: // from CCoeControl
    /*! Draw

    Draw this CSoundView to the screen Param - aRect the rectangle of this view that needs updating */
    void Draw( const TRect & aRect ) const;

private:
    /*! OnPlayerStateChange

    Hanlde the CSoundPlayer change in status */
    void OnPlayerStateChange( CBase * player, TInt iPlayerState );
    void OnPlayerError( CBase * player, TInt code );

protected: // From CCoeControl
    /*! CountComponentControls

    Count the number of component controls that the application view owns Returns the number of controls */
    TInt CountComponentControls() const;

    /*! ComponentControl

    Returns a pointer to the 'aIndex'th component control.

    */
    CCoeControl * ComponentControl( TInt aIndex ) const;

    /*! SizeChanged

    Respond to size changed. */
    void SizeChanged();

private:

    /*! CSoundView

    Perform the first phase of two phase construction */
    CSoundView();

    /*! ConstructL

    Perform the second phase construction of a CSoundView object Params - aRect the rectangle this view will be drawn to
    - aMessage the text to use for the label */
    void ConstructL( const TRect & aRect );

private:

    /** The label for displaying the current state of the sound player */
    CEikLabel * iLabel;

    /** Sound Player that contols the playing of wav files */
    CSoundPlayer * iSoundPlayer;

};

#endif // __SOUNDVIEW_H__

