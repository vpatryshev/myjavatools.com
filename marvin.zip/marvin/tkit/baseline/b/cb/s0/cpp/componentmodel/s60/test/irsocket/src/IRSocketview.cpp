////////////////////////////////////////////////////////////////////////////////
// Implementation of CIRSocketView
////////////////////////////////////////////////////////////////////////////////

#include <e32std.h>
#include <aknviewappui.h>
#include <aknconsts.h>

#include "IRSocketview.h"
#include "IRSocketcontainer.h"
#include "IRSocket.hrh"
#include <IRSocket.rsg>

const TUid EDefaultViewId = { 1 };

CIRSocketView* CIRSocketView::NewL()
{
  CIRSocketView* self = CIRSocketView::NewLC();
  CleanupStack::Pop(self);
  return self;
}

CIRSocketView* CIRSocketView::NewLC()
{
  CIRSocketView* self = new (ELeave) CIRSocketView();
  CleanupStack::PushL(self);
  self->ConstructL();
  return self;
}

CIRSocketView::CIRSocketView()
{
}

CIRSocketView::~CIRSocketView()
{
}

void CIRSocketView::ConstructL()
{
  BaseConstructL(R_DEFAULT_VIEW);
}

TUid CIRSocketView::Id() const
{
  return EDefaultViewId;
}

void CIRSocketView::DoActivateL(const TVwsViewId& aPrevViewId,
                                   TUid aCustomMessageId,
                                   const TDesC8& aCustomMessage)
{
  ASSERT(container == NULL);
  container = CIRSocketContainer::NewL(ClientRect());
  container->SetMopParent(this);
  AppUi()->AddToStackL(*this, container);
}

void CIRSocketView::DoDeactivate()
{
  if (container)
  {
    AppUi()->RemoveFromStack(container);
    delete container;
    container = NULL;
  }
}

void CIRSocketView::HandleCommandL(TInt aCommand)
{
  if (container && container->DispatchCommandEvents(aCommand))
  {
    return;
  }
  else
  {
    AppUi()->HandleCommandL(aCommand);
  }
}

