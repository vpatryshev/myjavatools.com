//---------------------------------------------------------------------------
// For compilers that support precompilation, includes "wx/wx.h".
//#include "wx/wxprec.h"

#ifdef __BORLANDC__
#include "rcmpch.h"
#endif

#include <iostream>
using namespace std;

#include "wxwserverimpl.h"

//---------------------------------------------------------------------------

static bool MustShutdown = false;
struct server_exception : exception
{
    const char *msg;

    server_exception(const char *s) : msg(s) {}
    virtual const char* what() { return msg; }
};

static LONG __stdcall uef(struct _EXCEPTION_POINTERS *ei)
{
    ExitProcess(2);
    return 0;
}

#if 0
/*
    Override the definition of assert support routines, so that if something
    bad happens in the server, then we don't pop a dialog, and lock up the
    designer.  Code is here in case we come back to this method of operations.
*/
void wxAssert(int cond,
              const wxChar *szFile,
              int nLine,
              const wxChar *szCond,
              const wxChar *szMsg) 
{
    if ( !cond )
    {
	// Ought to format some of this information into the string.  Do that
	// after we get it actually working.
	MustShutdown = true;
	server_exception x("wxWindows API failed");
	throw x;
    }
}
#endif

#pragma argsused
class ServerApp : public wxApp
{
public:
    // override base class virtuals
    // ----------------------------
    ~ServerApp() { if (server) server->Finalize(); }
	bool ProcessIdle();
    // this one is called on application startup and is a good place for the app
    // initialization (doing it here and not in the ctor allows to have an error
    // return: if OnInit() returns false, the application terminates)
    virtual bool OnInit();
};

IMPLEMENT_APP(ServerApp)

bool ServerApp::ProcessIdle()
{
	int soapCode = server->ProcessRequest(-100);
    // return true if more idle processing is required.
    if (soapCode < SOAP_EOF) { // we've encountered a serious fault
    	Exit();
        return false;
    }
    return true;
}

bool ServerApp::OnInit()
{
	SetExitOnFrameDelete(false);
    server = new wxwServerImpl(0, 0);
    return server->Initialize();
}

