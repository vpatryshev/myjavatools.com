////////////////////////////////////////////////////////////////////////////////
// Implementation of CDocument
////////////////////////////////////////////////////////////////////////////////

#include "appui.h"
#include "document.h"


CDocument::CDocument(CEikApplication& aApp)
                       :CAknDocument(aApp)
{
}

CDocument::~CDocument()
{
}

CDocument* CDocument::NewL(CEikApplication& aApp)
{
  CDocument* self = NewLC(aApp);
  CleanupStack::Pop(self);
  return self;
}

CDocument* CDocument::NewLC(CEikApplication& aApp)
{
  CDocument* self = new (ELeave) CDocument(aApp);
  CleanupStack::PushL(self);
  self->ConstructL();
  return self;
}

void CDocument::ConstructL()
{
}

CEikAppUi* CDocument::CreateAppUiL()
{
  return new (ELeave) CAppUi;
}

