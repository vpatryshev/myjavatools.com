#ifdef __BORLANDC__
#include "rcmpch.h"
#endif

#include "wxwevent.h"
#include "wxwroot.h"
#include "wxwdesigner.h"

IMPLEMENT_DYNAMIC_CLASS(xtiEvent, xtiProperty)

wxString xtiEvent::Get() const
{
    wxASSERT_MSG(Instance() && wxDesigner(), "Uninitialized event editor");
    wxwRootComponent *root = wxDesigner()->wxManager()->Root();
    wxwEventConnection *con = root->GetEventConnection(FPropInfo,
    	wxDesigner()->wxManager()->FindComponentByInstance(Instance()));
    if (con) {
        return con->GetSinkName();
    }
    return "";
}

const wxDelegateTypeInfo* xtiEvent::GetDelegateTypeInfo()
{
    return dynamic_cast<const wxDelegateTypeInfo*>(FPropInfo->GetTypeInfo());
}

wxString xtiEvent::Signature()
{
    wxString sig;
    const wxClassInfo *eventClass = GetDelegateTypeInfo()->GetEventClass();
    if (eventClass) {
        sig.Format("%s *event", eventClass->GetClassName());
    }
    return sig;
}

void xtiEvent::Set(const wxString &value)
{
    // event values are set and stored via the designer's root component, the
    // only allowable sink in our wxWindows model.
    wxASSERT_MSG(Instance() && wxDesigner(), "Uninitialized event editor");
    wxString oldValue = Get();
    if (value.IsEmpty()) {
        wxDesigner()->NotifyEventSinkDeleted(oldValue);
    }
    else if (oldValue.IsEmpty()) {
        wxwEventConnection *con = new wxwEventConnection(value, FPropInfo,
        	wxDesigner()->wxManager()->FindComponentByInstance(Instance()));
        wxDesigner()->NotifyEventSinkAdded(con);
    }
    else {
        wxDesigner()->NotifyEventSinkRenamed(value, oldValue);
    }
}




