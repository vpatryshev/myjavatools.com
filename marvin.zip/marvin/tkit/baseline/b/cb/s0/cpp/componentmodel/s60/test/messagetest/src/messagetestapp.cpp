////////////////////////////////////////////////////////////////////////////////
// Implementation of CmessagetestApplication
////////////////////////////////////////////////////////////////////////////////

#include "messagetestapp.h"
#include "messagetestdocument.h"

const TUid KUidmessagetest = { 0x01004123 };

TUid CmessagetestApplication::AppDllUid() const
{
	return KUidmessagetest;
}

CApaDocument* CmessagetestApplication::CreateDocumentL()
{
	CApaDocument* document = CmessagetestDocument::NewL(*this);
  return document;
}
