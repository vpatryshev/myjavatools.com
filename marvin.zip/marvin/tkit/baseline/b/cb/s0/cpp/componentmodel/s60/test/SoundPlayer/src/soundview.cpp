#include <eikenv.h>
#include <eikdef.h>
#include <eiklabel.h>
#include <gulcolor.h>

#include "sound.pan"
#include "SoundView.h"
#include "SoundDoc.h"

_LIT( KSoundSampleFile, "z:\\System\\Apps\\Sound\\playack.wav" );
_LIT( KSoundSampleFileChimes, "z:\\System\\Apps\\Sound\\chimes.wav" );

//_LIT(KSoundSampleFile, "c:\\System\\Apps\\Sound\\play.wav");

CSoundView * CSoundView::NewL( const TRect & aRect )
{
    CSoundView * self = CSoundView::NewLC( aRect );
    CleanupStack::Pop();
    return self;
}

CSoundView * CSoundView::NewLC( const TRect & aRect )
{
    CSoundView * self = new( ELeave )CSoundView();
    CleanupStack::PushL( self );
    self->ConstructL( aRect );
    return self;
}

void CSoundView::ConstructL( const TRect & aRect )
{

    CreateWindowL();

    iContext = this;
    iBrushStyle = CGraphicsContext::ESolidBrush;

    iBrushColor = iEikonEnv->ControlColor( EColorWindowBackground, * this );

    iSoundPlayer = CSoundPlayer::NewL();
    iSoundPlayer->SetRepeatCount( 10 );
    iSoundPlayer->SetVolume( 100 );
    //	iSoundPlayer = new (ELeave) CSoundPlayer();
    //    iSoundPlayer->ConstructL(KSoundSampleFile,5);
    TEventT < CSoundView, TInt > change( this, & CSoundView::OnPlayerStateChange );
    iSoundPlayer->SetOnStateChange( change );
    TEventT < CSoundView, TInt > error( this, & CSoundView::OnPlayerError );
    iSoundPlayer->SetOnError( error );

    iLabel = new( ELeave )CEikLabel;
    iLabel->SetContainerWindowL( * this );
    iLabel->SetTextL( _L( "Not Ready" ) );

    // Set the windows size
    SetRect( aRect );

    // Activate the window, which makes it ready to be drawn
    ActivateL();

}


CSoundView::~CSoundView()
{
    delete iSoundPlayer;
    iSoundPlayer = NULL;
    delete iLabel;
    iLabel = NULL;
}


CSoundView::CSoundView()
{
}


void CSoundView::Draw( const TRect & /* aRect */ ) const
{
    CWindowGc & gc = SystemGc();
    gc.Clear( Rect() );
}

TInt CSoundView::CountComponentControls() const
{
    return 1;
}

CCoeControl * CSoundView::ComponentControl( TInt aIndex ) const
{

    switch ( aIndex )
    {
        case 0:
            return iLabel;
        default:
            __ASSERT_ALWAYS( EFalse, User::Panic( KSound, KSoundPanicBadParameter ) );
            return 0;
    }
}

void CSoundView::SizeChanged()
{
    TRect rect = Rect();

    TSize labelSize = iLabel->MinimumSize();
    rect.iTl.iX += ( rect.Width() - labelSize.iWidth ) / 2;
    rect.iTl.iY += ( rect.Height() - labelSize.iHeight ) / 2;
    rect.iBr = rect.iTl + labelSize;

    iLabel->SetRect( rect );
}

void CSoundView::PlayPlayL()
{

    //	TTimeIntervalMicroSeconds time(2);
    //	iSoundPlayer->SetRepeats(10,time);
    iSoundPlayer->SetFilenameL( KSoundSampleFile );
    iSoundPlayer->PlayL();
}

void CSoundView::PlayChimesL()
{

    //	TTimeIntervalMicroSeconds time(2);
    //	iSoundPlayer->SetRepeats(10,time);
    iSoundPlayer->SetFilenameL( KSoundSampleFileChimes );
    iSoundPlayer->PlayL();
}

void CSoundView::StopL()
{
    iSoundPlayer->StopL();
}

void CSoundView::OnPlayerError( CBase * player, TInt code )
{
    TBuf < 128 > buf( _L( "Error" ) );
    buf.Append( _L( "(" ) );
    buf.AppendNum( code );
    buf.Append( _L( ")" ) );
    iLabel->SetTextL( buf );
}

void CSoundView::OnPlayerStateChange( CBase * player, TInt iPlayerState )
{
    if ( iPlayerState == 0 )
        iLabel->SetTextL( _L( "Not Ready" ) );
    else if ( iPlayerState == 1 )
        iLabel->SetTextL( iSoundPlayer->Filename() );
    else if ( iPlayerState == 2 )
        iLabel->SetTextL( _L( "Playing" ) );
    else if ( iPlayerState == 3 )
        iLabel->SetTextL( _L( "Error" ) );
    SizeChanged();
    DrawNow();
}
