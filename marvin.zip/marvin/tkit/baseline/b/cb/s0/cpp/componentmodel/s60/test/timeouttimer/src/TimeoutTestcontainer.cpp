////////////////////////////////////////////////////////////////////////////////
// Implementation of CTimeoutTestContainer
////////////////////////////////////////////////////////////////////////////////

#include <aknutils.h>
#include <eiklabel.h>
#include <TimeoutTest.rsg>

#include <barsread.h>
#include <eikappui.h>
#include <eikedwin.h>
#include <txtglobl.h>
#include <coeinput.h>
#include <aknlists.h>
#include <akniconarray.h>
#include <eikclbd.h>
#include <akntitle.h>
#include <aknslider.h>
#include <eikspane.h>
#include <aknnavilabel.h>
#include <eikmfne.h>
#include <aknnumseced.h>
#include <aknipfed.h>
#include <in_sock.h>
#include <eikprogi.h>
#include <AknNumEdwin.h>
#include <eikfpne.h>
#include <aknnumed.h>
#include <aknglobalnote.h>
#include <AknNoteDialog.h>
#include <aknnotewrappers.h>
#include <aknprogressdialog.h>
#include <aknstaticnotedialog.h>
#include <aknquerydialog.h>


#include "TimeoutTestcontainer.h"

CTimeoutTestContainer* CTimeoutTestContainer::NewL(const TRect& aRect)
{
  CTimeoutTestContainer* self = CTimeoutTestContainer::NewLC(aRect);
  CleanupStack::Pop(self);
  return self;
}

CTimeoutTestContainer* CTimeoutTestContainer::NewLC(const TRect& aRect)
{
  CTimeoutTestContainer* self = new (ELeave) CTimeoutTestContainer;
  CleanupStack::PushL(self);
  self->ConstructL(aRect);
  return self;
}

CTimeoutTestContainer::~CTimeoutTestContainer()
{
  CleanupComponents();
  iCtrlArray.Reset();
}

/**
 * Routine that creates and initializes designed components
 * NOTE: Maintained by CBuilder Designer
 */
void CTimeoutTestContainer::InitComponents()
{
    /* 1/27/04 12:21 PM */
    /* FIXME CAknView - Missing Property Setter snippet: "In tab group" */
    /* FIXME CAknView - Missing Property Setter snippet: "Tab group" */
    CEikStatusPane * StatusPane = iEikonEnv->AppUiFactory()->StatusPane();
    StatusPane->MakeVisible(ETrue);
    CAknContextPane * cAknContextPane1 =
         (CAknContextPane *) iEikonEnv->AppUiFactory()->StatusPane()->ControlL(TUid::Uid(EEikStatusPaneUidContext));
    /* FIXME CAknContextPane - Missing Property Setter snippet: "MBM file" */
    /* FIXME CAknContextPane - Missing Property Setter snippet: "Image index" */
    /* FIXME CAknContextPane - Missing Property Setter snippet: "Mask index" */
    CAknTitlePane * cAknTitlePane1 =
         (CAknTitlePane *) iEikonEnv->AppUiFactory()->StatusPane()->ControlL(TUid::Uid(EEikStatusPaneUidTitle));
    cAknTitlePane1->SetTextL(_L("Title Pane"));
    /* FIXME CAknTitlePane - Missing Property Setter snippet: "MBM file" */
    /* FIXME CAknTitlePane - Missing Property Setter snippet: "Image index" */
    CAknNavigationControlContainer * cAknNavigationControlContainer1 =
         (CAknNavigationControlContainer *)
         iEikonEnv->AppUiFactory()->StatusPane()->ControlL(TUid::Uid(EEikStatusPaneUidNavi));
    /* FIXME CAknNavigationControlContainer - Missing Property Setter snippet: "MBM file" */
    /* FIXME CAknNavigationControlContainer - Missing Property Setter snippet: "Image index" */
    iBackgroundColor = iEikonEnv->Color(EColorControlBackground);
    cTimeoutTimer1 = CTimeoutTimer::NewL(CActive::EPriorityIdle);
    cTimeoutTimer1->SetEnabled(ETrue);
    cTimeoutTimer1->SetTimeout(3000000);
    TEventT < CTimeoutTestContainer, TInt > cTimeoutTimer1_Timer(this, & CTimeoutTestContainer::OncTimeoutTimer1OnTimer);
    cTimeoutTimer1->SetOnTimer(cTimeoutTimer1_Timer);
}

/**
 * Routine that cleans up designed components
 * NOTE: Maintained by CBuilder Designer
 */
void CTimeoutTestContainer::CleanupComponents()
{
    /* 1/27/04 12:21 PM */
    delete cTimeoutTimer1;
}

void CTimeoutTestContainer::ConstructL(const TRect& aRect)
{
  CreateWindowL();
  SetRect(aRect);
  InitComponents();
  ActivateL();
}


void CTimeoutTestContainer::Draw(const TRect& aRect) const
{
  CWindowGc& gc = SystemGc();
  gc.SetPenStyle(CGraphicsContext::ENullPen);
  gc.SetBrushColor(iBackgroundColor);
  gc.SetBrushStyle(CGraphicsContext::ESolidBrush);
  gc.DrawRect(aRect);
}

TInt CTimeoutTestContainer::CountComponentControls() const
{
  return iCtrlArray.Count();
}

CCoeControl* CTimeoutTestContainer::ComponentControl(TInt aIndex) const
{
  return (CCoeControl*)iCtrlArray[aIndex];
}

TKeyResponse CTimeoutTestContainer::OfferKeyEventL(const TKeyEvent& aKeyEvent, TEventCode aType)
{
  /**
  * You may place code here to act on the users key event, or pass this to a child control
  * to be handled internally by that control.
  *
  * For example:
  *   return myControl->OfferKeyEventL(aKeyEvent, aType);
  */
  if (DispatchKeyEvents(aKeyEvent, aType))
    return EKeyWasConsumed;
  else
    return EKeyWasNotConsumed;
}

void CTimeoutTestContainer::HandleControlEventL(CCoeControl * aControl, TCoeEvent aEventType)
{
}

/**
 * The contents of this method is maintained by the CBuilder designer
 * It attemps to dispatch commands to individual handlers
 * NOTE: Maintained by CBuilder Designer
 */
bool CTimeoutTestContainer::DispatchCommandEvents(TInt aCommand)
{
  return false;
}

/**
 * Routine that attempts to dispatch Control Events
 * NOTE: Maintained by CBuilder Designer
 */
void CTimeoutTestContainer::DispatchControlEvents(CCoeControl * aControl, TCoeEvent aEventType)
{
}

/**
 * Routine that attempts to dispatch Key Events
 * NOTE: Maintained by CBuilder Designer
 */
bool CTimeoutTestContainer::DispatchKeyEvents(const TKeyEvent& aKeyEvent, TEventCode aType)
{
  return false;
}

void CTimeoutTestContainer::OncTimeoutTimer1OnTimer(CBase * sender, TInt status)
{
    _LIT(KTimerFired, "Timer fired.\n");
    CAknInformationNote* informationNote = new (ELeave) CAknInformationNote;
    informationNote->ExecuteLD(KTimerFired);

}






