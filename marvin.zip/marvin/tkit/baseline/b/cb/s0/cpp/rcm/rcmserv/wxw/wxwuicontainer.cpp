#ifdef __BORLANDC__
#include "rcmpch.h"
#endif

#include "wxwuicontainer.h"

// wxWindowContainer

bool wxwUIContainer::CanParentType(const wxClassInfo *type)
{
    return type->IsKindOf(wxClassInfo::FindClass("wxWindow"))
        || type->IsKindOf(wxClassInfo::FindClass("wxGridBagSizer"));
}


