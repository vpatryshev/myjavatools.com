#include "IRServerapp.h"

EXPORT_C CApaApplication* NewApplication()
{
    return new CIRServerApplication();
}

// dll entry point
GLDEF_C TInt E32Dll(TDllReason)
{
    return KErrNone;
}


