#include "bluetoothtestapp.h"

EXPORT_C CApaApplication* NewApplication()
{
    return new CbluetoothtestApplication();
}

// dll entry point
GLDEF_C TInt E32Dll(TDllReason)
{
    return KErrNone;
}


