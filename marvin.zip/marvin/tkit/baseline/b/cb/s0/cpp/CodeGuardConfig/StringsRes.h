//---------------------------------------------------------------------------

#ifndef StringsResH
#define StringsResH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TStringsResContainer : public TForm
{
__published:	// IDE-managed Components
        TLabel *CG_DLL_VERSION;
        TLabel *CG_FILE_OPEN_FILTER;
        TLabel *CG_IGNORED_MODULES_FILTER;
        TLabel *CG_FILE_OPEN_TITLE;
        TLabel *CG_IGNORED_MODULES_TITLE;
        TLabel *CG_LOADING_CAPTION;
        TLabel *CG_SAVING_CAPTION;
        TLabel *CG_GLOBAL;
        TLabel *CG_OPTIONS_CAPTION;
        TLabel *CG_CONFIG_CAPTION;
        TLabel *CG_OUT_OF_RANGE;
        TLabel *CG_DIRLISTDIALOG_STR1;
        TLabel *CG_DIRLISTDIALOG_STR2;
        TLabel *CG_ENABLED;
        TLabel *CG_DISABLED;
        TLabel *CG_CODEGUARD_IS;
        TLabel *CG_SAVE_CHANGES;
        TLabel *CG_EXTENDED_SELECT_NOTE;
private:	// User declarations
public:		// User declarations
        __fastcall TStringsResContainer(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TStringsResContainer *StringsResContainer;
//---------------------------------------------------------------------------
#endif
