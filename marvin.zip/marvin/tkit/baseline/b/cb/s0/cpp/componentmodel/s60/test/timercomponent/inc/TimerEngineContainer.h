#ifndef TIMER_ENGINE_CONTAINER_H
#define TIMER_ENGINE_CONTAINER_H

#include "TimeOutTimer.h"
#include "BeatingHeartbeat.h"

class CTimerEngineContainer : public CBase
{
public:

  CTimerEngineContainer( void );
  ~CTimerEngineContainer( void );
  void ConstructL( void );

private:

  void InitializeComponentsL( void );
  void CleanComponents( void );

  void OnTimerEvent( CBase * aTimer, int aErrorCode );

private:

  CTimeOutTimer < CTimer > * iTimerWrapper;
  CBeatingHeartbeat<MBeating> * iHeartbeat;
};

#endif
