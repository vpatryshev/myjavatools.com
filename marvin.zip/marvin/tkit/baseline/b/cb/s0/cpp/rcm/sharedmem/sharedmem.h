//---------------------------------------------------------------------------

#ifndef sharedmemH
#define sharedmemH

#ifdef __WIN32__

#include <windows.h>

#define MAX_SHMEM_SIZE 6*1024*1024
// 6 MB
#define MAX_KEYSIZE 127

#define MODEL_IMAGE     1
#define COMP_IMAGE      2
#define BYTE_DATA       3

struct Request {
    int key;
};

struct SoapData : public Request {
    size_t size;
    char data[];
};

struct TImageRequest : public Request {
    char modelKey[MAX_KEYSIZE];
    union {
        char uri[MAX_PATH];
        struct {
            char managerKey[MAX_KEYSIZE];
            char designerKey[MAX_KEYSIZE];
            char compInstanceKey[MAX_KEYSIZE];
            int x;
            int y;
            int w;
            int h;
        };
    };
};

struct ImageResponse {
    char mimeType[MAX_PATH];
    unsigned int scanWidth;
    unsigned int size;
    byte data[];
};

#define MAX_DATASIZE MAX_SHMEM_SIZE - sizeof(char)*MAX_PATH - sizeof(int)*2

class TSharedMem
{
public:
    TSharedMem(const char *name, unsigned int size, bool create = true);
    ~TSharedMem();

    int GetSize() { return iSize; }
    char* GetName() { return sName; }

    bool IsLocked() { return locked; }
    bool Lock();
    void Unlock();

    // Wait times to process (client) or wait for (server) a particular request type.
    int GetTimeout() { return FTimeout; }
    void SetTimeout(unsigned int ms) { FTimeout = ms; }

protected:
    void *pMem;             // Pointer to shared memory region
    HANDLE hFree;           // Mutex to synchronize clients
    HANDLE hImageRequest;   // Client informs server an image is requested
    HANDLE hImageDone;      // Server informs client image request fulfilled
    HANDLE hSoapRequest;    // Client informs server of a Soap request
    HANDLE hSoapDone;       // Server informs client a Soap request is fulfilled

private:
    HANDLE hMap;            // Shared memory
    char *sName;            // Base name used to create the region, mutexes, and events.
    int iSize;
    int timeOut;
    bool locked;
    unsigned int FTimeout;
};

class TTransportServer : public TSharedMem
{
public:
    TTransportServer(const char *name, unsigned int size);
    ~TTransportServer() { }

    bool CheckForImageRequest();
    bool CheckForSoapRequest();

protected:
    virtual bool GetImageData(char *uri, ImageResponse *ir);
    virtual bool GetImageData(char *managerKey, char *designerKey,
        char *compInstanceKey, int x, int y, int w, int h, ImageResponse *ir);
    virtual bool ServeSoapRequest(char *request, size_t len, SoapData *response);
};

class TTransportClient : public TSharedMem
{
public:
    TTransportClient(const char *name, unsigned int size);
    ~TTransportClient();

    bool RequestModelImage(char *modelKey, char *uri, ImageResponse *&ir);
    bool RequestCompImage(char *modelKey, char *managerKey, char *designerKey,
        char *compInstanceKey, int x, int y, int w, int h, ImageResponse *&ir);

protected:
    bool GetImageData();
};

#endif

//---------------------------------------------------------------------------
#endif
