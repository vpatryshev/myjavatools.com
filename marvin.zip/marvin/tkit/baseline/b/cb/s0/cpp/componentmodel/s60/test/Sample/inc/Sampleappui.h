#ifndef __SAMPLE_APPUI_H__
#define __SAMPLE_APPUI_H__

#include <aknViewAppUi.h>

#include "Sample.hrh"

#ifdef WITH_TAB_GROUP
#include <akntabgrp.h>
#include <aknnavide.h>
#endif

#include "Sample.h"

// View classes forward references
class CSampleView;

// CSampleAppUi
class CSampleAppUi : public CAknViewAppUi
{
  /**
   * Performs view construction
   */
  void InitViewsL();

public:
  /**
   * Performs second phase construction of this AppUi Object
   */
  void ConstructL();

  /**
   * Handles user menu selection
   */
  void HandleCommandL(TInt aCommand);
#ifdef WITH_TAB_GROUP
  virtual TKeyResponse HandleKeyEventL(const TKeyEvent& aKeyEvent,TEventCode aType);
#endif
private:
  CSampleView * iSampleView;
#ifdef WITH_TAB_GROUP
  CAknNavigationControlContainer* iNaviPane;
  CAknTabGroup* iTabGroup;
  CAknNavigationDecorator* iDecoratedTabGroup;
#endif
};


#endif // __SAMPLE_APPUI_H__

