#ifndef __SAMPLE_VIEW_H__
#define __SAMPLE_VIEW_H__

#include <aknview.h>
#include "Sample.hrh"

// Forward ref. to container class
class CSampleContainer;


// CSampleView
class CSampleView : public CAknView
{
  public:

    /**
     * Creates a CSampleView object
     */
    static CSampleView* NewL();

    /**
     * Creates a CSampleView object
     */
    static CSampleView* NewLC();

    /**
     * Identify of this view to the system
     */
    TUid Id() const;

    /**
     * Command Handler
     */
    void HandleCommandL(TInt aCommand);

    /**
     * Activates this View
     */
    void DoActivateL(const TVwsViewId &PrevViewId, TUid  aCustomMessageId, const TDesC8& aCustomMessage);

    /**
     * Deactivate this view
     */
    void DoDeactivate();

  private:
    CSampleView();
   ~CSampleView();

    /**
     * Performs second phase construction of this view
     */
    void ConstructL();

    /**
     * Container for this view
     */
    CSampleContainer* container;

    /**
     * Identifier for this view
     */
    TUid iIdentifier;
};


#endif // __SAMPLE_VIEW_H__

