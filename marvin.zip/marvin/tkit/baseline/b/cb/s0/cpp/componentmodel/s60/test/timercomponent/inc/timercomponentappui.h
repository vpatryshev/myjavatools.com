#ifndef __TIMERCOMPONENT_APPUI_H__
#define __TIMERCOMPONENT_APPUI_H__

#include <aknViewAppUi.h>

class CtimercomponentView;


// CtimercomponentAppUi
class CtimercomponentAppUi : public CAknViewAppUi
{
public:
  /**
   * Performs second phase construction of this AppUi Object
   */
  void ConstructL();

  /**
   * Handles user menu selection
   */
  void HandleCommandL(TInt aCommand);

private:
  CtimercomponentView * itimercomponentView;
};


#endif // __TIMERCOMPONENT_APPUI_H__

