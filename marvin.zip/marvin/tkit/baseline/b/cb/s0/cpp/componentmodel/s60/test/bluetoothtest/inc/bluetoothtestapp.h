#ifndef __BLUETOOTHTEST_APP_H__
#define __BLUETOOTHTEST_APP_H__

#include <aknapp.h>

// CbluetoothtestApplication
class CbluetoothtestApplication : public CAknApplication
{
private:

  /**
   * Create document object for this Application
   */
  CApaDocument* CreateDocumentL();

  /**
   * Returns application's UID
   */
  TUid AppDllUid() const;
};


#endif // __BLUETOOTHTEST_APP_H__

