#ifndef __TCPTEST_VIEW_H__
#define __TCPTEST_VIEW_H__

#include <aknview.h>

// Forward ref. to container class
class CtcptestContainer;


// CtcptestView
class CtcptestView : public CAknView
{
  public:

    /**
     * Creates a CtcptestView object
     */
    static CtcptestView* NewL();

    /**
     * Creates a CtcptestView object
     */
    static CtcptestView* NewLC();

    /**
     * Identify of this view to the system
     */
    TUid Id() const;

    /**
     * Command Handler
     */
    void HandleCommandL(TInt aCommand);


    /**
     * Activates this View
     */
    void DoActivateL(const TVwsViewId &PrevViewId, TUid  aCustomMessageId, const TDesC8& aCustomMessage);

    /**
     * Deactivate this view
     */
    void DoDeactivate();

  private:
    CtcptestView();
   ~CtcptestView();

    /**
     * Performs second phase construction of this view
     */
    void ConstructL();

    /**
     * Container for this view
     */
    CtcptestContainer* container;

    /**
     * Identifier for this view
     */
    TUid iIdentifier;
};


#endif // __TCPTEST_VIEW_H__

