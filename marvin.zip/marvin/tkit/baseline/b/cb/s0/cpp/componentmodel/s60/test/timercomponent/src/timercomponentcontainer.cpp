////////////////////////////////////////////////////////////////////////////////
// Implementation of CtimercomponentContainer
////////////////////////////////////////////////////////////////////////////////

#include <aknutils.h>
#include <eiklabel.h>
#include <timercomponent.rsg>
#include <barsread.h>
#include <eikappui.h>
#include <eikedwin.h>
#include <txtglobl.h>
#include <coeinput.h>
#include <aknlists.h>
#include <akniconarray.h>
#include <eikclbd.h>
#include <akntitle.h>
#include <aknslider.h>
#include <eikspane.h>
#include <aknnavilabel.h>
#include <eikmfne.h>
#include <aknnumseced.h>
#include <aknipfed.h>
#include <in_sock.h>
#include <eikprogi.h>
#include <AknNumEdwin.h>
#include <eikfpne.h>


#include "timercomponentcontainer.h"

CtimercomponentContainer* CtimercomponentContainer::NewL(const TRect& aRect)
{
  CtimercomponentContainer* self = CtimercomponentContainer::NewLC(aRect);
  CleanupStack::Pop(self);
  return self;
}

CtimercomponentContainer* CtimercomponentContainer::NewLC(const TRect& aRect)
{
  CtimercomponentContainer* self = new (ELeave) CtimercomponentContainer;
  CleanupStack::PushL(self);
  self->ConstructL(aRect);
  return self;
}

CtimercomponentContainer::~CtimercomponentContainer()
{
  CleanupComponents();
  iCtrlArray.Reset();
}


void CtimercomponentContainer::InitComponents()
{
  /* 1/11/04 6:18 PM */
  CEikStatusPane * StatusPane = iEikonEnv->AppUiFactory()->StatusPane();
  StatusPane->MakeVisible( ETrue );
  CAknContextPane * Contextpane =
       ( CAknContextPane * ) iEikonEnv->AppUiFactory()->StatusPane()->ControlL( TUid::Uid( EEikStatusPaneUidContext ) );
  /* FIXME CAknContextPane - Missing Property Setter snippet: "MBM file" */
  /* FIXME CAknContextPane - Missing Property Setter snippet: "Image index" */
  /* FIXME CAknContextPane - Missing Property Setter snippet: "Mask index" */
  CAknTitlePane * Titlepane =
       ( CAknTitlePane * ) iEikonEnv->AppUiFactory()->StatusPane()->ControlL( TUid::Uid( EEikStatusPaneUidTitle ) );
  Titlepane->SetTextL( _L( "Timer Wrapper" ) );
  /* FIXME CAknTitlePane - Missing Property Setter snippet: "MBM file" */
  /* FIXME CAknTitlePane - Missing Property Setter snippet: "Image index" */
  CAknNavigationControlContainer * Navigationpane =
       ( CAknNavigationControlContainer * )
       iEikonEnv->AppUiFactory()->StatusPane()->ControlL( TUid::Uid( EEikStatusPaneUidNavi ) );
  /* FIXME CAknNavigationControlContainer - Missing Property Setter snippet: "MBM file" */
  /* FIXME CAknNavigationControlContainer - Missing Property Setter snippet: "Image index" */
  /* no indicator yet */
  /* FIXME CAknIndicatorContainer - Missing Property Setter snippet: "Indicator state" */
  iBackgroundColor = iEikonEnv->Color( EColorControlBackground );
}

void CtimercomponentContainer::CleanupComponents()
{
  /* 1/11/04 6:18 PM */
}

void CtimercomponentContainer::ConstructL(const TRect& aRect)
{
  CreateWindowL();
  SetRect(aRect);
  InitComponents();
  ActivateL();
}


void CtimercomponentContainer::Draw(const TRect& aRect) const
{
  CWindowGc& gc = SystemGc();
  gc.SetPenStyle(CGraphicsContext::ENullPen);
  gc.SetBrushColor(iBackgroundColor);
  gc.SetBrushStyle(CGraphicsContext::ESolidBrush);
  gc.DrawRect(aRect);
}

TInt CtimercomponentContainer::CountComponentControls() const
{
  return iCtrlArray.Count();
}

CCoeControl* CtimercomponentContainer::ComponentControl(TInt aIndex) const
{
  return (CCoeControl*)iCtrlArray[aIndex];
}

TKeyResponse CtimercomponentContainer::OfferKeyEventL(const TKeyEvent& aKeyEvent, TEventCode aType)
{
  /**
  * place code here to act on the users key event, or pass this to a child control
  * to be handled internally by that control.
  *
  * For example:
  *   return myControl->OfferKeyEventL(aKeyEvent, aType);
  */
  return EKeyWasNotConsumed; // or EKeyWasConsumed if handled in this function
}

