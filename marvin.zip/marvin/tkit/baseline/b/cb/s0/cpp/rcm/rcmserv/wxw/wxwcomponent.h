#ifndef wxwcomponentH
#define wxwcomponentH

#include "wxw.h"

int ByteSwap(const int i)
{
    int swapped = i;
    unsigned char *p = reinterpret_cast<unsigned char*>(&swapped);
    *p ^= *(p+3);
    *(p+3) = *p ^ *(p+3);
    *p ^= *(p+3);
    *(p+1) ^= *(p+2);
    *(p+2) = *(p+1) ^ *(p+2);
    *(p+1) ^= *(p+2);
    return swapped;
}

// Component state flags

//#define CS_LOADING      0x0001
#define CS_READING      0x0002
#define CS_WRITING      0x0004
#define CS_DESTROYING   0x0008
#define CS_INITIALIZED  0x0010
#define CS_RECREATING   0x0020

class RCMEXPORT wxwComponent : public rcmComponent
{
public:
	wxwComponent(const wxClassInfo *classInfo, wxwDesigner *designer, wxwContainer *container);
    virtual ~wxwComponent();

    const wxClassInfo* ClassInfo() const;

    /*
        Second-phase construction of the proxy object. Do not call explicitly.
    */
    void Init();

    bool IsType(const wxClassInfo *classInfo) const;

    /*
        Notification that a new underlying wxWindows object is fully constructed.
        fromXRC indicates whether the object was created via streaming in an
        .xrc file or dynamically via user action.
    */
    virtual void ObjectCreated(bool fromXRC = false) { }

    /*
        Recreates the instance and all underlying components.
    */
    virtual void Recreate();

    /*
        Used by the streaming system and recreation (cut/copy/paste). Don't
        call unless you know what you want.
    */
    virtual void SetInstance(wxObject *instance);

    /*
        Flags indicating the state of the component
    */
    bool HasState(int state) { return (FStates & state) == state; }
    void ClearState(int state) { FStates &= ~state; }
    void SetState(int state) { FStates |= state; }

    wxwDesigner* wxDesigner();
    wxwContainer* wxContainer();

	// rcmComponent methods
    virtual bool CanDispose() { return true; }
    virtual bool CanRename() { return true; }
    virtual rcmComponentInfo* ComponentInfo();
    virtual rcmContainer* Container();
    virtual rcmDesigner* Designer();
    virtual rcmComponentEditor* Editor();
	virtual void GetEvents(rcmEvents &events);
	virtual void GetMethods(rcmMethods &methods);
    virtual wxString GetName() { return FName; }
    virtual void GetProperties(rcmProperties &props);
    virtual rcmProperty* GetProperty(wxArrayString &propPath);
    virtual wxString GetValue(wxArrayString &path);
    virtual wxString GetValue(const rcmProperty *prop);
    virtual wxObject* Instance();
    virtual bool IsContainer();
    virtual bool IsType(rcmComponentInfo *type) const;
    virtual wxString Key() { return FKey; }
	virtual Result* SetName(const wxString &newName);
	virtual Result* SetParent(rcmContainer *newContainer);
    virtual Result* SetValue(wxArrayString &path, const wxString &value);
protected:
    virtual void ConstructXTIObject(wxObject *object) = 0;
	void InternalSetName(const wxString &newName);
	virtual void InternalSetParent(wxwContainer *newContainer);

    /*
        A property of this component has changed value.
    */
    virtual void PropertyChanged(const wxPropertyBase *property);
    void Reparent(wxwContainer *newContainer);
    /*
        Create and initialize a new wxObject instance on which this proxy
        will act on behalf of the designer.
    */
    virtual void NewInstance();
    wxString NameSeed();
    wxObject *FInstance;
private:
    wxwComponentInfo *FComponentInfo;
    wxwDesigner *FDesigner;
    wxwContainer *FContainer;
    wxString FName;
    wxString FKey;
    int FStates;
};

template <typename T>
class RCMEXPORT wxwComponentT : public wxwComponent
{
public:
	wxwComponentT(wxwDesigner *designer, wxwContainer *container)
        : wxwComponent(CLASSINFO(T), designer, container) { }
protected:
    virtual void ConstructXTIObject(wxObject *object)
    {
        ConstructWXObject((T*)object, FName);
    }
};

class wxwComponentFactory
{
public:
    wxwComponentFactory() { }
    virtual wxwComponent* Create(wxwDesigner *designer, wxwContainer *container) = 0;
};

template <typename _proxy_class>
class wxwComponentFactoryT : public wxwComponentFactory
{
public:
    wxwComponentFactoryT() : wxwComponentFactory() { }

    wxwComponent* Create(wxwDesigner *designer, wxwContainer *container)
    {
        return new _proxy_class(designer, container);
    }
};

#endif
