#ifndef __DOCUMENT_H__
#define __DOCUMENT_H__

#include <akndoc.h>

// Forward references
class timercomponentAppUi;
class CEikApplication;

// CtimercomponentDocument
class CDocument : public CAknDocument
{
public:
  /**
   * Constructs CtimercomponentDocument for the AVKON application aApp
   * using two phase construction, and return a pointer to the created
   * object
   * @param aApp application creating this document
   * @result a pointer to the created instance of CtimercomponentDocument
   */
  static CDocument* NewL(CEikApplication& aApp);

  /**
   * Constructs CtimercomponentDocument for the AVKON application aApp
   * using two phase construction, and return a pointer to the created
   * object
   * @param aApp application creating this document
   * @result a pointer to the created instance of CtimercomponentDocument
   */
  static CDocument* NewLC(CEikApplication& aApp);

  /**
   * Destroys this document object and releases all memory
   */
  ~CDocument();

  /**
   * Creates a CtimercomponentAppUi object and return a pointer to it
   * @result a pointer to the created instance of the AppUi created
   */
  CEikAppUi* CreateAppUiL();

private:
  /**
   * Performs second phase construction for this CtimercomponentDocument object
   */
  void ConstructL();

  /**
   * Private constructor
   */
  CDocument(CEikApplication& aApp);
};

#endif // __DOCUMENT_H__
