#ifndef __CG_CGI_H
#define __CG_CGI_H

#ifdef __cplusplus
extern "C"{
#endif

#pragma option -a-

typedef char    IDEBool;

#define BoolFalse       0
#define BoolTrue        1

typedef enum
{
	M_SETTABLE = 0,
	M_NONSETTABLE = 1,
	M_NA = 2
} control;

typedef enum
{
  P_ALL   = 0,
  P_16    = 1,
  P_32    = 2,
  P_UNK   = 0xFF,
} Platform;

typedef struct
{
	IDEBool value;
	IDEBool set;
	IDEBool control;
}	CFG_Bool;

typedef struct
{
	unsigned short value;
	IDEBool set;
	IDEBool control;
}	CFG_short;

typedef struct
{
	unsigned int value;
	IDEBool set;
	IDEBool control;
}	CFG_int;


typedef struct
{
	char value[4096];  // for easier interfacing to the vcl CGCONFIG
	IDEBool set;
	IDEBool control;
}	CFG_string;




typedef struct
{
        CFG_Bool	guard;			// Guard this type of resource?
        CFG_Bool	guardLeaks;		// Report resource leaks at termination?
        CFG_Bool	guardParams;	// Report parameter errors?
        CFG_Bool	freeDelay;		// Do we delay-free?
        CFG_short	delayMax;		// Number of elements to track after freeing.
        CFG_int	delayMaxSize;	// Max size of memory blocks to delay-free
		  CFG_Bool	res[10];
}       CGResourceOptions;

typedef struct
{
        CFG_Bool	guardAccess;	// Validate pointer/reference parameter accesses?
        CFG_Bool	guardParams;	// Validate function parameters?
        CFG_Bool	guardFail;		// Check function returns for failure?
		  CFG_Bool	guardLog;		// Report all calls to this function?
		  CFG_Bool	guardWarn;		// Enable warnings for this function?
		  CFG_Bool	guardDisable;	// Disable CodeGuard wrapper for this function?
		  CFG_Bool	res[10];
}       CGFunctionOptions;


typedef struct
{
		CFG_Bool		on;            // Turn CodeGuard on/off.
		CFG_Bool		stat;          // report statistics at termination
		CFG_Bool		msgBox;        // put up messagebox if there are errors
		CFG_string	caption;			// msgbox caption
		CFG_string	text;				// msgbox text
		CFG_Bool		dbgInfo;       // parse debug info?
		CFG_string	srcPath;			// path for sources
		CFG_string	ignoredModules;			// semicolon seperated list of modules to exclude from events
		CFG_Bool		logAppend;		// append to logfile (or override)
		CFG_Bool		repeats;			// report repeats?
		CFG_short	stackFillFreq; // stack fill frequency
		CFG_Bool		outDbgStr;     // do OuputdebugString?
		CFG_Bool		dbgBreak;      // do DebugBreak?
		CFG_Bool		resourceLeaks;	// report resource leaks?
		CFG_short	maxErrors;		// max # errors in .CGL file
		CFG_Bool		limitErrors;
		CFG_Bool		res[7];
}       CGOptions;

struct InheritanceOptions
{
  IDEBool access;
  IDEBool params;
  IDEBool fail;
  IDEBool log;
  IDEBool warn;
  IDEBool disable;
};
typedef struct InheritanceOptions inheritOpts;
#pragma option -a.

/* ****************************************************************************
 *
 *      Return the version information of this copy of CodeGuard
 *
 */

unsigned int __pascal _cg_GetCGVersion(char **CGVerStr, char **CGPath);

/* ****************************************************************************
 *
 *      Returns the EXE type of the target (P_16, P_32, or P_UNK)
 *
 */
Platform __pascal _cg_GetPlatform(const char* targetName);

//function prototype
void __pascal _cg_InheritOptions (inheritOpts * iopts, const char *targetName, const char * funcName, CGFunctionOptions * functionOptions);
/* ****************************************************************************
 *
 *      Return the number of resources for the specified target.  If target
 *      is 0, return the number of global resources.
 *
 */
unsigned        __pascal _cg_GetNumberOfCGResources(const char *targetName);


/* ****************************************************************************
 *
 *      Return the number of functions for the specified target.  If target
 *      is 0, return the number of global functions.
 *
 */
unsigned        __pascal _cg_GetNumberOfCGFunctions(const char *targetName);


/* ****************************************************************************
 *
 *      Enumerate all available resources, for a the specified target, by
 *      calling enumFunc once for each available resource.  enumFunc returns a
 *      status which indicates if the enumeration should proceed.  If
 *      targetName is 0 or unknown, the defaults should be enumerated.
 *
 */
void    __pascal _cg_EnumResources(void * userParam, const char *targetName,
                      IDEBool CALLBACK (*enumFunc)(void * userParam, const char * targetName, const char *resourceName));


/* ****************************************************************************
 *
 *      Enumerate all available functionn, for the specified target, by calling
 *      enumFunc once for each available function.  enumFunc returns a status
 *      which indicates if the enumeration should proceed.  If targetName is 0
 *      or unknown, the defaults should be enumerated.
 *
 */
void    __pascal _cg_EnumFunctions(void * userParam, const char *targetName,
                      IDEBool CALLBACK (*enumFunc)( void * userParam, const char * targetName, const char *functionName));


/* ****************************************************************************
 *
 *      Return the current CodeGuard options for a specified target.  The
 *      options are returned through pOptions.  If the target name is 0, the
 *      defaults should be returned.
 *
 */
void    __pascal _cg_GetCGOptions(const char *targetName, CGOptions *options);

/* ****************************************************************************
 *
 *      Set the CodeGuard options for a specified target.  If the function
 *      could not be modified, an appropriate status is returned.
 *
 */

IDEBool __pascal _cg_SetCGOptions(const char *targetName, const CGOptions *options);

/* ****************************************************************************
 *
 *      Get the attributes for a specific resource for the chosen target. If set=0, the
 *		option is inherited. If set=1, the option is local override.
 */

IDEBool __pascal _cg_GetResourceOptions(const char *targetName, const char * resourceName, CGResourceOptions *resourceOptions, unsigned int resourceIndex);

/* ****************************************************************************
 *
 *      Set the attributes for a specific resource for the chosen target.
 *		set = 0 means the local overrides should be deleted. set=1 means set it to the given
 *      value.
 */
IDEBool __pascal _cg_SetResourceOptions(const char *targetName, const char * resourceName, const CGResourceOptions *resourceOptions);


/* ****************************************************************************
 *
 *      Get the attributes for a specific function for the chosen target.
 *
 */
IDEBool __pascal _cg_GetFunctionOptions(const char *targetName, const char *funcName, CGFunctionOptions *functionOptions, unsigned int functionIndex);

/* ****************************************************************************
 *
 *      Set the attributes for a specific resource for the chosen target.
 *		If the target name is given, and the resourceName is NULL, the target specific
 * 		default overrides should be set.
 *
 */
IDEBool __pascal _cg_SetFunctionOptions(const char *targetName, const char *funcName, const CGFunctionOptions *functionOptions, unsigned int functionIndex);


/* ****************************************************************************
 *  Removes an entire function section from the .CGI file
 *
 */

IDEBool __pascal _cg_RemoveFunction(const char *targetName, const char * funcName, unsigned int functionIndex);


/* ****************************************************************************
 *
 *      Reset all local options to global defaults for a specified target.
 *
 */
void    __pascal _cg_ResetCGTarget(const char *targetName);


/* Translates an index into a string for resources and functions: */
char * __export __pascal _cg_FunctionIndexToString(unsigned int functionIndex);
char * __export __pascal _cg_ResourceIndexToString(unsigned int resourceIndex);


#ifdef __cplusplus
}
#endif


#endif
