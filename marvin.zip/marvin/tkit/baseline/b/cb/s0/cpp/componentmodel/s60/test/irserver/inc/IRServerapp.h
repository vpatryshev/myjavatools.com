#ifndef __IRSERVER_APP_H__
#define __IRSERVER_APP_H__

#include <aknapp.h>

// CIRServerApplication
class CIRServerApplication : public CAknApplication
{
private:

  /**
   * Create document object for this Application
   */
  CApaDocument* CreateDocumentL();

  /**
   * Returns application's UID
   */
  TUid AppDllUid() const;
};


#endif // __IRSERVER_APP_H__

