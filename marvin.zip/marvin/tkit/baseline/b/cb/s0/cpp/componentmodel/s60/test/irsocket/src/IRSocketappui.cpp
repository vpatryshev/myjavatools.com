////////////////////////////////////////////////////////////////////////////////
// Implementation of CIRSocketAppUi
////////////////////////////////////////////////////////////////////////////////

#include <e32std.h>
#include "IRSocket.hrh"
#include "IRSocketappui.h"
#include "IRSocketview.h"


/**
 * Method managed by IDE to construct views
 * Please do not edit this routine as its
 * contents is regenerated upon new view creation.
 */
void CIRSocketAppUi::InitViewsL()
{
  iIRSocketView = CIRSocketView::NewL();
  AddViewL(iIRSocketView);
}

void CIRSocketAppUi::ConstructL()
{
  BaseConstructL();
  InitViewsL();

  // Set default view
  SetDefaultViewL(*iIRSocketView);
}

void CIRSocketAppUi::HandleCommandL(TInt aCommand)
{
  switch (aCommand) {
    case EEikCmdExit:
    case EAknSoftkeyExit:
      Exit();
      break;
    default:
      break;
  }
}

