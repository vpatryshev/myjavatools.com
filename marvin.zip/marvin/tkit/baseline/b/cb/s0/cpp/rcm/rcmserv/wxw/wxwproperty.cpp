#ifdef __BORLANDC__
#include "rcmpch.h"
#endif

#include "wxwproperty.h"
#include "wxwevent.h"
#include "wxwdesigner.h"
#include "wxwcomponent.h"

typedef struct {
    const wxTypeInfo *TypeInfo;
    const wxClassInfo *ComponentClass;
    wxString PropertyName;
    const wxClassInfo *EditorClass;
} xtiPropertyEntry;

typedef list<xtiPropertyEntry*> PropertyEditors;
PropertyEditors propEds;

bool IsClassType(const wxTypeInfo *ti)
{
	wxTypeKind kind = ti->GetKind();
	return kind == wxT_OBJECT || kind == wxT_OBJECT_PTR;
}

bool InheritsFrom(const wxTypeInfo *a, const wxTypeInfo *b)
{
	const wxClassTypeInfo *ca = dynamic_cast<const wxClassTypeInfo*>(a);
	const wxClassTypeInfo *cb = dynamic_cast<const wxClassTypeInfo*>(b);
    assert(ca && cb);
	return ca->GetClassInfo()->IsKindOf(cb->GetClassInfo());
}

const wxClassInfo* GetPropertyEditorClass(const wxPropertyInfo *propInfo, wxObject *instance)
{
	if (!propInfo)
    	return 0;

    const wxTypeInfo *propType = propInfo->GetTypeInfo();   // property type info
    if (!propType)
    	return 0;

    const wxPropertyAccessor *acc = propInfo->GetAccessor();

    if (!(propType->IsDelegateType() || (acc && (acc->HasGetter() || acc->HasCollectionGetter()))))
        return 0;

   	wxString propName(propInfo->GetName());                 // property name
    wxString cName;                                         // candidate name
    const wxTypeInfo *cType;                                // candidate type info
    classinfo_type *cClass;                                 // candidate class info
    xtiPropertyEntry *p = 0;                           // currently examined registered entry
    xtiPropertyEntry *c = 0;                           // best entry so far

    PropertyEditors::iterator it = propEds.begin();
   	while (it != propEds.end()) {
        p = *it;
        if (
            // compatible property type
            (p->TypeInfo == propType) ||
            // compatible class type
            (   (IsClassType(propType)) &&
            	(IsClassType(p->TypeInfo)) &&
                (InheritsFrom(propType, p->TypeInfo))
            )
        )
        {
            if (
                ((p->ComponentClass == CLASSINFO(wxObject)) || (instance && instance->IsKindOf((const_cast<wxClassInfo*>(p->ComponentClass)))))
                && ((p->PropertyName.Length() == 0) || (propInfo->GetName() == p->PropertyName))
                )
                {
                    if  ((c == NULL) || // see if p is a better match than c
                        ((c->ComponentClass == CLASSINFO(wxObject)) && (p->ComponentClass != CLASSINFO(wxObject))) ||
                        ((c->PropertyName.Length() == 0) && (p->PropertyName.Length() > 0)) ||
                        // p's typeinfo match is exact but c's isn't
                        ((c->TypeInfo != propType) && (p->TypeInfo == propType)) ||
                        // p's typeinfo is more specific than c's typeinfo
                        (   (p->TypeInfo != c->TypeInfo) &&
                            ( // p has a more specific class type than c
                                (c->TypeInfo != NULL) &&
                                (IsClassType(p->TypeInfo)) &&
								(IsClassType(c->TypeInfo)) &&
								(InheritsFrom(p->TypeInfo, c->TypeInfo))
							)
						) || // p's component class is more specific thatn c's component class
						(	(p->ComponentClass != CLASSINFO(wxObject)) && (c->ComponentClass != CLASSINFO(wxObject)) &&
							(p->ComponentClass != c->ComponentClass) &&
							(p->ComponentClass->IsKindOf(c->ComponentClass))
                    	))
                    {
						c = p;
                    }
                }
        }
		++it;
    }
	if (c != NULL) {
		return c->EditorClass;
	}

    if (propType) {
        const wxTypeKind tk = propType->GetKind();
        switch (tk) {
            case wxT_BOOL:
                return CLASSINFO(wxBooleanProperty);
            case wxT_UCHAR:
                return CLASSINFO(wxUCharProperty);
            case wxT_ENUM:
                return CLASSINFO(wxEnumProperty);
            case wxT_OBJECT_PTR:
            	return CLASSINFO(wxObjectProperty);
            case wxT_OBJECT:
                return CLASSINFO(wxObjectRefProperty);
            case wxT_INT:
            case wxT_UINT:
            case wxT_LONG:
            case wxT_ULONG:
                return CLASSINFO(wxIntProperty);
            case wxT_DELEGATE:
            	return CLASSINFO(xtiEvent);
                //wxASSERT_MSG(0, "trying to create property editor for an event");
			case wxT_COLLECTION:
			    return CLASSINFO(wxCollectionProperty);
            default:
                return CLASSINFO(xtiProperty);
        }
    }
    return 0;
}

void RegisterPropertyEditor(const wxTypeInfo *typeInfo, const wxClassInfo *componentClass,
    const wxString &propertyName, const wxClassInfo *editorClass)
{
    // editorClass can be null - then the property can't be edited and won't appear in the inspector
    if (!typeInfo) return;
    xtiPropertyEntry *entry = new xtiPropertyEntry();
    entry->TypeInfo = typeInfo;
    entry->ComponentClass = componentClass;
    entry->PropertyName = "";
    if (entry->ComponentClass) {
        entry->PropertyName = propertyName;
    }
    entry->EditorClass = editorClass;
    propEds.push_front(entry);
}

// wxPropertyBase

IMPLEMENT_ABSTRACT_CLASS(wxPropertyBase, wxObject)

wxPropertyBase::wxPropertyBase()
    : FDesigner(0), FParent(0), FFlags(0)
{
}

void wxPropertyBase::Init(
	wxwDesigner *designer,
	wxObject *instance,
	wxPropertyBase *parent,
	const wxString &name)
{
	if (FFlags & PE_NESTED) {
		FDesigner = parent->wxDesigner();
		FInstance = parent->Instance();
	}
	else {
		FDesigner = designer;
		FInstance = instance;
	}
	FParent = parent;
	FName = name;
    PropertyKeyArray(FKeys, this);
}


bool wxPropertyBase::SetValue(const wxString &value)
{
    if (FFlags & PE_READONLY) {
        return false;
    }
    bool wasSet = false;
    wxString oldValue = Get();
    if (value != oldValue) {
        Set(value);
        /*
            Requested value can be vetoed or modified by the property setter.
            Counts as successful change if the value changes to any new value.
        */
        wasSet = Get() != oldValue;
        if (wasSet &&FParent) {
            FParent->ChildChanged(this);
        }
    }
    return wasSet;
}

void wxPropertyBase::ChildChanged(wxPropertyBase *child)
{
    if (FParent)
        FParent->ChildChanged(child);
}

wxString wxPropertyBase::GetValue() const
{
    return Get();
}

const wxArrayString& wxPropertyBase::Keys() const
{
    return FKeys;
}

Result* wxPropertyBase::Revert()
{
    return new Result(false);
}

rcmDesigner* wxPropertyBase::Designer() const
{
    return FDesigner;
}

rcmProperty* wxPropertyBase::GetChildProperty(const wxString &name)
{
	// is there one in the list already that we've "faked"?
	PropertyHash::iterator it = FChildren.find(name);
    if (it != FChildren.end()) {
        return (*it).second;
    }
    return 0;
}

void wxPropertyBase::GetChildren(rcmProperties &subProps)
{
    xtiProperty *child = 0;
    // send back children we may have "faked"
    PropertyHash::iterator it = FChildren.begin();
    for (; it != FChildren.end(); ++it) {
        child = it->second;
        subProps.push_back(child);
    }
}

wxString wxPropertyBase::Description() const
{
    return FDescription;
}

// xtiProperty

IMPLEMENT_DYNAMIC_CLASS(xtiProperty, wxPropertyBase)

xtiProperty::xtiProperty()
    : wxPropertyBase(), FPropInfo(0)
{

}

void xtiProperty::Create(
    const wxPropertyInfo *propInfo,
    wxwDesigner *designer,
    wxObject *instance,
    wxPropertyBase *parent,
    const wxString &name)
{
    if (FFlags & PE_NESTED) {
		xtiProperty *xtiParent = dynamic_cast<xtiProperty*>(parent);
		if (!parent) {
			throw error("An xtiProperty must be nested within an xtiProperty");
		}
        FPropInfo = xtiParent->PropInfo();
    }
    else {
        FPropInfo = propInfo;
    }
	wxPropertyBase::Init(designer, instance, parent, name.IsEmpty() ? FPropInfo->GetName() : name);
    const wxPropertyAccessor *accessor = FPropInfo->GetAccessor();
    if (accessor && !accessor->HasSetter())
        FFlags |= PE_READONLY;
}

wxString xtiProperty::TypeKey() const
{
    return FPropInfo->GetTypeInfo()->GetTypeName();
}

wxString xtiProperty::Get() const
{
    wxASSERT_MSG(Instance(), "Cannot get value for null instance");
    wxASSERT_MSG(!FPropInfo->GetTypeInfo()->IsDelegateType(), "xtiProperty::Get() must be overridden for delegate types");
    wxString sValue("no string converter");
    const wxTypeInfo *ti = FPropInfo->GetTypeInfo();
    wxxVariant vValue = GetAsVariant();
//    FPropInfo->GetAccessor()->GetProperty(Instance(), vValue);
    // special case of "enum flags". See xti.h for the gory details.
    if (FPropInfo->GetFlags() & wxPROP_ENUM_STORE_LONG)
    {
        const wxEnumTypeInfo *eti = dynamic_cast<const wxEnumTypeInfo*>(ti);
        wxASSERT_MSG( eti, wxT("Type must have enum - long conversion")) ;
        eti->ConvertFromLong(vValue.Get<long>(), vValue) ;
    }
    if (ti->HasStringConverters()) {
        ti->ConvertToString(vValue, sValue);
    }
    return sValue;
}

wxxVariant xtiProperty::GetAsVariant() const
{
    wxxVariant value;
    FPropInfo->GetAccessor()->GetProperty(Instance(), value);
    return value;
}


void xtiProperty::Set(const wxString &value)
{
	wxASSERT_MSG(Instance(), "Instance cannot be NULL");
    wxASSERT_MSG(!FPropInfo->GetTypeInfo()->IsDelegateType(), "xtiProperty::Set() must be overridden for delegate types");
    wxxVariant vValue;
    const wxTypeInfo *ti = FPropInfo->GetTypeInfo();
    if (ti->HasStringConverters()) {
        ti->ConvertFromString(value, vValue);
        // special case of "enum flags". See xti.h for the gory details.
        if (FPropInfo->GetFlags() & wxPROP_ENUM_STORE_LONG)
        {
            const wxEnumTypeInfo *eti = dynamic_cast<const wxEnumTypeInfo*>(ti);
            wxASSERT_MSG( eti, wxT("Type must have enum - long conversion"));
            long longval;
            eti->ConvertToLong(vValue, longval);
            FPropInfo->GetAccessor()->SetProperty(Instance(), wxxVariant(longval));
            return;
        }
        //FPropInfo->GetAccessor()->SetProperty(Instance(), vValue);
        SetAsVariant(vValue);
    }
}

void xtiProperty::SetAsVariant(const wxxVariant &value)
{
    FPropInfo->GetAccessor()->SetProperty(Instance(), value);
}


wxObject* xtiProperty::GetPropInstance()
{
    if (Instance() && TypeInfo()
        && TypeInfo()->GetKind() == wxT_OBJECT_PTR)
    {
	    const wxPropertyAccessor *pa = FPropInfo->GetAccessor();
		wxxVariant v;
		pa->GetProperty(Instance(), v);
    	return v.GetAsObject();
    }
    return 0;
}

wxString xtiProperty::Description() const
{
    return FPropInfo->GetHelpString();
}

const wxTypeInfo* xtiProperty::TypeInfo() const
{
    return FPropInfo ? FPropInfo->GetTypeInfo() : 0;
}

// wxEnumProperty

IMPLEMENT_DYNAMIC_CLASS(wxEnumProperty, xtiProperty)

void wxEnumProperty::GetChoices(PropertyChoices &choices)
{
    const wxEnumTypeInfo *eti = dynamic_cast<const wxEnumTypeInfo*>(FPropInfo->GetTypeInfo());
    if (eti) {
        const wxEnumData *e = eti->GetEnumData();
        assert(e != NULL);
        for (int i=0; i<e->GetEnumCount(); i++) {
            wxString enumName(e->GetEnumMemberName(i));
            if (!enumName.empty()) {
                choices.push_back(new PropertyChoice(enumName));
            }
        }
    }
}


// wxIntProperty

IMPLEMENT_DYNAMIC_CLASS(wxIntProperty, xtiProperty)

wxString wxIntProperty::Get() const
{
    const wxTypeInfo *ti = FPropInfo->GetTypeInfo();
    const wxPropertyAccessor *pa = FPropInfo->GetAccessor();
    if (ti && pa) {
        wxxVariant val;
        pa->GetProperty(Instance(), val);
        switch (ti->GetKind()) {
            case wxT_INT:
                return wxString().Format("%d", val.Get<int>());
            case wxT_LONG:
                return wxString().Format("%d", val.Get<long>());
            case wxT_UINT:
                return wxString().Format("%u", val.Get<unsigned int>());
            case wxT_ULONG:
                return wxString().Format("%u", val.Get<unsigned long>());
            default:
                return wxT("Error: unknown integer type");
        }
    }
    else
        return wxT("Error: invalid accessor");
}

void wxIntProperty::Set(const wxString &value)
{
    const wxTypeInfo *ti = FPropInfo->GetTypeInfo();
    const wxPropertyAccessor *pa = FPropInfo->GetAccessor();
    if (ti && pa) {
        wxxVariant v;
        switch (ti->GetKind()) {
            case wxT_INT:
            case wxT_LONG:
            {
                long val;
                if (!value.ToLong(&val)) {
                    throw error(wxString().Format("\"%s\" is not a valid integer value", value));
                }
                if (ti->GetKind() == wxT_INT) {
                    int ival = val;
                    pa->SetProperty(Instance(), wxxVariant(ival));
                }
                else
                    pa->SetProperty(Instance(), wxxVariant(val));
                break;
            }
            case wxT_UINT:
            case wxT_ULONG:
            {
                unsigned long val;
                if (!value.ToULong(&val)) {
                    throw error(wxString().Format("\"%s\" is not a valid unsigned long value", value));
                }
                if (ti->GetKind() == wxT_UINT) {
                    unsigned int ival = val;
                    pa->SetProperty(Instance(), wxxVariant(ival));
                }
                else
                    pa->SetProperty(Instance(), wxxVariant(val));
            }
        }
    }
}

// wxCharProperty

IMPLEMENT_DYNAMIC_CLASS(wxCharProperty, xtiProperty)

void wxCharProperty::Set(const wxString &value)
{
    long charVal;
    if (!value.ToLong(&charVal) || charVal > 128 || charVal < -127) {
        throw error(wxString().Format("\"%s\" is not a valid char value", value));
    }
    xtiProperty::Set(value);
}


// wxUCharProperty

IMPLEMENT_DYNAMIC_CLASS(wxUCharProperty, xtiProperty)

void wxUCharProperty::Set(const wxString &value)
{
    unsigned long uCharVal;
    if (!value.ToULong(&uCharVal) || uCharVal > 255) {
        throw error(wxString().Format("\"%s\" is not a valid unsigned char value", value));
    }
    xtiProperty::Set(value);
}

// wxObjectProperty

IMPLEMENT_DYNAMIC_CLASS(wxObjectProperty, xtiProperty)

void RecurseObjectProperties(rcmProperties &props, wxPropertyBase *parentProp,
    const wxClassInfo *classInfo, wxObject *object, wxwDesigner *designer)
{
    const wxPropertyInfo *pi = classInfo->GetFirstProperty();
	while( pi )
	{
        // skip events
    	if (!pi->GetTypeInfo()->IsDelegateType()) {
            const wxClassInfo *peClass = GetPropertyEditorClass(pi, object);
            if (peClass) {
                xtiProperty *pe = dynamic_cast<xtiProperty*>(peClass->CreateObject());
                if (pe) {
                    pe->Create(pi, designer, object, parentProp);
                    props.push_back(pe);
                }
            }
        }
		pi = pi->GetNext();
	}
    const wxClassInfo **parents = classInfo->GetParents();
    int i = 0;
    while (parents[i]) {
        RecurseObjectProperties(props, parentProp, parents[i], object, designer);
        i++;
    }
}

bool wxObjectProperty::HasProperties() const
{
    wxObject *object = GetPropInstance();
    if (!object)
        return false;
    return object->GetClassInfo() && object->GetClassInfo()->GetFirstProperty();
}

rcmProperty* wxObjectProperty::GetChildProperty(const wxString &name)
{
    xtiProperty *result = 0;
    const wxPropertyInfo *pi = 0;
    wxObject *propObject = GetPropInstance();
    if (propObject) {
        pi = propObject->GetClassInfo()->FindPropertyInfo(name);
    }
    else {
        const wxClassTypeInfo *cti = dynamic_cast<const wxClassTypeInfo*>(TypeInfo());
        pi = cti->GetClassInfo()->FindPropertyInfo(name);
    }
    // if I have an actual property by this name, create a property object
    // with me as the parent.
    if (pi) {
        const wxClassInfo *peClass = GetPropertyEditorClass(pi, propObject);
        if (peClass) {
            result = dynamic_cast<xtiProperty*>(peClass->CreateObject());
            result->Create(pi, wxDesigner(), propObject, this);
        }
    }
    return result;
}

void wxObjectProperty::GetChildren(rcmProperties &subProps)
{
    if (HasProperties()) {
     	RecurseObjectProperties(subProps, this, GetPropInstance()->GetClassInfo(),
            GetPropInstance(), wxDesigner());
    }
}

int	wxObjectProperty::Flags() const
{
    int flags = FFlags;
    if (HasProperties()) {
        flags |= PE_SUBPROPS;
    }
    return flags;
}

wxString wxObjectProperty::Get() const
{
    wxObject *object = GetPropInstance();
    if (!object) {
        return wxT("NULL");
    }
    else if (wxDesigner()) {
        // is the property being designed by our designer?
        wxwComponent *compObject = wxDesigner()->wxManager()->FindComponentByInstance(object);
        if (compObject) {
            return compObject->GetName();
        }
        else if (wxWindow *myWindow = dynamic_cast<wxWindow*>(object)) {
            return wxString::Format("Id=%d", myWindow->GetId());
        }
        else {
            return object->GetClassInfo()->GetClassName();
        }
    }
    return wxT("Unknown value");
}

// wxObjectRefProperty

IMPLEMENT_DYNAMIC_CLASS(wxObjectRefProperty, xtiProperty)

wxObjectRefProperty::~wxObjectRefProperty()
{
    if (propInstance)
        delete propInstance;
}

wxObject* wxObjectRefProperty::GetPropInstance()
{
    // wxPropertyAccessor->GetProperty(instance) for an object reference will always
    // return a copy of the object, so we can't call the inherited GetPropInstance()
    // more than once during the property's lifetime without referring to a different object instance.
    // Have to cache the original property instance in a class-local variant.
    if (!Instance())
        return NULL;
    if (!propInstance) {
        // propInstance gets freed in the destructor.
        propInstance = new wxxVariant();
        FPropInfo->GetAccessor()->GetProperty(Instance(), *propInstance);
    }
    return propInstance->GetAsObject();
}

void wxObjectRefProperty::GetChildren(rcmProperties &subProps)
{
    wxObject *propObject = GetPropInstance();
    if (propObject) {
        RecurseObjectProperties(subProps, this, propObject->GetClassInfo(),
            propObject, wxDesigner());
    }
    else {
        const wxClassTypeInfo *cti = dynamic_cast<const wxClassTypeInfo*>(TypeInfo());
        if (cti) {
            RecurseObjectProperties(subProps, this, cti->GetClassInfo(), NULL, wxDesigner());
        }
    }
}

rcmProperty* wxObjectRefProperty::GetChildProperty(const wxString &name)
{
    xtiProperty *result = 0;
    const wxPropertyInfo *pi = 0;
    wxObject *propObject = GetPropInstance();
    if (propObject) {
        pi = propObject->GetClassInfo()->FindPropertyInfo(name);
    }
    else {
        const wxClassTypeInfo *cti = dynamic_cast<const wxClassTypeInfo*>(TypeInfo());
        pi = cti->GetClassInfo()->FindPropertyInfo(name);
    }
    // if I have an actual property by this name, create a property object
    // with me as the parent.
    if (pi) {
        const wxClassInfo *peClass = GetPropertyEditorClass(pi, propObject);
        if (peClass) {
            result = dynamic_cast<xtiProperty*>(peClass->CreateObject());
            result->Create(pi, wxDesigner(), propObject, this);
        }
    }
    return result;
}

void wxObjectRefProperty::ChildChanged(wxPropertyBase *child)
{
    // set the property based on our modified copy of the original object property
    // instance
    if (propInstance)
        FPropInfo->GetAccessor()->SetProperty(Instance(), *propInstance);
    wxPropertyBase::ChildChanged(child);
}

wxString wxObjectRefProperty::Get() const
{
    // this should return the name of the object, or some other unique identifier
    wxObject *property = GetPropInstance();
    if (property) {
        return property->GetClassInfo()->GetClassName();
    }
    return wxT("Unknown value");
}

// wxCollectionItem

wxCollectionItem::wxCollectionItem(wxxVariant &value, int index)
{
    FIndex = index;
    FValue = value;
}

wxString wxCollectionItem::Get() const
{
    wxString sValue = wxT("Unknown");
    const wxTypeInfo *ti = ((wxCollectionProperty*)Parent())->ElementType();
    if (ti->HasStringConverters()) {
        ti->ConvertToString(FValue, sValue);
    }
    return sValue;
}

wxString wxCollectionItem::TypeKey() const
{
    return ((wxCollectionProperty*)Parent())->ElementType()->GetTypeName();
}

IMPLEMENT_DYNAMIC_CLASS(wxCollectionProperty, xtiProperty)

void wxCollectionProperty::Create(
        const wxPropertyInfo *propInfo,
    	wxwDesigner *designer,
        wxObject *instance,
        wxPropertyBase *parent,
        const wxString &name)
{
    xtiProperty::Create(propInfo, designer, instance, parent, name);
    if (instance) {
        wxxVariantArray collection;
        FPropInfo->GetAccessor()->GetPropertyCollection(Instance(), collection);
        wxString childName;
        for (unsigned int i=0; i < collection.size(); i++) {
            childName = wxString::Format("%d", i);
            wxCollectionItem *ed = new wxCollectionItem(collection[i], i);
            ed->Create(propInfo, designer, instance, this, childName);
            FChildren[childName] = ed;
        }
    }
}

int wxCollectionProperty::Flags() const
{
    if (Instance() && FPropInfo->GetAccessor()) {
        wxxVariantArray collection;
        FPropInfo->GetAccessor()->GetPropertyCollection(Instance(), collection);
        if (collection.size() > 0)
            return FFlags | PE_SUBPROPS;
    }
    return FFlags;
}

const wxTypeInfo* wxCollectionProperty::ElementType() const
{
    const wxCollectionTypeInfo *cti = dynamic_cast<const wxCollectionTypeInfo*>(FPropInfo->GetTypeInfo());
    return cti->GetElementType();
}

wxString wxCollectionProperty::Get() const
{
    return wxString::Format(wxT("Collection of %s"), ElementType()->GetTypeName());
}

// wxBooleanProperty

IMPLEMENT_DYNAMIC_CLASS(wxBooleanProperty, xtiProperty)

void wxBooleanProperty::GetChoices(PropertyChoices &choices)
{
    choices.push_back(new PropertyChoice("true"));
    choices.push_back(new PropertyChoice("false"));
}

// wxwSetElementProperty

wxSetElementProperty::wxSetElementProperty() : wxBooleanProperty()
{
    FFlags |= PE_NESTED | PE_NOTIFYCOMPCHANGE;
}

wxString wxSetElementProperty::TypeKey() const
{
    return "bool";
}

wxSetProperty* wxSetElementProperty::ParentSet() const
{
 	return dynamic_cast<wxSetProperty*>(Parent());
}

int wxSetElementProperty::Value() const
{
	return ParentSet()->FEnumData->GetEnumMemberValue(this->Name());
}

void wxSetElementProperty::Set(const wxString &value)
{
 	wxxVariant v;
    FPropInfo->GetAccessor()->GetProperty(Instance(), v);
    long setval = v.Get<long>();
    bool include = false;
    wxStringReadValue(value, include);
    if (include)
    	setval |= Value();
    else
    	setval &= ~(Value());
    FPropInfo->GetAccessor()->SetProperty(Instance(), wxxVariant(setval));
}

wxString wxSetElementProperty::Get() const
{
    wxString sVal(wxT("???"));
    wxxVariant v;
    FPropInfo->GetAccessor()->GetProperty(Instance(), v);
    wxStringWriteValue(sVal, (bool)(Value() & v.Get<long>()));
    return sVal;
}

// wxSetProperty

IMPLEMENT_DYNAMIC_CLASS(wxSetProperty, xtiProperty)

void wxSetProperty::Create(
    const wxPropertyInfo *propInfo,
    wxwDesigner *designer,
    wxObject *instance,
    wxPropertyBase *parent,
    const wxString &name)
{
    xtiProperty::Create(propInfo, designer, instance, parent, name);
    FTypeInfo = dynamic_cast<const wxEnumTypeInfo*>(FPropInfo->GetTypeInfo());
    wxASSERT_MSG(FTypeInfo && FTypeInfo->GetKind() == wxT_SET,
        wxString::Format("Property %s is not a valid type", propInfo->GetName()));
    FEnumData = FTypeInfo->GetEnumData();
    for (int i=0; i<FEnumData->GetEnumCount(); i++) {
        wxString enumName = FEnumData->GetEnumMemberNameByIndex(i);
        int enumValue = FEnumData->GetEnumMemberValue(enumName);
        if (FEnumData->GetEnumMemberName(enumValue) == enumName) {
            wxSetElementProperty *el = new wxSetElementProperty();
            el->Create(propInfo, designer, instance, this, enumName);
            FChildren[enumName] = el;
        }
    }
}

