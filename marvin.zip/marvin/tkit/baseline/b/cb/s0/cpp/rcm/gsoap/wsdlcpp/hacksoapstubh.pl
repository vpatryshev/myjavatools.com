if (!(-e 'soapstub.h')) {
	die "File soapstub.h not found";
}
open (SOAPSTUBH, 'soapstub.h');
open (OUTFILE, '>soapstub.h.hacked');
$movedWSLiveUIDesigner = 0;
@wsLiveUIDesigner = ();
$movedWSLiveComponents = 0;
@wsLiveUIComponent = ();
@wsLiveUIContainer = ();
@movedWSLiveProperty = 0;
@wsLiveProperty = ();

while () {
	$line = <SOAPSTUBH>;
	$index = 0;
	
#	look for declaration of impl__WSLiveUIDesigner, which is declared before its ancestor
	if (($movedWSLiveUIDesigner == 0) && ($line =~ m/ifndef _SOAP_impl__WSLiveUIDesigner\b/)) {
		while (!($line =~ m/endif/)) {
			$wsLiveUIDesigner[$index] = $line;
			$index++;
			$line = <SOAPSTUBH>;		
		}
		$wsLiveUIDesigner[$index] = $line;
		next;
	}
	
	# look for declaration of impl__WSLiveDesigner and write impl__WSLiveUIDesigner after it.
	if ($line =~ m/#ifndef\s*_SOAP_impl__WSLiveDesigner\b/) {
		while (!($line =~ m/#endif/)) {
			print OUTFILE $line;
			$line = <SOAPSTUBH>;
		}		
		print OUTFILE $line;
		print OUTFILE "\n";
		print OUTFILE @wsLiveUIDesigner;
		$movedWSLiveUIDesigner = 1;
		next;
	}
	
#	look for declaration of impl__WSLiveUIComponent, which is declared before its ancestor
	if (($movedWSLiveComponents == 0) && ($line =~ m/ifndef _SOAP_impl__WSLiveUIComponent\b/)) {
		while (!($line =~ m/endif/)) {
			$wsLiveUIComponent[$index] = $line;
			$index++;
			$line = <SOAPSTUBH>;		
		}
		$wsLiveUIComponent[$index] = $line;
		next;
	}
	
#	look for declaration of impl__WSLiveUIContainer, which is declared before its ancestor
	if (($movedWSLiveComponents == 0) && ($line =~ m/ifndef _SOAP_impl__WSLiveUIContainer\b/)) {
		while (!($line =~ m/endif/)) {
			$wsLiveUIContainer[$index] = $line;
			$index++;
			$line = <SOAPSTUBH>;		
		}
		$wsLiveUIContainer[$index] = $line;
		next;
	}

#	look for declaration of impl__WSLiveUIContainer, which is declared before its ancestor
	if (($movedWSLiveProperty == 0) && ($line =~ m/ifndef _SOAP_impl__WSLiveProperty\b/)) {
		while (!($line =~ m/endif/)) {
			$wsLiveProperty[$index] = $line;
			$index++;
			$line = <SOAPSTUBH>;		
		}
		$wsLiveProperty[$index] = $line;
		next;
	}

	
	# look for declaration of impl__WSLiveComponent and write impl__WSLiveUIDesigner after it.
	if ($line =~ m/#ifndef\s*_SOAP_impl__WSLiveComponent\b/) {
		while (!($line =~ m/#endif/)) {
			print OUTFILE $line;
			$line = <SOAPSTUBH>;
		}		
		print OUTFILE $line;
		print OUTFILE "\n";
		print OUTFILE @wsLiveUIComponent;
		print OUTFILE "\n";
		print OUTFILE @wsLiveUIContainer;
		$movedWSLiveComponents = 1;
		next;
	}

	# look for declaration of impl__WSPropertyInfo and write impl__WSLiveProperty after it.
	if ($line =~ m/#ifndef\s*_SOAP_impl__WSPropertyInfo\b/) {
		while (!($line =~ m/#endif/)) {
			print OUTFILE $line;
			$line = <SOAPSTUBH>;
		}		
		print OUTFILE $line;
		print OUTFILE "\n";
		print OUTFILE @wsLiveProperty;
		print OUTFILE "\n";
		print OUTFILE @wsLiveUIContainer;
		$movedWSLiveProperty = 1;
		next;
	}

	
	print OUTFILE $line;
	if (eof(SOAPSTUBH)) { last; }
}

close(SOAPSTUBH);
close(OUTFILE);