//---------------------------------------------------------------------------

#ifndef MainInstantiatorFormH
#define MainInstantiatorFormH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Buttons.hpp>
#include "CodeGuardConfiguration_OCX.h"
#include <OleCtrls.hpp>
//---------------------------------------------------------------------------
class TfrmInstantiator : public TForm
{
__published:	// IDE-managed Components
    TPanel *pnlOKCancel;
    TBitBtn *cmdOK;
    TBitBtn *cmdCancel;
    TCodeGuardConfigDialog *CodeGuardConfigDialog;
    void __fastcall cmdCancelClick(TObject *Sender);
    void __fastcall cmdOKClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TfrmInstantiator(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmInstantiator *frmInstantiator;
//---------------------------------------------------------------------------
#endif
