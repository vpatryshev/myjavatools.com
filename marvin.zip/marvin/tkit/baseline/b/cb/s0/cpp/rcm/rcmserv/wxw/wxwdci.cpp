#ifdef __BORLANDC__
#include "rcmpch.h"
#endif

#include "wxw.h"
#include "wxwdci.h"
#include <stdexcept>

wxRootClassInfo* NewRootClassInfo(const wxString &className, const wxClassInfo *superClass)
{
    if (wxClassInfo::FindClass(className)) {
        throw new runtime_error(wxString::Format(
            "A class named \"%s\" already exists.\n \
            Cannot design frames with identical classnames. \n \
            Please close all design nodes and reopen only one. ", className).c_str());
    }
    return new wxRootClassInfo(className, superClass);
}

void DeleteRootClassInfo(wxRootClassInfo *rci)
{
    char *className = const_cast<char*>(rci->m_className);
    delete rci;
    delete className;
}

wxRootClassInfo::wxRootClassInfo(const wxString &className, const wxClassInfo *superClass)
    : wxDynamicClassInfo("", StrAlloc(FClassName, className.c_str()), superClass) { }

bool wxRootClassInfo::SetClassName(const wxString &newClassName)
{
    if (newClassName.compare(m_className) == 0)
        return true;
    if (wxClassInfo::FindClass(newClassName))
        throw new runtime_error(wxString::Format("A class named \"%s\" already exists", newClassName).c_str());
    Unregister();
    delete FClassName;
    StrAlloc(FClassName, newClassName.c_str());
    m_className = FClassName;
    Register();
    return wxClassInfo::FindClass(newClassName) == this;
}
