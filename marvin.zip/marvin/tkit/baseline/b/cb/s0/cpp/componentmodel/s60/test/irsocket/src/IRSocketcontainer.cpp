////////////////////////////////////////////////////////////////////////////////
// Implementation of CIRSocketContainer
////////////////////////////////////////////////////////////////////////////////

#include <aknutils.h>
#include <eiklabel.h>
#include <IRSocket.rsg>

#include <barsread.h>
#include <eikappui.h>
#include <eikedwin.h>
#include <txtglobl.h>
#include <coeinput.h>
#include <aknlists.h>
#include <akniconarray.h>
#include <eikclbd.h>
#include <akntitle.h>
#include <aknslider.h>
#include <eikspane.h>
#include <aknnavilabel.h>
#include <eikmfne.h>
#include <aknnumseced.h>
#include <aknipfed.h>
#include <in_sock.h>
#include <eikprogi.h>
#include <AknNumEdwin.h>
#include <eikfpne.h>
#include <aknnumed.h>
#include <aknglobalnote.h>
#include <AknNoteDialog.h>
#include <aknnotewrappers.h>
#include <aknprogressdialog.h>
#include <aknstaticnotedialog.h>
#include <aknquerydialog.h>


#include "IRSocketcontainer.h"

_LIT(KAlreadyConnected, "Already connected");
_LIT(KNotConnected, "Not connected");
_LIT(KConnected, "Connected");
_LIT(KConnecting, "Connecting...");
_LIT(KDisconnected, "Disconnected");
_LIT(KDisconnecting, "Disconnecting...");
_LIT(KConnectError, "Connect Error");
_LIT(KLookingUp, "Looking up host...");
_LIT(KLookupError, "Lookup failed");
_LIT(KTimeout, "Timed out");
_LIT(KQuerying, "Querying...");
_LIT(KQueryError, "Query Error");
_LIT(KBadState, "Unknown state");

_LIT(KReceived, "Recv: ");
_LIT(KSent, "Sent: ");
_LIT(Kcrlf, "\f");
_LIT(KSpace, " ");

// IAS Query parameters
_LIT8(KDevice,"Device");
_LIT8(KDeviceName,"DeviceName");
_LIT8(KIrDAIrCOMM,"IrDA:IrCOMM");
//_LIT8(KTxtIrDAIrCOMM, "Mark");
_LIT8(KIrDATinyTP,"IrDA:TinyTP:LsapSel");


CIRSocketContainer* CIRSocketContainer::NewL(const TRect& aRect)
{
  CIRSocketContainer* self = CIRSocketContainer::NewLC(aRect);
  CleanupStack::Pop(self);
  return self;
}

CIRSocketContainer* CIRSocketContainer::NewLC(const TRect& aRect)
{
  CIRSocketContainer* self = new (ELeave) CIRSocketContainer;
  CleanupStack::PushL(self);
  self->ConstructL(aRect);
  return self;
}

CIRSocketContainer::~CIRSocketContainer()
{
  CleanupComponents();
  iCtrlArray.Reset();
}

/**
 * Routine that creates and initializes designed components
 * NOTE: Maintained by CBuilder Designer
 */
void CIRSocketContainer::InitComponents()
{
    /* 1/31/04 5:23 PM */
    /* FIXME CAknView - Missing Property Setter snippet: "In tab group" */
    /* FIXME CAknView - Missing Property Setter snippet: "Tab group" */
    CEikStatusPane * StatusPane = iEikonEnv->AppUiFactory()->StatusPane();
    StatusPane->MakeVisible( ETrue );
    CAknContextPane * cAknContextPane1 =
         ( CAknContextPane * ) iEikonEnv->AppUiFactory()->StatusPane()->ControlL( TUid::Uid( EEikStatusPaneUidContext ) );
    /* FIXME CAknContextPane - Missing Property Setter snippet: "MBM file" */
    /* FIXME CAknContextPane - Missing Property Setter snippet: "Image index" */
    /* FIXME CAknContextPane - Missing Property Setter snippet: "Mask index" */
    CAknTitlePane * cAknTitlePane1 =
         ( CAknTitlePane * ) iEikonEnv->AppUiFactory()->StatusPane()->ControlL( TUid::Uid( EEikStatusPaneUidTitle ) );
    cAknTitlePane1->SetTextL( _L( "Title Pane" ) );
    /* FIXME CAknTitlePane - Missing Property Setter snippet: "MBM file" */
    /* FIXME CAknTitlePane - Missing Property Setter snippet: "Image index" */
    CAknNavigationControlContainer * cAknNavigationControlContainer1 =
         ( CAknNavigationControlContainer * )
         iEikonEnv->AppUiFactory()->StatusPane()->ControlL( TUid::Uid( EEikStatusPaneUidNavi ) );
    /* FIXME CAknNavigationControlContainer - Missing Property Setter snippet: "MBM file" */
    /* FIXME CAknNavigationControlContainer - Missing Property Setter snippet: "Image index" */
    iBackgroundColor = iEikonEnv->Color( EColorControlBackground );
    {
        TResourceReader reader;
        iCoeEnv->CreateResourceReaderLC( reader, R_EDWIN_LAYOUT );
        cEikEdwin1 = new( ELeave )CEikEdwin;
        cEikEdwin1->SetContainerWindowL( * this );
        cEikEdwin1->ConstructFromResourceL( reader );
        CleanupStack::PopAndDestroy(); //reader
        iCtrlArray.Append( cEikEdwin1 );
    }
    cEikEdwin1->SetDimmed( EFalse );
    cEikEdwin1->SetFocus( ETrue );
    {
        TMargins8 tempMargins;
        tempMargins.iLeft = 0;
        tempMargins.iRight = 0;
        tempMargins.iTop = 0;
        tempMargins.iBottom = 0;

        cEikEdwin1->SetBorderViewMargins( tempMargins );
    }
    cEikEdwin1->SetRightWrapGutter( 0 );
    cEikEdwin1->SetExtent( TPoint( 2, 2 ), TSize( 172, 135 ) );
    cEikEdwin1->AddFlagToUserFlags( CEikEdwin::EZeroEnumValue | CEikEdwin::ENoAutoSelection | CEikEdwin::EJustAutoCurEnd );
    cEikEdwin1->SetAknEditorFlags( EAknEditorFlagDefault );
    {
        TCharFormat format;
        Mem::FillZ( & format, sizeof( TCharFormat ) );
        TCharFormatMask mask;
        Mem::FillZ( & mask, sizeof( TCharFormatMask ) );
        format.iFontSpec.iTypeface = LatinPlain12()->FontSpecInTwips().iTypeface;
        mask.SetAttrib( EAttFontTypeface );
        format.iFontPresentation.iTextColor = iEikonEnv->Color( EColorLabelText );
        mask.SetAttrib( EAttColor );
        format.iFontPresentation.iStrikethrough = ( TFontStrikethrough )EFalse;
        mask.SetAttrib( EAttFontStrikethrough );
        format.iFontPresentation.iUnderline = ( TFontUnderline )EFalse;
        mask.SetAttrib( EAttFontUnderline );
        CCharFormatLayer * layer = CCharFormatLayer::NewL( format, mask );
        cEikEdwin1->SetCharFormatLayer( layer );
    }
    cEikEdwin1->SetTextLimit( 0 );
    cEikEdwin1->SetTextL( & _L( "" ) );
    cEikEdwin1->SetWordWrapL( ETrue );
    cEikEdwin1->SetBackgroundColorL( iEikonEnv->Color( EColorWindowBackground ) );
    cEikEdwin1->SetReadOnly( EFalse );
    cEikEdwin1->SetAllowUndo( EFalse );
    cEikEdwin1->SetOnlyASCIIChars( EFalse );
    {
        TNonPrintingCharVisibility tempNonPrintingCharVisibility;
        tempNonPrintingCharVisibility.SetTabsVisible( EFalse );
        tempNonPrintingCharVisibility.SetSpacesVisible( EFalse );
        tempNonPrintingCharVisibility.SetParagraphDelimitersVisible( EFalse );
        tempNonPrintingCharVisibility.SetLineBreaksVisible( EFalse );
        tempNonPrintingCharVisibility.SetPotentialHyphensVisible( EFalse );
        tempNonPrintingCharVisibility.SetNonBreakingHyphensVisible( EFalse );
        tempNonPrintingCharVisibility.SetNonBreakingSpacesVisible( EFalse );
        tempNonPrintingCharVisibility.SetPageBreaksVisible( EFalse );
        cEikEdwin1->SetNonPrintingCharsVisibility( tempNonPrintingCharVisibility );
    }
    iIrdaSock = CIrdaSocket::NewL( 128, 128, CActive::EPriorityStandard );
    iIrdaSock->SetTimeout( 5000000 );
    iIrdaSock->SetLocalPort( 10 );
    iIrdaSock->SetRemotePort( 101 );
}

/**
 * Routine that cleans up designed components
 * NOTE: Maintained by CBuilder Designer
 */
void CIRSocketContainer::CleanupComponents()
{
    /* 1/31/04 5:23 PM */
    delete cEikEdwin1;
    delete iIrdaSock;
}

void CIRSocketContainer::ConstructL(const TRect& aRect)
{
    CreateWindowL();
    SetRect(aRect);
    InitComponents();
    TEventT<CIRSocketContainer, TInt> OnStateChangeEvent(this, &CIRSocketContainer::SocketStateChange);
    iIrdaSock->SetOnStateChange(OnStateChangeEvent);
    TEventT<CIRSocketContainer> OnConnectEvent(this, &CIRSocketContainer::SocketConnected);
    iIrdaSock->SetOnConnect(OnConnectEvent);
    TEventT<CIRSocketContainer, TInt, const TDesC8&> OnRecvEvent(this, &CIRSocketContainer::SocketRecvComplete);
    iIrdaSock->SetOnRecvComplete(OnRecvEvent);
    TEventT<CIRSocketContainer, TInt> OnWriteEvent(this, &CIRSocketContainer::SocketWriteComplete);
    iIrdaSock->SetOnWriteComplete(OnWriteEvent);
    TEventT<CIRSocketContainer, TNameRecord&> OnDiscoveredEvent(this, &CIRSocketContainer::SocketDiscovery);
    iIrdaSock->SetOnDeviceDiscovered(OnDiscoveredEvent);
    TEventT<CIRSocketContainer, TInt> OnErrorEvent(this, &CIRSocketContainer::SocketError);
    iIrdaSock->SetOnError(OnErrorEvent);
    TEventT<CIRSocketContainer, TIASResponse&> OnQueryEvent(this, &CIRSocketContainer::SocketIASQueryDone);
    iIrdaSock->SetOnIASQueryComplete(OnQueryEvent);
    cEikEdwin1->SetAknEditorFlags(EAknEditorFlagEnableScrollBars);

    ActivateL();
}


void CIRSocketContainer::Draw(const TRect& aRect) const
{
  CWindowGc& gc = SystemGc();
  gc.SetPenStyle(CGraphicsContext::ENullPen);
  gc.SetBrushColor(iBackgroundColor);
  gc.SetBrushStyle(CGraphicsContext::ESolidBrush);
  gc.DrawRect(aRect);
}

TInt CIRSocketContainer::CountComponentControls() const
{
  return iCtrlArray.Count();
}

CCoeControl* CIRSocketContainer::ComponentControl(TInt aIndex) const
{
  return (CCoeControl*)iCtrlArray[aIndex];
}

TKeyResponse CIRSocketContainer::OfferKeyEventL(const TKeyEvent& aKeyEvent, TEventCode aType)
{
  /**
  * You may place code here to act on the users key event, or pass this to a child control
  * to be handled internally by that control.
  *
  * For example:
  *   return myControl->OfferKeyEventL(aKeyEvent, aType);
  */
  if (DispatchKeyEvents(aKeyEvent, aType))
    return EKeyWasConsumed;
  else
    return EKeyWasNotConsumed;
}

void CIRSocketContainer::HandleControlEventL(CCoeControl * aControl, TCoeEvent aEventType)
{
}

/**
 * The contents of this method is maintained by the CBuilder designer
 * It attemps to dispatch commands to individual handlers
 * NOTE: Maintained by CBuilder Designer
 */
bool CIRSocketContainer::DispatchCommandEvents(TInt aCommand)
{
    switch (aCommand) {
        case EFindDevices:
        {
            iIrdaSock->FindDevices();
            break;
        }
        case EConnect:
        {
            dispBuf.Append(_L("Connect to "));
            dispBuf.Append(remoteDeviceName);
            dispBuf.Append(_L(" Port "));
            dispBuf.AppendNum(iIrdaSock->RemotePort());
            dispBuf.Append(Kcrlf);
            cEikEdwin1->SetTextL(&dispBuf);
            cEikEdwin1->DrawNow();
            iIrdaSock->ConnectL();
            break;
        }
        case EQueryName:
        {
            DoQueryName();
            break;
        }
        case EQueryPort:
        {
            DoQueryPort();
            break;
        }
        case ESend:
        {
            _LIT8(KHello, "Hello\n");
            sendBuf.Copy(KHello);
            iIrdaSock->WriteL(sendBuf);
            break;
        }
        case EDisconnect:
        {
            iIrdaSock->Disconnect();
            break;
        }
    }
  return false;
}

/**
 * Routine that attempts to dispatch Control Events
 * NOTE: Maintained by CBuilder Designer
 */
void CIRSocketContainer::DispatchControlEvents(CCoeControl * aControl, TCoeEvent aEventType)
{
}

/**
 * Routine that attempts to dispatch Key Events
 * NOTE: Maintained by CBuilder Designer
 */
bool CIRSocketContainer::DispatchKeyEvents(const TKeyEvent& aKeyEvent, TEventCode aType)
{
    if (cEikEdwin1->IsFocused()) {
        return cEikEdwin1->OfferKeyEventL(aKeyEvent, aType);
    }
  return false;
}

// Event Handlers & user supplied code

void InfoNote(const TDesC &note)
{
    CAknInformationNote *dlg = new (ELeave) CAknInformationNote;
    dlg->ExecuteLD(note);
}

void CIRSocketContainer::SocketConnected(CBase *sender)
{
    _LIT(KConnectedEvent, "(SocketConnected event)\f");
//    _LIT8(KHello, "Hello\n");
//    sendBuf.Copy(KHello);
//    iIrdaSock->WriteL(sendBuf);
    iIrdaSock->Recv();
//    iIrdaSock->RecvOneOrMore();
}

void CIRSocketContainer::SocketDiscovery(CBase *sender, TNameRecord &nameRecord)
{
    _LIT(KDiscovered, "Found: ");
    dispBuf.Append(KDiscovered);
    dispBuf.AppendNum(TIrdaSockAddr::Cast(nameRecord.iAddr).GetRemoteDevAddr());
    dispBuf.Append(Kcrlf);
    cEikEdwin1->SetTextL(&dispBuf);
    cEikEdwin1->DrawNow();
}

void CIRSocketContainer::SocketStateChange(CBase *sender, TInt state)
{
    if (sender != iIrdaSock) return;
    const TDesC *text = &KBadState;
    switch (state) {
        case CIrdaSocket::ENotConnected:
            text = &KNotConnected;
            break;
        case CIrdaSocket::EDisconnected:
            text = &KDisconnected;
            break;
        case CIrdaSocket::EDisconnecting:
            text = &KDisconnecting;
            break;
        case CIrdaSocket::EConnected:
            text = &KConnected;
            break;
        case CIrdaSocket::EConnecting:
            text = &KConnecting;
            break;
        case CIrdaSocket::EConnectError:
            text = &KConnectError;
            break;
        case CIrdaSocket::EDiscovering:
            text = &KLookingUp;
            break;
        case CIrdaSocket::EDiscoveryError:
            text = &KLookupError;
            break;
        case CIrdaSocket::ETimeout:
            text = &KTimeout;
            break;
        case CIrdaSocket::EQuerying:
            text = &KQuerying;
            break;
        case CIrdaSocket::EQueryError:
            text = &KQueryError;
            break;
        default:
            break;
    }
    dispBuf.Append(*text);
    dispBuf.Append(_L("("));
    dispBuf.AppendNum(state);
    dispBuf.Append(_L(")"));
    dispBuf.Append(Kcrlf);
    cEikEdwin1->SetTextL(&dispBuf);
    cEikEdwin1->DrawNow();
}

void CIRSocketContainer::SocketRecvComplete(CBase *sender, TInt state, const TDesC8 &data)
{
    dispBuf.Append(KReceived);
    TBuf16<KSocketDefaultBufferSize> tmp;
    tmp.Copy(data);
    dispBuf.Append(tmp);
    dispBuf.Append(Kcrlf);
    cEikEdwin1->SetTextL(&dispBuf);
}

void CIRSocketContainer::SocketWriteComplete(CBase *sender, TInt state)
{
    dispBuf.Append(KSent);
    TBuf16<KSocketDefaultBufferSize> tmp;
    tmp.Copy(sendBuf);
    dispBuf.Append(tmp);
    dispBuf.Append(Kcrlf);
    cEikEdwin1->SetTextL(&dispBuf);
//    iIrdaSock->Recv();
}


void CIRSocketContainer::SocketError(CBase *sender, TInt errorCode)
{
    _LIT(KError, "Error: ");
    dispBuf.Append(KError);
    dispBuf.AppendNum(errorCode);
    dispBuf.Append(Kcrlf);
    cEikEdwin1->SetTextL(&dispBuf);
}

void CIRSocketContainer::HandlePortQuery(TIASResponse &response)
{
    switch (response.Type()) {
        case EIASDataInteger:
        {
            dispBuf.Append(_L("Integer: "));
            TInt num;
            response.GetInteger(num);
            dispBuf.AppendNum(num);
            dispBuf.Append(Kcrlf);
            iIrdaSock->SetRemotePort(num);
            break;
        }
        default:
        {
            dispBuf.Append(_L("Unexpected result type\f"));
            break;
        }
    }
}


void CIRSocketContainer::HandleNameQuery(TIASResponse &response)
{
    switch (response.Type()) {
        case EIASDataUserString:
        {
            remoteDeviceName.Copy(response.GetCharString8());
            dispBuf.Append(_L("String: "));
            dispBuf.Append(remoteDeviceName);
            dispBuf.Append(Kcrlf);
            break;
        }
        default:
        {
            dispBuf.Append(_L("Unexpected result type\f"));
            dispBuf.Append(_L("("));
            dispBuf.AppendNum(response.Type());
            dispBuf.Append(_L(")\f"));
            break;
        }
    }
}

void CIRSocketContainer::SocketIASQueryDone(CBase *sender, TIASResponse &response)
{
    _LIT(KQueryDone, "Query Complete\f");
    dispBuf.Append(KQueryDone);
    switch (iQueryType) {
        case qtQueryName:
        {
            HandleNameQuery(response);
            break;
        }
        case qtQueryPort:
        {
            HandlePortQuery(response);
            break;
        }
    }
    cEikEdwin1->SetTextL(&dispBuf);
    cEikEdwin1->DrawNow();
}

void CIRSocketContainer::DoQueryName()
{
    dispBuf.Append(_L("Querying device name..."));
    dispBuf.Append(Kcrlf);
    cEikEdwin1->SetTextL(&dispBuf);
    cEikEdwin1->DrawNow();
    iQueryType = qtQueryName;
    iIrdaSock->IASQuery(KDevice, KDeviceName, iIrdaSock->Addr());
}

void CIRSocketContainer::DoQueryPort()
{
    _LIT8(KServiceName, "Mark Service");
    dispBuf.Append(_L("Querying IrDA:TinyTP:LsapSel..."));
    dispBuf.Append(Kcrlf);
    cEikEdwin1->SetTextL(&dispBuf);
    cEikEdwin1->DrawNow();
    iQueryType = qtQueryPort;
//    iIrdaSock->IASQuery(KIrDAIrCOMM, KIrDATinyTP, iIrdaSock->Addr());
    iIrdaSock->IASQuery(KServiceName, KIrDATinyTP, iIrdaSock->Addr());
}



