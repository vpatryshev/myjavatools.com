////////////////////////////////////////////////////////////////////////////////
// Implementation of CSampleAppUi
////////////////////////////////////////////////////////////////////////////////

#include <e32std.h>

#include "Sample.hrh"
#include "Sampleappui.h"
#include "Sampleview.h"


/**
 * Method managed by IDE to construct views
 * Please do not edit this routine as its
 * contents are regenerated upon new view creation.
 */
void CSampleAppUi::InitViewsL()
{
  iSampleView = CSampleView::NewL();
  AddViewL(iSampleView);
}

void CSampleAppUi::ConstructL()
{
  BaseConstructL();
  InitViewsL();

#ifdef WITH_TAB_GROUP
  // Show tabs for main views from resources
  CEikStatusPane* sp = StatusPane();
  iNaviPane = (CAknNavigationControlContainer *)sp->ControlL(TUid::Uid(EEikStatusPaneUidNavi));
  sp->SetDimmed(ETrue);

  // Tabgroup has been read from resource and it were pushed to the navi pane.
  // Get pointer to the navigation decorator with the ResourceDecorator() function.
  // Application owns the decorator and it has responsibility to delete the object.
  iDecoratedTabGroup = iNaviPane->ResourceDecorator();

  if (iDecoratedTabGroup) {
    iTabGroup = (CAknTabGroup*) iDecoratedTabGroup->DecoratedControl();
  }

  if (iTabGroup) {
    ActivateLocalViewL(TUid::Uid(iTabGroup->ActiveTabId()));
  } 
#else
  // Set default view
  SetDefaultViewL(*iSampleView);
#endif
}

#ifdef WITH_TAB_GROUP
TKeyResponse CSampleAppUi::HandleKeyEventL(const TKeyEvent& aKeyEvent,TEventCode aType)
{
  if (aType == EEventKey) {
    if (iTabGroup == NULL)
      return EKeyWasNotConsumed;
  }

  TInt active = iTabGroup->ActiveTabIndex();
  TInt count = iTabGroup->TabCount();

  switch (aKeyEvent.iCode) {
    case EKeyLeftArrow:
      if (active > 0) {
	// Change to usual layout
	TRect cr = ClientRect();  
	if (cr.iTl.iY == Kqpn_height_status_pane_idle) {
	  StatusPane()->SwitchLayoutL(R_AVKON_STATUS_PANE_LAYOUT_USUAL);
	}

	active--;
	iTabGroup->SetActiveTabByIndex(active);
	ActivateLocalViewL(TUid::Uid(iTabGroup->TabIdFromIndex(active)));
	return EKeyWasConsumed;
      }
      break;

  case EKeyRightArrow:
    if((active + 1) < count) {
      TRect cr = ClientRect();  
      if (cr.iTl.iY == Kqpn_height_status_pane_idle) {
	StatusPane()->SwitchLayoutL(R_AVKON_STATUS_PANE_LAYOUT_USUAL);
      }

      active++;
      iTabGroup->SetActiveTabByIndex(active);
      ActivateLocalViewL(TUid::Uid(iTabGroup->TabIdFromIndex(active)));
      return EKeyWasConsumed;
    }
    break;

  default:
    break;
  }        

  return EKeyWasNotConsumed;
}
#endif

void CSampleAppUi::HandleCommandL(TInt aCommand)
{
  switch (aCommand) {
    case EEikCmdExit:
    case EAknSoftkeyExit:
      Exit();
      break;
    case EKeyLeftArrow:
      break;

    case EKeyRightArrow:
      break;
    default:
      break;
  }
}

