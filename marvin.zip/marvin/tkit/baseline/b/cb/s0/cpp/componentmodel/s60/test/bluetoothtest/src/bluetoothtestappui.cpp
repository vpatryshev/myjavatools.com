////////////////////////////////////////////////////////////////////////////////
// Implementation of CbluetoothtestAppUi
////////////////////////////////////////////////////////////////////////////////

#include <e32std.h>
#include "bluetoothtestappui.h"
#include "bluetoothtestview.h"

void CbluetoothtestAppUi::ConstructL()
{
  BaseConstructL();

  ibluetoothtestView = CbluetoothtestView::NewL();

  AddViewL(ibluetoothtestView);
  SetDefaultViewL(*ibluetoothtestView);
}

void CbluetoothtestAppUi::HandleCommandL(TInt aCommand)
{
  switch (aCommand) {
    case EEikCmdExit:
    case EAknSoftkeyExit:
      Exit();
      break;
//    default:
//      Panic(L"Resource me");
//      break;
  }
}

