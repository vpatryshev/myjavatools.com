#ifndef __TIMEOUTTEST_VIEW_H__
#define __TIMEOUTTEST_VIEW_H__

#include <aknview.h>
#include "TimeoutTest.hrh"

// Forward ref. to container class
class CTimeoutTestContainer;


// CTimeoutTestView
class CTimeoutTestView : public CAknView
{
  public:

    /**
     * Creates a CTimeoutTestView object
     */
    static CTimeoutTestView* NewL();

    /**
     * Creates a CTimeoutTestView object
     */
    static CTimeoutTestView* NewLC();

    /**
     * Identify of this view to the system
     */
    TUid Id() const;

    /**
     * Command Handler
     */
    void HandleCommandL(TInt aCommand);

    /**
     * Activates this View
     */
    void DoActivateL(const TVwsViewId &PrevViewId, TUid  aCustomMessageId, const TDesC8& aCustomMessage);

    /**
     * Deactivate this view
     */
    void DoDeactivate();

  private:
    CTimeoutTestView();
   ~CTimeoutTestView();

    /**
     * Performs second phase construction of this view
     */
    void ConstructL();

    /**
     * Container for this view
     */
    CTimeoutTestContainer* container;

    /**
     * Identifier for this view
     */
    TUid iIdentifier;
};


#endif // __TIMEOUTTEST_VIEW_H__

