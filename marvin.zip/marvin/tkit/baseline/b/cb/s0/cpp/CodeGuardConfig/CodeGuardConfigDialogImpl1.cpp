//$$---- Active Form CPP ---- (stActiveFormSource)
//---------------------------------------------------------------------------

#include <assert.h>
#include <vcl.h>
#include <registry.hpp>
#pragma hdrstop

#include "CodeGuardConfigDialogImpl1.h"
#include "StringsRes.h"
#include "Cg_cgi.h"
#include "frmSetDefaultOptions.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

#define szCGRegistryKey "\\Software\\Borland\\CGConfig\\5.0" //do not localize
#define szCGVersion "5.0" //do not localize
#define szCGDEFAULTS "- Defaults -" //do not localize

TCodeGuardConfigDialog *CodeGuardConfigDialog;



__fastcall TCodeGuardConfigDialog::TCodeGuardConfigDialog(HWND ParentWindow)
        : TActiveForm(ParentWindow)
{}

__fastcall TCodeGuardConfigDialog::~TCodeGuardConfigDialog()
{
 if (AskToSave(StringsResContainer->CG_SAVE_CHANGES->Caption))
    SaveFile();
  delete gcgOptions;
  delete DefaultFunctionOptions;
  delete StringsResContainer;
}


void __fastcall TCodeGuardConfigDialog::ActiveFormCreate(TObject *Sender)
{
    PseudoFormCreate();
    ReadOptions();
}



void __fastcall TCodeGuardConfigDialog::PseudoFormCreate()
{
  Application->Title = Format(StringsResContainer->CG_LOADING_CAPTION->Caption,
    ARRAYOFCONST(("", "")));
  OptionUnionArray = NULL;
  lbxResources->ItemIndex = -1;
  lbxFunctions->ItemIndex = -1;
  LastResIndex = lbxResources->ItemIndex;
  LastFuncIndex = lbxFunctions->ItemIndex;
  gcgOptions = new CGOptions;
  DefaultFunctionOptions = new CGFunctionOptions;
  memset(DefaultFunctionOptions, 0, sizeof(CGFunctionOptions));
  strcpy(OptFileName, ParamStr(1).c_str());
  pgeCGOptions->ActivePage = tabPreferences;
  lblResourcesExtendedSelectNote->Caption =
    StringsResContainer->CG_EXTENDED_SELECT_NOTE->Caption;
  lblFunctionsExtendedSelectNote->Caption =
    StringsResContainer->CG_EXTENDED_SELECT_NOTE->Caption;
  cbxCGEnableClick(cbxCGEnable);
}



void __fastcall TCodeGuardConfigDialog::ReadOptions()
{
  Screen->Cursor = crHourGlass;
  try {
    AnsiString Buffer = Format(StringsResContainer->CG_LOADING_CAPTION->Caption,
      ARRAYOFCONST(((OptionsFileName() == NULL) ?
        StringsResContainer->CG_GLOBAL->Caption.c_str() : OptFileName)));
    NewCaption(Buffer);
    ClearDirty(D_OPTIONS);
    ClearDirty(D_RESOURCES);
    ClearDirty(D_FUNCTIONS);
    _cg_GetFunctionOptions(OptionsFileName(), szCGDEFAULTS, DefaultFunctionOptions, 0);
    int numRes = _cg_GetNumberOfCGResources(OptionsFileName());
    int numFunc = _cg_GetNumberOfCGFunctions(OptionsFileName());
    OptionUnion *pOptionUnion;
    if (OptionUnionArray)
      delete[] OptionUnionArray;
    OptionUnionArray = new OptionUnion[numRes+numFunc];
    memset(OptionUnionArray, 0, sizeof(OptionUnion)*numRes+numFunc);
    //Clean up
    lbxResources->Items->Clear();
    lbxFunctions->Items->Clear();
    //CGOptions
    isReading = true;
    _cg_GetCGOptions(OptionsFileName(), gcgOptions);
    cbxCGEnable->Checked                    = gcgOptions->on.value;
    edtStackFillFrequency->Text             = gcgOptions->stackFillFreq.value;
    cbxStatistics->Checked                  = gcgOptions->stat.value;
    cbxResourceLeaks->Checked               = gcgOptions->resourceLeaks.value;
    cbxSendToOutputDebugString->Checked     = gcgOptions->outDbgStr.value;
    cbxAppendToLogFile->Checked             = gcgOptions->logAppend.value;
    cbxRepeatedErrors->Checked              = gcgOptions->repeats.value;
    edtNumberOfErrorMessages->Text          = gcgOptions->maxErrors.value;
    cbxLimitNumberOfErrorMessages->Checked  = gcgOptions->limitErrors.value;
    cbxEnableErrorMessageBox->Checked       = gcgOptions->msgBox.value;
    edtErrorMessageBoxCaption->Text         = gcgOptions->caption.value;
    edtErrorMessageBoxMessage->Text         = gcgOptions->text.value;
    edtSourcePath->Text                     = gcgOptions->srcPath.value;
    cbxReadDebugInfo->Checked               = gcgOptions->dbgInfo.value;
    AnsiString s = ConvertString(gcgOptions->ignoredModules.value,';','\n');
    lbxIgnoredModules->Items->Text = s;
    //Resources
    lbxResources->Items->BeginUpdate();
    for (int i = 0; i < numRes; i++) {
      pOptionUnion = &OptionUnionArray[i];
      lbxResources->Items->AddObject(_cg_ResourceIndexToString(i), (TObject*)pOptionUnion);
      _cg_GetResourceOptions(OptionsFileName(), NULL, &pOptionUnion->resOpts, i);
    };
    lbxResources->Items->EndUpdate();
    //Functions
    lbxFunctions->Items->BeginUpdate();
    for (int i = 1; i < numFunc; i++) {
      pOptionUnion = &OptionUnionArray[numRes+i];
      lbxFunctions->Items->AddObject(_cg_FunctionIndexToString(i), (TObject*)pOptionUnion);
      _cg_GetFunctionOptions(OptionsFileName(), NULL, &pOptionUnion->funcOpts, i);
    };
    lbxFunctions->Items->EndUpdate();
    pgeCGOptionsChange(0);
    isReading = false;
    Buffer = Format(StringsResContainer->CG_OPTIONS_CAPTION->Caption.c_str(),
      ARRAYOFCONST(((OptionsFileName() == NULL) ?
        StringsResContainer->CG_GLOBAL->Caption.c_str() : OptFileName)));
    NewCaption(Buffer);
  } __finally {
    Screen->Cursor = crDefault;
  }
}



void __fastcall TCodeGuardConfigDialog::WriteOptions(void)
{
  Screen->Cursor = crHourGlass;
  try {
    AnsiString Buffer = Format(StringsResContainer->CG_SAVING_CAPTION->Caption,
      ARRAYOFCONST(((OptionsFileName() == NULL) ?
      StringsResContainer->CG_GLOBAL->Caption.c_str() : OptFileName)));
    NewCaption(Buffer);
    OptionUnion *pOptionUnion;
    int numRes = _cg_GetNumberOfCGResources(OptionsFileName());
    int numFunc = _cg_GetNumberOfCGFunctions(OptionsFileName());
    //CGOptions
    _cg_GetCGOptions(OptionsFileName(), gcgOptions);
    gcgOptions->on.value = cbxCGEnable->Checked;
    gcgOptions->stackFillFreq.value = (short)atoi(edtStackFillFrequency->Text.c_str());
    gcgOptions->stat.value = cbxStatistics->Checked;
    gcgOptions->resourceLeaks.value = cbxResourceLeaks->Checked;
    gcgOptions->outDbgStr.value = cbxSendToOutputDebugString->Checked;
    gcgOptions->logAppend.value = cbxAppendToLogFile->Checked;
    gcgOptions->repeats.value = cbxRepeatedErrors->Checked;
    gcgOptions->maxErrors.value = (short)atoi(edtNumberOfErrorMessages->Text.c_str());
    gcgOptions->limitErrors.value = cbxLimitNumberOfErrorMessages->Checked;
    gcgOptions->msgBox.value = cbxEnableErrorMessageBox->Checked;
    strcpy(gcgOptions->caption.value, edtErrorMessageBoxCaption->Text.c_str());
    strcpy(gcgOptions->text.value, edtErrorMessageBoxMessage->Text.c_str());
    strcpy(gcgOptions->srcPath.value, edtSourcePath->Text.c_str());
    gcgOptions->dbgInfo.value = cbxReadDebugInfo->Checked;
    gcgOptions->on.set = gcgOptions->on.set | isDirty(D_OPTIONS);
    gcgOptions->stackFillFreq.set = gcgOptions->stackFillFreq.set | isDirty(D_OPTIONS);
    gcgOptions->stat.set = gcgOptions->stat.set | isDirty(D_OPTIONS);
    gcgOptions->resourceLeaks.set = gcgOptions->resourceLeaks.set | isDirty(D_OPTIONS);
    gcgOptions->outDbgStr.set = gcgOptions->outDbgStr.set | isDirty(D_OPTIONS);
    gcgOptions->logAppend.set = gcgOptions->logAppend.set | isDirty(D_OPTIONS);
    gcgOptions->repeats.set = gcgOptions->repeats.set | isDirty(D_OPTIONS);
    gcgOptions->maxErrors.set = gcgOptions->maxErrors.set | isDirty(D_OPTIONS);
    gcgOptions->limitErrors.set = gcgOptions->limitErrors.set | isDirty(D_OPTIONS);
    gcgOptions->msgBox.set = gcgOptions->msgBox.set | isDirty(D_OPTIONS);
    gcgOptions->caption.set = gcgOptions->caption.set | isDirty(D_OPTIONS);
    gcgOptions->text.set = gcgOptions->text.set | isDirty(D_OPTIONS);
    gcgOptions->srcPath.set = gcgOptions->srcPath.set | isDirty(D_OPTIONS);
    gcgOptions->dbgInfo.set = gcgOptions->dbgInfo.set | isDirty(D_OPTIONS);
    AnsiString s = "";
    for (int i = 0; i < lbxIgnoredModules->Items->Count; i++)
      s = s + lbxIgnoredModules->Items->Strings[i] +
        ((i == lbxIgnoredModules->Items->Count-1) ?  "" : ";");
    strcpy(gcgOptions->ignoredModules.value, s.c_str());
    gcgOptions->ignoredModules.set = gcgOptions->ignoredModules.set | isDirty(D_OPTIONS);
    _cg_SetCGOptions(OptionsFileName(), gcgOptions);
    //Resources
    lbxResources->Items->BeginUpdate();
    AnsiString ResourceName = "";
    for (int i = 0; i < numRes; i++) {
      ResourceName = lbxResources->Items->Strings[i];
      pOptionUnion = (OptionUnion*)lbxResources->Items->Objects[i];
      _cg_SetResourceOptions(OptionsFileName(), ResourceName.c_str(), &pOptionUnion->resOpts);
    };
    lbxResources->Items->EndUpdate();
    //Functions
    lbxFunctions->Items->BeginUpdate();
    AnsiString FunctionName = "";
    for (int i = 0; i < numFunc-1; i++) {
      FunctionName = lbxFunctions->Items->Strings[i];
      pOptionUnion = (OptionUnion*)lbxFunctions->Items->Objects[i];
      _cg_SetFunctionOptions(OptionsFileName(), FunctionName.c_str(), &pOptionUnion->funcOpts ,0);
    };
    lbxFunctions->Items->EndUpdate();
    ClearDirty(D_OPTIONS);
    ClearDirty(D_RESOURCES);
    ClearDirty(D_FUNCTIONS);
    Buffer = Format(StringsResContainer->CG_OPTIONS_CAPTION->Caption,
      ARRAYOFCONST((OptionsFileName() == NULL ?
      StringsResContainer->CG_GLOBAL->Caption.c_str() : OptFileName)));
    NewCaption(Buffer);
  } __finally {
    Screen->Cursor = crDefault;
  }
}



STDMETHODIMP TCodeGuardConfigDialogImpl::_set_Font(IFontDisp** Value)
{
  try
  {
    const DISPID dispid = -512;
    if (FireOnRequestEdit(dispid) == S_FALSE)
      return S_FALSE;
    SetVclCtlProp(m_VclCtl->Font, Value);
    FireOnChanged(dispid);
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



STDMETHODIMP TCodeGuardConfigDialogImpl::AboutBox()
{
  try
  {
    ShowMessage("Copyright @2004 - Borland Software Corp.");
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



STDMETHODIMP TCodeGuardConfigDialogImpl::get_Active(VARIANT_BOOL* Value)
{
  try
  {
   *Value = m_VclCtl->Active;
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



STDMETHODIMP TCodeGuardConfigDialogImpl::get_AlignDisabled(
  VARIANT_BOOL* Value)
{
  try
  {
   *Value = m_VclCtl->AlignDisabled;
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



STDMETHODIMP TCodeGuardConfigDialogImpl::get_AutoScroll(
  VARIANT_BOOL* Value)
{
  try
  {
   *Value = m_VclCtl->AutoScroll;
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



STDMETHODIMP TCodeGuardConfigDialogImpl::get_AutoSize(VARIANT_BOOL* Value)
{
  try
  {
   *Value = m_VclCtl->AutoSize;
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



STDMETHODIMP TCodeGuardConfigDialogImpl::get_AxBorderStyle(
  TxActiveFormBorderStyle* Value)
{
  try
  {
   *Value = (TxActiveFormBorderStyle)(m_VclCtl->AxBorderStyle);
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



STDMETHODIMP TCodeGuardConfigDialogImpl::get_BorderWidth(long* Value)
{
  try
  {
   *Value = (long)(m_VclCtl->BorderWidth);
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



STDMETHODIMP TCodeGuardConfigDialogImpl::get_Caption(BSTR* Value)
{
  try
  {
    *Value = WideString(m_VclCtl->Caption).Copy();
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



STDMETHODIMP TCodeGuardConfigDialogImpl::get_Color(::OLE_COLOR* Value)
{
  try
  {
   *Value = (::OLE_COLOR)(m_VclCtl->Color);
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



STDMETHODIMP TCodeGuardConfigDialogImpl::get_DoubleBuffered(
  VARIANT_BOOL* Value)
{
  try
  {
   *Value = m_VclCtl->DoubleBuffered;
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



STDMETHODIMP TCodeGuardConfigDialogImpl::get_DropTarget(
  VARIANT_BOOL* Value)
{
  try
  {
   *Value = m_VclCtl->DropTarget;
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



STDMETHODIMP TCodeGuardConfigDialogImpl::get_Enabled(VARIANT_BOOL* Value)
{
  try
  {
   *Value = m_VclCtl->Enabled;
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



STDMETHODIMP TCodeGuardConfigDialogImpl::get_Font(IFontDisp** Value)
{
  try
  {
    GetVclCtlProp(m_VclCtl->Font, Value);
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



STDMETHODIMP TCodeGuardConfigDialogImpl::get_HelpFile(BSTR* Value)
{
  try
  {
    *Value = WideString(m_VclCtl->HelpFile).Copy();
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



STDMETHODIMP TCodeGuardConfigDialogImpl::get_KeyPreview(
  VARIANT_BOOL* Value)
{
  try
  {
   *Value = m_VclCtl->KeyPreview;
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



STDMETHODIMP TCodeGuardConfigDialogImpl::get_PixelsPerInch(long* Value)
{
  try
  {
   *Value = (long)(m_VclCtl->PixelsPerInch);
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



STDMETHODIMP TCodeGuardConfigDialogImpl::get_PrintScale(
  TxPrintScale* Value)
{
  try
  {
   *Value = (TxPrintScale)(m_VclCtl->PrintScale);
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



STDMETHODIMP TCodeGuardConfigDialogImpl::get_Scaled(VARIANT_BOOL* Value)
{
  try
  {
   *Value = m_VclCtl->Scaled;
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



STDMETHODIMP TCodeGuardConfigDialogImpl::get_Visible(VARIANT_BOOL* Value)
{
  try
  {
   *Value = m_VclCtl->Visible;
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



STDMETHODIMP TCodeGuardConfigDialogImpl::get_VisibleDockClientCount(
  long* Value)
{
  try
  {
   *Value = (long)(m_VclCtl->VisibleDockClientCount);
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



STDMETHODIMP TCodeGuardConfigDialogImpl::set_AutoScroll(VARIANT_BOOL Value)
{
  try
  {
    const DISPID dispid = 2;
    if (FireOnRequestEdit(dispid) == S_FALSE)
     return S_FALSE;
    m_VclCtl->AutoScroll = Value;
    FireOnChanged(dispid);
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



STDMETHODIMP TCodeGuardConfigDialogImpl::set_AutoSize(VARIANT_BOOL Value)
{
  try
  {
    const DISPID dispid = 3;
    if (FireOnRequestEdit(dispid) == S_FALSE)
     return S_FALSE;
    m_VclCtl->AutoSize = Value;
    FireOnChanged(dispid);
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



STDMETHODIMP TCodeGuardConfigDialogImpl::set_AxBorderStyle(
  TxActiveFormBorderStyle Value)
{
  try
  {
    const DISPID dispid = 4;
    if (FireOnRequestEdit(dispid) == S_FALSE)
     return S_FALSE;
    m_VclCtl->AxBorderStyle = (TActiveFormBorderStyle)(Value);
    FireOnChanged(dispid);
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



STDMETHODIMP TCodeGuardConfigDialogImpl::set_BorderWidth(long Value)
{
  try
  {
    const DISPID dispid = 5;
    if (FireOnRequestEdit(dispid) == S_FALSE)
     return S_FALSE;
    m_VclCtl->BorderWidth = (int)(Value);
    FireOnChanged(dispid);
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



STDMETHODIMP TCodeGuardConfigDialogImpl::set_Caption(BSTR Value)
{
  try
  {
    const DISPID dispid = -518;
    if (FireOnRequestEdit(dispid) == S_FALSE)
      return S_FALSE;
    m_VclCtl->Caption = AnsiString(Value);
    FireOnChanged(dispid);
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



STDMETHODIMP TCodeGuardConfigDialogImpl::set_Color(::OLE_COLOR Value)
{
  try
  {
    const DISPID dispid = -501;
    if (FireOnRequestEdit(dispid) == S_FALSE)
     return S_FALSE;
    m_VclCtl->Color = (TColor)(Value);
    FireOnChanged(dispid);
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



STDMETHODIMP TCodeGuardConfigDialogImpl::set_DoubleBuffered(
  VARIANT_BOOL Value)
{
  try
  {
    const DISPID dispid = 13;
    if (FireOnRequestEdit(dispid) == S_FALSE)
     return S_FALSE;
    m_VclCtl->DoubleBuffered = Value;
    FireOnChanged(dispid);
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



STDMETHODIMP TCodeGuardConfigDialogImpl::set_DropTarget(VARIANT_BOOL Value)
{
  try
  {
    const DISPID dispid = 11;
    if (FireOnRequestEdit(dispid) == S_FALSE)
     return S_FALSE;
    m_VclCtl->DropTarget = Value;
    FireOnChanged(dispid);
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



STDMETHODIMP TCodeGuardConfigDialogImpl::set_Enabled(VARIANT_BOOL Value)
{
  try
  {
    const DISPID dispid = -514;
    if (FireOnRequestEdit(dispid) == S_FALSE)
     return S_FALSE;
    m_VclCtl->Enabled = Value;
    FireOnChanged(dispid);
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



STDMETHODIMP TCodeGuardConfigDialogImpl::set_Font(IFontDisp* Value)
{
  try
  {
    const DISPID dispid = -512;
    if (FireOnRequestEdit(dispid) == S_FALSE)
      return S_FALSE;
    SetVclCtlProp(m_VclCtl->Font, Value);
    FireOnChanged(dispid);
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



STDMETHODIMP TCodeGuardConfigDialogImpl::set_HelpFile(BSTR Value)
{
  try
  {
    const DISPID dispid = 12;
    if (FireOnRequestEdit(dispid) == S_FALSE)
      return S_FALSE;
    m_VclCtl->HelpFile = AnsiString(Value);
    FireOnChanged(dispid);
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



STDMETHODIMP TCodeGuardConfigDialogImpl::set_KeyPreview(VARIANT_BOOL Value)
{
  try
  {
    const DISPID dispid = 6;
    if (FireOnRequestEdit(dispid) == S_FALSE)
     return S_FALSE;
    m_VclCtl->KeyPreview = Value;
    FireOnChanged(dispid);
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



STDMETHODIMP TCodeGuardConfigDialogImpl::set_PixelsPerInch(long Value)
{
  try
  {
    const DISPID dispid = 7;
    if (FireOnRequestEdit(dispid) == S_FALSE)
     return S_FALSE;
    m_VclCtl->PixelsPerInch = (int)(Value);
    FireOnChanged(dispid);
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



STDMETHODIMP TCodeGuardConfigDialogImpl::set_PrintScale(TxPrintScale Value)
{
  try
  {
    const DISPID dispid = 8;
    if (FireOnRequestEdit(dispid) == S_FALSE)
     return S_FALSE;
    m_VclCtl->PrintScale = (TPrintScale)(Value);
    FireOnChanged(dispid);
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



STDMETHODIMP TCodeGuardConfigDialogImpl::set_Scaled(VARIANT_BOOL Value)
{
  try
  {
    const DISPID dispid = 9;
    if (FireOnRequestEdit(dispid) == S_FALSE)
     return S_FALSE;
    m_VclCtl->Scaled = Value;
    FireOnChanged(dispid);
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



STDMETHODIMP TCodeGuardConfigDialogImpl::set_Visible(VARIANT_BOOL Value)
{
  try
  {
    const DISPID dispid = 1;
    if (FireOnRequestEdit(dispid) == S_FALSE)
     return S_FALSE;
    m_VclCtl->Visible = Value;
    FireOnChanged(dispid);
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



void __fastcall TCodeGuardConfigDialogImpl::ActivateEvent(TObject *Sender)
{
  Fire_OnActivate();
}



void __fastcall TCodeGuardConfigDialogImpl::ClickEvent(TObject *Sender)
{
  Fire_OnClick();
}



void __fastcall TCodeGuardConfigDialogImpl::CreateEvent(TObject *Sender)
{
  Fire_OnCreate();
}



void __fastcall TCodeGuardConfigDialogImpl::DblClickEvent(TObject *Sender)
{
  Fire_OnDblClick();
}



void __fastcall TCodeGuardConfigDialogImpl::DeactivateEvent(
  TObject *Sender)
{
  Fire_OnDeactivate();
}



void __fastcall TCodeGuardConfigDialogImpl::DestroyEvent(TObject *Sender)
{
  Fire_OnDestroy();
}



void __fastcall TCodeGuardConfigDialogImpl::KeyPressEvent(TObject *Sender,
  char &Key)
{
  short TempKey;
  TempKey = (short)Key;
  Fire_OnKeyPress(&TempKey);
  Key = (short)TempKey;
}



void __fastcall TCodeGuardConfigDialogImpl::PaintEvent(TObject *Sender)
{
  Fire_OnPaint();
}



STDMETHODIMP TCodeGuardConfigDialogImpl::Persist()
{
  try
  {
    m_VclCtl->PseudoBtnOKClick(NULL);
  }
  catch(Exception &e)
  {
    return Error(e.Message.c_str(), IID_ICodeGuardConfigDialog);
  }
  return S_OK;
};



void __fastcall TCodeGuardConfigDialog::PseudoBtnOKClick(TObject *Sender)
{
  if (isDirty(D_OPTIONS) | isDirty(D_RESOURCES) | isDirty(D_FUNCTIONS))
    SaveFile();
}


char* __fastcall TCodeGuardConfigDialog::OpenFile()
{
    dlgOpen->Title = StringsResContainer->CG_FILE_OPEN_TITLE->Caption;
    return dlgOpen->Execute() ? dlgOpen->FileName.c_str() : NULL;
}



void __fastcall TCodeGuardConfigDialog::SetAndEnableFunctionOptions(OptionUnion* pOptionUnion)
{
  cbxDisableFunctionTracking->Checked = pOptionUnion->funcOpts.guardDisable.value;
  cbxMemoryAccessErrors->Checked = pOptionUnion->funcOpts.guardAccess.value;
  cbxLogEachCall->Checked = pOptionUnion->funcOpts.guardLog.value;
  cbxWarnings->Checked = pOptionUnion->funcOpts.guardWarn.value;
  cbxFunctionResultErrors->Checked = pOptionUnion->funcOpts.guardFail.value;
  cbxInvalidHandleOrResourceParameters->Checked = pOptionUnion->funcOpts.guardParams.value;
}



void __fastcall TCodeGuardConfigDialog::SetAndEnableResourceOptions(OptionUnion* pOptionUnion)
{
  cbxEnableTracking->Checked = pOptionUnion->resOpts.guard.value;
  cbxTrackResourceLeaks->Checked = pOptionUnion->resOpts.guardLeaks.value;
  cbxReportInvalidHandleOrResourceParameters->Checked = pOptionUnion->resOpts.guardParams.value;
  cbxDelayFree->Checked = pOptionUnion->resOpts.freeDelay.value;
  edtDelayQueueLength->Text = pOptionUnion->resOpts.delayMax.value;
  edtMaximumMemoryBlockSize->Text = pOptionUnion->resOpts.delayMaxSize.value;
}



void __fastcall TCodeGuardConfigDialog::SetResourceOptions(TListBox* Sender)
{
  assert(Sender);
  OptionUnion* pOptionUnion;
  int idx = Sender->ItemIndex;
  if (idx == -1) return;
  pOptionUnion  = (OptionUnion*)Sender->Items->Objects[idx];
  if (isDirty(D_RESOURCES) && LastResIndex == idx) {
    pOptionUnion->resOpts.guard.value         = cbxEnableTracking->Checked;
    pOptionUnion->resOpts.guardLeaks.value    = cbxTrackResourceLeaks->Checked;
    pOptionUnion->resOpts.guardParams.value   = cbxReportInvalidHandleOrResourceParameters->Checked;
    pOptionUnion->resOpts.freeDelay.value     = cbxDelayFree->Checked;
    pOptionUnion->resOpts.delayMax.value      = (short)atoi(edtDelayQueueLength->Text.c_str());
    pOptionUnion->resOpts.delayMaxSize.value  = atoi(edtMaximumMemoryBlockSize->Text.c_str());
  }
  SetAndEnableResourceOptions(pOptionUnion);
  pOptionUnion->resOpts.guard.set = pOptionUnion->resOpts.guard.set | isDirty(D_RESOURCES);
  pOptionUnion->resOpts.guardLeaks.set = pOptionUnion->resOpts.guardLeaks.set | isDirty(D_RESOURCES);
  pOptionUnion->resOpts.guardParams.set = pOptionUnion->resOpts.guardParams.set | isDirty(D_RESOURCES);
  pOptionUnion->resOpts.freeDelay.set = pOptionUnion->resOpts.freeDelay.set | isDirty(D_RESOURCES);
  pOptionUnion->resOpts.delayMax.set  = pOptionUnion->resOpts.delayMax.set  | isDirty(D_RESOURCES);
  pOptionUnion->resOpts.delayMaxSize.set = pOptionUnion->resOpts.delayMaxSize.set | isDirty(D_RESOURCES);
  LastResIndex = lbxResources->ItemIndex;
}



void __fastcall TCodeGuardConfigDialog::SetFunctionOptions(TListBox* Sender)
{
  assert(Sender);
  OptionUnion* pOptionUnion;
  int idx = Sender->ItemIndex;
  if (idx == -1) return;
  pOptionUnion = (OptionUnion*)Sender->Items->Objects[idx];
  if (isDirty(D_FUNCTIONS) && LastFuncIndex == idx) {
    pOptionUnion->funcOpts.guardAccess.value  = cbxMemoryAccessErrors->Checked;
    pOptionUnion->funcOpts.guardParams.value  = cbxInvalidHandleOrResourceParameters->Checked;
    pOptionUnion->funcOpts.guardFail.value    = cbxFunctionResultErrors->Checked;
    pOptionUnion->funcOpts.guardLog.value     = cbxLogEachCall->Checked;
    pOptionUnion->funcOpts.guardWarn.value    = cbxWarnings->Checked;
    pOptionUnion->funcOpts.guardDisable.value = cbxDisableFunctionTracking->Checked;
  }
  SetAndEnableFunctionOptions(pOptionUnion);
  pOptionUnion->funcOpts.guardAccess.set = pOptionUnion->funcOpts.guardAccess.set | isDirty(D_FUNCTIONS);
  pOptionUnion->funcOpts.guardParams.set = pOptionUnion->funcOpts.guardParams.set | isDirty(D_FUNCTIONS);
  pOptionUnion->funcOpts.guardFail.set = pOptionUnion->funcOpts.guardFail.set | isDirty(D_FUNCTIONS);
  pOptionUnion->funcOpts.guardLog.set = pOptionUnion->funcOpts.guardLog.set | isDirty(D_FUNCTIONS);
  pOptionUnion->funcOpts.guardWarn.set = pOptionUnion->funcOpts.guardWarn.set | isDirty(D_FUNCTIONS);
  pOptionUnion->funcOpts.guardDisable.set = pOptionUnion->funcOpts.guardDisable.set | isDirty(D_FUNCTIONS);
  LastFuncIndex = lbxFunctions->ItemIndex;
}



bool __fastcall TCodeGuardConfigDialog::ValidateRange(TEdit* Edit, int low, int high)
{
  assert(Edit);
  try {
    int nVal = atoi(Edit->Text.c_str());
    if (!nVal)
      throw new Exception("Invalid atoi conversion");
    return ( nVal >= low || nVal <= high );
  } catch ( ... ) {
    ShowMessage(Format(StringsResContainer->CG_OUT_OF_RANGE->Caption,
      ARRAYOFCONST((IntToStr(low), IntToStr(high)))));
    Edit->SetFocus();
    return false;
  }
}



void __fastcall TCodeGuardConfigDialog::SaveFile()
{
    SetResourceOptions(lbxResources);
    SetFunctionOptions(lbxFunctions);
    if (ValidateRange(edtStackFillFrequency, 0, 31) &&
        ValidateRange(edtNumberOfErrorMessages, -1, 65535))
      WriteOptions();
}



void __fastcall TCodeGuardConfigDialog::ToggleControls(TControl** ControlArrayElement, int NumElements, bool isChecked)
{
  for (int i = 0; i < NumElements; i++)
    ControlArrayElement[i]->Enabled = isChecked;
}



AnsiString __fastcall TCodeGuardConfigDialog::ConvertString(AnsiString s, char in, char out)
{
  char * Result = s.c_str();
  char * p = Result;
  while (*p != 0) {
    if (*p == in) *p = out;
    p++;
  }
  return Result;
}



void __fastcall TCodeGuardConfigDialog::NewCaption(AnsiString NewCaption)
{
  Caption = Format(StringsResContainer->CG_FILE_OPEN_TITLE->Caption,
    ARRAYOFCONST(("-", NewCaption)));
}



void __fastcall TCodeGuardConfigDialog::WriteLastFileName()
{
  TRegistry* Reg = new TRegistry;
  try {
    Reg->RootKey = HKEY_CURRENT_USER;
    if (Reg->OpenKey(szCGRegistryKey, true))
    {
      Reg->WriteString("LastOpenFile", OptionsFileName()); //do not localize
      Reg->CloseKey();
    }
  } __finally {
    delete Reg;
  }
}



void __fastcall TCodeGuardConfigDialog::ReadLastFileName()
{
  TRegistry *Reg = new TRegistry;
  try {
    Reg->RootKey = HKEY_CURRENT_USER;
    if (Reg->OpenKey(szCGRegistryKey, true)) {
      strcpy(OptFileName, Reg->ReadString("LastOpenFile").c_str()); //do not localize
      Reg->CloseKey();
    }
  } __finally {
    delete Reg;
  }
}



bool __fastcall TCodeGuardConfigDialog::AskToSave(AnsiString Message)
{
  if (isDirty(D_OPTIONS) | isDirty(D_RESOURCES) | isDirty(D_FUNCTIONS))
    return (MessageDlg(Message.c_str(), mtConfirmation, TMsgDlgButtons() << mbYes << mbNo, 0) == mrYes);
  else return false;
}



void __fastcall TCodeGuardConfigDialog::EnableFunctionOptions()
{
  cbxDisableFunctionTracking->Enabled = true;
  cbxMemoryAccessErrors->Enabled = true;
  cbxLogEachCall->Enabled = true;
  cbxWarnings->Enabled = true;
  cbxFunctionResultErrors->Enabled = true;
  cbxInvalidHandleOrResourceParameters->Enabled = true;
  cbxDisableFunctionTracking->Checked = false;
  cbxMemoryAccessErrors->Checked = false;
  cbxLogEachCall->Checked = false;
  cbxWarnings->Checked = false;
  cbxFunctionResultErrors->Checked = false;
  cbxInvalidHandleOrResourceParameters->Checked = false;
}



void __fastcall TCodeGuardConfigDialog::EnableResourceOptions()
{
  cbxEnableTracking->Checked = false;
  cbxTrackResourceLeaks->Checked = false;
  cbxReportInvalidHandleOrResourceParameters->Checked = false;
  cbxDelayFree->Checked = false;
  edtDelayQueueLength->Text = "0";
  edtMaximumMemoryBlockSize->Text = "0";
  cbxEnableTracking->Enabled = true;
  cbxTrackResourceLeaks->Enabled = true;
  cbxReportInvalidHandleOrResourceParameters->Enabled = true;
  cbxDelayFree->Enabled = true;
  edtDelayQueueLength->Enabled = true;
  edtMaximumMemoryBlockSize->Enabled = true;
}



void __fastcall TCodeGuardConfigDialog::pgeCGOptionsChange(TObject *Sender)
{
  lblFunctionsExtendedSelectNote->Visible = false;
  lblResourcesExtendedSelectNote->Visible = false;
  HelpContext = pgeCGOptions->ActivePage->HelpContext;
  lbxResources->ItemIndex = 0;
  lbxFunctions->ItemIndex = 0;
  lbxResources->Selected[0] = true;
  lbxFunctions->Selected[0] = true;
  SetResourceOptions(lbxResources);
  SetFunctionOptions(lbxFunctions);
}



void __fastcall TCodeGuardConfigDialog::cbxEnableTrackingClick(
      TObject *Sender)
{
  TControl* ControlArray[7] = { cbxTrackResourceLeaks,
                                cbxReportInvalidHandleOrResourceParameters,
                                cbxDelayFree,
                                edtDelayQueueLength,
                                edtMaximumMemoryBlockSize,
                                lblDelayQueueLength,
                                lblMaximumMemoryBlockSize
                              };
  ToggleControls(&ControlArray[0], 7, cbxEnableTracking->Checked);
  if (cbxEnableTracking->Checked)
    cbxDelayFreeClick(cbxDelayFree);
}



void __fastcall TCodeGuardConfigDialog::cbxDelayFreeClick(TObject *Sender)
{
  TControl* ControlArray[4] = { edtDelayQueueLength,
                                edtMaximumMemoryBlockSize,
                                lblDelayQueueLength,
                                lblMaximumMemoryBlockSize
                              };

  ToggleControls(&ControlArray[0], 4, cbxDelayFree->Checked);}



void __fastcall TCodeGuardConfigDialog::cbxEnableErrorMessageBoxClick(
      TObject *Sender)
{
  TControl* ControlArray[4] = { lblCaption,
                                lblMessage,
                                edtErrorMessageBoxCaption,
                                edtErrorMessageBoxMessage
                              };
  ToggleControls(&ControlArray[0], 4, cbxEnableErrorMessageBox->Checked);
}



void __fastcall TCodeGuardConfigDialog::cbxReadDebugInfoClick(
      TObject *Sender)
{
  TControl* ControlArray[2] = { lblSourcePath,
                                edtSourcePath//,
                                //btnChangePath
                              };
  ToggleControls(&ControlArray[0], 2, cbxReadDebugInfo->Checked);
}




void __fastcall TCodeGuardConfigDialog::btnAddModuleClick(TObject *Sender)
{
  dlgOpen->Filter = StringsResContainer->CG_IGNORED_MODULES_FILTER->Caption;
  dlgOpen->Title = StringsResContainer->CG_IGNORED_MODULES_TITLE->Caption;
  dlgOpen->Options << ofAllowMultiSelect;
  if (dlgOpen->Execute())
    for (int i = 0; i < dlgOpen->Files->Count; i++) {
      if (lbxIgnoredModules->Items->IndexOf(dlgOpen->Files->Strings[i]) == -1) {
        lbxIgnoredModules->Items->Add(dlgOpen->Files->Strings[i]);
        lbxIgnoredModules->Items->Objects[lbxIgnoredModules->Items->Count] =
          new TObject;
      }
    }
  SetDirty(D_OPTIONS);
}



void __fastcall TCodeGuardConfigDialog::btnRemoveModuleClick(
      TObject *Sender)
{
  int LastSelected = -1;
  for (int i = lbxIgnoredModules->Items->Count-1; i >= 0; i--) {
    if (lbxIgnoredModules->Selected[i]){
      lbxIgnoredModules->Items->Delete(i);
      LastSelected = i;
      SetDirty(D_OPTIONS);
    }
  }
  if (LastSelected > lbxIgnoredModules->Items->Count-1) {LastSelected = lbxIgnoredModules->Items->Count-1;}
  if (LastSelected > -1)
    lbxIgnoredModules->Selected[LastSelected] = true;
}



void __fastcall TCodeGuardConfigDialog::lbxIgnoredModulesKeyUp(
      TObject *Sender, WORD &Key, TShiftState Shift)
{
  if (Key == VK_DELETE && btnRemoveModule->Enabled) btnRemoveModuleClick(NULL);
  if (Key == VK_INSERT) btnAddModuleClick(NULL);
}



void __fastcall TCodeGuardConfigDialog::Timer1Timer(TObject *Sender)
{
  if (pgeCGOptions->ActivePage != tabIgnoredModules)
    return;
  int i = lbxIgnoredModules->ItemIndex;
  if (lbxIgnoredModules->SelCount)
    btnRemoveModule->Enabled = lbxIgnoredModules->SelCount && i > -1 &&
      lbxIgnoredModules->Selected[i];
  else
    btnRemoveModule->Enabled = false;
}



void __fastcall TCodeGuardConfigDialog::cbxCGEnableClick(TObject *Sender)
{
  TCheckBox* cbx = reinterpret_cast<TCheckBox*>(Sender);
  gbxCodeGuard->Font->Color = cbx->Checked ? clWindowText : clRed;
  AnsiString Buffer = cbx->Checked ?
    StringsResContainer->CG_ENABLED->Caption :
    StringsResContainer->CG_DISABLED->Caption;
  AnsiString Buffer2 = Format(StringsResContainer->CG_CODEGUARD_IS->Caption,
    ARRAYOFCONST((Buffer)));
  gbxCodeGuard->Caption = Buffer2;
  gbxCodeGuard->Caption = Buffer2;
  edtStackFillFrequency->Font->Color = clWindowText;
  lblStackFillFrequency->Font->Color = clWindowText;
  cbxCGEnable->Font->Color = clWindowText;
}



void __fastcall TCodeGuardConfigDialog::lbxResourcesClick(TObject *Sender)
{
  if (lbxResources->SelCount > 1) {
    lblResourcesExtendedSelectNote->Visible = true;
    EnableResourceOptions();
  }
  else {
    lblResourcesExtendedSelectNote->Visible = false;
    SetResourceOptions(reinterpret_cast<TListBox*>(Sender));
  }
}




void __fastcall TCodeGuardConfigDialog::lbxFunctionsClick(TObject *Sender)
{
  if (lbxFunctions->SelCount > 1) {
    lblFunctionsExtendedSelectNote->Visible = true;
    EnableFunctionOptions();
  }
  else {
    lblFunctionsExtendedSelectNote->Visible = false;
    SetFunctionOptions(reinterpret_cast<TListBox*>(Sender));
  }
}



void __fastcall TCodeGuardConfigDialog::itmOpenClick(TObject *Sender)
{
  if (AskToSave(StringsResContainer->CG_SAVE_CHANGES->Caption))
    SaveFile();
  if (char* p = OpenFile())
  {
    strcpy(OptFileName, p);
    NewCaption(OptionsFileName());
    ReadOptions();
  }
}



void __fastcall TCodeGuardConfigDialog::itmSaveClick(TObject *Sender)
{
  SaveFile();
}



void __fastcall TCodeGuardConfigDialog::btnResetToDefaultFunctionOptionsClick(
      TObject *Sender)
{
  Screen->Cursor = crHourGlass;
  try {
    int numFuncs = _cg_GetNumberOfCGFunctions(OptionsFileName());
    OptionUnion *pOptionUnion;
    for (int i = 0; i < numFuncs-1; i++) {
      if (lbxFunctions->Selected[i]) {
        _cg_RemoveFunction(OptionsFileName(), NULL, i+1);
        pOptionUnion = (OptionUnion*)lbxFunctions->Items->Objects[i];
        _cg_GetFunctionOptions(OptionsFileName(), NULL, &pOptionUnion->funcOpts, i);
      }
    }
    SetAndEnableFunctionOptions(pOptionUnion);
  } __finally {
    Screen->Cursor = crDefault;
  }
}



void __fastcall TCodeGuardConfigDialog::btnSetDefaultFunctionOptionsClick(
      TObject *Sender)
{
  TfrmSetDefaultFunctionOptions *frm = new TfrmSetDefaultFunctionOptions(this);
  assert(frm);
  try {
    _cg_GetFunctionOptions(OptionsFileName(), szCGDEFAULTS, DefaultFunctionOptions, 0);
    frm->cbxDisableFunctionTracking->Checked            = DefaultFunctionOptions->guardDisable.value;
    frm->cbxMemoryAccessErrors->Checked                 = DefaultFunctionOptions->guardAccess.value;
    frm->cbxLogEachCall->Checked                        = DefaultFunctionOptions->guardLog.value;
    frm->cbxWarnings->Checked                           = DefaultFunctionOptions->guardWarn.value;
    frm->cbxFunctionResultErrors->Checked               = DefaultFunctionOptions->guardFail.value;
    frm->cbxInvalidHandleOrResourceParameters->Checked  = DefaultFunctionOptions->guardParams.value;
    if (frm->ShowModal() == mrOk)
    {
      DefaultFunctionOptions->guardAccess.value  = frm->cbxMemoryAccessErrors->Checked;
      DefaultFunctionOptions->guardParams.value  = frm->cbxInvalidHandleOrResourceParameters->Checked;
      DefaultFunctionOptions->guardFail.value    = frm->cbxFunctionResultErrors->Checked;
      DefaultFunctionOptions->guardLog.value     = frm->cbxLogEachCall->Checked;
      DefaultFunctionOptions->guardWarn.value    = frm->cbxWarnings->Checked;
      DefaultFunctionOptions->guardDisable.value = frm->cbxDisableFunctionTracking->Checked;
      DefaultFunctionOptions->guardAccess.set  = true;
      DefaultFunctionOptions->guardParams.set  = true;
      DefaultFunctionOptions->guardFail.set    = true;
      DefaultFunctionOptions->guardLog.set     = true;
      DefaultFunctionOptions->guardWarn.set    = true;
      DefaultFunctionOptions->guardDisable.set = true;
      _cg_SetFunctionOptions(OptionsFileName(), szCGDEFAULTS, DefaultFunctionOptions, 0);
    }
  } __finally {
    delete frm;
  }
}



void __fastcall TCodeGuardConfigDialog::cbxTrackResourceLeaksMouseUp(
      TObject *Sender, TMouseButton Button, TShiftState Shift, int X,
      int Y)
{
  SetDirty(D_RESOURCES);
  if (lbxResources->SelCount > 1) {
    OptionUnion* pOptionUnion;
    for (int i = 0; i < lbxResources->Items->Count; i++) {
      if (lbxResources->Selected[i]) {
        pOptionUnion = (OptionUnion*)lbxResources->Items->Objects[i];
        pOptionUnion->resOpts.guard.value         = cbxEnableTracking->Checked;
        pOptionUnion->resOpts.guardLeaks.value    = cbxTrackResourceLeaks->Checked;
        pOptionUnion->resOpts.guardParams.value   = cbxReportInvalidHandleOrResourceParameters->Checked;
        pOptionUnion->resOpts.freeDelay.value     = cbxDelayFree->Checked;
        pOptionUnion->resOpts.delayMax.value      = (short)atoi(edtDelayQueueLength->Text.c_str());
        pOptionUnion->resOpts.delayMaxSize.value  = atoi(edtMaximumMemoryBlockSize->Text.c_str());
      }
    }
  }
  else
    SetResourceOptions(lbxResources);
}



void __fastcall TCodeGuardConfigDialog::cbxMemoryAccessErrorsMouseUp(
      TObject *Sender, TMouseButton Button, TShiftState Shift, int X,
      int Y)
{
  SetDirty(D_FUNCTIONS);
  if (lbxFunctions->SelCount > 1) {
    OptionUnion* pOptionUnion;
    for (int i = 0; i < lbxFunctions->Items->Count; i++) {
      if (lbxFunctions->Selected[i]) {
        pOptionUnion = (OptionUnion*)lbxFunctions->Items->Objects[i];
        pOptionUnion->funcOpts.guardAccess.value  = cbxMemoryAccessErrors->Checked;
        pOptionUnion->funcOpts.guardParams.value  = cbxInvalidHandleOrResourceParameters->Checked;
        pOptionUnion->funcOpts.guardFail.value    = cbxFunctionResultErrors->Checked;
        pOptionUnion->funcOpts.guardLog.value     = cbxLogEachCall->Checked;
        pOptionUnion->funcOpts.guardWarn.value    = cbxWarnings->Checked;
        pOptionUnion->funcOpts.guardDisable.value = cbxDisableFunctionTracking->Checked;
      }
    }
  }
  else
    SetFunctionOptions(lbxFunctions);
}



void __fastcall TCodeGuardConfigDialog::edtDelayQueueLengthExit(
      TObject *Sender)
{
  SetDirty(D_RESOURCES);
  ValidateRange(reinterpret_cast<TEdit*>(Sender), 0, 65535);
  SetResourceOptions(lbxResources);
}


void __fastcall TCodeGuardConfigDialog::cbxCGEnableMouseUp(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
  SetDirty(D_OPTIONS);
}



void __fastcall TCodeGuardConfigDialog::edtStackFillFrequencyExit(
      TObject *Sender)
{
  SetDirty(D_OPTIONS);
  ValidateRange(reinterpret_cast<TEdit*>(Sender), 0, 31);
}



void __fastcall TCodeGuardConfigDialog::edtNumberOfErrorMessagesExit(
      TObject *Sender)
{
  SetDirty(D_OPTIONS);
  ValidateRange(reinterpret_cast<TEdit*>(Sender), -1, 65535);
}



void __fastcall TCodeGuardConfigDialog::cbxLimitNumberOfErrorMessagesClick(
      TObject *Sender)
{
  TControl* ControlArray[1] = { edtNumberOfErrorMessages };
  ToggleControls(&ControlArray[0], 1, cbxLimitNumberOfErrorMessages->Checked);
}



void __fastcall TCodeGuardConfigDialog::PositiveIntergersOnly(
      TObject* /*Sender*/, char &Key)
{
  if (Key != '\b' && Key < '0' || Key > '9')
    Key = 0;
}



void __fastcall TCodeGuardConfigDialog::itmLoadGlobalOptionsClick(
      TObject *Sender)
{
  if (AskToSave(StringsResContainer->CG_SAVE_CHANGES->Caption))
    SaveFile();
  char * p = "";
  strcpy(OptFileName, p);
  NewCaption(OptionsFileName());
  ReadOptions();
}



void __fastcall TCodeGuardConfigDialog::MainPopupMenuPopup(TObject *Sender)
{
  itmLoadGlobalOptions->Enabled = OptionsFileName();
}



void __fastcall TCodeGuardConfigDialog::commonDirtyer(
      TObject *Sender)
{
  SetDirty(D_OPTIONS);
}



void __fastcall TCodeGuardConfigDialog::cbxDisableFunctionTrackingClick(
      TObject *Sender)
{
  TControl* ControlArray[5] = { cbxMemoryAccessErrors,
                                cbxLogEachCall,
                                cbxWarnings,
                                cbxFunctionResultErrors,
                                cbxInvalidHandleOrResourceParameters
                              };
  ToggleControls(&ControlArray[0], 5, ! cbxDisableFunctionTracking->Checked);
}




void __fastcall TCodeGuardConfigDialog::ActiveFormKeyUp(TObject *Sender,
      WORD &Key, TShiftState Shift)
{
  if (Key==13) {
    ModalResult = mrOk; // will fire close with mrOK
    ///Close();
  }
  if (Key==27) {
    ModalResult = mrCancel;  // will fire close with mrCancel
    ///Close();
  }
}
//---------------------------------------------------------------------------

