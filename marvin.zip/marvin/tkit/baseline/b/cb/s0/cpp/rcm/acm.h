//gsoap impl schema namespace: ws.acm.borland.com
//gsoap soapenc schema namespace: http://schemas.xmlsoap.org/soap/encoding/
//gsoap apachesoap schema namespace: http://xml.apache.org/xml-soap
//gsoap intf schema namespace: ws.acm.borland.com

//gsoap impl service namespace: ws.acm.borland.com

//gsoap impl service location: http://RemoteComponentModelServer
//gsoap impl service name: soapWSComponentModelServerService

/*start primitive data types*/
typedef char * xsd__string;
typedef int xsd__int;
class xsd__base64Binary {
public:
unsigned char *__ptr;
int __size;
};
typedef bool xsd__boolean;

/*end primitive data types*/

class impl__methodinfo_USCORE_GetMethodInfosResponse {
   public: 
	class ArrayOfWSMethodInfo * _methodinfo_USCORE_GetMethodInfosReturn;
};

class impl__WSLiveDesignerManager {
   public: 
	xsd__string  managerInstanceKey;
	xsd__string  modelKey;
};

class impl__WSComponentModel {
   public: 
	xsd__string  modelKey;
	xsd__string  displayName;
	xsd__string  description;
	xsd__string  displayIconURI;
};

class impl__comp_USCORE_GetEventResponse {
   public: 
	class impl__WSLiveEvent * _comp_USCORE_GetEventReturn;
};

class impl__server_USCORE_GetComponentModelsResponse {
   public: 
	class ArrayOfWSComponentModel * _server_USCORE_GetComponentModelsReturn;
};

class impl__prop_USCORE_SetValueAsTextResponse {
   public: 
	class impl__WSResult * _prop_USCORE_SetValueAsTextReturn;
};

class impl__uidesigner_USCORE_GetUIComponentResponse {
   public: 
	class impl__WSLiveUIComponent * _uidesigner_USCORE_GetUIComponentReturn;
};

class impl__uicomp_USCORE_GetAsContainerResponse {
   public: 
	class impl__WSLiveUIContainer * _uicomp_USCORE_GetAsContainerReturn;
};

class impl__manager_USCORE_IsPersistenceDataModifiedResponse {
   public: 
	xsd__boolean  _manager_USCORE_IsPersistenceDataModifiedReturn;
};

class impl__designer_USCORE_GetRootComponentsResponse {
   public: 
	class ArrayOfWSLiveComponent * _designer_USCORE_GetRootComponentsReturn;
};

class impl__designer_USCORE_GetContextTagsResponse {
   public: 
	class ArrayOfWSTag * _designer_USCORE_GetContextTagsReturn;
};

class impl__manager_USCORE_GetPersistenceDataResponse {
   public: 
	xsd__base64Binary * _manager_USCORE_GetPersistenceDataReturn;
};

class impl__result_USCORE_TagInvokedResponse {
   public: 
	class impl__WSResult * _result_USCORE_TagInvokedReturn;
};

class impl__WSEventInfo {
   public: 
	int  __size_;
	xsd__string * eventKeyPath;
	xsd__string  displayName;
	xsd__string  description;
	xsd__string  displayIconURI;
	xsd__string  signature;
	xsd__boolean  hookTags;
	xsd__boolean  constrainedToTags;
	xsd__boolean  hasChildren;
	xsd__boolean  hookable;
};

class impl__comp_USCORE_GetContextTagsResponse {
   public: 
	class ArrayOfWSTag * _comp_USCORE_GetContextTagsReturn;
};

class impl__event_USCORE_UnhookResponse {
   public: 
	class impl__WSResult * _event_USCORE_UnhookReturn;
};

class impl__palette_USCORE_GetComponentInfosResponse {
   public: 
	class ArrayOfWSComponentInfo * _palette_USCORE_GetComponentInfosReturn;
};

class impl__eventinfo_USCORE_GetEventInfosResponse {
   public: 
	class ArrayOfWSEventInfo * _eventinfo_USCORE_GetEventInfosReturn;
};

class ArrayOfWSComponentModel {
   public: 
	impl__WSComponentModel * __ptr;
	int  __size;
	int  __offset;
};

class impl__uidesignrect_USCORE_GetContextTagsResponse {
   public: 
	class ArrayOfWSTag * _uidesignrect_USCORE_GetContextTagsReturn;
};

class ArrayOfWSComponentInfo {
   public: 
	class impl__WSComponentInfo * __ptr;
	int  __size;
	int  __offset;
};

class impl__WSLiveComponent {
   public: 
	xsd__string  instanceKey;
	xsd__string  instanceName;
	xsd__boolean  userRenamable;
	xsd__string  designerKey;
	xsd__string  parentInstanceKey;
	xsd__string  componentTypeKey;
	xsd__boolean  container;
};

class impl__prop_USCORE_RevertResponse {
   public: 
	class impl__WSResult * _prop_USCORE_RevertReturn;
};

class impl__WSDesignerEvent {
   public: 
	xsd__int  designerEventID;
	xsd__string  managerInstanceKey;
	xsd__string  designerKey;
	xsd__string  compInstanceKey;
	int  __size_;
	xsd__string * propertyKeyPath;
	int  __size__;
	xsd__string * eventKeyPath;
	xsd__string  customDataKey;
	xsd__string  customDataValue;
};

class impl__event_USCORE_GetHookTagsResponse {
   public: 
	class ArrayOfWSTag * _event_USCORE_GetHookTagsReturn;
};

class ArrayOf_USCORE_xsd_USCORE_string {
   public: 
	xsd__string * __ptr;
	int  __size;
	int  __offset;
};

class impl__model_USCORE_GetComponentInfoResponse {
   public: 
	class impl__WSComponentInfo * _model_USCORE_GetComponentInfoReturn;
};

class impl__model_USCORE_GetDesignerInfoForComponentResponse {
   public: 
	class impl__WSDesignerInfo * _model_USCORE_GetDesignerInfoForComponentReturn;
};

class impl__WSResultMessage {
   public: 
	xsd__int  messageType;
	xsd__string  messageKey;
	xsd__string  messageTitle;
	xsd__string  messageText;
	xsd__string  messageIconURI;
};

class ArrayOfWSLiveProperty {
   public: 
	class impl__WSLiveProperty * __ptr;
	int  __size;
	int  __offset;
};

class impl__uidesignrect_USCORE_ResizeCompletedResponse {
   public: 
	class impl__WSRect * _uidesignrect_USCORE_ResizeCompletedReturn;
};

class impl__prop_USCORE_GetValueTagsResponse {
   public: 
	class ArrayOfWSTag * _prop_USCORE_GetValueTagsReturn;
};

class impl__WSPropertyInfo {
   public: 
	int  __size_;
	xsd__string * propertyKeyPath;
	xsd__string  displayName;
	xsd__string  description;
	xsd__string  displayIconURI;
	xsd__boolean  readOnly;
	xsd__boolean  hasValueTags;
	xsd__boolean  constrainedToTags;
	xsd__string  propertyTypeKey;
	xsd__boolean  hasChildren;
};

class ArrayOfWSLiveEvent {
   public: 
	class impl__WSLiveEvent * __ptr;
	int  __size;
	int  __offset;
};

class impl__model_USCORE_CustomDataRequestResponse {
   public: 
	xsd__string  _model_USCORE_CustomDataRequestReturn;
};

class impl__container_USCORE_SetComponentIndexResponse {
   public: 
	class impl__WSResult * _container_USCORE_SetComponentIndexReturn;
};

class impl__designer_USCORE_DisposeComponentResponse {
   public: 
	class impl__WSResult * _designer_USCORE_DisposeComponentReturn;
};

class impl__designer_USCORE_CreateComponentResponse {
   public: 
	class impl__WSCreateResult * _designer_USCORE_CreateComponentReturn;
};

class impl__model_USCORE_GetDefaultDesignerInfoResponse {
   public: 
	class impl__WSDesignerInfo * _model_USCORE_GetDefaultDesignerInfoReturn;
};

class impl__comp_USCORE_TestSetParentContainerResponse {
   public: 
	xsd__boolean  _comp_USCORE_TestSetParentContainerReturn;
};

class impl__compinfo_USCORE_GetPropertyInfosResponse {
   public: 
	class ArrayOfWSPropertyInfo * _compinfo_USCORE_GetPropertyInfosReturn;
};

class impl__event_USCORE_SetHookAsTextResponse {
   public: 
	class impl__WSResult * _event_USCORE_SetHookAsTextReturn;
};

class ArrayOfWSTag {
   public: 
	class impl__WSTag * __ptr;
	int  __size;
	int  __offset;
};

class impl__model_USCORE_GetPalettePagesResponse {
   public: 
	class ArrayOfWSPalettePage * _model_USCORE_GetPalettePagesReturn;
};

class impl__uidesignrect_USCORE_MoveCompletedResponse {
   public: 
	class impl__WSRect * _uidesignrect_USCORE_MoveCompletedReturn;
};

class impl__uidesigner_USCORE_CreateComponentResponse {
   public: 
	class impl__WSUICreateResult * _uidesigner_USCORE_CreateComponentReturn;
};

class impl__propinfo_USCORE_GetValueTagsResponse {
   public: 
	ArrayOfWSTag * _propinfo_USCORE_GetValueTagsReturn;
};

class impl__comp_USCORE_TagInvokedResponse {
   public: 
	class impl__WSResult * _comp_USCORE_TagInvokedReturn;
};

class ArrayOfWSEventInfo {
   public: 
	impl__WSEventInfo * __ptr;
	int  __size;
	int  __offset;
};

class impl__comp_USCORE_SetParentContainerResponse {
   public: 
	class impl__WSResult * _comp_USCORE_SetParentContainerReturn;
};

class impl__propinfo_USCORE_GetPropertyInfosResponse {
   public: 
	class ArrayOfWSPropertyInfo * _propinfo_USCORE_GetPropertyInfosReturn;
};

class impl__compinfo_USCORE_GetMethodInfosResponse {
   public: 
	class ArrayOfWSMethodInfo * _compinfo_USCORE_GetMethodInfosReturn;
};

class impl__WSMethodInfo {
   public: 
	int  __size_;
	xsd__string * methodKeyPath;
	xsd__string  displayName;
	xsd__string  description;
	xsd__string  displayIconURI;
	int  __size__;
	xsd__string * modifiers;
	int  __size___;
	xsd__string * parameterTypeKeys;
	int  __size____;
	xsd__string * parameterNames;
	xsd__string  returnTypeKey;
	xsd__string  syntax;
	xsd__boolean  hasChildren;
};

class impl__WSTag {
   public: 
	xsd__string  tagKey;
	xsd__string  displayName;
	xsd__string  description;
	xsd__string  displayIconURI;
	xsd__boolean  enabled;
	xsd__boolean  hasChildren;
	int  __size_;
	impl__WSTag * tags;
	xsd__boolean  invokable;
	xsd__boolean  popup;
};

class impl__designer_USCORE_GetComponentResponse {
   public: 
	impl__WSLiveComponent * _designer_USCORE_GetComponentReturn;
};

class impl__event_USCORE_GetEventsResponse {
   public: 
	ArrayOfWSLiveEvent * _event_USCORE_GetEventsReturn;
};

class impl__WSComponentInfo {
   public: 
	xsd__string  compTypeKey;
	xsd__string  displayName;
	xsd__string  description;
	xsd__string  paletteIconURI;
	xsd__string  treeIconURI;
	xsd__string  defaultPropertyKey;
	xsd__string  hdrFileName;
	xsd__string  defaultMethodKey;
	xsd__string  defaultEventKey;
	xsd__boolean  container;
};

class impl__model_USCORE_CreateDesignerManagerResponse {
   public: 
	impl__WSLiveDesignerManager * _model_USCORE_CreateDesignerManagerReturn;
};

class impl__comp_USCORE_GetEventsResponse {
   public: 
	ArrayOfWSLiveEvent * _comp_USCORE_GetEventsReturn;
};

class ArrayOfWSMethodInfo {
   public: 
	impl__WSMethodInfo * __ptr;
	int  __size;
	int  __offset;
};

class impl__prop_USCORE_GetPropertiesResponse {
   public: 
	ArrayOfWSLiveProperty * _prop_USCORE_GetPropertiesReturn;
};

class impl__manager_USCORE_GetDesignerEventsResponse {
   public: 
	class ArrayOfWSDesignerEvent * _manager_USCORE_GetDesignerEventsReturn;
};

class impl__uicomp_USCORE_SetUIComponentRectResponse {
   public: 
	class impl__WSRect * _uicomp_USCORE_SetUIComponentRectReturn;
};

class impl__WSUIDesignRect {
   public: 
	xsd__string  designRectKey;
	class impl__WSRect * rect;
	xsd__string  toolTipText;
	xsd__boolean  clickable;
	xsd__boolean  hasContextTags;
	xsd__boolean  movable;
	xsd__boolean  moveVertical;
	xsd__boolean  moveHorizontal;
	class impl__WSRect * moveConstraintRect;
	xsd__boolean  resizable;
	xsd__boolean  resizeTop;
	xsd__boolean  resizeLeft;
	xsd__boolean  resizeBottom;
	xsd__boolean  resizeRight;
	class impl__WSRect * resizeConstraintRect;
};

class impl__event_USCORE_SetDefaultHookResponse {
   public: 
	class impl__WSResult * _event_USCORE_SetDefaultHookReturn;
};

class impl__compinfo_USCORE_GetEventInfosResponse {
   public: 
	ArrayOfWSEventInfo * _compinfo_USCORE_GetEventInfosReturn;
};

class impl__manager_USCORE_SetPersistenceDataResponse {
   public: 
	class impl__WSResult * _manager_USCORE_SetPersistenceDataReturn;
};

class ArrayOfWSDesignerEvent {
   public: 
	impl__WSDesignerEvent * __ptr;
	int  __size;
	int  __offset;
};

class impl__WSDesignerInfo {
   public: 
	xsd__string  designerKey;
	xsd__string  displayName;
	xsd__string  description;
	xsd__string  displayIconURI;
};

class ArrayOfWSLiveDesignerManager {
   public: 
	impl__WSLiveDesignerManager * __ptr;
	int  __size;
	int  __offset;
};

class impl__eventinfo_USCORE_GetHookTagsResponse {
   public: 
	ArrayOfWSTag * _eventinfo_USCORE_GetHookTagsReturn;
};

class impl__model_USCORE_DisposeDesignerManagerResponse {
   public: 
	class impl__WSResult * _model_USCORE_DisposeDesignerManagerReturn;
};

class impl__manager_USCORE_GetComponentsOfTypeResponse {
   public: 
	class ArrayOfWSLiveComponent * _manager_USCORE_GetComponentsOfTypeReturn;
};

class impl__WSResult {
   public: 
	xsd__string  resultKey;
	xsd__boolean  success;
	int  __size_;
	impl__WSResultMessage * messages;
	int  __size__;
	impl__WSTag * options;
};

class impl__model_USCORE_GetDesignerManagersResponse {
   public: 
	ArrayOfWSLiveDesignerManager * _model_USCORE_GetDesignerManagersReturn;
};

class impl__comp_USCORE_GetAsContainerResponse {
   public: 
	class impl__WSLiveContainer * _comp_USCORE_GetAsContainerReturn;
};

class impl__uidesignrect_USCORE_TagInvokedResponse {
   public: 
	impl__WSResult * _uidesignrect_USCORE_TagInvokedReturn;
};

class ArrayOfWSLiveComponent {
   public: 
	impl__WSLiveComponent * __ptr;
	int  __size;
	int  __offset;
};

class impl__comp_USCORE_GetPropertyResponse {
   public: 
	class impl__WSLiveProperty * _comp_USCORE_GetPropertyReturn;
};

class impl__comp_USCORE_SetInstanceNameResponse {
   public: 
	impl__WSResult * _comp_USCORE_SetInstanceNameReturn;
};

class impl__uicomp_USCORE_TestUIComponentRectResponse {
   public: 
	class impl__WSRect * _uicomp_USCORE_TestUIComponentRectReturn;
};

class impl__WSPalettePage {
   public: 
	xsd__string  pageKey;
	xsd__string  pageTitle;
	xsd__string  pageDescription;
	xsd__string  pageIconURI;
};

class impl__designer_USCORE_TagInvokedResponse {
   public: 
	impl__WSResult * _designer_USCORE_TagInvokedReturn;
};

class impl__WSRect {
   public: 
	xsd__int  x;
	xsd__int  y;
	xsd__int  width;
	xsd__int  height;
};

class impl__uidesigner_USCORE_GetRootUIComponentsResponse {
   public: 
	class ArrayOfWSLiveUIComponent * _uidesigner_USCORE_GetRootUIComponentsReturn;
};

class impl__comp_USCORE_GetPropertiesResponse {
   public: 
	ArrayOfWSLiveProperty * _comp_USCORE_GetPropertiesReturn;
};

class impl__manager_USCORE_GetUIDesignerResponse {
   public: 
	class impl__WSLiveUIDesigner * _manager_USCORE_GetUIDesignerReturn;
};

class ArrayOfWSPropertyInfo {
   public: 
	impl__WSPropertyInfo * __ptr;
	int  __size;
	int  __offset;
};

class impl__manager_USCORE_GetDefaultDesignerResponse {
   public: 
	class impl__WSLiveDesigner * _manager_USCORE_GetDefaultDesignerReturn;
};

class impl__designer_USCORE_TestCreateComponentResponse {
   public: 
	xsd__boolean  _designer_USCORE_TestCreateComponentReturn;
};

class impl__uidesignrect_USCORE_MouseClickResponse {
   public: 
	impl__WSResult * _uidesignrect_USCORE_MouseClickReturn;
};

class ArrayOfWSLiveUIComponent {
   public: 
	class impl__WSLiveUIComponent * __ptr;
	int  __size;
	int  __offset;
};

class impl__model_USCORE_GetUIDesignerInfoResponse {
   public: 
	impl__WSDesignerInfo * _model_USCORE_GetUIDesignerInfoReturn;
};

class impl__WSLiveEvent {
   public: 
	int  __size_;
	xsd__string * eventKeyPath;
	xsd__string  compInstanceKey;
	xsd__string  hookAsText;
	xsd__boolean  hooked;
	xsd__boolean  hasHookTags;
	xsd__boolean  hasChildren;
};

class ArrayOfWSPalettePage {
   public: 
	impl__WSPalettePage * __ptr;
	int  __size;
	int  __offset;
};


class impl__WSLiveProperty : public impl__WSPropertyInfo { 
	xsd__string  compInstanceKey;
	xsd__string  valueAsText;
	xsd__boolean  modified;
};


class impl__WSLiveUIComponent : public impl__WSLiveComponent { 
	impl__WSRect * rect;
	xsd__boolean  visible;
	int  __size_;
	impl__WSUIDesignRect * designRects;
};

class impl__WSLiveUIContainer : public impl__WSLiveUIComponent { 
	int  __size__;
	impl__WSLiveUIComponent * uiComponents;
	impl__WSRect * clientRect;
	xsd__boolean  constrainedChildren;
	xsd__boolean  canPaintChildren;
};

class impl__WSCreateResult : public impl__WSResult { 
	impl__WSLiveComponent * component;
};

class impl__WSLiveContainer : public impl__WSLiveComponent { 
	int  __size_;
	impl__WSLiveComponent * components;
};

class impl__WSLiveDesigner : public impl__WSDesignerInfo { 
	xsd__string  managerInstanceKey;
};

class impl__WSLiveUIDesigner : public impl__WSLiveDesigner { 
	xsd__string  designerImageURI;
	impl__WSRect * designerClientRect;
	xsd__boolean  constrainChildrenToClientRect;
	int  __size_;
	impl__WSUIDesignRect * designRects;
};

class impl__WSUICreateResult : public impl__WSCreateResult { 
	impl__WSLiveUIComponent * uiComponent;
};

//gsoap impl service method-action: comp_USCORE_GetContextTags ""
impl__comp_USCORE_GetContextTags( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  compInstanceKey, xsd__int  x, xsd__int  y, impl__comp_USCORE_GetContextTagsResponse * out );
//gsoap impl service method-action: result_USCORE_TagInvoked ""
impl__result_USCORE_TagInvoked( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  compInstanceKey, xsd__string  designRectKey, xsd__string  resultKey, ArrayOf_USCORE_xsd_USCORE_string * tagKeyPath, impl__result_USCORE_TagInvokedResponse * out );
//gsoap impl service method-action: designer_USCORE_CreateComponent ""
impl__designer_USCORE_CreateComponent( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  containerInstanceKey, xsd__string  compTypeKey, xsd__base64Binary * persistData, impl__designer_USCORE_CreateComponentResponse * out );
//gsoap impl service method-action: uicomp_USCORE_GetAsContainer ""
impl__uicomp_USCORE_GetAsContainer( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  compInstanceKey, impl__uicomp_USCORE_GetAsContainerResponse * out );
//gsoap impl service method-action: manager_USCORE_GetDefaultDesigner ""
impl__manager_USCORE_GetDefaultDesigner( xsd__string  modelKey, xsd__string  managerInstanceKey, impl__manager_USCORE_GetDefaultDesignerResponse * out );
//gsoap impl service method-action: prop_USCORE_Revert ""
impl__prop_USCORE_Revert( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string * propKeyPath, impl__prop_USCORE_RevertResponse * out );
//gsoap impl service method-action: uidesignrect_USCORE_ResizeCompleted ""
impl__uidesignrect_USCORE_ResizeCompleted( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  compInstanceKey, xsd__string  designRectKey, xsd__int  x, xsd__int  y, xsd__int  width, xsd__int  height, impl__uidesignrect_USCORE_ResizeCompletedResponse * out );
//gsoap impl service method-action: comp_USCORE_SetInstanceName ""
impl__comp_USCORE_SetInstanceName( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  compInstanceKey, xsd__string  name, impl__comp_USCORE_SetInstanceNameResponse * out );
//gsoap impl service method-action: manager_USCORE_GetUIDesigner ""
impl__manager_USCORE_GetUIDesigner( xsd__string  modelKey, xsd__string  managerInstanceKey, impl__manager_USCORE_GetUIDesignerResponse * out );
//gsoap impl service method-action: uidesignrect_USCORE_GetContextTags ""
impl__uidesignrect_USCORE_GetContextTags( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  compInstanceKey, xsd__string  designRectKey, xsd__int  x, xsd__int  y, impl__uidesignrect_USCORE_GetContextTagsResponse * out );
//gsoap impl service method-action: propinfo_USCORE_GetValueTags ""
impl__propinfo_USCORE_GetValueTags( xsd__string  modelKey, xsd__string  compTypeKey, ArrayOf_USCORE_xsd_USCORE_string * propKeyPath, impl__propinfo_USCORE_GetValueTagsResponse * out );
//gsoap impl service method-action: comp_USCORE_GetAsContainer ""
impl__comp_USCORE_GetAsContainer( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  compInstanceKey, impl__comp_USCORE_GetAsContainerResponse * out );
//gsoap impl service method-action: prop_USCORE_GetValueTags ""
impl__prop_USCORE_GetValueTags( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string * propKeyPath, impl__prop_USCORE_GetValueTagsResponse * out );
//gsoap impl service method-action: uidesignrect_USCORE_MouseClick ""
impl__uidesignrect_USCORE_MouseClick( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  compInstanceKey, xsd__string  designRectKey, xsd__int  x, xsd__int  y, xsd__int  clickCount, impl__uidesignrect_USCORE_MouseClickResponse * out );
//gsoap impl service method-action: server_USCORE_GetComponentModels ""
impl__server_USCORE_GetComponentModels( impl__server_USCORE_GetComponentModelsResponse * out );
//gsoap impl service method-action: model_USCORE_GetPalettePages ""
impl__model_USCORE_GetPalettePages( xsd__string  modelKey, impl__model_USCORE_GetPalettePagesResponse * out );
//gsoap impl service method-action: eventinfo_USCORE_GetHookTags ""
impl__eventinfo_USCORE_GetHookTags( xsd__string  modelKey, xsd__string  compTypeKey, ArrayOf_USCORE_xsd_USCORE_string * eventKeyPath, impl__eventinfo_USCORE_GetHookTagsResponse * out );
//gsoap impl service method-action: comp_USCORE_GetProperty ""
impl__comp_USCORE_GetProperty( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string * propKeyPath, impl__comp_USCORE_GetPropertyResponse * out );
//gsoap impl service method-action: comp_USCORE_TestSetParentContainer ""
impl__comp_USCORE_TestSetParentContainer( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  containerInstanceKey, xsd__string  compInstanceKey, impl__comp_USCORE_TestSetParentContainerResponse * out );
//gsoap impl service method-action: event_USCORE_GetHookTags ""
impl__event_USCORE_GetHookTags( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string * eventKeyPath, impl__event_USCORE_GetHookTagsResponse * out );
//gsoap impl service method-action: uidesignrect_USCORE_MoveCompleted ""
impl__uidesignrect_USCORE_MoveCompleted( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  compInstanceKey, xsd__string  designRectKey, xsd__int  x, xsd__int  y, xsd__int  width, xsd__int  height, impl__uidesignrect_USCORE_MoveCompletedResponse * out );
//gsoap impl service method-action: model_USCORE_GetDesignerManagers ""
impl__model_USCORE_GetDesignerManagers( xsd__string  modelKey, impl__model_USCORE_GetDesignerManagersResponse * out );
//gsoap impl service method-action: methodinfo_USCORE_GetMethodInfos ""
impl__methodinfo_USCORE_GetMethodInfos( xsd__string  modelKey, xsd__string  compTypeKey, ArrayOf_USCORE_xsd_USCORE_string * parentMethodKeyPath, impl__methodinfo_USCORE_GetMethodInfosResponse * out );
//gsoap impl service method-action: manager_USCORE_GetDesignerEvents ""
impl__manager_USCORE_GetDesignerEvents( xsd__string  modelKey, xsd__string  managerInstanceKey, impl__manager_USCORE_GetDesignerEventsResponse * out );
//gsoap impl service method-action: uidesigner_USCORE_GetRootUIComponents ""
impl__uidesigner_USCORE_GetRootUIComponents( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, impl__uidesigner_USCORE_GetRootUIComponentsResponse * out );
//gsoap impl service method-action: comp_USCORE_SetParentContainer ""
impl__comp_USCORE_SetParentContainer( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  containerInstanceKey, xsd__string  compInstanceKey, impl__comp_USCORE_SetParentContainerResponse * out );
//gsoap impl service method-action: uicomp_USCORE_TestUIComponentRect ""
impl__uicomp_USCORE_TestUIComponentRect( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  compInstanceKey, xsd__int  x, xsd__int  y, xsd__int  width, xsd__int  height, xsd__int  dragX, xsd__int  dragY, impl__uicomp_USCORE_TestUIComponentRectResponse * out );
//gsoap impl service method-action: uidesigner_USCORE_CreateComponent_ ""
impl__uidesigner_USCORE_CreateComponent_( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  containerInstanceKey, xsd__string  compTypeKey, xsd__int  x, xsd__int  y, xsd__int  width, xsd__int  height, impl__uidesigner_USCORE_CreateComponentResponse * out );
//gsoap impl service method-action: model_USCORE_CreateDesignerManager ""
impl__model_USCORE_CreateDesignerManager( xsd__string  modelKey, impl__model_USCORE_CreateDesignerManagerResponse * out );
//gsoap impl service method-action: designer_USCORE_GetContextTags ""
impl__designer_USCORE_GetContextTags( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__int  x, xsd__int  y, impl__designer_USCORE_GetContextTagsResponse * out );
//gsoap impl service method-action: compinfo_USCORE_GetEventInfos ""
impl__compinfo_USCORE_GetEventInfos( xsd__string  modelKey, xsd__string  compTypeKey, impl__compinfo_USCORE_GetEventInfosResponse * out );
//gsoap impl service method-action: event_USCORE_SetDefaultHook ""
impl__event_USCORE_SetDefaultHook( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string * eventKeyPath, impl__event_USCORE_SetDefaultHookResponse * out );
//gsoap impl service method-action: eventinfo_USCORE_GetEventInfos ""
impl__eventinfo_USCORE_GetEventInfos( xsd__string  modelKey, xsd__string  compTypeKey, ArrayOf_USCORE_xsd_USCORE_string * parentEventKeyPath, impl__eventinfo_USCORE_GetEventInfosResponse * out );
//gsoap impl service method-action: designer_USCORE_TagInvoked ""
impl__designer_USCORE_TagInvoked( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, ArrayOf_USCORE_xsd_USCORE_string * tagKeyPath, impl__designer_USCORE_TagInvokedResponse * out );
//gsoap impl service method-action: container_USCORE_SetComponentIndex ""
impl__container_USCORE_SetComponentIndex( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  containerInstanceKey, xsd__string  compInstanceKey, xsd__int  index, impl__container_USCORE_SetComponentIndexResponse * out );
//gsoap impl service method-action: designer_USCORE_TestCreateComponent ""
impl__designer_USCORE_TestCreateComponent( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  containerInstanceKey, xsd__string  compTypeKey, impl__designer_USCORE_TestCreateComponentResponse * out );
//gsoap impl service method-action: comp_USCORE_TagInvoked ""
impl__comp_USCORE_TagInvoked( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string * tagKeyPath, impl__comp_USCORE_TagInvokedResponse * out );
//gsoap impl service method-action: prop_USCORE_GetProperties ""
impl__prop_USCORE_GetProperties( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string * parentPropKeyPath, impl__prop_USCORE_GetPropertiesResponse * out );
//gsoap impl service method-action: palette_USCORE_GetComponentInfos ""
impl__palette_USCORE_GetComponentInfos( xsd__string  modelKey, xsd__string  pageKey, impl__palette_USCORE_GetComponentInfosResponse * out );
//gsoap impl service method-action: comp_USCORE_GetProperties ""
impl__comp_USCORE_GetProperties( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  compInstanceKey, impl__comp_USCORE_GetPropertiesResponse * out );
//gsoap impl service method-action: manager_USCORE_GetPersistenceData ""
impl__manager_USCORE_GetPersistenceData( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  compInstanceKey, impl__manager_USCORE_GetPersistenceDataResponse * out );
//gsoap impl service method-action: model_USCORE_GetDefaultDesignerInfo ""
impl__model_USCORE_GetDefaultDesignerInfo( xsd__string  modelKey, impl__model_USCORE_GetDefaultDesignerInfoResponse * out );
//gsoap impl service method-action: model_USCORE_DisposeDesignerManager ""
impl__model_USCORE_DisposeDesignerManager( xsd__string  modelKey, xsd__string  managerInstanceKey, impl__model_USCORE_DisposeDesignerManagerResponse * out );
//gsoap impl service method-action: uidesignrect_USCORE_TagInvoked ""
impl__uidesignrect_USCORE_TagInvoked( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  compInstanceKey, xsd__string  designRectKey, ArrayOf_USCORE_xsd_USCORE_string * tagKeyPath, impl__uidesignrect_USCORE_TagInvokedResponse * out );
//gsoap impl service method-action: prop_USCORE_SetValueAsText ""
impl__prop_USCORE_SetValueAsText( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string * propKeyPath, xsd__string  value, impl__prop_USCORE_SetValueAsTextResponse * out );
//gsoap impl service method-action: comp_USCORE_GetEvents ""
impl__comp_USCORE_GetEvents( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  compInstanceKey, impl__comp_USCORE_GetEventsResponse * out );
//gsoap impl service method-action: designer_USCORE_CreateComponent_ ""
impl__designer_USCORE_CreateComponent_( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  containerInstanceKey, xsd__string  compTypeKey, impl__designer_USCORE_CreateComponentResponse * out );
//gsoap impl service method-action: manager_USCORE_IsPersistenceDataModified ""
impl__manager_USCORE_IsPersistenceDataModified( xsd__string  modelKey, xsd__string  managerInstanceKey, impl__manager_USCORE_IsPersistenceDataModifiedResponse * out );
//gsoap impl service method-action: uicomp_USCORE_SetUIComponentRect ""
impl__uicomp_USCORE_SetUIComponentRect( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  compInstanceKey, xsd__int  x, xsd__int  y, xsd__int  width, xsd__int  height, xsd__int  dragX, xsd__int  dragY, impl__uicomp_USCORE_SetUIComponentRectResponse * out );
//gsoap impl service method-action: model_USCORE_GetUIDesignerInfo ""
impl__model_USCORE_GetUIDesignerInfo( xsd__string  modelKey, impl__model_USCORE_GetUIDesignerInfoResponse * out );
//gsoap impl service method-action: model_USCORE_CustomDataRequest ""
impl__model_USCORE_CustomDataRequest( xsd__string  modelKey, xsd__string  key, xsd__string  data, impl__model_USCORE_CustomDataRequestResponse * out );
//gsoap impl service method-action: event_USCORE_Unhook ""
impl__event_USCORE_Unhook( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string * eventKeyPath, impl__event_USCORE_UnhookResponse * out );
//gsoap impl service method-action: model_USCORE_GetComponentInfo ""
impl__model_USCORE_GetComponentInfo( xsd__string  modelKey, xsd__string  compTypeKey, impl__model_USCORE_GetComponentInfoResponse * out );
//gsoap impl service method-action: propinfo_USCORE_GetPropertyInfos ""
impl__propinfo_USCORE_GetPropertyInfos( xsd__string  modelKey, xsd__string  compTypeKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string * parentPropKeyPath, impl__propinfo_USCORE_GetPropertyInfosResponse * out );
//gsoap impl service method-action: manager_USCORE_GetComponentsOfType ""
impl__manager_USCORE_GetComponentsOfType( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  compTypeKey, impl__manager_USCORE_GetComponentsOfTypeResponse * out );
//gsoap impl service method-action: event_USCORE_GetEvents ""
impl__event_USCORE_GetEvents( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string * parentEventKeyPath, impl__event_USCORE_GetEventsResponse * out );
//gsoap impl service method-action: uidesigner_USCORE_CreateComponent ""
impl__uidesigner_USCORE_CreateComponent( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  containerInstanceKey, xsd__string  compTypeKey, xsd__int  x, xsd__int  y, xsd__base64Binary * persistData, impl__uidesigner_USCORE_CreateComponentResponse * out );
//gsoap impl service method-action: manager_USCORE_SetPersistenceData ""
impl__manager_USCORE_SetPersistenceData( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__base64Binary * persistData, impl__manager_USCORE_SetPersistenceDataResponse * out );
//gsoap impl service method-action: comp_USCORE_GetEvent ""
impl__comp_USCORE_GetEvent( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string * eventKeyPath, impl__comp_USCORE_GetEventResponse * out );
//gsoap impl service method-action: designer_USCORE_GetComponent ""
impl__designer_USCORE_GetComponent( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  compInstanceKey, impl__designer_USCORE_GetComponentResponse * out );
//gsoap impl service method-action: event_USCORE_SetHookAsText ""
impl__event_USCORE_SetHookAsText( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string * eventKeyPath, xsd__string  hookText, impl__event_USCORE_SetHookAsTextResponse * out );
//gsoap impl service method-action: compinfo_USCORE_GetPropertyInfos ""
impl__compinfo_USCORE_GetPropertyInfos( xsd__string  modelKey, xsd__string  compTypeKey, impl__compinfo_USCORE_GetPropertyInfosResponse * out );
//gsoap impl service method-action: designer_USCORE_DisposeComponent ""
impl__designer_USCORE_DisposeComponent( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  compInstanceKey, impl__designer_USCORE_DisposeComponentResponse * out );
//gsoap impl service method-action: compinfo_USCORE_GetMethodInfos ""
impl__compinfo_USCORE_GetMethodInfos( xsd__string  modelKey, xsd__string  compTypeKey, impl__compinfo_USCORE_GetMethodInfosResponse * out );
//gsoap impl service method-action: designer_USCORE_GetRootComponents ""
impl__designer_USCORE_GetRootComponents( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, impl__designer_USCORE_GetRootComponentsResponse * out );
//gsoap impl service method-action: uidesigner_USCORE_GetUIComponent ""
impl__uidesigner_USCORE_GetUIComponent( xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  compInstanceKey, impl__uidesigner_USCORE_GetUIComponentResponse * out );
//gsoap impl service method-action: model_USCORE_GetDesignerInfoForComponent ""
impl__model_USCORE_GetDesignerInfoForComponent( xsd__string  modelKey, xsd__string  compTypeKey, impl__model_USCORE_GetDesignerInfoForComponentResponse * out );
