#include "messagetestapp.h"

EXPORT_C CApaApplication* NewApplication()
{
    return new CmessagetestApplication();
}

// dll entry point
GLDEF_C TInt E32Dll(TDllReason)
{
    return KErrNone;
}


