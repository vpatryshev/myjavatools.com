//---------------------------------------------------------------------------

#ifndef rcmclientuH
#define rcmclientuH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Grids.hpp>
#include <ValEdit.hpp>
#include <Menus.hpp>
#include <ComCtrls.hpp>
#include <list.h>
#include <ExtCtrls.hpp>
#include <Dialogs.hpp>
#include <IdBaseComponent.hpp>
#include <IdComponent.hpp>
#include <IdTCPClient.hpp>
#include <IdTCPConnection.hpp>
#include <hash_map>

typedef hash_map<char*, impl__WSComponentInfo*, hash<char*> > compInfoHash;
typedef list<impl__WSComponentInfo*> compInfoList;

//char server[] = "http://localhost:5050/";

typedef struct {
	impl__WSPropertyInfo *pInfo;
    impl__WSLiveProperty *pLive;
} TPropPair, *PPropPair;

typedef struct {
	impl__WSEventInfo *eInfo;
    impl__WSLiveEvent *eLive;
} TEventPair, *PEventPair;

//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TPopupMenu *pmProperties;
	TMenuItem *Tags1;
	TPanel *Panel1;
    TPageControl *PageControl1;
	TMainMenu *MainMenu1;
	TMenuItem *Designer1;
	TMenuItem *Component1;
	TMenuItem *Dispose2;
	TPopupMenu *pmCompInfo;
	TMenuItem *ComponentsOfType1;
	TPopupMenu *pmDesigner;
	TMenuItem *TopLevelComponents1;
	TPopupMenu *pmComps;
	TTabSheet *tsPersist;
    TMemo *mPersist;
	TMenuItem *Persist1;
	TSaveDialog *SaveDialog1;
	TOpenDialog *OpenDialog1;
	TMenuItem *Depersist1;
	TSplitter *Splitter1;
	TMenuItem *Image1;
    TMenuItem *Image2;
    TTabSheet *tsEvents;
    TMemo *mEvents;
    TTimer *Timer1;
	TMenuItem *PartialImage1;
    TMenuItem *PropertyInfos1;
	TIdTCPClient *TCPClient;
    TMenuItem *CreateChild2;
    TTabSheet *tsUIComponents;
    TTreeView *tvComps;
    TScrollBox *ScrollBox1;
    TImage *Image;
    TSplitter *Splitter2;
    TPanel *Panel2;
    TComboBox *cbProp;
    TSplitter *Splitter3;
    TTabSheet *tsModel;
    TLabel *Label1;
    TLabel *Label2;
    TPageControl *tsData;
    TGroupBox *GroupBox1;
    TComboBox *cbModels;
    TValueListEditor *veModel;
    TGroupBox *GroupBox2;
    TValueListEditor *veDesigner;
    TComboBox *cbDesigners;
    TValueListEditor *veCompInfos;
    TGroupBox *GroupBox3;
    TComboBox *cbDesignerInfos;
    TValueListEditor *veDesignerInfo;
    TLabel *Label3;
	TPageControl *pcProps;
	TTabSheet *tsProps;
	TTabSheet *tsCompEvents;
	TTreeView *tvProps;
	TTreeView *tvEvents;
    TMenuItem *Persist2;
	void __fastcall FormCreate(TObject *Sender);
	void __fastcall cbModelsClick(TObject *Sender);
	void __fastcall FormDestroy(TObject *Sender);
	void __fastcall CreateDesignersClick(TObject *Sender);
	void __fastcall cbDesignersClick(TObject *Sender);
	void __fastcall ComponentsOfType1Click(TObject *Sender);
	void __fastcall tvCompsClick(TObject *Sender);
	void __fastcall PageControl1Change(TObject *Sender);
	void __fastcall Persist1Click(TObject *Sender);
	void __fastcall Depersist1Click(TObject *Sender);
	void __fastcall tvPropsExpanding(TObject *Sender, TTreeNode *Node,
          bool &AllowExpansion);
	void __fastcall tvPropsClick(TObject *Sender);
	void __fastcall cbPropKeyPress(TObject *Sender, char &Key);
	void __fastcall cbPropSelect(TObject *Sender);
	void __fastcall Image1Click(TObject *Sender);
    void __fastcall cbDesignerInfosClick(TObject *Sender);
    void __fastcall Timer1Timer(TObject *Sender);
    void __fastcall pmCompsPopup(TObject *Sender);
	void __fastcall PartialImage1Click(TObject *Sender);
    void __fastcall PropertyInfos1Click(TObject *Sender);
    void __fastcall Create3Click(TObject *Sender);
    void __fastcall CreateChild1Click(TObject *Sender);
    void __fastcall Create2Click(TObject *Sender);
    void __fastcall Component1Click(TObject *Sender);
	void __fastcall tvCompsEdited(TObject *Sender, TTreeNode *Node,
          AnsiString &S);
	void __fastcall tvEventsClick(TObject *Sender);
    void __fastcall Dispose2Click(TObject *Sender);
    void __fastcall Persist2Click(TObject *Sender);
    void __fastcall pcPropsChange(TObject *Sender);
private:	// User declarations
    Graphics::TBitmap *compBmp;
public:		// User declarations
	__fastcall TForm1(TComponent* Owner);
	void __fastcall SetCurrentPropValue(AnsiString &value);
	void __fastcall SetCurrentEventValue(AnsiString &value);    
    void __fastcall ExpandPropNode(TTreeNode *node);
    void __fastcall RecurseComponents(impl__WSLiveComponent *comp, TTreeNode *node);
	void __fastcall PopulateComponentsTree();
    void __fastcall AddPropertyNode(TTreeNode *node, impl__WSPropertyInfo *pi, impl__WSLiveComponent *c);
    void __fastcall AddPropertyNode(TTreeNode *node, impl__WSLiveProperty *pi, impl__WSLiveComponent *c);
    void __fastcall AddEventNode(TTreeNode *node, impl__WSEventInfo *ei, impl__WSLiveComponent *c);
    void __fastcall AddEventNode(TTreeNode *node, impl__WSLiveEvent *ei, impl__WSLiveComponent *c);
    void __fastcall ListProperties(impl__WSLiveComponent *c);
	void __fastcall ListEvents(impl__WSLiveComponent *c);
    void __fastcall HandleDesignerEvent(impl__WSDesignerEvent *e);
    void __fastcall CompTagClicked(TObject *Sender);
    void __fastcall PaintUIComponent(impl__WSLiveUIComponent *uic, TRect &rect);
    void __fastcall CreateComponent(char *containerKey = 0);
    void __fastcall CreateTLComponent();
    void __fastcall CreateChildComponentClick(TObject *Sender);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
