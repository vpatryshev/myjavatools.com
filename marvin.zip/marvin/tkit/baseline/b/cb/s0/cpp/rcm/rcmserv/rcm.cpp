#ifdef __BORLANDC__
#include "rcmpch.h"
#pragma hdrstop
#endif

#include "rcm.h"
#include "soapWSComponentModelServerService.nsmap"

typedef list<Result*> Results;
Results pendingResults;

Result* FindResult(const wxString &resultKey)
{
    for (Results::iterator it = pendingResults.begin(); it != pendingResults.end(); ++it) {
		if ((*it)->Key() == resultKey)
        	return *it;
    }
    return 0;
}

Result* ErrorMessage(const wxString &title, const wxString &message)
{
	ResultMessage *msg = new ResultMessage(title, message, ResultMessage::mtCritical);
    return new Result(false, msg);
}

Result* ErrorMessage(const wxString &message)
{
    return ErrorMessage("Error", message);
}

int UniqueID()
{
    static id = 1;
    return ++id;
}

// ResultOption

ResultOption::ResultOption(const wxString &text, const wxString &description,
    int id) : FText(text), FDesc(description)
{
    if (id == -1)
        FId = UniqueID();
}

Result* ResultOption::Selected()
{
    return new Result(true);
}

// ResultMessage

ResultMessage::ResultMessage(const wxString &text, const wxString &detail, MessageType msgType)
	: FText(text), FDetail(detail), FType(msgType)
{
    KeyGen(this, FKey);
}

// Result

Result::Result(bool success, const wxString &msgText, const wxString &msgDetail) : FSuccess(success)
{
    KeyGen(this, FKey);
	if (!msgText.IsEmpty() || !msgDetail.IsEmpty()) {
    	ResultMessage *msg = new ResultMessage(msgText, msgDetail);
		AddMessage(msg);
    }
    pendingResults.push_back(this);
}

Result::Result(bool success, ResultMessage *message) : FSuccess(success)
{
    KeyGen(this, FKey);
	if (message) 
    	AddMessage(message);
    pendingResults.push_back(this);
}

Result::~Result()
{
	for (ResultOptions::iterator it = FOptions.begin(); it != FOptions.end(); ++it) {
        delete *it;
    }
    FOptions.clear();
	for (ResultMessages::iterator it = FMessages.begin(); it != FMessages.end(); ++it) {
        delete *it;
    }
    FMessages.clear();
	pendingResults.remove(this);
}

void Result::AddMessage(ResultMessage *message)
{
	if (message) {
	    FMessages.push_front(message);
    }
}

void Result::AddOption(ResultOption *option)
{
	if (option) {
		FOptions.push_front(option);
	}
}

ResultOption* Result::GetOption(int id)
{
	for (ResultOptions::iterator it = FOptions.begin(); it != FOptions.end(); ++it) {
		if ((*it)->Id() == id) {
            return *it;
        }
    }
    return 0;
}

// PropertyChoice

PropertyChoice::PropertyChoice(const string_type &displayValue, const string_type &valueAsString)
    : FDisplayIconURI("")
{
    FDisplayValue = displayValue;
    FValue = STRLEN(valueAsString) == 0 ? displayValue : valueAsString;
}


// CreateResult

CreateResult::CreateResult(rcmComponent *component, ResultMessage *message)
	: Result(component != 0, message)
{
	FComponent = component;
}

CreateResult::CreateResult(rcmComponent *component, const wxString &msgText, const wxString &msgDetail)
	: Result(component != 0, msgText, msgDetail)
{
	FComponent = component;
}

// MenuItem

MenuItem::MenuItem(const string_type &caption, int id, bool autoFree)
    : FParent(0), FCaption(caption), FItems(0), FEnabled(true), FId(id), FAutoFree(autoFree)
{
}

MenuItem::~MenuItem()
{
    Clear();
}

void MenuItem::Clear()
{
    if (FItems) {
        if (Count() > 0) {
            MenuItems::iterator it = FItems->begin();
            for (; it != FItems->end(); ++it)
                delete *it;
            FItems->clear();
        }
        delete FItems;
        FItems = 0;
    }
}

Result* MenuItem::DoItemClick()
{
    Result *result = 0;
    if (FOnItemClick)
        FOnItemClick(this, result);
    return result;
}

void MenuItem::Add(MenuItem *item)
{
    Insert(Count(), item);
}

void MenuItem::Insert(int index, MenuItem *item)
{
    if (!item) return;
    if (!FItems)
        FItems = new list<MenuItem*>();
    int i = 0;
    MenuItems::iterator it = FItems->begin();
    while (i < index && it != FItems->end()) {
        ++it;
        i++;
    }
    if (it == FItems->end()) {
        FItems->push_back(item);
    }
    else if (it == FItems->begin()) {
        FItems->push_front(item);
    }
    else
        FItems->insert(it, item);
    item->FParent = this;
}

MenuItem* MenuItem::Find(MenuItem *item, bool recurse)
{
    if (!FItems) return 0;
    MenuItems::iterator it = FItems->begin();
    for (; it != FItems->end(); ++it) {
        if (*it == item) {
            return *it;
        }
        else if (recurse) {
            MenuItem *item = (dynamic_cast<MenuItem*>(*it))->Find(item, true);
            if (item) return item;
        }
    }
    return 0;
}

MenuItems* MenuItem::Items()
{
    return FItems;
}


void MenuItem::Remove(MenuItem *item)
{
    Items()->remove(item);
    delete (item);
}

// DesignRect

DesignRect::DesignRect(int left, int top, int width, int height, int flags, wxString &toolTip)
{
	KeyGen(this, FKey);
    FLeft = left;
    FTop = top;
    FWidth = width;
    FHeight = height;
    FFlags = flags;
    FToolTip = toolTip;
}

bool DesignRect::CanClick()
{
	return true;
}

string_type DesignRect::Key()
{
	return FKey;
}

Result* DesignRect::DoClick(int x, int y)
{
    Result *result = 0;
    if (FOnClick)
        FOnClick(this, x, y, result);
    return result;
}

Result* DesignRect::DoDblClick(int x, int y)
{
    Result *result = 0;
    if (FOnDblClick)
        FOnDblClick(this, x, y, result);
    return result;
}

void DesignRect::DoMoved(int &x, int &y, int &w, int &h)
{
    if (FOnMoved)
        FOnMoved(this, x, y, w, h);
    SetRect(x, y, w, h);
}

void DesignRect::DoResized(int &x, int &y, int &w, int &h)
{
    if (FOnResized)
        FOnResized(this, x, y, w, h);
    SetRect(x, y, w, h);
}

void DesignRect::GetMoveConstraints(int &x, int &y, int &w, int &h)
{
	x = FLeft;
    y = FTop;
    w = FWidth;
    h = FHeight;
}

void DesignRect::GetRect(int &x, int &y, int &w, int &h)
{
	x = FLeft;
    y = FTop;
    w = FWidth;
    h = FHeight;
}

void DesignRect::SetRect(int x, int y, int w, int h)
{
    FLeft = x;
    FTop = y;
    FWidth = w;
    FHeight = h;
}

void DesignRect::GetResizeConstraints(int &x, int &y, int &w, int &h)
{
	x = FLeft;
    y = FTop;
    w = FWidth;
    h = FHeight;
}

// DesignRectProvider

DesignRectProvider::DesignRectProvider()
{
    FRects = 0;
}

DesignRectProvider::~DesignRectProvider()
{
    ClearRects();
}

void DesignRectProvider::AddRect(DesignRect *dr)
{
    if (dr) {
        Rects()->push_back(dr);
    }
}

void DesignRectProvider::ClearRects()
{
    if (FRects) {
        DesignRects::iterator it = FRects->begin();
        for (; it != FRects->end(); ++it)
            delete *it;
        FRects->clear();
    }
}

DesignRect* DesignRectProvider::FindRect(wxString &key)
{
	if (FRects) {
	    DesignRects::const_iterator it = FRects->begin();
    	for (; it != FRects->end(); ++it) {
        	if ((*it)->Key() == key) {
            	return *it;
            }
	    }
    }
    return 0;
}

void DesignRectProvider::RemoveRect(DesignRect *dr)
{
	if (FRects) {
	    FRects->remove(dr);
        delete dr;
    }
}

DesignRects* DesignRectProvider::Rects()
{
    if (!FRects) {
        FRects = new DesignRects();
    }
    return FRects;
}

// DesignerEvent

DesignerEvent::DesignerEvent(rcmDesigner *designer, int code)
{
    FCode = code;
    FDesignerKey = designer->GetDesignerInfo()->DesignerKey();
    FManagerKey = designer->Manager()->Key();
}

ComponentEvent::ComponentEvent(rcmDesigner *designer, rcmComponent *comp, int code)
    : DesignerEvent(designer, code)
{
    FComponentKey = comp->Key();
}

PropertyChangedEvent::PropertyChangedEvent(rcmDesigner *designer, rcmProperty *property, rcmComponent *comp)
    : ComponentEvent(designer, comp, PROPERTY_CHANGED)
{
    PropertyKeyArray(FKeys, property);
}

EventChangedEvent::EventChangedEvent(rcmDesigner *designer, rcmEvent *event, rcmComponent *comp)
    : ComponentEvent(designer, comp, EVENT_CHANGED)
{
    PropertyKeyArray(FKeys, event);
}

CustomEvent::CustomEvent(rcmDesigner *designer, string_type& key, string_type &data)
    : DesignerEvent(designer, CUSTOM_DATA)
{
    FKey = key;
    FData = data;
}


