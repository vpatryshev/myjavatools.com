#ifdef __BORLANDC__
#include "rcmpch.h"
#endif

#include "wxwroot.h"

// wxwEventConnection

const wxDelegateTypeInfo* wxwEventConnection::GetSourceTypeInfo()
{
    return dynamic_cast<const wxDelegateTypeInfo*>(FPropInfo->GetTypeInfo());
}

wxString& wxwEventConnection::GetSinkName()
{
    return FName;
}

void wxwEventConnection::SetSinkName(const wxString &newName)
{
    FName = newName;
}

wxwComponent* wxwEventConnection::GetSource()
{
    return FSource;
}

const wxPropertyInfo* wxwEventConnection::GetSourcePropInfo()
{
    return FPropInfo;
}

// wxwRootComponent

wxwRootComponent::wxwRootComponent(const wxClassInfo *classInfo, wxwDesigner *designer, wxwContainer *container)
	: wxwComponent(classInfo, designer, NULL), wxwContainer(), FDCI(0)
{
}

wxwRootComponent::~wxwRootComponent()
{
    FInstance = 0;
    // wxDynamicClassInfo will delete all of its dynamic instances
    // when it is destroyed. It should be safe to just abandon FInstance here.
    delete FDCI;
    FDCI = 0;
}

void wxwRootComponent::InternalSetParent(wxwContainer *newContainer)
{
    if (newContainer)
        throw runtime_error(wxString::Format(
            "Component \"%s\" cannot have a parent", GetName()).c_str());
}

void wxwRootComponent::CheckClassName(const wxString &className)
{
    if (wxClassInfo::FindClass(className))
        throw new runtime_error(wxString::Format("A class named \"%s\" already exists",
            className).c_str());
}

void wxwRootComponent::SetInstance(wxObject *instance)
{
    wxASSERT_MSG(FInstance == 0, "Root component instance already created");
    wxASSERT_MSG(dynamic_cast<wxDynamicObject*>(instance), "Root component instance \
        must be a dynamic object");
    wxwComponent::SetInstance(instance);
    // The root component holds its own dynamic class info pointer, necessary
    // for deleting & adding component properties and handlers.
    // The normal ClassInfo() pointer is used to display the component's properties
    // normally.
    wxDynamicClassInfo *dci = dynamic_cast<wxDynamicClassInfo*>(instance->GetClassInfo());
    wxASSERT_MSG(dci, "ClassInfo pointer is not a wxDynamicClassInfo!");
    FDCI = dci;
}

void wxwRootComponent::NewInstance()
{
    wxASSERT_MSG(FInstance == 0, "wxwComponent already has an instance");
    CheckClassName(GetName());
    // First-phase construction from the wxDynamicClassInfo.
    char *newClassName;
    StrAlloc(newClassName, wxString("wx" + GetName()).c_str());
    FDCI = new wxDynamicClassInfo(
        0, // unit name. Fill this in later.
        newClassName, // "this" class name
        ComponentInfo()->ClassInfo());        //  superclass classInfo

    wxObject *object = FDCI->CreateObject();
    wxASSERT_MSG(object != 0, wxString::Format("Failed to create instance of %s",
        FDCI->GetClassName()));
    // Type-specific second-phase construction.
    ConstructXTIObject(object);
    SetInstance(object);
    ObjectCreated();
}

wxDynamicClassInfo* wxwRootComponent::DynamicClassInfo()
{
    return FDCI;
}

wxDynamicObject* wxwRootComponent::DynamicInstance()
{
    if (!FInstance)
        NewInstance();
    return dynamic_cast<wxDynamicObject*>(FInstance);
}

wxObject* wxwRootComponent::Instance()
{
    if (!FInstance)
        NewInstance();
    return DynamicInstance()->GetSuperClassInstance();
}

bool wxwRootComponent::HasHandler(const wxString &handlerName)
{
    wxDynamicClassInfo *dci = DynamicClassInfo();
    return dci && (bool)dci->FindHandlerInfoInThisClass(handlerName);
}

bool wxwRootComponent::HasProperty(const wxString &propName)
{
    wxDynamicClassInfo *dci = DynamicClassInfo();
    return dci && (bool)dci->FindPropertyInfoInThisClass(propName);
}

wxxVariant wxwRootComponent::GetComponentInstance(wxwComponent *component)
{
    wxxVariant value;
    if (component && component->Instance())
        value = component->Instance()->GetClassInfo()->InstanceToVariant(component->Instance());
    return value;
}

void wxwRootComponent::AddComponentProperty(wxwComponent *comp)
{
    wxxVariant propValue = GetComponentInstance(comp);
    if (!HasProperty(comp->GetName())) {
        DynamicClassInfo()->AddProperty(comp->GetName(), propValue.GetTypeInfo());
    }
    DynamicInstance()->SetProperty(comp->GetName(), propValue);
}

void wxwRootComponent::AddHandler(const wxString &handlerName, const wxClassInfo *eventClass)
{
    DynamicClassInfo()->AddHandler(handlerName, NULL, eventClass);
}

void wxwRootComponent::AssignHandler(wxwEventConnection *connection)
{
    if (connection) {
        if (!HasHandler(connection->GetSinkName())) {
    		DynamicClassInfo()->AddHandler(connection->GetSinkName(), 0,
            	connection->GetSourceTypeInfo()->GetEventClass());
        }
        FEventConnections[connection->GetSinkName()] = connection;
    }
}

const wxHandlerInfo* wxwRootComponent::GetHandler(const wxString &handlerName)
{
    return DynamicClassInfo()->FindHandlerInfoInThisClass(handlerName);
}

wxwEventConnection* wxwRootComponent::GetEventConnection(const wxPropertyInfo *propInfo, const wxwComponent *source)
{
    // this is less than optimal but I'm in a hurry.
    eventConnections::iterator it = FEventConnections.begin();
    for (; it != FEventConnections.end(); it++) {
        wxwEventConnection* candidate = (*it).second;
        if (candidate->GetSourcePropInfo() == propInfo
//            && candidate->GetDelegateTypeInfo() == propInfo->GetTypeInfo()
            && candidate->GetSource() == source) {
            return (*it).second;
        }
    }
    return 0;
}

void wxwRootComponent::RenameHandler(const wxString &newName, const wxString &oldName)
{
	if (!HasHandler(newName)) {
       	DynamicClassInfo()->RenameHandler(oldName, newName);
        eventConnections::iterator it = FEventConnections.find(oldName);
        if (it != FEventConnections.end()) {
            wxwEventConnection *sink = (*it).second;
            if (sink) {
                sink->SetSinkName(newName);
                FEventConnections.erase(it);
                FEventConnections[newName] = sink;
            }
        }
    }
}

void wxwRootComponent::RemoveHandler(const wxString &handlerName)
{
    if (HasHandler(handlerName)) {
        DynamicClassInfo()->RemoveHandler(handlerName);
        eventConnections::iterator it = FEventConnections.find(handlerName);
        if (it != FEventConnections.end()) {
        	delete (*it).second;
            FEventConnections.erase(it);
        }
    }
}

void wxwRootComponent::RemoveComponentProperty(wxwComponent *comp)
{
    if (HasProperty(comp->GetName())) {
        DynamicClassInfo()->RemoveProperty(comp->GetName());
//        DynamicInstance()->SetProperty(comp->GetName())
    }
}

void wxwRootComponent::RenameComponentProperty(wxwComponent *comp, const wxString &oldName)
{
    if (HasProperty(oldName)) {
        DynamicClassInfo()->RenameProperty(oldName, comp->GetName());
        wxxVariant propValue = GetComponentInstance(comp);
        DynamicInstance()->SetProperty(comp->GetName(), propValue);
    }
}

void wxwRootComponent::RenameClass(const wxString &newClassName)
{
    CheckClassName(newClassName);
    wxASSERT_MSG(wxClassInfo::sm_classTable, "wxClassInfo::sm_classTable is null!");
    wxClassInfo::sm_classTable->Delete(FDCI->m_className);
    delete FDCI->m_className;
    char *tmp;
    StrAlloc(tmp, newClassName.c_str());
    FDCI->m_className = tmp;
    wxClassInfo::sm_classTable->Put(FDCI->m_className, (wxObject *)FDCI);
}

Result* wxwRootComponent::SetName(const wxString &newName)
{
    wxString newClassName = "wx" + newName;
    if (newClassName != FDCI->m_className) {
        RenameClass(newClassName);
    }
  	return wxwComponent::SetName(newName);
}


