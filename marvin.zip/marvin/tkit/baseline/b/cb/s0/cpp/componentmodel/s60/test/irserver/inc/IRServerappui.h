#ifndef __IRSERVER_APPUI_H__
#define __IRSERVER_APPUI_H__

#include <aknViewAppUi.h>
#include "IRServer.h"

class CIRServerView;


// CIRServerAppUi
class CIRServerAppUi : public CAknViewAppUi
{
  /**
   * Performs view construction
   */
  void InitViewsL();

public:
  /**
   * Performs second phase construction of this AppUi Object
   */
  void ConstructL();

  /**
   * Handles user menu selection
   */
  void HandleCommandL(TInt aCommand);

private:
  CIRServerView * iIRServerView;
};


#endif // __IRSERVER_APPUI_H__

