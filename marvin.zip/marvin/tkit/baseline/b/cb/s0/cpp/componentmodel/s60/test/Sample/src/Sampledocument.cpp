////////////////////////////////////////////////////////////////////////////////
// Implementation of CSampleDocument
////////////////////////////////////////////////////////////////////////////////

#include "Sampleappui.h"
#include "Sampledocument.h"


CSampleDocument::CSampleDocument(CEikApplication& aApp)
                       :CAknDocument(aApp)
{
}

CSampleDocument::~CSampleDocument()
{
}

CSampleDocument* CSampleDocument::NewL(CEikApplication& aApp)
{
  CSampleDocument* self = NewLC(aApp);
  CleanupStack::Pop(self);
  return self;
}

CSampleDocument* CSampleDocument::NewLC(CEikApplication& aApp)
{
  CSampleDocument* self = new (ELeave) CSampleDocument(aApp);
  CleanupStack::PushL(self);
  self->ConstructL();
  return self;
}

void CSampleDocument::ConstructL()
{
}

CEikAppUi* CSampleDocument::CreateAppUiL()
{
  return new(ELeave) CSampleAppUi;
}

