//$$---- Active Form HDR ---- (stActiveFormHdr)
//---------------------------------------------------------------------------


#ifndef CodeGuardConfigDialogImpl1H
#define CodeGuardConfigDialogImpl1H
//---------------------------------------------------------------------------
#include <classes.hpp>
#include <controls.hpp>
#include <stdCtrls.hpp>
#include <forms.hpp>
#include "CodeGuardConfiguration_TLB.h"
#include <AxCtrls.hpp>
#include <Classes.hpp>
#include <ComCtrls.hpp>
#include <Controls.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
#include <StdCtrls.hpp>
#include <Dialogs.hpp>
#include <Menus.hpp>

#include "Cg_cgi.h" // codeguard kernel interface header

typedef union {
  CGFunctionOptions funcOpts;
  CGResourceOptions resOpts;
} OptionUnion;

#define D_OPTIONS  0
#define D_RESOURCES 1
#define D_FUNCTIONS 2

class TCodeGuardConfigDialog : public TActiveForm
{
__published:	// IDE-managed Components
        TPageControl *pgeCGOptions;
        TTabSheet *tabPreferences;
        TGroupBox *gbxCodeGuard;
        TLabel *lblStackFillFrequency;
        TCheckBox *cbxCGEnable;
        TEdit *edtStackFillFrequency;
        TGroupBox *gbxReport;
        TCheckBox *cbxStatistics;
        TCheckBox *cbxResourceLeaks;
        TCheckBox *cbxAppendToLogFile;
        TCheckBox *cbxSendToOutputDebugString;
        TCheckBox *cbxRepeatedErrors;
        TEdit *edtNumberOfErrorMessages;
        TCheckBox *cbxLimitNumberOfErrorMessages;
        TGroupBox *bgcErrorMessageBox;
        TLabel *lblCaption;
        TLabel *lblMessage;
        TCheckBox *cbxEnableErrorMessageBox;
        TEdit *edtErrorMessageBoxCaption;
        TEdit *edtErrorMessageBoxMessage;
        TGroupBox *gbxDebuggingInformation;
        TLabel *lblSourcePath;
        TCheckBox *cbxReadDebugInfo;
        TEdit *edtSourcePath;
        TTabSheet *tabResourceOptions;
        TLabel *lblResources;
        TListBox *lbxResources;
        TPanel *pnlResourceOptions;
        TLabel *lblDelayQueueLength;
        TLabel *lblMaximumMemoryBlockSize;
        TLabel *lblResourcesExtendedSelectNote;
        TCheckBox *cbxEnableTracking;
        TCheckBox *cbxTrackResourceLeaks;
        TCheckBox *cbxReportInvalidHandleOrResourceParameters;
        TCheckBox *cbxDelayFree;
        TEdit *edtDelayQueueLength;
        TEdit *edtMaximumMemoryBlockSize;
        TTabSheet *tabFunctionOverrides;
        TLabel *lblFunctions;
        TListBox *lbxFunctions;
        TButton *btnResetToDefaultFunctionOptions;
        TButton *btnSetDefaultFunctionOptions;
        TPanel *pnlFunctionOptions;
        TLabel *lblFunctionsExtendedSelectNote;
        TCheckBox *cbxDisableFunctionTracking;
        TCheckBox *cbxMemoryAccessErrors;
        TCheckBox *cbxLogEachCall;
        TCheckBox *cbxWarnings;
        TCheckBox *cbxFunctionResultErrors;
        TCheckBox *cbxInvalidHandleOrResourceParameters;
        TTabSheet *tabIgnoredModules;
        TLabel *lblIgnoredModules;
        TListBox *lbxIgnoredModules;
        TButton *btnAddModule;
        TButton *btnRemoveModule;
        TOpenDialog *dlgOpen;
        TPopupMenu *MainPopupMenu;
        TMenuItem *itmOpen;
        TMenuItem *itmSave;
        TMenuItem *N1;
        TMenuItem *itmLoadGlobalOptions;
        TTimer *Timer1;
    void __fastcall cbxEnableTrackingClick(TObject *Sender);
    void __fastcall cbxDelayFreeClick(TObject *Sender);
    void __fastcall cbxEnableErrorMessageBoxClick(TObject *Sender);
    void __fastcall cbxReadDebugInfoClick(TObject *Sender);
    void __fastcall PseudoBtnOKClick(TObject *Sender);
    void __fastcall btnAddModuleClick(TObject *Sender);
    void __fastcall lbxIgnoredModulesKeyUp(TObject *Sender, WORD &Key,
          TShiftState Shift);
    void __fastcall btnRemoveModuleClick(TObject *Sender);
    void __fastcall Timer1Timer(TObject *Sender);
    void __fastcall pgeCGOptionsChange(TObject *Sender);
    void __fastcall cbxCGEnableClick(TObject *Sender);
    void __fastcall lbxResourcesClick(TObject *Sender);
    void __fastcall lbxFunctionsClick(TObject *Sender);
    void __fastcall itmOpenClick(TObject *Sender);
    void __fastcall itmSaveClick(TObject *Sender);
    void __fastcall btnResetToDefaultFunctionOptionsClick(TObject *Sender);
    void __fastcall btnSetDefaultFunctionOptionsClick(TObject *Sender);
    void __fastcall cbxTrackResourceLeaksMouseUp(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
    void __fastcall cbxMemoryAccessErrorsMouseUp(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
    void __fastcall edtDelayQueueLengthExit(TObject *Sender);
    void __fastcall cbxCGEnableMouseUp(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
    void __fastcall edtStackFillFrequencyExit(TObject *Sender);
    void __fastcall edtNumberOfErrorMessagesExit(TObject *Sender);
    void __fastcall commonDirtyer(TObject *Sender);
    void __fastcall cbxLimitNumberOfErrorMessagesClick(TObject *Sender);
    void __fastcall itmLoadGlobalOptionsClick(TObject *Sender);
    void __fastcall MainPopupMenuPopup(TObject *Sender);
    void __fastcall cbxDisableFunctionTrackingClick(TObject *Sender);
    void __fastcall ActiveFormCreate(TObject *Sender);
    void __fastcall ActiveFormKeyUp(TObject *Sender, WORD &Key,
          TShiftState Shift);
private:
    char OptFileName[1024];
    CGOptions* gcgOptions;
    CGFunctionOptions* DefaultFunctionOptions;
    OptionUnion *OptionUnionArray;
    int LastFuncIndex;
    int LastResIndex;
    bool Dirty[3];
    bool isReading;
    bool __fastcall isDirty(int Section){return Dirty[Section];}
    void __fastcall ClearDirty(int Section){Dirty[Section] = false;}
    void __fastcall SetDirty(int Section){Dirty[Section] = !isReading;}
    void __fastcall ToggleControls(TControl** ControlArrayElement, int NumElements, bool isChecked);
    AnsiString __fastcall ConvertString(AnsiString s, char in, char out);
    void __fastcall NewCaption(AnsiString NewCaption);
    void __fastcall ReadLastFileName();
    void __fastcall WriteLastFileName();
    bool __fastcall AskToSave(AnsiString Message);
    void __fastcall EnableFunctionOptions();
    void __fastcall EnableResourceOptions();
    inline char * OptionsFileName() {return ((strcmp(OptFileName, "") == 0) ? NULL : OptFileName);}
    void __fastcall PositiveIntergersOnly(TObject* /*Sender*/, char &Key);
protected:
    virtual char* __fastcall OpenFile();
    virtual void __fastcall SaveFile();
    virtual void __fastcall SetResourceOptions(TListBox* Sender);
    virtual void __fastcall SetFunctionOptions(TListBox* Sender);
    virtual bool __fastcall ValidateRange(TEdit* Edit, int low, int high);
    virtual void __fastcall SetAndEnableResourceOptions(OptionUnion* pOptionUnion);
    virtual void __fastcall SetAndEnableFunctionOptions(OptionUnion* pOptionUnion);
    virtual void __fastcall ReadOptions();
    virtual void __fastcall WriteOptions();
    virtual void __fastcall PseudoFormCreate();
public:
    __fastcall TCodeGuardConfigDialog(HWND ParentWindow);
    __fastcall TCodeGuardConfigDialog(TComponent* AOwner): TActiveForm(AOwner) {};
    __fastcall ~TCodeGuardConfigDialog();
};



extern PACKAGE TCodeGuardConfigDialog *CodeGuardConfigDialog;



class ATL_NO_VTABLE TCodeGuardConfigDialogImpl:
  VCLCONTROL_IMPL(TCodeGuardConfigDialogImpl, CodeGuardConfigDialog, TCodeGuardConfigDialog, ICodeGuardConfigDialog, DIID_ICodeGuardConfigDialogEvents)
{
  void __fastcall ActivateEvent(TObject *Sender);
  void __fastcall ClickEvent(TObject *Sender);
  void __fastcall CreateEvent(TObject *Sender);
  void __fastcall DblClickEvent(TObject *Sender);
  void __fastcall DeactivateEvent(TObject *Sender);
  void __fastcall DestroyEvent(TObject *Sender);
  void __fastcall KeyPressEvent(TObject *Sender, char &Key);
  void __fastcall PaintEvent(TObject *Sender);
public:

  void InitializeControl()
  {
    m_VclCtl->OnActivate = ActivateEvent;
    m_VclCtl->OnClick = ClickEvent;
    m_VclCtl->OnCreate = CreateEvent;
    m_VclCtl->OnDblClick = DblClickEvent;
    m_VclCtl->OnDeactivate = DeactivateEvent;
    m_VclCtl->OnDestroy = DestroyEvent;
    m_VclCtl->OnKeyPress = KeyPressEvent;
    m_VclCtl->OnPaint = PaintEvent;
  }

// The COM MAP entries declares the interfaces your object exposes (through
// QueryInterface). CComRootObjectEx::InternalQueryInterface only returns
// pointers for interfaces in the COM map. VCL controls exposed as OCXes
// have a minimum set of interfaces defined by the
// VCL_CONTROL_COM_INTERFACE_ENTRIES macro. Add other interfaces supported
// by your object with additional COM_INTERFACE_ENTRY[_xxx] macros.
//
BEGIN_COM_MAP(TCodeGuardConfigDialogImpl)
  VCL_CONTROL_COM_INTERFACE_ENTRIES(ICodeGuardConfigDialog)
END_COM_MAP()



// The PROPERTY map stores property descriptions, property DISPIDs,
// property page CLSIDs and IDispatch IIDs. You may use use
// IPerPropertyBrowsingImpl, IPersistPropertyBagImpl, IPersistStreamInitImpl,
// and ISpecifyPropertyPageImpl to utilize the information in you property
// map.
//
// NOTE: The BCB Wizard does *NOT* maintain your PROPERTY_MAP table. You must
//       add or remove entries manually.
//
BEGIN_PROPERTY_MAP(TCodeGuardConfigDialogImpl)
  // PROP_PAGE(CLSID_CodeGuardConfigDialogPage)
END_PROPERTY_MAP()

/* DECLARE_VCL_CONTROL_PERSISTENCE(CppClass, VclClass) is needed for VCL
 * controls to persist via the VCL streaming mechanism and not the ATL mechanism.
 * The macro adds static IPersistStreamInit_Load and IPersistStreamInit_Save
 * methods to your implementation class, overriding the methods in IPersistStreamImpl. 
 * This macro must be manually undefined or removed if you port to C++Builder 4.0. */

DECLARE_VCL_CONTROL_PERSISTENCE(TCodeGuardConfigDialogImpl, TCodeGuardConfigDialog);

// The DECLARE_ACTIVEXCONTROL_REGISTRY macro declares a static 'UpdateRegistry' 
// routine which registers the basic information about your control. The
// parameters expected by the macro are the ProgId & the ToolboxBitmap ID of
// your control.
//
DECLARE_ACTIVEXCONTROL_REGISTRY("CodeGuardConfiguration.CodeGuardConfigDialog", 1);

protected: 
  STDMETHOD(_set_Font(IFontDisp** Value));
  STDMETHOD(AboutBox());
  STDMETHOD(get_Active(VARIANT_BOOL* Value));
  STDMETHOD(get_AlignDisabled(VARIANT_BOOL* Value));
  STDMETHOD(get_AutoScroll(VARIANT_BOOL* Value));
  STDMETHOD(get_AutoSize(VARIANT_BOOL* Value));
  STDMETHOD(get_AxBorderStyle(TxActiveFormBorderStyle* Value));
  STDMETHOD(get_BorderWidth(long* Value));
  STDMETHOD(get_Caption(BSTR* Value));
  STDMETHOD(get_Color(::OLE_COLOR* Value));
  STDMETHOD(get_DoubleBuffered(VARIANT_BOOL* Value));
  STDMETHOD(get_DropTarget(VARIANT_BOOL* Value));
  STDMETHOD(get_Enabled(VARIANT_BOOL* Value));
  STDMETHOD(get_Font(IFontDisp** Value));
  STDMETHOD(get_HelpFile(BSTR* Value));
  STDMETHOD(get_KeyPreview(VARIANT_BOOL* Value));
  STDMETHOD(get_PixelsPerInch(long* Value));
  STDMETHOD(get_PrintScale(TxPrintScale* Value));
  STDMETHOD(get_Scaled(VARIANT_BOOL* Value));
  STDMETHOD(get_Visible(VARIANT_BOOL* Value));
  STDMETHOD(get_VisibleDockClientCount(long* Value));
  STDMETHOD(set_AutoScroll(VARIANT_BOOL Value));
  STDMETHOD(set_AutoSize(VARIANT_BOOL Value));
  STDMETHOD(set_AxBorderStyle(TxActiveFormBorderStyle Value));
  STDMETHOD(set_BorderWidth(long Value));
  STDMETHOD(set_Caption(BSTR Value));
  STDMETHOD(set_Color(::OLE_COLOR Value));
  STDMETHOD(set_DoubleBuffered(VARIANT_BOOL Value));
  STDMETHOD(set_DropTarget(VARIANT_BOOL Value));
  STDMETHOD(set_Enabled(VARIANT_BOOL Value));
  STDMETHOD(set_Font(IFontDisp* Value));
  STDMETHOD(set_HelpFile(BSTR Value));
  STDMETHOD(set_KeyPreview(VARIANT_BOOL Value));
  STDMETHOD(set_PixelsPerInch(long Value));
  STDMETHOD(set_PrintScale(TxPrintScale Value));
  STDMETHOD(set_Scaled(VARIANT_BOOL Value));
  STDMETHOD(set_Visible(VARIANT_BOOL Value));
  STDMETHOD(Persist());
};

#endif
