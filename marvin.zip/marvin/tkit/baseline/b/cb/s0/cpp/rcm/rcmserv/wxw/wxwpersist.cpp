#ifdef __BORLANDC__
#include "rcmpch.h"
#endif

#include "wxwpersist.h"
#include "wxwdesigner.h"
#include "wxwroot.h"
#include "wxwcomponentmodel.h"

static int lastId = 100;

int GetUniqueID()
{
    return ++lastId;
}

class wxMetadataWriter
{
public:
    wxMetadataWriter(wxXmlNode *root) : FRoot(root), FNode(0) { }
    void Write(wxDynamicObject *dyno, const wxString &name);
private:
	void WriteHandler(const wxHandlerInfo *hi);
	void WriteProperty(const wxPropertyInfo *pi);
    wxXmlNode *FRoot;
	wxXmlNode *FNode;
};

class wxMetadataReader
{
public:
	wxMetadataReader(wxXmlNode *root) : FDCI(0), FRoot(root) { }
    const wxDynamicClassInfo* GetClassInfo() { return FDCI; }
	wxString Read();
private:
	void ReadProperties(wxXmlNode *node);
	void ReadHandlers(wxXmlNode *node);
	wxXmlNode* FRoot;
    wxDynamicClassInfo *FDCI;
};

// wxDesignerPerister

bool wxDesignerPersister::BeforeWriteDelegate(wxWriter *writer, const wxObject *object,
        const wxClassInfo* classInfo, const wxPropertyInfo *propInfo,
        const wxObject *&eventSink, const wxHandlerInfo *&handlerInfo)
{
    if (FManager) {
        wxwRootComponent *root = FManager->Root();
        // first, do we have the object referred to?
        wxwComponent *comp = FManager->FindComponentByInstance(object);
        if (root && comp) {
            // manager's root component is the only sink.
            eventSink = root->DynamicInstance();
            // have to look up the handler based on the supplied propInfo.
            // The root's event sink table holds a wxwEvent which can be used
            // to get the sink's name.
            wxwEventConnection *con = root->GetEventConnection(propInfo, comp);
            if (con) {
                handlerInfo = root->DynamicClassInfo()->FindHandlerInfo(con->GetSinkName());
                return true;
            }
        }
    }
    return false;
}

bool wxDesignerPersister::BeforeWriteProperty(wxWriter *writer, const wxObject *object,
    const wxPropertyInfo *propInfo, wxxVariant &value)
{
    if (FManager && propInfo->GetTypeInfo() == wxGetTypeInfo((wxPoint*)0) &&
        propInfo->GetName().compare("Position") == 0)
    {
        // Fix up top-level window coordinates
        if (TYPEOF(object, wxWindow) && dynamic_cast<const wxDynamicObject*>(object)) {
            wxPoint pt = value.Get<wxPoint>();
            pt.x -= FrameOffsetX;
            pt.y -= FrameOffsetY;
            value = wxxVariant((wxPoint)pt);
        }
    }
    return wxPersister::BeforeWriteProperty(writer, object, propInfo, value);
}


bool wxDesignerPersister::BeforeWriteObject( wxWriter *writer, const wxObject *object, const wxClassInfo *classInfo, wxxVariantArray &metadata)
{
    // If the object is a designed component, write the component name to
    // metadata, embedded in <object> tag
    if (FManager) {
        rcmComponent *designedComponent = FManager->FindComponentByInstance(object);
        if (!designedComponent) {
            // check if this is a dynamic object
            const wxDynamicObject *dyno = dynamic_cast<const wxDynamicObject*>(object);
            if (dyno) {
                designedComponent = FManager->FindComponentByInstance(dyno->GetSuperClassInstance());
            }
        }
        if (designedComponent) {
            metadata.Add(wxxVariant(wxString(designedComponent->GetName()), "name"));
        }
    }
    return wxPersister::BeforeWriteObject(writer, object, classInfo, metadata);
}

// wxMetadataWriter

void wxMetadataWriter::WriteProperty(const wxPropertyInfo *pi)
{
	// only support writing object properties
    if (pi->GetTypeInfo()->GetKind() != wxT_OBJECT_PTR)
        throw new runtime_error(wxString("Dynamic property must be an object pointer").c_str());
   	const wxClassTypeInfo *cti = dynamic_cast<const wxClassTypeInfo*>(pi->GetTypeInfo());
    if (!cti)
        throw new runtime_error(wxString::Format("\"%s\" is not a class-type property", pi->GetName()).c_str());
    wxXmlNode *propNode = new wxXmlNode(wxXML_ELEMENT_NODE, "property");
    propNode->AddProperty(wxString("type"), cti->GetTypeName());
    propNode->AddChild(new wxXmlNode(wxXML_TEXT_NODE, "value", pi->GetName()));
    FNode->AddChild(propNode);
}

void wxMetadataWriter::WriteHandler(const wxHandlerInfo *hi)
{
	wxXmlNode *eventNode = new wxXmlNode(wxXML_ELEMENT_NODE, "eventhandler");
    eventNode->AddChild(new wxXmlNode(wxXML_TEXT_NODE, "value", hi->GetName()));
    eventNode->AddProperty(wxString("eventclass"), hi->GetEventClassInfo()->GetClassName());
	FNode->AddChild(eventNode);
}

void wxMetadataWriter::Write(wxDynamicObject *dyno, const wxString &name)
{
    FNode = new wxXmlNode(wxXML_ELEMENT_NODE, "metadata");
    wxDynamicClassInfo *dci = dynamic_cast<wxDynamicClassInfo*>(dyno->GetClassInfo());
    FNode->AddProperty(wxString("classname"), dci->m_className);
    FNode->AddProperty(wxString("baseclass"), dyno->GetSuperClassInstance()->GetClassInfo()->m_className);
    FNode->AddProperty(wxString("objectname"), name);
    // TODO: wxDynamicClassInfo doesn't expose "unitname" ctor parameter anywhere
    FNode->AddProperty(wxString("unitname"), "unitname");
    const wxPropertyInfo *pi = dci->GetFirstProperty();
    while (pi) {
        WriteProperty(pi);
        pi = pi->GetNext();
    }
    const wxHandlerInfo *hi = dci->GetFirstHandler();
    while (hi) {
    	WriteHandler(hi);
        hi = hi->GetNext();
    }
	FRoot->AddChild(FNode);
}

// wxMetadataReader

void wxMetadataReader::ReadProperties(wxXmlNode *node)
{
	wxXmlNode *iter = node->GetChildren();
    while (iter) {
    	if (iter->GetName() == "property") {
        	wxString className;
            if (iter->GetPropVal("type", &className)) {
               	wxXmlNode *data = iter->GetChildren();
                if (!data)
                    throw new runtime_error("Error reading xrc");
             	wxString propName = data->GetContent();
                const wxTypeInfo *ti = wxTypeInfo::FindType(className);
                if (!ti)
                    throw new runtime_error(wxString::Format("\"%s\" is not a registered type", className).c_str());
                FDCI->AddProperty(propName, ti);
               	//TODO: handle errors
            }
        }
        iter = iter->GetNext();
    }
}

void wxMetadataReader::ReadHandlers(wxXmlNode *node)
{
	wxXmlNode *iter = node->GetChildren();
    while (iter) {
    	if (iter->GetName() == "eventhandler") {
        	wxString eventClassName;
            if (iter->GetPropVal("eventclass", &eventClassName)) {
                wxXmlNode *data = iter->GetChildren();
                if (data) {
                    wxString handlerName = data->GetContent();
                	wxClassInfo *eventClass = wxClassInfo::FindClass(eventClassName);
                    if (eventClass) {
                        FDCI->AddHandler(handlerName, 0, eventClass);
                    }
                }
                else {
                	//TODO: handle errors
                }

            }
            else {
                // TODO: handle errors
            }
        }
        iter = iter->GetNext();
    }
}

wxString wxMetadataReader::Read()
{
    wxXmlNode *iter = FRoot->GetChildren() ;
    while (iter)
    {
        if (iter->GetName() == "metadata") {
	        wxString className;
            wxString baseClassName;
            wxString unitName;
            wxString name;
    	    if (iter->GetPropVal("classname", &className) &&
            	iter->GetPropVal("baseclass", &baseClassName) &&
                iter->GetPropVal("unitname", &unitName) &&
                iter->GetPropVal("objectname", &name))
        	{
            	wxClassInfo *rootClass = wxClassInfo::FindClass(className);
                if (rootClass)
                    throw new runtime_error(wxString::Format("Class \"%s\" already exists", className).c_str());
            	wxClassInfo *baseClass = wxClassInfo::FindClass(baseClassName);
                if (!baseClass)
                    throw new runtime_error(wxString::Format("Ancestor class \"%s\" not a registered class", baseClassName).c_str());
                char *c_class = StrAlloc(c_class, className.c_str());
				FDCI = new wxDynamicClassInfo(
                    c_class,
                    c_class,
                    baseClass
                );
                //NewRootClassInfo(className, baseClass);
                ReadProperties(iter);
                ReadHandlers(iter);
                return name;
        	}
        }
        iter = iter->GetNext();
    }
    return wxT("");
}

// wxDesignerDepersister

wxwComponent* wxDesignerDepersister::CreateComponentProxy(wxObject *object, wxxVariant *VariantValues,
    const wxString &name)
{
    // Find the component info which can create a component proxy for this object.
    // Must special case a dynamic object (i.e., a top-level or root component) and use
    // it's superclass info.

    wxDynamicObject *dyno = dynamic_cast<wxDynamicObject*>(object);
    if (dyno) {
        object = dyno->GetSuperClassInstance();
    }

    // decide which designer will work on this component based off class type.
    wxwDesigner *designer = 0;
    if (TYPEOF(object, wxWindow) || TYPEOF(object, wxSizer)) {
        designer = dynamic_cast<wxwDesigner*>(FManager->UIDesigner());
    }
    // else if (TYPEOF(object, wxMenu) || (TYPEOF(object, wxMenuBar)
    //    || (TYPEOF(object, wxMenuItem)){
    //  designer = FManager->MenuDesigner();
    // }
    else {
        designer = dynamic_cast<wxwDesigner*>(FManager->DefaultDesigner());
    }

    if (designer) {
        designer->SetState(DS_READING);
    }
    // wxWindows and wxMenuItems may require containers. Lots of things
    // below make assumptions about create parameters and how XTI works with
    // a given class in detail.
    wxObject *parent = 0;
    if (dynamic_cast<wxWindow*>(object) && !dyno) {
        // wxWindows which aren't top level (i.e., the root) require parents
        // assuming: wxWindow constructor
        parent = VariantValues[0].Get<wxWindow*>();
        if (!parent)
            throw new error(wxString::Format("\"%s\" has no parent", name));
        // prevent duplicate ids for new components handled by this manager.
        wxWindow *win = (wxWindow*)object;
        if (win && win->GetId() >= lastId)
            lastId = win->GetId();
    }
    else if (dynamic_cast<wxSizer*>(object)) {
        parent = VariantValues[0].Get<wxWindow*>();
        if (!parent)
            throw new error(wxString::Format("\"%s\" has no parent", name));
    }
    else if (dynamic_cast<wxMenuItem*>(object)) {
    }

    return CreateComponent((wxwDesigner*)designer, parent, dyno ? dyno : object, name);
}


void wxDesignerDepersister::CreateObject(int objectID, const wxClassInfo *classInfo,
	int paramCount, wxxVariant *VariantValues, int *objectIDValues,
	const wxClassInfo **objectClassInfos, wxxVariantArray &metadata)
{

    // set wxFRAME_NO_TASKBAR on the main frame. Otherwise defer to the runtime depersister.
    // And, I have to "guess" at which parameter contains the flags if this is a frame.
    if (classInfo->IsKindOf(CLASSINFO(wxFrame)) && paramCount == 6 && VariantValues[5].HasData<long>()) {
        long flags = VariantValues[5].Get<long>();
        flags |= wxFRAME_NO_TASKBAR;
        VariantValues[5] = wxxVariant((long)flags);
    }

    // now create the actual object
	wxRuntimeDepersister::CreateObject(objectID, classInfo, paramCount, VariantValues,
	    objectIDValues, objectClassInfos, metadata);

    if (!FManager) return;
    // retrieve component name embedded in metadata
    wxString compName;
    for (size_t i=0; i<metadata.GetCount(); ++i)
    {
    	if (metadata[i].GetName().compare("name") == 0) {
        	compName = metadata[i].GetAsString();
        }
    }
    if (compName.IsEmpty()) {
    	// gotta have some valid name...
    	compName = wxString::Format("%s%d", classInfo->m_className, objectID);
    }

    wxObject *obj = GetObject(objectID);
	if (!obj) return;

    wxwComponent *newProxy = CreateComponentProxy(obj, VariantValues, compName);
    if (newProxy)
        newProxy->ObjectCreated(true);
}

void wxDesignerDepersister::SetConnect(int EventSourceObjectID,
    const wxClassInfo *EventSourceClassInfo,
    const wxPropertyInfo *delegateInfo,
    const wxClassInfo *EventSinkClassInfo,
    const wxHandlerInfo* handlerInfo,
    int EventSinkObjectID )
{
    wxRuntimeDepersister::SetConnect(EventSourceObjectID, EventSourceClassInfo,
        delegateInfo, EventSinkClassInfo, handlerInfo, EventSinkObjectID);
    /*
    assumptions:
        EventSinkObjectID refers to the root component only (==0)
        ComponentProxy for event source already exists.
        Root is created and DynamicClassInfo has at least an entry for event source.
    */
    if (FManager && handlerInfo)
    {
        wxwRootComponent *root = FManager->Root();
        if (!root || EventSinkObjectID != 0) return;
        wxObject *sourceObj = GetObject(EventSourceObjectID);
        // Special case for the dynamic (root) object, where the designer has to act on the superclass
        wxDynamicObject *dynObj = dynamic_cast<wxDynamicObject*>(sourceObj);
        if (dynObj) {
            sourceObj = dynObj->GetSuperClassInstance();
        }
        wxwComponent *source = FManager->FindComponentByInstance(sourceObj);
        if (source && root->HasHandler(handlerInfo->GetName())) {
            // there should be an unassigned handler as a result of depersisting metadata.
            wxwEventConnection *connection = new wxwEventConnection(handlerInfo->GetName(), delegateInfo, source);
            root->AssignHandler(connection);
        }
    }
}

void wxDesignerDepersister::SetProperty(int objectID, const wxClassInfo *classInfo,
    const wxPropertyInfo* propertyInfo, const wxxVariant &VariantValue)
{
    wxRuntimeDepersister::SetProperty(objectID, classInfo, propertyInfo, VariantValue);
}

// wxXrcReader

rcmComponent* wxXrcReader::ReadRoot()
{
    wxMetadataReader mReader(FRootNode);
    wxString rootName = mReader.Read();
    wxXmlReader Reader(FRootNode);
    wxDesignerDepersister Callbacks(FManager);
    int obj = Reader.ReadObject(rootName, &Callbacks) ;
    wxObject *object = Callbacks.GetObject( obj ) ;
    wxWindow *trueWin = dynamic_cast<wxWindow *>(object) ;
    if (!trueWin)
    {
        wxDynamicObject* dyno = dynamic_cast<wxDynamicObject*>(object) ;
        if (dyno)
            trueWin = dynamic_cast<wxWindow*>(dyno->GetSuperClassInstance()) ;
    }
    if (trueWin)
        trueWin->Show();
    return FManager->FindComponentByInstance(trueWin);
}

int wxXrcWriter::Write(wxObject *root, const wxClassInfo *classInfo,
    wxMemoryOutputStream &stream, const wxString &rootName, wxDesignerPersister &persister)
{
    // standard xrc
    wxXmlWriter writer(FRootNode);
    wxxVariantArray dummy;
    writer.WriteObject(root, classInfo, &persister, rootName, dummy);
    FXml.Save(stream);
    return stream.GetSize();
}

int wxXrcWriter::WriteRoot(wxwRootComponent &root, const wxString &rootName, wxwDesignerManager &manager,
    wxMemoryOutputStream &stream)
{
    // metadata to allow recreation of wxDynamicClassInfo before actual streaming in.
    // Don't blame me, this wasn't my idea.
    wxMetadataWriter mWriter(FRootNode);
    mWriter.Write(root.DynamicInstance(), rootName);

    wxDesignerPersister persister(dynamic_cast<wxwDesignerManager*>(&manager));
    return Write(root.DynamicInstance(), root.DynamicClassInfo(), stream, rootName, persister);
}

// wxInstancePersister

bool wxInstancePersister::BeforeWriteDelegate(wxWriter *writer, const wxObject *object,
	const wxClassInfo* classInfo, const wxPropertyInfo *propInfo,
    const wxObject *&eventSink, const wxHandlerInfo *&handlerInfo)
{
	return false;
}

// wxInstanceDepersister

void wxInstanceDepersister::CreateObject(int objectID, const wxClassInfo *classInfo,
		int paramCount, wxxVariant *VariantValues, int *objectIDValues,
		const wxClassInfo **objectClassInfos, wxxVariantArray &metadata)
{
    // make sure the object actually gets Create()-ed.
	wxRuntimeDepersister::CreateObject(objectID, classInfo, paramCount, VariantValues,
	    objectIDValues, objectClassInfos, metadata);
    // Assume objectID == 0 indicates the root component, so don't do anything with it.
    if (objectID == 0 || !FManager) return;
    // retrieve component name embedded in metadata, to find the proxy it will
    // belong to.
    wxString compName;
    for (size_t i=0; i<metadata.GetCount(); ++i)
    {
    	if (metadata[i].GetName().compare("name") == 0) {
        	compName = metadata[i].GetAsString();
        }
    }
    // root component won't exist, but that's okay. It's deleted by the creator
    // of this depersister.
    wxwComponent *compProxy = FManager->FindComponentByName(compName);
    wxObject *object = GetObject(objectID);
    if (compProxy) {
        compProxy->SetInstance(object);
        compProxy->ObjectCreated(true);
        // Fix up the root component's dynamic class info so that
        // the property value of the recreated component is valid.
        FManager->NotifyComponentRecreated((wxwDesigner*)compProxy->Designer(), compProxy);
	}
    else {
        wxwComponent *newProxy = CreateComponentProxy(object, VariantValues, compName);
        if (newProxy)
            newProxy->ObjectCreated(true);
    }
}


