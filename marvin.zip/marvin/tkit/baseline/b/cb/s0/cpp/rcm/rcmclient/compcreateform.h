//---------------------------------------------------------------------------

#ifndef compcreateformH
#define compcreateformH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
#include "soapWSComponentModelServerService.nsmap"
#include "soapstub.h"
#include "rcmclientu.h"

//---------------------------------------------------------------------------
class TCompTypeForm : public TForm
{
__published:	// IDE-managed Components
	TLabel *Label1;
	TPanel *Panel1;
	TButton *Button1;
	TButton *Button2;
	TListBox *lbTypes;
	void __fastcall lbTypesClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TCompTypeForm(TComponent* Owner);
};

extern AnsiString GetComponentType(soap *soap, list<impl__WSComponentInfo*> &compInfos);

//---------------------------------------------------------------------------
extern PACKAGE TCompTypeForm *CompTypeForm;
//---------------------------------------------------------------------------
#endif
