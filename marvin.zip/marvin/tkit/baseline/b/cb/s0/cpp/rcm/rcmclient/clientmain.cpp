//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

//---------------------------------------------------------------------------

//#include "soapWSComponentModelServerService.nsmap"
#include "soapstub.h"

#include <string>
#include <stdarg.h>
#include <stdio.h>

#pragma argsused

#define SUCCESS(x) x == SOAP_OK

const char server[] = "http://localhost:8080/";

static FILE *fh = 0;
static int indent = 0;

void output(const char *format, ...)
{
   va_list paramList;
   va_start(paramList, format);
   vprintf(format, paramList);
   vfprintf(fh, format, paramList);
   va_end(paramList);
}

void write_getComponentModelResponse(impl__getComponentModelResponse &response)
{
	impl__WSComponentModel* model = response._getComponentModelReturn;
    if (model) {
    	output("Model %s:\n", model->displayName);
        output("\tKey: %s\n", model->modelKey);
        output("\tDescription: %s\n", model->description);
        output("\tImageURL: %s\n", model->imageURL);
        output("\n");
    }
}

void write_getComponentModelsResponse(impl__getComponentModelsResponse &response)
{
	ArrayOfWSComponentModel* models = response._getComponentModelsReturn;
    if (models) {
    	output("getComponentModels:\n");
        impl__WSComponentModel* cm = models->__ptr;
        for (int i=0; i<models->__size; i++) {
        	output("%d Model(s):\n", models->__size);
            output("\t%s (key=%s)\n", cm->displayName, cm->modelKey);
            output("\n");
            cm++;
        }
    }
}

void write_fault(SOAP_ENV__Fault* fault)
{
    if (fault) {
		output("ERROR:\n");
    	output("\tReason: %s\n", fault->SOAP_ENV__Reason);
    	output("\tDetail: %s\n", fault->SOAP_ENV__Detail);
    } else {
    	output("AN UNKNOWN ERROR OCCURRED\n");
    }
}

int main(int argc, char **argv)
{
	using namespace std;
	struct soap soap;
    fh = fopen("soaplog.txt", "w+t");
	soap_init(&soap);

    TStringList *params = new TStringList;
    for (int i=1; i<ParamCount(); i++) {
    	params->Add(ParamStr(i));
    }

    for (int i=0; i<params->Count; i++) {
    	cout << params->Strings[i].c_str();
    }

    getch();
	delete params;
 /*   impl__getComponentModelsResponse modelsResponse;
    if (SUCCESS(soap_call_impl__getComponentModels(&soap, server, "", &modelsResponse)))
        write_getComponentModelsResponse(modelsResponse);
    else {
        write_fault(soap.fault);
        return 1;
    }

    char buf[1024];
	string cmdl;
    while (true) {
        fgets(buf, 1024, stdin);
    	cmdl = buf;
        if (cmdl.length() > 0 && cmdl[0] != '\n') {
	     	cmdl.find
        }
        else break;
    }
    // model <modelkey>
 /*   if (cmd == "model") {
    	if (argc < 3) {
        }
        else
        {
         	impl__getComponentModelResponse modelResponse;
            if (SUCCESS(soap_call_impl__getComponentModel(&soap, server, "", argv[2], &modelResponse)))
            	write_getComponentModelResponse(modelResponse);
            else
            	write_fault(soap.fault);
        }
    }
    else {

    }
   */
    fclose(fh);
	return 0;
}
//---------------------------------------------------------------------------


