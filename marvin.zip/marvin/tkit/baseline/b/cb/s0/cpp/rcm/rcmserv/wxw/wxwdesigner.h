#ifndef wxwdesignerH
#define wxwdesignerH

#include "wxw.h"

class wxwDesigner;

typedef hash_map<wxString, wxwDesigner*, hash<wxString&> > Designers;
typedef hash_map<wxString, wxwComponent*, hash<wxString&> > ComponentMap;

class RCMEXPORT wxwDesignerManager : public rcmDesignerManager
{
friend class wxwDesigner;
public:
	wxwDesignerManager(wxwComponentModel *model);
    virtual ~wxwDesignerManager();

	void PostEvent(DesignerEvent *event);
    void DeleteDesigners();

    wxwComponent* FindComponentByKey(const wxString &key);
   	wxwComponent* FindComponentByName(const wxString &name);
    wxwComponent* FindComponentByInstance(const wxObject *instance);

    wxwDesigner* GetDesigner(DesignerType type);
    wxwRootComponent* Root() { return FRoot; }
//    void SetRoot(wxwRootComponent *root);
	bool IsDuplicateEvent(DesignerEvent *event);
    void Modified();
	wxString NewComponentName(const wxString &baseName);

    virtual void NotifyComponentChanged(wxwDesigner *designer, wxwComponent *comp, bool post = false);
    virtual void NotifyComponentCreated(wxwDesigner *designer, wxwComponent *comp, wxwContainer *container, bool post = false);
    virtual void NotifyComponentDeleted(wxwDesigner *designer, wxwComponent *comp, bool post = false);
    virtual void NotifyComponentRecreated(wxwDesigner *designer, wxwComponent *comp);
    virtual void NotifyComponentRenamed(wxwComponent *comp, const wxString &oldName, bool post = false);
    virtual void NotifyDesignerChanged(wxwDesigner *designer, bool post = false);
    virtual void NotifyEventChanged(wxwDesigner *designer, rcmEvent *event, wxwComponent *comp, bool post = false);
    virtual void NotifyEventSinkAdded(wxwEventConnection *connection);
    virtual void NotifyEventSinkDeleted(const wxString &handlerName);
	virtual void NotifyEventSinkRenamed(const wxString &newName, const wxString &oldName);
    virtual void NotifyPropertyChanged(wxwDesigner *designer, rcmProperty *prop, wxwComponent *comp, bool post = false);

	// rcmDesignerManager methods
	virtual void ClearEventQueue();
    virtual rcmDesigner* DefaultDesigner();
    virtual Result* Depersist(wxMemoryInputStream *stream);
    virtual rcmComponent* GetComponent(const wxString &instanceKey);
    virtual void GetComponentsOfType(rcmComponentInfo *type, rcmComponents &comps);
    virtual rcmDesigner* GetDesigner(const wxString &designerKey);
	virtual DesignerEvents& GetEvents() { return FEvents; }
	virtual bool IsModified() { return FModified; }
	virtual wxString Key() { return FKey; }
    virtual rcmComponentModel* Model() { return FModel; }
    virtual int	Persist(wxMemoryOutputStream *stream, rcmComponent *root = 0);
    virtual rcmDesigner* UIDesigner();
	virtual bool ValidateRename(const wxString &newName);

protected:
    virtual void Insert(wxwComponent *comp);
    virtual void Remove(wxwComponent *comp);
    wxwDesigner* CreateDesigner(DesignerType type);
    wxwDesigner* GetOrCreateDesigner(DesignerType type);
    rcmComponentModel *FModel;
private:
	wxwRootComponent *FRoot;
    bool FModified;
    bool FReading;
    ComponentMap FComponentMap;
    Designers FDesigners;
	DesignerEvents FEvents;
    wxString FKey;
};

// DesignerManager state flags

#define DS_READING      0x0100
#define DS_WRITING      0x0200
#define DS_DESTROYING   0x0400

class RCMEXPORT wxwDesigner : public rcmDesigner, public MenuItemProvider
{
public:
	wxwDesigner(wxwDesignerManager *manager);
    virtual ~wxwDesigner();

    class wxwDesignerInfo : public rcmDesigner::Info
    {
    public:
        virtual wxwDesigner* CreateDesigner(wxwDesignerManager *manager)
        {
            return new wxwDesigner(manager);
        }
        virtual wxString DesignerKey() { return "wxwDesigner"; }
        virtual wxString DisplayName() { return "wxFramework Default Designer"; }
        virtual wxString Description() { return "Description of wxFramework Default Designer"; }
        virtual wxString DisplayIconURI() { return "wxwdesigner.gif"; }
        virtual DesignerType GetType() { return dtDefault; }
    };

    static wxwDesignerInfo* GetInfo()
    {
        static wxwDesignerInfo *info = new wxwDesignerInfo();
        return info;
    }

    virtual wxwDesignerInfo* GetDesignerInfo() { return this->GetInfo(); }

    virtual void Changed();

    wxwComponent* FindComponentByKey(const wxString &key);
   	wxwComponent* FindComponentByName(const wxString &name);
    wxwComponent* FindComponentByInstance(const wxObject *instance);

    virtual void Insert(wxwComponent *comp);
    wxString NewComponentName(const wxString &baseName);

    virtual void NotifyComponentChanged(wxwComponent *comp, bool post = false);
    virtual void NotifyComponentCreated(wxwComponent *comp, wxwContainer *container, bool post = false);
    virtual void NotifyComponentDeleted(wxwComponent *comp, bool post = false);
    virtual void NotifyComponentRecreated(wxwComponent *comp);
    virtual void NotifyComponentRenamed(wxwComponent *comp, const wxString &oldName, bool post = false);
    virtual void NotifyEventChanged(rcmEvent *event, wxwComponent *comp, bool post = false);
    virtual void NotifyEventSinkAdded(wxwEventConnection *connection);
    virtual void NotifyEventSinkDeleted(const wxString &handlerName);
	virtual void NotifyEventSinkRenamed(const wxString &newName, const wxString &oldName);
    virtual void NotifyPropertyChanged(rcmProperty *prop, wxwComponent *comp, bool post = false);

    /*
        Flags indicating the state of the designer
    */
    bool HasState(int state) { return (FStates & state) == state; }
    void ClearState(int state) { FStates &= ~state; }
    void SetState(int state) { FStates |= state; }

    virtual void Remove(wxwComponent *comp);
    wxwDesignerManager* wxManager() { return FManager; }


    virtual void UpdateMenu(MenuItems &menu, int x, int y) { }

    // rcmDesigner methods
	virtual bool CanCreate(rcmContainer *container, rcmComponentInfo *compType);
	virtual Result* DisposeComponent(const wxString &instanceKey);
    virtual bool DisposeComponent(rcmComponent *instance);
	virtual rcmComponent* GetComponent(const wxString &instanceKey);
    virtual void GetRootComponents(rcmComponents &roots);
    virtual rcmDesignerManager* Manager();
    virtual rcmComponentModel* Model() { return FManager->Model(); }
    virtual int	Persist(wxMemoryOutputStream *stream, rcmComponent *root = 0);

private:
	rcmComponents FComponents;
    wxwDesignerManager *FManager;
    int FStates;
};

class RCMEXPORT wxwUIDesigner : public wxwDesigner, public DesignRectProvider, public rcmUIDesigner
{
public:
	wxwUIDesigner(wxwDesignerManager *manager)
        : wxwDesigner(manager) { }
    virtual ~wxwUIDesigner();

    class wxwUIDesignerInfo : public wxwDesignerInfo
    {
    public:
        virtual wxwDesigner* CreateDesigner(wxwDesignerManager *manager)
        {
            return new wxwUIDesigner(manager);
        }
        virtual wxString DesignerKey() { return "wxwUIDesigner"; }
        virtual wxString DisplayName() { return "wxFramework UI Designer"; }
        virtual wxString Description() { return "Description of wxFramework UI Designer"; }
        virtual wxString DisplayIconURI() { return "wxwuidesigner.gif"; }
        virtual DesignerType GetType() { return dtUI; }
    };

    static wxwUIDesignerInfo* GetInfo()
    {
        static wxwUIDesignerInfo *info = new wxwUIDesignerInfo();
        return info;
    }

    virtual wxwDesignerInfo* GetDesignerInfo() { return wxwUIDesigner::GetInfo(); }
    void SetImageURI(const wxString &uri);

    // rcmDesigner methods
	virtual bool CanCreate(rcmContainer *container, rcmComponentInfo *compType);

    // rcmUIDesigner methods
  	virtual void ClientRect(int &x, int &y, int &w, int &h);
    virtual bool ConstrainsChildren() { return true; }
	virtual wxString GetDesignerImage(void *stream);
	virtual wxString ImageURI() { return FImageURI; }

    // DesignRectProvider overrides
    virtual void UpdateRects() { }

private:
    wxString FImageURI;
};

#endif
