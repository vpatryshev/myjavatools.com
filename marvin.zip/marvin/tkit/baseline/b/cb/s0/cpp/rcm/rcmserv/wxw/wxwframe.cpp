#ifdef __BORLANDC__
#include "rcmpch.h"
#endif

#include "wxwframe.h"
#include "wxwcomponentmodel.h"
#include "wxwgraphics.h"
#include "wxwproped.h"

IMPLEMENT_DYNAMIC_CLASS(wxFramePainter, wxWindowPainter)

#ifdef __WINDOWS__

void wxFramePainter::PaintObject(wxObject *object, wxDC &dc)
{
	wxFrame *frame = dynamic_cast<wxFrame*>(object);
    if (!frame)
    	return;
	HDC hdc = (HDC)dc.GetHDC();
    SendMessage((HWND)frame->GetHWND(), WM_PRINT, (unsigned int)hdc,
        PRF_ERASEBKGND | PRF_CLIENT | PRF_NONCLIENT);
}

#endif // __WINDOWS__


wxwFrameComponent::wxwFrameComponent(wxwDesigner *designer, wxwContainer *container)
	: wxwRootComponent(CLASSINFO(wxFrame), designer, container)
{
}

void wxwFrameComponent::ObjectCreated(bool fromXRC)
{
    if (fromXRC) {
        wxPoint pos = Frame()->GetPosition();
        SetTopLeft(pos.y, pos.x);
    }
    else {
        Frame()->SetAutoLayout(false);
        Frame()->SetSizer(0);
    }
    Frame()->Show();
}

void wxwFrameComponent::ConstructXTIObject(wxObject *object)
{
    wxDynamicObject *dyno = dynamic_cast<wxDynamicObject*>(object);
    wxFrame *realFrame = dynamic_cast<wxFrame*>(dyno->GetSuperClassInstance());
    wxxVariant params[6];
    params[0] = wxxVariant((wxWindow*)NULL);
    params[1] = wxxVariant((wxWindowID)GetUniqueID());
    params[2] = wxxVariant(wxString(GetName()));
    params[3] = wxxVariant(wxPoint(-1, -1));
    params[4] = wxxVariant(wxSize(640, 480));
    params[5] = wxxVariant((long)wxDEFAULT_FRAME_STYLE | wxFRAME_NO_TASKBAR);
    realFrame->GetClassInfo()->Create(realFrame, 6, params);
}

bool wxwFrameComponent::CanParentType(const wxClassInfo *type)
{
    return type->IsKindOf(wxClassInfo::FindClass("wxWindow"))
        || type->IsKindOf(wxClassInfo::FindClass("wxGridBagSizer"));
}

void wxwFrameComponent::GetSize(int &w, int &h)
{
    int x, y;
    GetRect(x, y, w, h);
}

void wxwFrameComponent::GetTopLeft(int &t, int &l)
{
    int w, h;
    GetRect(l, t, w, h);
}

void wxwFrameComponent::SetSize(int &w, int &h)
{
    int dummy = -1;
    SetRect(dummy, dummy, w, h);
}

void wxwFrameComponent::SetTopLeft(int &t, int &l)
{
    int dummy = -1;
    SetRect(t, l, dummy, dummy);
}

Result* wxwFrameComponent::SetZOrderPosition(rcmComponent *child, int z)
{
    return ErrorMessage("wxWindows doesn't appear to support explicit Z-ordering");
}


void wxwFrameComponent::GetRect(int &x, int &y, int &w, int &h)
{
    wxRect r = Frame()->GetRect();
    x = r.GetX() - FrameOffsetX;
    y = r.GetY() - FrameOffsetY;
    w = r.GetWidth();
    h = r.GetHeight();
}

void wxwFrameComponent::SetRect(int &x, int &y, int &w, int &h, bool testOnly)
{
    Frame()->SetSize(x + FrameOffsetX, y + FrameOffsetY, w, h, wxSIZE_USE_EXISTING);
}

void wxwFrameComponent::GetClientRect(int &x, int &y, int &w, int &h)
{
#ifdef __WINDOWS__
    wxRect r(wxPoint(0, 0), Frame()->GetSize());
    SendMessage((HWND)Frame()->GetHWND(), WM_NCCALCSIZE, false, (long)&r);
    x = r.x;
    y = r.y;
    w = r.GetWidth();
    h = r.GetHeight();
#else
    #error wxwFrameComponent::GetClientRect only implemented on windows so far.
#endif
}

wxString wxwFrameComponent::GetImageData(int x, int y, int w, int h, wxMemoryOutputStream *&stream)
{
    return "";
}

void wxwFrameComponent::Paint(wxDC &dc, int x, int y)
{
    HDC hdc = (HDC)dc.GetHDC();
    int saveIdx = SaveDC(hdc);
    MoveWindowOrg(hdc, x, y);
    int cx, cy, cw, ch;
    GetRect(cx, cy, cw, ch);
    IntersectClipRect(hdc, 0, 0, cw, ch);

    // Paint this object first
    wxPainter *painter = FindPainter(Instance()->GetClassInfo());
    if (painter)
        painter->PaintObject(Instance(), dc);

    // now paint its child components, if it can.
    wxwContainer *contnr = dynamic_cast<wxwContainer*>(this);
    if (contnr) {
        rcmComponents &list = contnr->Components();
        rcmComponents::reverse_iterator it = list.rbegin();
        GetClientRect(cx, cy, cw, ch);
        while (it != list.rend()) {
            int saveIdx2 = SaveDC(hdc);
            wxwUIComponent *child = dynamic_cast<wxwUIComponent*>(*it);
            if (child) {
                int t, l;
                child->GetTopLeft(t, l);
                child->Paint(dc, l+cx, t+cy);
            }
            it++;
            RestoreDC(hdc, saveIdx2);
        }
    }
    RestoreDC(hdc, saveIdx);
}


void wxwFrameComponent::GetImageData(int x, int y, int w, int h, ImageResponse *ir)
{
    void *bits = 0;
    int myw, myh;
    GetSize(myw, myh);
    HBITMAP hbAll = CreateDIB(myw, myh, bits);
    if (hbAll && bits) {
        HDC memDC = CreateCompatibleDC(0);
        if (memDC) {
	        wxDC dc;
            dc.SetHDC((unsigned long)memDC);

            // fill in solid background.
            wxWindow *win = Frame();
            wxBrush backBrush(win->GetBackgroundColour(), wxSOLID);
            HGDIOBJ oldObj = SelectObject(memDC, hbAll);
            dc.SetBackground(backBrush);

            Paint(dc, 0, 0);

            if (w < myw || h < myh) {
                void *partialBits = 0;
                HBITMAP hbPartial = CreateDIB(w, h, partialBits);
                if (hbPartial && partialBits) {
                    HDC partialDC = CreateCompatibleDC(0);
                    if (partialDC) {
                        HGDIOBJ oldObj2 = SelectObject(partialDC, hbPartial);
                        if (BitBlt(partialDC, 0, 0, w, h, memDC, x, y, SRCCOPY)) {
                            strncpy(ir->mimeType, mtRaw32, min(strlen(mtRaw32), sizeof(ir->mimeType)));
                            ir->scanWidth = w;
                            ir->size = w * h * sizeof(int);
                            memcpy(ir->data, partialBits, min(ir->size, MAX_DATASIZE));
                        }
                        SelectObject(partialDC, oldObj2);
                    }
                    DeleteDC(partialDC);
                }
                DeleteObject(hbPartial);
            }
            else {
                strncpy(ir->mimeType, mtRaw32, min(strlen(mtRaw32), sizeof(ir->mimeType)));
                ir->scanWidth = w;
                ir->size = min(w * h * sizeof(int), MAX_DATASIZE);
                memcpy(ir->data, bits, min(ir->size, MAX_DATASIZE));
            }
            SelectObject(memDC, oldObj);
            DeleteDC(memDC);
        }
        DeleteObject(hbAll);
    }
}

bool wxwFrameComponent::Visible()
{
    return Frame()->IsShown();
}


