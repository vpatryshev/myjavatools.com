#ifndef __IRSOCKET_VIEW_H__
#define __IRSOCKET_VIEW_H__

#include <aknview.h>
#include "IRSocket.hrh"

// Forward ref. to container class
class CIRSocketContainer;


// CIRSocketView
class CIRSocketView : public CAknView
{
  public:

    /**
     * Creates a CIRSocketView object
     */
    static CIRSocketView* NewL();

    /**
     * Creates a CIRSocketView object
     */
    static CIRSocketView* NewLC();

    /**
     * Identify of this view to the system
     */
    TUid Id() const;

    /**
     * Command Handler
     */
    void HandleCommandL(TInt aCommand);

    /**
     * Activates this View
     */
    void DoActivateL(const TVwsViewId &PrevViewId, TUid  aCustomMessageId, const TDesC8& aCustomMessage);

    /**
     * Deactivate this view
     */
    void DoDeactivate();

  private:
    CIRSocketView();
   ~CIRSocketView();

    /**
     * Performs second phase construction of this view
     */
    void ConstructL();

    /**
     * Container for this view
     */
    CIRSocketContainer* container;

    /**
     * Identifier for this view
     */
    TUid iIdentifier;
};


#endif // __IRSOCKET_VIEW_H__

