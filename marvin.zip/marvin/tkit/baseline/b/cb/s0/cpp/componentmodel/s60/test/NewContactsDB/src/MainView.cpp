////////////////////////////////////////////////////////////////////////////////
// Implementation of CMainView
////////////////////////////////////////////////////////////////////////////////


#include <aknviewappui.h>
//#include <aknconsts.h>
#include "MainView.h"
#include "MainViewContainer.h"
#include <NewContactsDB.rsg>

const TUid EDefaultViewId = { 1 };

CMainView* CMainView::NewL()
{
	CMainView* self = CMainView::NewLC();
	CleanupStack::Pop(self);
	return self;
}

CMainView* CMainView::NewLC()
{
	CMainView* self = new (ELeave) CMainView();
	CleanupStack::PushL(self);
	self->ConstructL();
	return self;
}

CMainView::CMainView()
: iUid(EDefaultViewId)
{
}

CMainView::~CMainView()
{
}

void CMainView::ConstructL()
{
	BaseConstructL(R_DEFAULT_VIEW);
}

TUid CMainView::Id() const
{
	return iUid;
}

void CMainView::DoActivateL(const TVwsViewId& /*aPrevViewId*/,
                            TUid /*aCustomMessageId*/,
                            const TDesC8& /*aCustomMessage*/)
{
	ASSERT(iContainer == NULL);
	iContainer = CMainViewContainer::NewL(ClientRect());
	iContainer->SetMopParent(this);
	AppUi()->AddToStackL(*this, iContainer); 
}

void CMainView::DoDeactivate()
{
	if (iContainer)
	{
		AppUi()->RemoveFromStack(iContainer);
		delete iContainer;
		iContainer = NULL;
	}
}

void CMainView::HandleCommandL(TInt aCommand)
{
	AppUi()->HandleCommandL(aCommand);
}
