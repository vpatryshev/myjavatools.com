//---------------------------------------------------------------------------

#ifndef messagedialogH
#define messagedialogH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "soapWSComponentModelServerService.nsmap"
#include "soapstub.h"
#include <ComCtrls.hpp>
//---------------------------------------------------------------------------
class TMessageForm : public TForm
{
__published:	// IDE-managed Components
	TListBox *ListBox1;
	TLabel *Label1;
	TLabel *Label2;
	TButton *Button1;
	TButton *Button2;
    TListView *lvMsgs;
private:	// User declarations
public:		// User declarations
	__fastcall TMessageForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TMessageForm *MessageForm;

extern impl__WSTag* ShowMessage(impl__WSResult *result);
//---------------------------------------------------------------------------
#endif
