#ifndef wxwframeH
#define wxwframeH

#include "wxw.h"
#include "wxwroot.h"
#include "wxwindow.h"

class RCMEXPORT wxFramePainter : public wxWindowPainter
{
DECLARE_DYNAMIC_CLASS(wxFramePainter)
public:
	wxFramePainter() : wxWindowPainter() { }
    virtual void PaintObject(wxObject *object, wxDC &dc);
};

class RCMEXPORT wxwFrameComponent : public wxwRootComponent, public rcmUIComponent
{
public:
	wxwFrameComponent(wxwDesigner *designer, wxwContainer *container);
    wxFrame *Frame() { return dynamic_cast<wxFrame*>(Instance()); }

    virtual void ObjectCreated(bool fromXRC);

    // rcmUIComponent
    virtual bool CanPaintChildren() { return true; }
    virtual bool CanParentType(const wxClassInfo *type);
	virtual bool ConstrainChildren() { return true; }
    virtual bool IsTopLevel() { return true; }
    virtual void GetClientRect(int &x, int &y, int &w, int &h);
  	virtual wxString GetImageData(int x, int y, int w, int h, wxMemoryOutputStream *&stream);
	virtual void GetImageData(int x, int y, int w, int h, ImageResponse *ir);
    virtual void GetRect(int &x, int &y, int &w, int &h);
    virtual void SetRect(int &x, int &y, int &w, int &h, bool testOnly = false);
    virtual void GetSize(int &w, int &h);
	virtual void SetSize(int &w, int &h);
   	virtual void GetTopLeft(int &t, int &l);
    virtual void SetTopLeft(int &t, int &l);
    virtual bool Visible();
    virtual int GetZOrderPosition() { return 0; }
	virtual Result* SetZOrderPosition(rcmComponent *child, int z);

protected:
    virtual void ConstructXTIObject(wxObject *object);
    void Paint(wxDC &dc, int x, int y);

};

#endif
