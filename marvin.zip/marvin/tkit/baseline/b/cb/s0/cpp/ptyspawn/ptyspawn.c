/*
 * Copyright Borland Software Copropration
 * (c) 2003
 *
 * spawn a process with it's standard input and output hooked up to a
 * raw pseudo-terminal.  this is useful for controlling applications
 * that don't work properly when input comes from a pipe.  this program
 * does _not_ support applications that want a proper terminal.
 *
 * usage: ptyspawn [-e] program args ...
 * -e: also dup standard error
 */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <locale.h>

#include <unistd.h>
#include <sys/poll.h>
#include <termios.h>
#include <fcntl.h>

/* detect linux with gcc or bcc */
#ifdef __linux__
    #define LINUX
#endif
/* detect solaris with sun cc or gcc */
#if defined(__SVR4) && defined(__sun)
    #define SOLARIS
#endif

#ifdef LINUX
    #define HAVE_OPENPTY
#endif

#ifdef SOLARIS
    #define NEED_OPENPTY_STREAMS
#endif

#if defined(HAVE_OPENPTY)
    #include <pty.h>
#elif defined(NEED_OPENPTY_STREAMS)
    #include <stropts.h>
    static int openpty(int *, int *, char *, struct termios *, struct winsize *);
#else
    #error unsupported platform
#endif

/*
 * these should have been defined in <unistd.h>, but if not ...
 */
#ifndef STDIN_FILENO
    #define STDIN_FILENO 0
#endif
#ifndef STDOUT_FILENO
    #define STDOUT_FILENO 1
#endif
#ifndef STDERR_FILENO
    #define STDERR_FILENO 2
#endif


struct filedescs {
    int slave;
    int master;
    int ntfy[2];
};

struct options {
    int dup_err;
};


static int ptypair(int *master, int *slave);
static void fatal_error(int fd, char const *desc);
static void event_loop(struct filedescs const *fds);
static pid_t spawn(struct options const *, struct filedescs const *,
	char **av, int ac);

int main(int argc, char **argv)
{
    struct filedescs fds;
    struct options opts = { 0 };
    int exe_arg = 1;

    /* with only one argument, no point bothering with getopt() */
    if (argc > 1 && argv[1][0] == '-' && argv[1][1] == 'e') {
	opts.dup_err = 1;
	++exe_arg;
    }

    if (exe_arg >= argc)
	return 1;

    /* set locale (for strerror()) based upon the environment */
    setlocale(LC_ALL, "");

    /* open up the ptys */
    if (ptypair(&fds.master, &fds.slave) != 0)
	fatal_error(STDERR_FILENO, "pty");

    /* create our sync pipe */
    if (pipe(fds.ntfy) != 0)
	fatal_error(STDERR_FILENO, "pipe");

    /* spawn child, this doesn't come back on failure */
    spawn(&opts, &fds, argv + exe_arg, argc - exe_arg);

    /* get to work */
    event_loop(&fds);

    /* FIXME: return a real error code of some sort */
    return 0;
}

/*
 * -----------------------------
 * --- low-level I/O helpers ---
 * -----------------------------
 */

/**
 * write a buffer to a file descriptor, continuing when interrupted (EINTR)
 */
static ssize_t writec(int fd, void const *p, ssize_t n)
{
    int nw;
    do {
	nw = write(fd, p, n);
    } while (nw == -1 && errno == EINTR);
    return nw;
}

/**
 * write a buffer to a file descriptor, continuing on both
 * interruptions and short writes.
 */
static ssize_t writen(int fd, void const *p, ssize_t n)
{
    char const *cp = p;
    int nw = 0;
    do {
	int wr = writec(fd, cp + nw, n - nw);
	if (wr <= 0) {
	    if (nw == 0)
		nw = -1;
	    break;
	}
	nw += wr;
    } while (nw < n);
    return nw;
}


/**
 * read from a file descriptor, continuing on interruptions
 */
static ssize_t readc(int fd, void *p, ssize_t n)
{
    int nr;
    do {
	nr = read(fd, p, n);
    } while (nr == -1 && errno == EINTR);
    return nr;
}

#if 0
/**
 * read from a file descriptor, continuing on interruptions and short
 * reads
 */
static ssize_t readn(int fd, void *p, ssize_t n)
{
    char *cp = p;
    int nr = 0;
    do {
	int rd = readc(fd, cp + nr, n - nr);
	if (nr <= 0) {
	    if (rd == 0)
		nr = -1;
	    break;
	}
	nr += rd;
    } while (nr < n);
    return nr;
}
#endif

/**
 * log a fatal error message, appending the error message from strerror(),
 * to a file descriptor and _exit.
 */
static void fatal_error(int fd, char const *desc)
{
    char const *err = strerror(errno);
    char buf[512];
    snprintf(buf, sizeof(buf), "%s: %s\n", desc, err);
    writen(fd, buf, strlen(buf));
    _exit(1);
}


struct fdbuf;
static void fdbuf_init(struct fdbuf *buf);
static int fdbuf_empty(struct fdbuf const *buf);
static int fdbuf_fill(int fd, struct fdbuf *buf);
static int fdbuf_send(int fd, struct fdbuf *buf);

/*
 * ---------------------------
 * --- simple io buffering ---
 * ---------------------------
 */

struct fdbuf {
    char buf[512];
    int nfill;
    int nsent;
};

static void fdbuf_init(struct fdbuf *buf)
{
    buf->nfill = buf->nsent = 0;
}

static int fdbuf_empty(struct fdbuf const *buf)
{
    return buf->nfill == buf->nsent;
}


static int fdbuf_fill(int fd, struct fdbuf *buf)
{
    int rc = buf->nsent - buf->nfill;
    if (rc == 0) {
	rc = buf->nfill = readc(fd, buf->buf, sizeof(buf->buf));
	buf->nsent = 0;
    }
    return rc;
}

static int fdbuf_send(int fd, struct fdbuf *buf)
{
    int rc = writec(fd, buf->buf + buf->nsent, buf->nfill - buf->nsent);
    if (rc > 0)
	buf->nsent += rc;
    return rc;
}


/**
 * poll for data to shovel in both directions.
 *
 * from standard input =>  to pty
 * from pty => to standard output
 */
static void event_loop(struct filedescs const *fds)
{
    enum {
	PFD_STDIN,
	PFD_STDOUT,
	PFD_PTY,
	PFD_count
    };

    enum {
	BUF_TO_PTY,
	BUF_FROM_PTY,
	BUF_count
    };

    struct pollfd pfds[PFD_count];
    struct fdbuf bufs[BUF_count];

    fdbuf_init(&bufs[BUF_TO_PTY]);
    fdbuf_init(&bufs[BUF_FROM_PTY]);

    /* poll standard input for read */
    pfds[PFD_STDIN].fd = STDIN_FILENO;
    pfds[PFD_STDIN].events = POLLIN;
    pfds[PFD_STDIN].revents = 0;

    /* we'll poll standard output for write ... later */
    pfds[PFD_STDOUT].fd = STDOUT_FILENO;
    pfds[PFD_STDOUT].events = 0;
    pfds[PFD_STDOUT].revents = 0;

    /* poll the pty for read */
    pfds[PFD_PTY].fd = fds->master;
    pfds[PFD_PTY].events = POLLIN;
    pfds[PFD_PTY].revents = 0;

    while (poll(pfds, sizeof(pfds)/sizeof(pfds[0]), -1) != 0) {
	/* if any fd reports errors, we bail now. this might be wrong */
	if ((pfds[0].revents | pfds[1].revents | pfds[2].revents) & (POLLERR|POLLHUP))
	    break;

	/* check each descriptor and process accordingly ... */

	if (pfds[PFD_STDIN].revents & POLLIN) {
	    if (fdbuf_fill(pfds[PFD_STDIN].fd, &bufs[BUF_TO_PTY]) <= 0)
		break;
	}

	if (pfds[PFD_STDOUT].revents & POLLOUT) {
	    if (fdbuf_send(pfds[PFD_STDOUT].fd, &bufs[BUF_FROM_PTY]) <= 0)
		break;
	}

	if (pfds[PFD_PTY].revents & POLLIN) {
	    if (fdbuf_fill(pfds[PFD_PTY].fd, &bufs[BUF_FROM_PTY]) <= 0)
		break;
	}

	if (pfds[PFD_PTY].revents & POLLOUT) {
	    if (fdbuf_send(pfds[PFD_PTY].fd, &bufs[BUF_TO_PTY]) <= 0)
		break;
	}

	/*
	 * decide what we want to poll for on the next go-around.  for
	 * each direction, we want to poll for input if there is no data
	 * to transfer.  otherwise, we want to wait for the destination
	 * to be ready to receive the data.
	 */

	/* standard input => pty */
	if (fdbuf_empty(&bufs[BUF_TO_PTY])) {
	    pfds[PFD_STDIN].events = POLLIN;
	    pfds[PFD_PTY].events &= ~POLLOUT;
	}
	else {
	    pfds[PFD_STDIN].events = 0;
	    pfds[PFD_PTY].events |= POLLOUT;
	}

	/* pty => standard output */
	if (fdbuf_empty(&bufs[BUF_FROM_PTY])) {
	    pfds[PFD_PTY].events |= POLLIN;
	    pfds[PFD_STDOUT].events = 0;
	}
	else {
	    pfds[PFD_PTY].events &= ~POLLIN;
	    pfds[PFD_STDOUT].events = POLLOUT;
	}
    }
    close(fds->master);
}

/*
 * ------------------------
 * --- process spawning ---
 * ------------------------
 */

/**
 * spawn handling, child process
 */
static void spawn_child(struct options const *opts,
	struct filedescs const *fds, char const *exe, char ** const args)
{
    /* disconnect from our controlling terminal */
    setsid();

    /* close unneeded file descriptors */
    close(fds->master);
    close(fds->ntfy[0]);

    /* dup stdin/stdout onto the pty */
    if (dup2(fds->slave, STDIN_FILENO) == -1)
	fatal_error(fds->ntfy[1], "dup2 0");
    if (dup2(fds->slave, STDOUT_FILENO) == -1)
	fatal_error(fds->ntfy[1], "dup2 1");
    if (opts->dup_err)
	if (dup2(fds->slave, STDERR_FILENO) == -1)
	    fatal_error(fds->ntfy[1], "dup2 2");

    /*
     * set close-on-exec for the notify pipe so that the 
     * our parent will know we've exec'd (read will return 0)
     */
    fcntl(fds->ntfy[1], F_SETFD, 1);


    /* exec the child */
    execvp(exe, args);

    /* oops: shouldn't get here */
    fatal_error(fds->ntfy[1], "exec");
}

/**
 * spawn handling, parent process
 */
static void spawn_parent(struct filedescs const *fds)
{
    char buf[512];
    ssize_t n;

    /* close unneeded file descriptors */
    close(fds->slave);
    close(fds->ntfy[1]);

    /* wait for the child to exec */
    n = readc(fds->ntfy[0], buf, sizeof(buf));
    if (n > 0) {
	/* exec failed, this is the error message */
	writen(2, buf, n);
	_exit(1);
    }
    else if (n == -1) {
	/* unexepcted error! */
	fatal_error(STDERR_FILENO, "read");
    }
    close(fds->ntfy[0]);
}

/**
 * spawn a child hooked up to the slave end of a pty
 */
static pid_t spawn(struct options const *opts,
	struct filedescs const *fds, char **av, int ac)
{
    pid_t pid = fork();
    switch (pid) {
	case -1:    /* --- fork failed --- */
	    fatal_error(STDERR_FILENO, "fork");
	    break;

	case 0:	    /* --- child --- */
	    spawn_child(opts, fds, av[0], av);
	    break;

	default:    /* -- parent --- */
	    spawn_parent(fds);
	    break;
    }
    return pid;
}

/*
 * -------------------------
 * --- pty/event support ---
 * -------------------------
 */

/**
 * open up both ends of a pseudo-terminal with the slave set to raw
 * mode.
 */
static int ptypair(int *master, int *slave)
{
#if 0
    struct termios termp;
    /* setup terminal attributes for "raw" mode, starting with "ours" */
    if (tcgetattr(STDIN_FILENO, &termp) == -1)
	fatal_error(STDERR_FILENO, "tcgetattr");

    termp.c_iflag &= ~(IGNBRK|BRKINT|PARMRK|ISTRIP|INLCR|IGNCR|ICRNL|IXON);
    termp.c_oflag &= ~OPOST;
    termp.c_lflag &= ~(ECHO|ECHONL|ICANON|ISIG|IEXTEN);
    termp.c_cflag &= ~(CSIZE|PARENB);
    termp.c_cflag |= CS8;
    /*termp.c_cc[VTIME] = 0;
    termp.c_cc[VMIN] = 0;*/
    return openpty(master, slave, NULL, &termp, NULL);
#else
    int rc = openpty(master, slave, NULL, NULL, NULL);
    if (rc >= 0) {
	struct termios termp;
	if (tcgetattr(*slave, &termp) == -1)
	    fatal_error(STDERR_FILENO, "tcgetattr");
	termp.c_iflag &= ~(IGNBRK|BRKINT|PARMRK|ISTRIP|INLCR|IGNCR|ICRNL|IXON);
	termp.c_oflag &= ~OPOST;
	termp.c_lflag &= ~(ECHO|ECHONL|ICANON|ISIG|IEXTEN);
	termp.c_cflag &= ~(CSIZE|PARENB);
	termp.c_cflag |= CS8;
	/*termp.c_cc[VTIME] = 0;
	termp.c_cc[VMIN] = 0;*/
	if (tcsetattr(*slave, TCSAFLUSH, &termp) == -1)
	    fatal_error(STDERR_FILENO, "tcsetattr");
    }
    return rc;
#endif
}



#ifdef NEED_OPENPTY_STREAMS
/*
 * this is an implmentation of openpty for a system that has /dev/ptmx
 * and STREAMS.  this at least includes solaris and sco openserver,
 * and probably any other SVR4 variant.  a bsd-ish system should have
 * openpty already.
 */

static int openpty(int *master, int *slave, char *name,
	struct termios *termp, struct winsize *winp)
{
    int mfd = -1;
    int sfd = -1;
    char *pname;

    /* open the master pty */
    mfd = open("/dev/ptmx", O_RDWR|O_NOCTTY, 0);
    if (mfd == -1)
	goto Error;

    if (grantpt(mfd) == -1)
	goto Error;

    if (unlockpt(mfd) == -1)
	goto Error;

    /* get the name of the slave pty */
    pname = ptsname(mfd);
    if (!pname)
	goto Error;

    /* open the slave pty */
    sfd = open(pname, O_RDWR|O_NOCTTY, 0);
    if (sfd == -1)
	goto Error;

    if (ioctl(sfd, I_PUSH, "ptem") < 0)
	goto Error;

    if (ioctl(sfd, I_PUSH, "ldterm") < 0)
	goto Error;

    /* apply terminal opts, ignore errors */
    if (termp)
	tcsetattr(sfd, TCSAFLUSH, termp);

    /* apply winsize, ignore errors */
    if (winp)
	ioctl(sfd, TIOCSWINSZ, winp);

    if (name) {
	/* eek! */
	strcpy(name, pname);
    }

    *master = mfd;
    *slave = sfd;
    return 0;

Error:
    /* error cleanup, being careful to preserve errno for posterity */
    if (mfd != -1) {
	int err = errno;
	close(mfd);
	if (sfd != -1)
	    close(sfd);
	errno = err;
    }
    return -1;
}

#endif /* NEED_OPENPTY_STREAMS */
