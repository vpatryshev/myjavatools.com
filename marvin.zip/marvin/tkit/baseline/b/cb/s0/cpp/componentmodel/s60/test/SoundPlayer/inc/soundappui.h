#ifndef __SOUNDAPPUI_H__
#define __SOUNDAPPUI_H__

#include <eikappui.h>
#include <aknappui.h>
#include <eikmenub.h> 
#include <e32base.h>
#include "Soundplayer.h"

class MAudioAdapter;
class CToneAdapter;
class CPlayerAdapter;
class CRecorderAdapter;
class CSoundDocument;
class CSoundView;

/*! 
  class CSoundAppUi
  
  An instance of class CSoundAppUi is the UserInterface part of the AVKON
  application framework for the Sound example application
*/

class CSoundAppUi : public CAknAppUi 
    {
public:
/*!
   ~CSoundAppUi
  
  Destroy the object and release all memory objects
*/

    ~CSoundAppUi();

/*!
  CSoundAppUi
  
  Perform the first phase of two phase construction.
  This needs to be public due to the way the framework constructs the AppUi 
*/

    CSoundAppUi();

/*!
  ConstructL
  
  Perform the second phase construction of a CSoundAppUi object
  this needs to be public due to the way the framework constructs the AppUi 
*/

    void ConstructL();

public: // from CAknAppUi
/*!
  HandleCommandL
  
  Handle user menu selections
  Param - aCommand the enumerated code for the option selected
*/

    void HandleCommandL(TInt aCommand);

private:

    
/** The view. */
    CSoundView* iAppView;
    };

#endif // __SOUNDAPPUI_H__
