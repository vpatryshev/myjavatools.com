#ifndef wxwcomponentinfoH
#define wxwcomponentinfoH

#include "wxw.h"

class RCMEXPORT wxwComponentInfo : public rcmComponentInfo
{
public:
	wxwComponentInfo(const wxClassInfo *classInfo, const wxString &desc = wxT(""));

    wxString GetClassName() { return FClassInfo->GetClassName(); } 
    void SetDefaultEvent(const wxString &eventName);
    void SetDescription(const wxString &value) { FDesc = value; }
    void SetPalettePage(rcmPalettePage *page);

    // rcmComponentInfo methods
   	virtual const wxClassInfo* ClassInfo() { return FClassInfo; }
    virtual wxString DefaultEventKey();
	virtual wxString DefaultMethodKey() { return ""; } // what the heck is a "default" method?
    virtual wxString DefaultPropertyKey() { return ""; } // "default" property? How useless.
    virtual wxString Description() { return FDesc; }
    virtual wxString Filename();
	virtual rcmEvent* GetEvent(wxArrayString &path, rcmComponent *component = 0);
	virtual void GetEvents(rcmEvents &events, rcmComponent *component = 0);
	virtual rcmMethod* GetMethod(wxArrayString &path, rcmComponent *component = 0);
	virtual void GetMethods(rcmMethods &methods, rcmComponent *component = 0);
    virtual wxString Name() { return FName; }
    virtual void GetProperties(rcmProperties &props, rcmComponent *component = 0);
    virtual rcmProperty* GetProperty(wxArrayString &path, rcmComponent *component = 0);
    virtual wxString IconURI();
	virtual wxString Key() { return FKey; }
    virtual wxString PaletteIconURI();
    virtual rcmPalettePage*	PalettePage() { return FPage; }

protected:
    void InternalGetProperties(rcmProperties &props, const wxClassInfo *classInfo,
    	wxwComponent *component = 0);
	void InternalGetEvents(rcmEvents &events, const wxClassInfo *classInfo,
    	wxwComponent *component = 0);
	const wxClassInfo *FClassInfo;
private:
    const wxPropertyInfo* GetFirstEvent(const wxClassInfo *classInfo);
    wxString FDefaultEventName;
    wxString FDesc;
	wxString FName;
    wxString FKey;
    rcmPalettePage *FPage;
    const wxPropertyInfo *FDefaultEvent;
};

template <typename proxy_type>
class RCMEXPORT wxwComponentInfoT : public wxwComponentInfo
{
public:
    wxwComponentInfoT(const wxClassInfo *classInfo, const wxString &desc)
        : wxwComponentInfo(classInfo, desc) { }

protected:
    virtual wxwComponent* CreateProxy(
        wxwDesigner *designer,
        wxwContainer *container,
        wxMemoryInputStream *stream = 0)
    {
        return new proxy_type(this, designer, container);
    }
};

#endif

