////////////////////////////////////////////////////////////////////////////////
// Implementation of CtcptestContainer
////////////////////////////////////////////////////////////////////////////////

#include <aknutils.h>
#include <eiklabel.h>
#include <tcptest.rsg>
#include <barsread.h>
#include <eikappui.h>
#include <eikedwin.h>
#include <txtglobl.h>
#include <coeinput.h>
#include <aknlists.h>
#include <akniconarray.h>
#include <eikclbd.h>
#include <akntitle.h>
#include <aknslider.h>
#include <eikspane.h>
#include <aknnavilabel.h>
#include <eikmfne.h>
#include <aknnumseced.h>
#include <aknipfed.h>
#include <in_sock.h>
#include <eikprogi.h>
#include <AknNumEdwin.h>
#include <eikfpne.h>
#include <aknnumed.h>
#include <aknnotewrappers.h>

#include "tcptest.hrh"
#include "tcptest.rsg"

#include "tcptestcontainer.h"

//_LIT(KServerName, "10.143.11.69");
_LIT(KServerName, "www.borland.com");

_LIT(KAlreadyConnected, "Already connected");
_LIT(KNotConnected, "Not connected");

_LIT16(KConnected, "Connected\f");
_LIT16(KConnecting, "Connecting...\f");
_LIT(KDisconnected, "Disconnected\f");
_LIT(KDisconnecting, "Disconnecting...\f");
_LIT(KConnectError, "Connect Error\f");
_LIT(KLookingUp, "Looking up host...\f");
_LIT(KLookupError, "Lookup failed\f");
_LIT(KTimeout, "Timed out\f");
_LIT(KBadState, "Unknown state!\f");

_LIT(KReceived, "Recv: ");
_LIT(KSent, "Sent: ");
_LIT(Kcrlf, "\f");

#define BUFSIZE 512

CtcptestContainer* CtcptestContainer::NewL(const TRect& aRect)
{
    CtcptestContainer* self = CtcptestContainer::NewLC(aRect);
    CleanupStack::Pop(self);
    return self;
}

CtcptestContainer* CtcptestContainer::NewLC(const TRect& aRect)
{
    CtcptestContainer* self = new (ELeave) CtcptestContainer;
    CleanupStack::PushL(self);
    self->ConstructL(aRect);
    return self;
}

CtcptestContainer::~CtcptestContainer()
{
    CleanupComponents();
    iCtrlArray.Reset();
}


void CtcptestContainer::InitComponents()
{
    /* 1/26/04 10:59 AM */
    {
        TResourceReader reader;
        iCoeEnv->CreateResourceReaderLC(reader, R_EDWIN_LAYOUT);
        cEikEdwin1 = new (ELeave) CEikEdwin;
        cEikEdwin1->SetContainerWindowL(*this);
        cEikEdwin1->ConstructFromResourceL(reader);
        CleanupStack::PopAndDestroy();	//reader
        iCtrlArray.Append(cEikEdwin1);
    }
    cEikEdwin1->SetDimmed(EFalse);
    cEikEdwin1->SetFocus(ETrue);
    {
        TMargins8 tempMargins;
        tempMargins.iLeft = 0;
        tempMargins.iRight = 0;
        tempMargins.iTop = 0;
        tempMargins.iBottom = 0;

        cEikEdwin1->SetBorderViewMargins(tempMargins);
    }
    cEikEdwin1->SetRightWrapGutter(0);
    cEikEdwin1->SetExtent(TPoint(5, 7), TSize(167, 156));
    cEikEdwin1->AddFlagToUserFlags(CEikEdwin::EZeroEnumValue);
    {
        TCharFormat format;
        Mem::FillZ(&format, sizeof(TCharFormat));
        TCharFormatMask mask;
        Mem::FillZ(&mask, sizeof(TCharFormatMask));
        format.iFontSpec.iTypeface = LatinPlain12()->FontSpecInTwips().iTypeface;
        mask.SetAttrib(EAttFontTypeface);
        format.iFontPresentation.iTextColor = iEikonEnv->Color(EColorLabelText);
        mask.SetAttrib(EAttColor);
        format.iFontPresentation.iStrikethrough = (TFontStrikethrough)EFalse;
        mask.SetAttrib(EAttFontStrikethrough);
        format.iFontPresentation.iUnderline = (TFontUnderline)EFalse;
        mask.SetAttrib(EAttFontUnderline);
        CCharFormatLayer * layer = CCharFormatLayer::NewL(format, mask);
        cEikEdwin1->SetCharFormatLayer(layer);
    }
    cEikEdwin1->SetTextLimit(0);
    cEikEdwin1->SetTextL(&_L(""));
    cEikEdwin1->SetWordWrapL(ETrue);
    cEikEdwin1->SetBackgroundColorL(iEikonEnv->Color(EColorWindowBackground));
    cEikEdwin1->SetReadOnly(EFalse);
    cEikEdwin1->SetAllowUndo(EFalse);
    cEikEdwin1->SetOnlyASCIIChars(EFalse);
    {
        TNonPrintingCharVisibility tempNonPrintingCharVisibility;
        tempNonPrintingCharVisibility.SetTabsVisible(EFalse);
        tempNonPrintingCharVisibility.SetSpacesVisible(EFalse);
        tempNonPrintingCharVisibility.SetParagraphDelimitersVisible(EFalse);
        tempNonPrintingCharVisibility.SetLineBreaksVisible(EFalse);
        tempNonPrintingCharVisibility.SetPotentialHyphensVisible(EFalse);
        tempNonPrintingCharVisibility.SetNonBreakingHyphensVisible(EFalse);
        tempNonPrintingCharVisibility.SetNonBreakingSpacesVisible(EFalse);
        tempNonPrintingCharVisibility.SetPageBreaksVisible(EFalse);
        cEikEdwin1->SetNonPrintingCharsVisibility(tempNonPrintingCharVisibility);
    }
    cTCPClientSocket1 = CTCPClientSocket::NewL(4096, 4096, EPriorityHigh);
    cTCPClientSocket1->SetReadTimeout(10000000);
    cTCPClientSocket1->SetWriteTimeout(10000000);
    cTCPClientSocket1->SetTimeout(60000000);
    cTCPClientSocket1->SetPort(8090);
    cTCPClientSocket1->SetServerName(_L("10.143.11.69"));
}

void CtcptestContainer::CleanupComponents()
{
    /* 1/26/04 10:59 AM */
    delete cEikEdwin1;
    delete cTCPClientSocket1;
}

void CtcptestContainer::ConstructL(const TRect& aRect)
{
    CreateWindowL();
    SetRect(aRect);
    InitComponents();
    ActivateL();
    cTCPClientSocket1->SetOnStateChange(TEventT<CtcptestContainer, TInt>(this, &CtcptestContainer::SocketStateChange));
    cTCPClientSocket1->SetOnConnect(TEventT<CtcptestContainer>(this, &CtcptestContainer::SocketConnected));
    cTCPClientSocket1->SetOnRecvComplete(TEventT<CtcptestContainer, TInt, const TDesC8&>(this, &CtcptestContainer::SocketRecvComplete));
    cTCPClientSocket1->SetOnWriteComplete(TEventT<CtcptestContainer, TInt>(this, &CtcptestContainer::SocketWriteComplete));
    cTCPClientSocket1->SetOnNameLookup(TEventT<CtcptestContainer, TNameRecord&>(this, &CtcptestContainer::SocketNameLookup));
}


void CtcptestContainer::Draw(const TRect& aRect) const
{
    CWindowGc& gc = SystemGc();
    gc.SetPenStyle(CGraphicsContext::ENullPen);
    gc.SetBrushColor(iBackgroundColor);
    gc.SetBrushStyle(CGraphicsContext::ESolidBrush);
    gc.DrawRect(aRect);
}

TInt CtcptestContainer::CountComponentControls() const
{
    return iCtrlArray.Count();
}

CCoeControl* CtcptestContainer::ComponentControl(TInt aIndex) const
{
    return (CCoeControl*) iCtrlArray[aIndex];
}

TKeyResponse CtcptestContainer::OfferKeyEventL(const TKeyEvent& aKeyEvent, TEventCode aType)
{
    /** ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
     place code here to act on the users key event, or pass this to a child control to be handled internally by that control.

    For example: return myControl->OfferKeyEventL(aKeyEvent, aType);
    fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff */
    return EKeyWasNotConsumed; // or EKeyWasConsumed if handled in this function
}

void InfoNote(const TDesC &note)
{
    CAknInformationNote *dlg = new (ELeave) CAknInformationNote;
    dlg->ExecuteLD(note);
}

void CtcptestContainer::SocketConnected(CBase *sender)
{
    _LIT8(KHello, "Hello\n");
    sendBuf.Copy(KHello);
    cTCPClientSocket1->WriteL(sendBuf);
    cTCPClientSocket1->RecvOneOrMore();
}

void CtcptestContainer::SocketNameLookup(CBase *sender, TNameRecord &nameRecord)
{
    _LIT(KNameLookup, "Found: ");
    dispBuf.Append(KNameLookup);
    TBuf16<20> ip;
    TInetAddr::Cast(nameRecord.iAddr).Output(ip);
    dispBuf.Append(nameRecord.iName);
    dispBuf.Append(_L("="));
    dispBuf.Append(ip);
    dispBuf.Append(Kcrlf);
    cEikEdwin1->SetTextL(&dispBuf);
}

void CtcptestContainer::SocketStateChange(CBase *sender, TInt state)
{
    if (sender != cTCPClientSocket1) return;
    const TDesC *text = &KBadState;
    switch (state) {
        case CTCPClientSocket::ENotConnected:
            text = &KNotConnected;
            break;
        case CTCPClientSocket::EDisconnected:
            text = &KDisconnected;
            break;
        case CTCPClientSocket::EDisconnecting:
            text = &KDisconnecting;
            break;
        case CTCPClientSocket::EConnected:
            text = &KConnected;
            break;
        case CTCPClientSocket::EConnecting:
            text = &KConnecting;
            break;
        case CTCPClientSocket::EConnectError:
            text = &KConnectError;
            break;
        case CTCPClientSocket::ELookingUp:
            text = &KLookingUp;
            break;
        case CTCPClientSocket::ELookupError:
            text = &KLookupError;
            break;
        case CTCPClientSocket::ETimeout:
            text = &KTimeout;
            break;
        default:
            break;
    }
    dispBuf.Append(*text);
    cEikEdwin1->SetTextL(&dispBuf);
}

void CtcptestContainer::SocketRecvComplete(CBase *sender, TInt state, const TDesC8 &data)
{
    if (sender != cTCPClientSocket1) return;
    dispBuf.Append(KReceived);
    TBuf16<BUFSIZE> tmp;
    tmp.Copy(data);
    dispBuf.Append(tmp);
    dispBuf.Append(Kcrlf);
    cEikEdwin1->SetTextL(&dispBuf);
}

void CtcptestContainer::SocketWriteComplete(CBase *sender, TInt state)
{
    if (sender != cTCPClientSocket1) return;
    dispBuf.Append(KSent);
    TBuf16<BUFSIZE> tmp;
    tmp.Copy(sendBuf);
    dispBuf.Append(tmp);
    dispBuf.Append(Kcrlf);
    cEikEdwin1->SetTextL(&dispBuf);
}

void CtcptestContainer::HandleCommandL(TInt aCommand)
{
    switch (aCommand) {
        case EConnectCmd:
            if (cTCPClientSocket1->State() == CTCPClientSocket::EConnected) {
                InfoNote(KAlreadyConnected);
            }
            else {
                cTCPClientSocket1->ConnectL();
            }
            break;
        case EDisconnectCmd:
            if (cTCPClientSocket1->State() == CTCPClientSocket::EConnected) {
                cTCPClientSocket1->Disconnect();
            }
            else {
                InfoNote(KNotConnected);
            }

    }

}

// explicit instatiation for compile checking
template class CClientSocketT<CActive> CFoo(20, 20, 0);
template class CSocketReaderT<CClientSocketT<CActive> > CBar(0, 0);
template class CSocketWriterT<CClientSocketT<CActive> > CBar2(0, 0);

