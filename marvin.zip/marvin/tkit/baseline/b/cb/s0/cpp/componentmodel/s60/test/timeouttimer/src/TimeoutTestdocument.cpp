////////////////////////////////////////////////////////////////////////////////
// Implementation of CTimeoutTestDocument
////////////////////////////////////////////////////////////////////////////////

#include "TimeoutTestappui.h"
#include "TimeoutTestdocument.h"


CTimeoutTestDocument::CTimeoutTestDocument(CEikApplication& aApp)
                       :CAknDocument(aApp)
{
}

CTimeoutTestDocument::~CTimeoutTestDocument()
{
}

CTimeoutTestDocument* CTimeoutTestDocument::NewL(CEikApplication& aApp)
{
  CTimeoutTestDocument* self = NewLC(aApp);
  CleanupStack::Pop(self);
  return self;
}

CTimeoutTestDocument* CTimeoutTestDocument::NewLC(CEikApplication& aApp)
{
  CTimeoutTestDocument* self = new (ELeave) CTimeoutTestDocument(aApp);
  CleanupStack::PushL(self);
  self->ConstructL();
  return self;
}

void CTimeoutTestDocument::ConstructL()
{
}

CEikAppUi* CTimeoutTestDocument::CreateAppUiL()
{
  return new(ELeave) CTimeoutTestAppUi;
}

