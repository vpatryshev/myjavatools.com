#ifndef __TIMEOUTTEST_APPUI_H__
#define __TIMEOUTTEST_APPUI_H__

#include <aknViewAppUi.h>
#include "TimeoutTest.h"

class CTimeoutTestView;


// CTimeoutTestAppUi
class CTimeoutTestAppUi : public CAknViewAppUi
{
  /**
   * Performs view construction
   */
  void InitViewsL();

public:
  /**
   * Performs second phase construction of this AppUi Object
   */
  void ConstructL();

  /**
   * Handles user menu selection
   */
  void HandleCommandL(TInt aCommand);

private:
  CTimeoutTestView * iTimeoutTestView;
};


#endif // __TIMEOUTTEST_APPUI_H__

