#ifdef __BORLANDC__
#include "rcmpch.h"
#endif

#include "wxwindow.h"
#include "wxwcontainer.h"
#include "wxwuicontainer.h"
#include "wxwdesigner.h"
#include "wxwpersist.h"
#include "wxwgraphics.h"

// wxWindowComponent

wxWindowComponent::wxWindowComponent(const wxClassInfo *classInfo, wxwDesigner *designer,
    wxwContainer *container) : wxwUIComponent(classInfo, designer, container)
{
    wxASSERT_MSG(classInfo->IsKindOf(CLASSINFO(wxWindow)),
        wxString::Format("Trying to create a wxWindowComponent around a %s",
            classInfo->GetClassName()));
}

void wxWindowComponent::GetClientRect(int &x, int &y, int &w, int &h)
{
    const wxPoint pt = Window()->GetClientAreaOrigin();
    const wxSize sz = Window()->GetClientSize();
    x = pt.x;
    y = pt.y;
    w = sz.x;
    h = sz.y;
}

void wxWindowComponent::Paint(wxDC &dc, int x, int y)
{
    wxBrush backBrush(Window()->GetBackgroundColour(), wxSOLID);
    dc.SetBackground(backBrush);

    wxwUIComponent::Paint(dc, x, y);

    // fill in solid background.

    wxwContainer *contnr = dynamic_cast<wxwContainer*>(this);
    if (contnr && CanPaintChildren()) {

        HDC hdc = (HDC)dc.GetHDC();
        int saveIdx = SaveDC(hdc);
        MoveWindowOrg(hdc, x, y);
        int cx, cy, cw, ch;
        DoGetRect(cx, cy, cw, ch);
        IntersectClipRect(hdc, 0, 0, cw, ch);

       // Paint child windows which are not subcomponents (to handle aggregate controls)
        wxWindow *w = Window();
        wxList &children = w->GetChildren();
        if (contnr && children.size() > 0) {
            wxRect r(wxPoint(0, 0), w->GetSize());
            SendMessage((HWND)w->GetHWND(), WM_NCCALCSIZE, false, (long)&r);
            unsigned int clientX, clientY = 0;
            clientX = r.x;
            clientY = r.y;
            for (unsigned int i=0; i<children.size(); i++) {
                wxWindow *childWin = dynamic_cast<wxWindow*>(children[i]);
                if (childWin) {
                    bool paintThisChild = true;
                    // check to see if this child window is a sub-component
                    // if it isn't, it's part of an aggregate and must
                    // be painted explicitly.
                    rcmComponents &list = contnr->Components();
                    rcmComponents::iterator it = list.begin();
                    while (it != list.end() && paintThisChild) {
                        paintThisChild &= ((*it)->Instance() != childWin) && (childWin->GetContainingSizer() == 0);
                        it++;
                    }
                    if (paintThisChild) {
                        int childX = 0;
                        int childY = 0;
                        childWin->GetPosition(&childX, &childY);
                        childX += clientX;
                        childY += clientY;
                        int saveIdx = SaveDC(hdc);
                        MoveWindowOrg(hdc, childX, childY);
                        wxPainter *childPainter = FindPainter(childWin->GetClassInfo());
                        if (childPainter) {
                            childPainter->PaintObject(childWin, dc);
                        }
                        RestoreDC(hdc, saveIdx);
                    }
                }
            }
        }
        RestoreDC(hdc, saveIdx);
    }
}

void wxWindowComponent::DoGetRect(int &x, int &y, int &w, int &h)
{
	wxSizer *sizer = Window()->GetContainingSizer();
    if (sizer) {

    }
    wxRect r = Window()->GetRect();
    x = r.GetX();
    y = r.GetY();
    w = r.GetWidth();
    h = r.GetHeight();
}

bool wxWindowComponent::IsTopLevel()
{
    return Window()->GetParent() == NULL;
}

void wxWindowComponent::Recreate()
{
    // Don't recreate the top-level form. You'll die.
    if (!Container())
        return;
    wxwDesignerManager *manager = dynamic_cast<wxwDesignerManager*>(Designer()->Manager());

    SetState(CS_RECREATING);

    // Create a temporary parent for the streaming system, so the recreated
    // wxWindow's parent property isn't streamed in detail, but as a reference.
    wxFrame *tmpParent = new wxFrame(0, GetUniqueID(), "", wxPoint(FrameOffsetX, FrameOffsetY),
        wxSize(1,1), wxDEFAULT_FRAME_STYLE | wxFRAME_NO_TASKBAR);
    wxFrame *newParent = 0;

    // prune the recreated control from it's parent and set to the temp.
    Window()->Reparent(tmpParent);
    wxMemoryOutputStream ostream;
    wxXrcWriter writer(manager);
    // Write with the temp parent as the root.
    wxInstancePersister persister(manager);
    SetState(CS_WRITING);
    writer.Write(tmpParent, tmpParent->GetClassInfo(), ostream, wxString("tmpParent"), persister);
    ClearState(CS_WRITING);
    // I have no idea how to do this efficiently in wxWindows...transfer data from an output to input stream.
    void *data = malloc(ostream.GetSize());
    ostream.SeekO(0);
    ostream.CopyTo(data, ostream.GetSize());
    wxMemoryInputStream istream(data, ostream.GetSize());

    wxwContainer *container = dynamic_cast<wxwContainer*>(this);
    if (container) {
        container->DeleteChildren();
    }

    SetInstance(0);

    if (istream.GetSize() > 0) {
        wxXmlDocument xml;
        xml.Load(istream);
        wxXmlNode *xmlRoot = xml.GetRoot();
        wxXmlReader Reader(xmlRoot);
        wxDesigner()->SetState(DS_READING);

        wxInstanceDepersister Callbacks(dynamic_cast<wxwDesignerManager*>(Designer()->Manager()));
        int obj = Reader.ReadObject(wxString("tmpParent"), &Callbacks);

        newParent = dynamic_cast<wxFrame*>(Callbacks.GetObject(obj));
        // get the new parent of the recreated component returned by the depersister.
        // assume 1 and only child of newParent is the wxWindow we recreated.
        wxASSERT_MSG(newParent->GetChildren().size() == 1, "failed recreate");
        wxWindow *newWindow = dynamic_cast<wxWindow*>(newParent->GetChildren()[0]);
        // The component proxy still is valid, and has the new instance, now
        // just reparent the new instance to the old instance's parent.
        wxWindow *actualParent = dynamic_cast<wxWindow*>(wxContainer()->ParentInstance());
        if (actualParent)
            newWindow->Reparent(actualParent);
    }
    if (newParent)
        delete newParent;
    delete tmpParent;

    wxDesigner()->ClearState(DS_READING);
    ClearState(CS_READING);
    ClearState(CS_RECREATING);
    manager->NotifyComponentRecreated(wxDesigner(), this);
}

void wxWindowComponent::ObjectCreated(bool fromXRC)
{
    if (!fromXRC)
        Window()->SetAutoLayout(true);
}

void wxWindowComponent::DoSetRect(int &x, int &y, int &w, int &h, bool testOnly)
{
    Window()->SetSize(x, y, w, h, wxSIZE_USE_EXISTING);
}

bool wxWindowComponent::Visible()
{
    return Window()->IsShown();
}

wxWindow* wxWindowComponent::Window()
{
    return dynamic_cast<wxWindow*>(Instance());
}

// wxWindowPainter

IMPLEMENT_DYNAMIC_CLASS(wxWindowPainter, wxPainter)

#ifdef __WINDOWS__

void wxWindowPainter::PaintObject(wxObject* object, wxDC &dc)
{
    wxWindow *w = dynamic_cast<wxWindow*>(object);
    if (!object)
    	return;
	HDC hdc = (HDC)dc.GetHDC();
    RECT cr;
    cr.left = 0;
    cr.top = 0;
    int right, bottom;
    w->GetSize(&right, &bottom);
    cr.right = right;
    cr.bottom = bottom;
    SendMessage((HWND)w->GetHWND(), WM_ERASEBKGND, (unsigned int)hdc, 0);
    InvalidateRect((HWND)w->GetHWND(), &cr, true);
    SendMessage((HWND)w->GetHWND(), WM_PAINT, (unsigned int)hdc, 0);
}

#endif

// wxBevelWindowPainter

IMPLEMENT_DYNAMIC_CLASS(wxBevelWindowPainter, wxWindowPainter)

#ifdef __WINDOWS__

void wxBevelWindowPainter::PaintObject(wxObject* object, wxDC &dc)
{
    wxWindow *w = dynamic_cast<wxWindow*>(object);
    if (!object)
    	return;
	HDC hdc = (HDC)dc.GetHDC();
    int edgeFlags = 0;
    int borderFlags = 0;
    long wxFlags = w->GetWindowStyleFlag();
    if (GetWindowLong((HWND)w->GetHWND(), GWL_EXSTYLE) && WS_EX_CLIENTEDGE) {
        if (wxFlags & wxBORDER_RAISED)
            edgeFlags |= EDGE_RAISED;
        else if (wxFlags & wxBORDER_SUNKEN || wxFlags & wxBORDER_DOUBLE || wxFlags & wxBORDER_STATIC)
            edgeFlags = EDGE_SUNKEN;
        else
            edgeFlags = 0;
        borderFlags = BF_RECT | BF_ADJUST;
    }
    else if (GetWindowLong((HWND)w->GetHWND(), GWL_STYLE) && WS_BORDER) {
        if (wxFlags & wxBORDER_SUNKEN || (wxFlags & wxBORDER_RAISED)) {
            edgeFlags = EDGE_SUNKEN;
            borderFlags |= BF_FLAT | BF_RECT | BF_ADJUST;
        }
        else if (wxFlags & wxBORDER_SIMPLE) {
            edgeFlags = EDGE_SUNKEN;
            borderFlags |= BF_MONO | BF_RECT | BF_ADJUST;
        }
        else if (wxFlags & wxBORDER_STATIC || wxFlags & wxBORDER_NONE) {
            edgeFlags = EDGE_ETCHED;
            borderFlags |= BF_FLAT | BF_RECT | BF_ADJUST;
        }
    }
    if (borderFlags && edgeFlags) {
        RECT r;
        ::SetRect(&r, 0, 0, w->GetSize().x, w->GetSize().y);
        DrawEdge(hdc, &r, edgeFlags, borderFlags);
        MoveWindowOrg(hdc, r.left, r.top);
        IntersectClipRect(hdc, 0, 0, r.right - r.left, r.bottom - r.top);
    }
    else {
        if (wxFlags & wxBORDER_DOUBLE) {
            MoveWindowOrg(hdc, 2, 2);
            dc.DrawRectangle(0, 0, w->GetSize().x + 2, w->GetSize().y + 2);
        }
    }
    wxWindowPainter::PaintObject(object, dc);
}

#endif




