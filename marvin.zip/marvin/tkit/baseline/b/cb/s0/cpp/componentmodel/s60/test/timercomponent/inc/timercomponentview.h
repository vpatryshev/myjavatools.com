#ifndef __TIMERCOMPONENT_VIEW_H__
#define __TIMERCOMPONENT_VIEW_H__

#include <aknview.h>

// Forward ref. to container class
class CtimercomponentContainer;


// CtimercomponentView
class CtimercomponentView : public CAknView
{
  public:

    /**
     * Creates a CtimercomponentView object
     */
    static CtimercomponentView* NewL();

    /**
     * Creates a CtimercomponentView object
     */
    static CtimercomponentView* NewLC();

    /**
     * Identify of this view to the system
     */
    TUid Id() const;

    /**
     * Command Handler
     */
    void HandleCommandL(TInt aCommand);


    /**
     * Activates this View
     */
    void DoActivateL(const TVwsViewId &PrevViewId, TUid  aCustomMessageId, const TDesC8& aCustomMessage);

    /**
     * Deactivate this view
     */
    void DoDeactivate();

  private:
    CtimercomponentView();
   ~CtimercomponentView();

    /**
     * Performs second phase construction of this view
     */
    void ConstructL();

    /**
     * Container for this view
     */
    CtimercomponentContainer* container;

    /**
     * Identifier for this view
     */
    TUid iIdentifier;
};


#endif // __TIMERCOMPONENT_VIEW_H__

