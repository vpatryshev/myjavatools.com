////////////////////////////////////////////////////////////////////////////////
// Implementation of CApplication
////////////////////////////////////////////////////////////////////////////////

#include "app.h"
#include "document.h"

const TUid KUIDNewContactsDB = { 0x01006666 };

TUid CApplication::AppDllUid() const
{
	return KUIDNewContactsDB;
}

CApaDocument* CApplication::CreateDocumentL()
{
	CApaDocument* document = CDocument::NewL(*this);
	return document;
}
