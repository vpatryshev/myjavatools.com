#ifndef __SOUNDDOC_H__
#define __SOUNDDOC_H__

#include <eikdoc.h>

/*! 
 	CSoundDocument
  
  An instance of class CSoundDocument is the Document part of the AVKON
  application framework for the Sound example application
*/
  
class CSoundDocument : public CEikDocument
    {
public:
/*!
  NewL
  
  Construct a CSoundDocument for the AVKON application aApp 
  using two phase construction, and return a pointer to the created object
  Param -  aApp application creating this document
  Returns a pointer to the created instance of CSoundDocument
*/

    static CSoundDocument* NewL(CEikApplication& aApp);

/*!
  NewLC
  
  Construct a CSoundDocument for the AVKON application aApp 
  using two phase construction, and return a pointer to the created object
  Param - aApp application creating this document
  Returns a pointer to the created instance of CSoundDocument
*/
    static CSoundDocument* NewLC(CEikApplication& aApp);

public: // from CEikDocument
/*!
  CreateAppUiL 
  
  Create a CSoundAppUi object and return a pointer to it
  Returns a pointer to the created instance of the AppUi created
*/
    CEikAppUi* CreateAppUiL();

private:

/*!
  ConstructL
  
  Perform the second phase construction of a CSoundDocument object
*/
    void ConstructL();

/*!
  CSoundDocument
  
  Perform the first phase of two phase construction 
  Param - aApp application creating this document
*/
    CSoundDocument(CEikApplication& aApp);

    };


#endif // __SOUNDDOC_H__

