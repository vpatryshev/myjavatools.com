#ifdef __BORLANDC__
#include "rcmpch.h"
#endif

#include "wxwgraphics.h"

#ifdef __WINDOWS__
#include <windows.h>
#endif

#ifdef __WINDOWS__
typedef struct {
    BITMAPV4HEADER    bmiHeader;
    RGBQUAD           bmiColors[1];
} BITMAPV4INFO;

HBITMAP CreateDIB(int w, int h, void *&bits)
{
#ifdef DUMB_PROFILE
	int time = ::GetTickCount();
#endif
    BITMAPV4HEADER bih;
    bih.bV4Size = sizeof(BITMAPV4HEADER);
    bih.bV4Width = w;
    bih.bV4Height = -h; // create top-down
    bih.bV4Planes = 1;
    bih.bV4BitCount = 32;
    bih.bV4V4Compression = BI_BITFIELDS;
    bih.bV4SizeImage = w * h * 4;
    bih.bV4XPelsPerMeter = 0;
    bih.bV4YPelsPerMeter = 0;
    bih.bV4ClrUsed = 0;
    bih.bV4ClrImportant = 0;
    bih.bV4AlphaMask =  0xFF000000;
    bih.bV4RedMask =    0x00FF0000;
    bih.bV4GreenMask =  0x0000FF00;
    bih.bV4BlueMask =   0x000000FF;
    bih.bV4CSType = LCS_sRGB;
    bih.bV4GammaRed = 0;
    bih.bV4GammaGreen = 0;
    bih.bV4GammaBlue = 0;

    BITMAPV4INFO bi;
    bi.bmiHeader = bih;
    bi.bmiColors[0].rgbBlue = 0;
    bi.bmiColors[0].rgbGreen = 0;
    bi.bmiColors[0].rgbRed = 0;
    bi.bmiColors[0].rgbReserved = 0;

    // TODO: investigate using hSection and dwOffset to create the DIB section
    // in a separate shared memory region.
    HBITMAP bHandle = CreateDIBSection(
        GetDC(0),
        (BITMAPINFO*)&bi,
        DIB_RGB_COLORS,
        &bits,
        0,
        0);
#ifdef DUMB_PROFILE
    cout << "CreateDibSection: " << ::GetTickCount() - time << "\n";
#endif
    return bHandle;
}

void MoveWindowOrg(HDC dc, int dx, int dy)
{
    POINT p;
    GetWindowOrgEx(dc, &p);
    SetWindowOrgEx(dc, p.x - dx, p.y - dy, 0);
}

#endif __WINDOWS__

