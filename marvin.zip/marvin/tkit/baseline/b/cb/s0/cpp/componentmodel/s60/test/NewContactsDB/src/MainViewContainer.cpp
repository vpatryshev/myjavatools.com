////////////////////////////////////////////////////////////////////////////////
// Implementation of CMainViewContainer
////////////////////////////////////////////////////////////////////////////////


//#include <txtfmlyr.h>

#include "MainViewContainer.h"
#include "ContactsDB.h"
#include "AgendaInstanceModel.h"
#include "AgendaEntryModel.h"

const TInt KStartDelay = 500000; // 0.5 seconds
const TInt KStartInterval = 300000; // 5 seconds, not that we're going to use it

template class CAgendaEntryModelT<CBase>;
template class CAgendaInstanceModelT<CBase>;
template class CContactT<CBase>;
template class CContactsDBT<CBase>;

_LIT(KDefaultCalendarFilename, "\\system\\data\\Calendar");
_LIT(KDBFileName, "\\system\\data\\contacts.cdb");

CMainViewContainer* CMainViewContainer::NewL(const TRect& aRect)
{
    CMainViewContainer* self = CMainViewContainer::NewLC(aRect);
    CleanupStack::Pop(self);
    return self;
}

CMainViewContainer* CMainViewContainer::NewLC(const TRect& aRect)
{
    CMainViewContainer* self = new (ELeave) CMainViewContainer;
    CleanupStack::PushL(self);
    self->ConstructL(aRect);
    return self;
}

CMainViewContainer::~CMainViewContainer()
{
    CleanupComponents();
}


void CMainViewContainer::InitComponents()
{
    iAgnInstanceModel = CAgendaInstanceModel::NewL(KDefaultCalendarFilename);
    iAgnEntryModel = CAgendaEntryModel::NewL(KDefaultCalendarFilename);

    TEventT<CMainViewContainer, CAgnEntryModel::TState> event(this, &CMainViewContainer::MyStateCallback);
    iAgnInstanceModel->SetOnStateChange(event);
    iAgnEntryModel->SetOnStateChange(event);
}

void CMainViewContainer::CleanupComponents()
{
    if (iAgnInstanceModel)
        delete iAgnInstanceModel;
    if (iAgnEntryModel)
        delete iAgnEntryModel;
}

void CMainViewContainer::ConstructL(const TRect& aRect)
{
    CreateWindowL();
    SetRect(aRect);
    iModelState = CAgnEntryModel::ENoFile;
    InitComponents();
    ActivateL();
}


void CMainViewContainer::Draw(const TRect& aRect) const
{
    CWindowGc& gc = SystemGc();
    gc.SetPenStyle(CGraphicsContext::ENullPen);
    gc.SetBrushColor(KRgbWhite); // for now
    gc.SetBrushStyle(CGraphicsContext::ESolidBrush);
    gc.DrawRect(aRect);
}

TInt CMainViewContainer::CountComponentControls() const
{
    return 0;
}

CCoeControl* CMainViewContainer::ComponentControl(TInt aIndex) const
{
    return NULL;
}

void CMainViewContainer::HandleControlEventL(CCoeControl * /*aControl*/, TCoeEvent /*aEventType*/)
{
}

TKeyResponse CMainViewContainer::OfferKeyEventL(const TKeyEvent& aKeyEvent, TEventCode aType)
{
    return EKeyWasNotConsumed; // or EKeyWasConsumed if handled in this function
}

TInt CMainViewContainer::DoStartTest(TAny* aThis)
{
    CMainViewContainer* self = (CMainViewContainer*)aThis;
    self->iStartTest->Cancel();
    delete self->iStartTest;
    self->iStartTest = NULL;

    self->RunContactTest();
    self->RunAgendaInstanceTest();
    self->RunAgendaEntryTest();
    return 0;
}

void CMainViewContainer::MyStateCallback(CBase * aAgnThing, CAgnEntryModel::TState aState)
{
    iModelState = aState;

    if (aState == CAgnEntryModel::EOk)
    {
        iStartTest = CPeriodic::NewL(EPriorityNormal);
        iStartTest->Start(KStartDelay, KStartInterval, TCallBack(CMainViewContainer::DoStartTest, this));
    }
}

void CMainViewContainer::RunContactTest()
{
    // get the default contacts database
    CContactsDB* db = CContactsDB::NewLC(KDBFileName);
    TInt count = db->CountL();

    // WARNING, for this test code, I will clear out your default Contacts Database
    //if (count > 0)
    //	db->ResetL();

    // create a contact
    CContact* contact1 = CContact::NewLC();
    contact1->AddField(KUidContactFieldGivenName, _L("S"), KUidContactFieldVCardMapUnusedN);
    contact1->AddField(KUidContactFieldFamilyName, _L("D"), KUidContactFieldVCardMapUnusedN);
    contact1->AddField(KUidContactFieldPhoneNumber, _L("19251234567"), KUidContactFieldVCardMapTEL, EContactCategoryWork);

    // add and remove a field just for the hell of it
    contact1->AddField(KUidContactFieldSuffixName, _L("DDS"));
    contact1->RemoveFieldL(KUidContactFieldSuffixName);

    // add the contact to the database
    TContactItemId id1 = db->AddContactL(*contact1);

    // look at the UID
    TPtrC uid1 = contact1->UidL(db->DbUid());

    count = db->CountL();

    // create another contact
    CContact* contact2 = CContact::NewLC(_L("A"), _L("S"), _L("14151234567"), _L("14157654321"));

    // add the contact to the database
    TContactItemId id2 = db->AddContactL(*contact2);

    count = db->CountL();

    // retrieve a read-only contact based on the Contact ID
    CContact* temp = db->GetContactL(id1);

    // we own the pointer so clean it up
    delete temp;

    temp = db->OpenContactL(id2);
    db->CloseContactL(temp->Id());

    delete temp;

    // create a sort priority list.  In this case I'm saying
    // sort first by ascending First Name, then (if items are equal) by descending Family Name
    db->AppendSortField(KUidContactFieldGivenName);
    db->AppendSortField(KUidContactFieldFamilyName, CContactsDB::EDescending);

    // sort transfers ownership of the sort array to the database
    db->SortL();
    const CContactIdArray* sortedItems = db->GetSortedItemsL();

    // verify that match1 == id2 and match2 == id1
    const TContactItemId& match1 = (*sortedItems)[0];
    const TContactItemId& match2 = (*sortedItems)[1];

    db->ResetSortArray();

    // create a new sort priority list.  In this case I'm just reversing the previous sort
    db->AppendSortField(KUidContactFieldFamilyName);
    db->AppendSortField(KUidContactFieldGivenName);

    // sort transfers ownership of the sort array to the database
    db->SortL();
    sortedItems = db->GetSortedItemsL();

    // verify that match3 == id1 and match4 == id2
    const TContactItemId& match3 = (*sortedItems)[0];
    const TContactItemId& match4 = (*sortedItems)[1];

    // try deleting a contact
    db->DeleteContactL(id1);
    count = db->CountL();


    CleanupStack::PopAndDestroy(3); // db, contact1, contact2
}


void CMainViewContainer::RunAgendaInstanceTest()
{
    CParaFormatLayer* paraFormatLayer = CParaFormatLayer::NewL();
    CleanupStack::PushL(paraFormatLayer);
    CCharFormatLayer* charFormatLayer = CCharFormatLayer::NewL();
    CleanupStack::PushL(charFormatLayer);


    // test out the day adjustment features
    iAgnInstanceModel->SetTomorrow();
    TTime date = iAgnInstanceModel->GetDay();
    iAgnInstanceModel->SetYesterday();

    // create a sample appointment
    _LIT(KTxtApptWithAlarm,"An appt with an alarm");
    TTimeIntervalDays apptDay(3);
    TTime startDateTime;
    startDateTime.HomeTime(); // i.e. today
    startDateTime += apptDay; // i.e. 3 days from now
    TDateTime startTime = startDateTime.DateTime();
    startTime.SetHour(13); // 1pm
    startTime.SetMinute(30); // 1:30pm
    startDateTime = startTime; // so the startDateTime is 1:30pm 3 days from today

    TTimeIntervalHours apptLength(1); // a one hour appt
    TTime endDateTime = startDateTime + apptLength;

    CAgnAppt* appt = CAgnAppt::NewL(paraFormatLayer, charFormatLayer);
    CleanupStack::PushL(appt);

    appt->RichTextL()->InsertL(0, KTxtApptWithAlarm);
    appt->SetStartAndEndDateTime(startDateTime, endDateTime);
    appt->SetAlarm(TTimeIntervalDays(2), TTimeIntervalMinutes(600)); // 2 days before start date, at 10am

    // experiment with Repeat info
    CAgnRptDef* rpt = CAgnRptDef::NewL();
    CleanupStack::PushL(rpt);
    // NOTE: after adding a RptDef, funcs using the InstanceId don't work
    TAgnDailyRpt drpt;
    rpt->SetDaily(drpt);
    TTimeIntervalDays fourDays(4);
    rpt->SetStartDate(startDateTime);
    rpt->SetEndDate(startDateTime+TTimeIntervalDays(4));
    rpt->SetInterval(1);
    appt->SetRptDefL(rpt);


    // add the appointment to the model
    TAgnInstanceId apptId = iAgnInstanceModel->AddEntryL(appt);

    CleanupStack::PopAndDestroy(2); // rpt, appt

    // fetch the instance and verify its text
    CAgnAppt* entry = iAgnInstanceModel->FetchInstanceL(apptId)->CastToAppt();
    CleanupStack::PushL(entry);
    TPtrC txt = entry->RichTextL()->Read(0);

    // change the text
    entry->RichTextL()->InsertL(0, _L("changed "));

    // change the start and end dates (by 2 days)
    TTime newStartTime = entry->InstanceStartDate();
    TTimeIntervalDays twoDays(2);
    newStartTime += twoDays;
    TTime newEndTime = newStartTime + apptLength;
    entry->SetStartAndEndDateTime(newStartTime, newEndTime);

    // update the instance
    TAgnInstanceId updatedId = iAgnInstanceModel->UpdateInstanceL(entry);

    CleanupStack::PopAndDestroy(entry);

    // delete the appointment instance
    TAgnEntryId deletedEntryId = iAgnInstanceModel->DeleteInstanceL(updatedId, ECurrentInstance);

    // get todays Agenda item instance IDs
    iAgnInstanceModel->SetToday();
    CAgnDayList<TAgnInstanceId>* dayList = iAgnInstanceModel->FetchDayListIdsL();
    CleanupStack::PushL(dayList);
    TInt countIds = dayList->Count();
    CleanupStack::PopAndDestroy();

    // get todays Agenda items
    CAgnDayList<CAgnEntry*>* dayListItems = iAgnInstanceModel->FetchDayListInstancesL();
    CleanupStack::PushL(dayListItems);
    TInt countItems = dayListItems->Count();
    for (TInt i = 0; i < countItems; ++i)
        delete (*dayListItems)[i];
    CleanupStack::PopAndDestroy();

    // create a sample todo item
    CAgnTodo* todo = CAgnTodo::NewL(paraFormatLayer, charFormatLayer);
    CleanupStack::PushL(todo);
    _LIT(KTxtTodo,"A sample todo item");
    todo->RichTextL()->InsertL(0, KTxtTodo);
    todo->SetDueDate(startDateTime);
    TAgnInstanceId todoId = iAgnInstanceModel->AddEntryL(todo);
    CleanupStack::PopAndDestroy(todo);

    // retrieve the default list and see how many items are in it
    CAgnTodoInstanceList* instanceList = iAgnInstanceModel->FetchTodoListL();
    CleanupStack::PushL(instanceList);
    TInt countTodoItems = instanceList->Count();
    CleanupStack::PopAndDestroy();

    // create a new Todo list
    CAgnTodoList* newTodoList = CAgnTodoList::NewL();
    CleanupStack::PushL(newTodoList);
    TAgnTodoListId newListId = iAgnInstanceModel->AddTodoListL(newTodoList);
    CleanupStack::PopAndDestroy();

    // add a Todo item to the new list
    todo = CAgnTodo::NewL(paraFormatLayer, charFormatLayer);
    CleanupStack::PushL(todo);
    _LIT(KTxtTodo2,"Another sample todo item");
    todo->RichTextL()->InsertL(0, KTxtTodo2);
    todo->SetDueDate(startDateTime);
    todo->SetTodoListId(newListId);
    todoId = iAgnInstanceModel->AddEntryL(todo);
    CleanupStack::PopAndDestroy(todo);

    // retrieve the new list and see how many items are in it
    instanceList = iAgnInstanceModel->FetchTodoListL(newListId);
    CleanupStack::PushL(instanceList);
    countTodoItems = instanceList->Count();
    CleanupStack::PopAndDestroy();

    // remove the new list
    iAgnInstanceModel->DeleteTodoListL(newListId);


    CleanupStack::PopAndDestroy(2); // charFormatLayer, paraFormatLayer
}

void CMainViewContainer::RunAgendaEntryTest()
{
    CParaFormatLayer* paraFormatLayer = CParaFormatLayer::NewL();
    CleanupStack::PushL(paraFormatLayer);
    CCharFormatLayer* charFormatLayer = CCharFormatLayer::NewL();
    CleanupStack::PushL(charFormatLayer);

    // create a sample appointment
    _LIT(KTxtApptWithAlarm,"An appt with an alarm");
    TTimeIntervalDays apptDay(2);
    TTime startDateTime;
    startDateTime.HomeTime(); // i.e. today/now
    startDateTime += apptDay; // i.e. 2 days from now
    TDateTime startTime = startDateTime.DateTime();
    startTime.SetHour(12); // noon
    startTime.SetMinute(0);
    startDateTime = startTime; // so the startDateTime is 12pm two days from today

    TTimeIntervalHours apptLength(1); // a one hour appt
    TTime endDateTime = startDateTime + apptLength;

    CAgnAppt* appt = CAgnAppt::NewL(paraFormatLayer, charFormatLayer);
    CleanupStack::PushL(appt);

    appt->RichTextL()->InsertL(0, KTxtApptWithAlarm);
    appt->SetStartAndEndDateTime(startDateTime, endDateTime);
    appt->SetAlarm(TTimeIntervalDays(1), TTimeIntervalMinutes(600)); // 1 day before start date, at 10am

    // experiment with Repeat info
    CAgnRptDef* rpt = CAgnRptDef::NewL();
    CleanupStack::PushL(rpt);
    TAgnDailyRpt drpt;
    rpt->SetDaily(drpt);
    TTimeIntervalDays fourDays(4);
    rpt->SetStartDate(startDateTime);
    rpt->SetEndDate(startDateTime+TTimeIntervalDays(4));
    rpt->SetInterval(1);
    appt->SetRptDefL(rpt);


    // add the appointment to the model
    TAgnEntryId apptId = iAgnEntryModel->AddEntryL(appt);

    CleanupStack::PopAndDestroy(2); // rpt, appt

    CAgnAppt* entry = iAgnEntryModel->FetchEntryL(apptId)->CastToAppt();
    CleanupStack::PushL(entry);
    TPtrC txt = entry->RichTextL()->Read(0);

    // change the text
    entry->RichTextL()->InsertL(0, _L("changed "));

    // update the entry
    iAgnEntryModel->UpdateEntryL(entry);

    CleanupStack::PopAndDestroy(entry);

    // delete the appointment
    iAgnEntryModel->DeleteEntryL(apptId);

    // create a sample todo item
    CAgnTodo* todo = CAgnTodo::NewL(paraFormatLayer, charFormatLayer);
    CleanupStack::PushL(todo);
    _LIT(KTxtTodo,"A sample todo item");
    todo->RichTextL()->InsertL(0, KTxtTodo);
    todo->SetDueDate(startDateTime);
    TAgnEntryId todoId = iAgnEntryModel->AddEntryL(todo);
    CleanupStack::PopAndDestroy(todo);

    // retrieve the default list and see how many items are in it
    CAgnTodoList* entryList = iAgnEntryModel->FetchTodoListL();
    CleanupStack::PushL(entryList);
    TInt countTodoItems = entryList->Count();
    CleanupStack::PopAndDestroy();

    // create a new Todo list
    CAgnTodoList* newTodoList = CAgnTodoList::NewL();
    CleanupStack::PushL(newTodoList);
    TAgnTodoListId newListId = iAgnEntryModel->AddTodoListL(newTodoList);
    CleanupStack::PopAndDestroy();

    // add a Todo item to the new list
    todo = CAgnTodo::NewL(paraFormatLayer, charFormatLayer);
    CleanupStack::PushL(todo);
    _LIT(KTxtTodo2,"Another sample todo item");
    todo->RichTextL()->InsertL(0, KTxtTodo2);
    todo->SetDueDate(startDateTime);
    todo->SetTodoListId(newListId);
    todoId = iAgnEntryModel->AddEntryL(todo);
    CleanupStack::PopAndDestroy(todo);

    // retrieve the new list and see how many items are in it
    entryList = iAgnEntryModel->FetchTodoListL(newListId);
    CleanupStack::PushL(entryList);
    countTodoItems = entryList->Count();
    CleanupStack::PopAndDestroy();

    // remove the new list
    iAgnEntryModel->DeleteTodoListL(newListId);


    CleanupStack::PopAndDestroy(2); // charFormatLayer, paraFormatLayer
}
