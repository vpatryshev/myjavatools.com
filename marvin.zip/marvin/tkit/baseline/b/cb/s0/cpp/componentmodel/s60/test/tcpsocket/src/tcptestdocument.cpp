////////////////////////////////////////////////////////////////////////////////
// Implementation of CtcptestDocument
////////////////////////////////////////////////////////////////////////////////

#include "tcptestappui.h"
#include "tcptestdocument.h"


CtcptestDocument::CtcptestDocument(CEikApplication& aApp)
                       :CAknDocument(aApp)
{
}

CtcptestDocument::~CtcptestDocument()
{
}

CtcptestDocument* CtcptestDocument::NewL(CEikApplication& aApp)
{
  CtcptestDocument* self = NewLC(aApp);
  CleanupStack::Pop(self);
  return self;
}

CtcptestDocument* CtcptestDocument::NewLC(CEikApplication& aApp)
{
  CtcptestDocument* self = new (ELeave) CtcptestDocument(aApp);
  CleanupStack::PushL(self);
  self->ConstructL();
  return self;
}

void CtcptestDocument::ConstructL()
{
}

CEikAppUi* CtcptestDocument::CreateAppUiL()
{
  return new(ELeave) CtcptestAppUi;
}

