////////////////////////////////////////////////////////////////////////////////
// Implementation of CmessagetestView
////////////////////////////////////////////////////////////////////////////////

#include <e32std.h>
#include <aknviewappui.h>
#include <aknconsts.h>

#include "messagetestappui.h"
#include "messagetestview.h"
#include "messagetestcontainer.h"
#include "messagetest.hrh"
#include <messagetest.rsg>

const TUid EDefaultViewId = { messagetestViewId };

CmessagetestView* CmessagetestView::NewL()
{
  CmessagetestView* self = CmessagetestView::NewLC();
  CleanupStack::Pop(self);
  return self;
}

CmessagetestView* CmessagetestView::NewLC()
{
  CmessagetestView* self = new (ELeave) CmessagetestView();
  CleanupStack::PushL(self);
  self->ConstructL();
  return self;
}

CmessagetestView::CmessagetestView()
{
}

CmessagetestView::~CmessagetestView()
{
}

void CmessagetestView::ConstructL()
{
  BaseConstructL(R_MESSAGETEST);
}

TUid CmessagetestView::Id() const
{
  return EDefaultViewId;
}

void CmessagetestView::DoActivateL(const TVwsViewId& aPrevViewId,
                                   TUid aCustomMessageId,
                                   const TDesC8& aCustomMessage)
{
  ASSERT(container == NULL);
  container = CmessagetestContainer::NewL(ClientRect());
  container->SetMopParent(this);
  AppUi()->AddToStackL(*this, container);
}

void CmessagetestView::DoDeactivate()
{
  if (container)
  {
    AppUi()->RemoveFromStack(container);
    delete container;
    container = NULL;
  }
}

void CmessagetestView::HandleCommandL(TInt aCommand)
{
  if (container && container->DispatchCommandEvents(aCommand))
  {
    return;
  }
  else
  {
    AppUi()->HandleCommandL(aCommand);
  }
}
