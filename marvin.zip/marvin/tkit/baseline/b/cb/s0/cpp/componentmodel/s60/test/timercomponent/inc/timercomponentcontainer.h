#ifndef __TIMERCOMPONENT_CONTAINER_H__
#define __TIMERCOMPONENT_CONTAINER_H__


#include <coecntrl.h>
#include <txtfmlyr.h>
#include <aknview.h>
#include <akncontext.h>
#include <akntitle.h>
#include <aknnavi.h>
#include <akntabgrp.h>
#include <aknnavide.h>
#include <eiklbo.h>

class CEikEdwin;
class CEikGlobalTextEditor;
class CEikLabel;
class CAknSlider;
class CEikColumnListBox;
class CAknSingleStyleListBox;
class CEikTimeEditor;
class CAknNumericSecretEditor;
class CAknIpFieldEditor;
class CEikTimeAndDateEditor;
class CEikRangeEditor;
class CEikProgressInfo;
class CEikDateEditor;
class CEikDurationEditor;
//class CAknNumericEdwin;
class CAknIntegerEdwin;
class CEikFloatingPointEditor;
class CEikFixedPointEditor;


// CtimercomponentContainer
class CtimercomponentContainer : public CCoeControl, public MCoeControlObserver {

  RPointerArray<CCoeControl> iCtrlArray;
  TRgb iBackgroundColor;
public :
  /**
   * Creates a CtimercomponentContainer object
   */
  static CtimercomponentContainer * NewL(const TRect& aRect);

  /**
   * Creates a CtimercomponentView object
   */
  static CtimercomponentContainer * NewLC(const TRect& aRect);


  /**
   * Performs second pahese construction of this Container
   */
  void ConstructL(const TRect & aRect);

  /**
   * Returns the number of controls contained in this compound control
   */
  TInt CountComponentControls()const;

  /**
   * Returns the component at the specified index
   * @param aIndex specifies index of component
   * @return Pointer to component control
   */
  CCoeControl * ComponentControl(TInt aIndex)const;

  /**
   * Draws this container
   */
  void Draw(const TRect& aRect) const;

  /**
   * Destroys container
   */
  ~CtimercomponentContainer();

  void HandleControlEventL(CCoeControl * aControl, TCoeEvent aEventType){}

/**
 * Overridden function used to pass key events to child controls owned by this container
 */
  TKeyResponse OfferKeyEventL(const TKeyEvent& aKeyEvent, TEventCode aType);


private:

  /**
   * Routine that initializes components owned by this Container
   */
  void InitComponents();

  /**
   * Routine that cleans up components owned by this container
   */
  void CleanupComponents();

private:
  //IDE-MANAGED-START
  /* 1/11/04 6:18 PM */

  //IDE-MANAGED-END
};

#endif // __TIMERCOMPONENT_CONTAINER_H__
