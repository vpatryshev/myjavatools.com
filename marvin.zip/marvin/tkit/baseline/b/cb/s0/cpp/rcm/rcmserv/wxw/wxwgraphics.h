#ifndef wxwgraphicsH
#define wxwgraphicsH

#ifdef __WINDOWS__
#include <windows.h>

void MoveWindowOrg(HDC dc, int dx, int dy);
HBITMAP CreateDIB(int w, int h, void *&bits);

#endif

#endif
