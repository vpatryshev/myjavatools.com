#ifndef __SAMPLE_DOCUMENT_H__
#define __SAMPLE_DOCUMENT_H__

#include <akndoc.h>

// Forward references
class SampleAppUi;
class CEikApplication;

// CSampleDocument
class CSampleDocument : public CAknDocument
{
public:
  /**
   * Constructs CSampleDocument for the AVKON application aApp
   * using two phase construction, and return a pointer to the created
   * object
   * @param aApp application creating this document
   * @result a pointer to the created instance of CSampleDocument
   */
  static CSampleDocument* NewL(CEikApplication& aApp);

  /**
   * Constructs CSampleDocument for the AVKON application aApp
   * using two phase construction, and return a pointer to the created
   * object
   * @param aApp application creating this document
   * @result a pointer to the created instance of CSampleDocument
   */
  static CSampleDocument* NewLC(CEikApplication& aApp);

  /**
   * Destroys this document object and releases all memory
   */
  ~CSampleDocument();

  /**
   * Creates a CSampleAppUi object and return a pointer to it
   * @result a pointer to the created instance of the AppUi created
   */
  CEikAppUi* CreateAppUiL();

private:
  /**
   * Performs second phase construction for this CSampleDocument object
   */
  void ConstructL();

  /**
   * Private constructor
   */
  CSampleDocument(CEikApplication& aApp);
};

#endif // __SAMPLE_DOCUMENT_H__
