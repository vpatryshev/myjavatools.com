#ifndef __TCPTEST_CONTAINER_H__
#define __TCPTEST_CONTAINER_H__


#include <coecntrl.h>
#include <txtfmlyr.h>
#include <aknview.h>
#include <akncontext.h>
#include <akntitle.h>
#include <aknnavi.h>
#include <akntabgrp.h>
#include <aknnavide.h>
#include <eiklbo.h>

#include "tcpclientsocket.h"

class CEikEdwin;
class CEikGlobalTextEditor;
class CEikLabel;
class CAknSlider;
class CEikColumnListBox;
class CAknSingleStyleListBox;
class CEikTimeEditor;
class CAknNumericSecretEditor;
class CAknIpFieldEditor;
class CEikTimeAndDateEditor;
class CEikRangeEditor;
class CEikProgressInfo;
class CEikDateEditor;
class CEikDurationEditor;
class CAknNumericEdwin;
class CAknIntegerEdwin;
class CEikFloatingPointEditor;
class CEikFixedPointEditor;


// CtcptestContainer
class CtcptestContainer : public CCoeControl, public MCoeControlObserver
{

    RPointerArray<CCoeControl> iCtrlArray;
    TRgb iBackgroundColor;
public :
    /** Creates a CtcptestContainer object */
    static CtcptestContainer * NewL(const TRect& aRect);

    /** Creates a CtcptestView object */
    static CtcptestContainer * NewLC(const TRect& aRect);


    /** Performs second pahese construction of this Container */
    void ConstructL(const TRect & aRect);

    /** Returns the number of controls contained in this compound control */
    TInt CountComponentControls() const;

    /** ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
     Returns the component at the specified index
     @param aIndex specifies index of component
     @return Pointer to component control
    fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff */
    CCoeControl * ComponentControl(TInt aIndex) const;

    /** Draws this container */
    void Draw(const TRect& aRect) const;

    /** Destroys container */
    ~CtcptestContainer();

    void HandleControlEventL(CCoeControl * aControl, TCoeEvent aEventType)
    {
    }

    /** Overridden function used to pass key events to child controls owned by this container */
    TKeyResponse OfferKeyEventL(const TKeyEvent& aKeyEvent, TEventCode aType);

    void HandleCommandL(TInt aCommand);
private:

    /** Routine that initializes components owned by this Container */
    void InitComponents();

    /** Routine that cleans up components owned by this container */
    void CleanupComponents();

    // EventHandlers
    void SocketStateChange(CBase *sender, TInt state);
    void SocketConnected(CBase *sender);
    void SocketRecvComplete(CBase *sender, TInt state, const TDesC8 &data);
    void SocketWriteComplete(CBase *sender, TInt state);
    void SocketNameLookup(CBase *sender, TNameRecord &nameRecord);
private:
    TBuf16<1000> dispBuf;
    TBuf16<KSocketDefaultBufferSize> recvBuf;
    TBuf8<KSocketDefaultBufferSize> sendBuf;
    //IDE-MANAGED-START
    /* 1/26/04 10:59 AM */
    CEikEdwin * cEikEdwin1;
    CTCPClientSocket *cTCPClientSocket1;

    //IDE-MANAGED-END
};

#endif // __TCPTEST_CONTAINER_H__
