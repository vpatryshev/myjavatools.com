////////////////////////////////////////////////////////////////////////////////
// Implementation of CtcptestAppUi
////////////////////////////////////////////////////////////////////////////////

#include <e32std.h>
#include <eikmenup.h>
#include "tcptestappui.h"
#include "tcptestview.h"
#include "tcptest.hrh"
#include "tcptest.rsg"

void CtcptestAppUi::ConstructL()
{
    BaseConstructL();

    itcptestView = CtcptestView::NewL();

    AddViewL(itcptestView);
    SetDefaultViewL(* itcptestView);

    iConsole=new(ELeave) CEikConsoleScreen;
    _LIT(KEikEcho,"EikEcho");
    iConsole->ConstructL(KEikEcho,0);
    iConsole->SetHistorySizeL(10,10);

}

void CtcptestAppUi::DynInitMenuPaneL(TInt aMenuId, CEikMenuPane* aMenuPane)
{
    if (aMenuId == R_DEFAULT_MENU)
    {
//        aMenuPane->SetItemDimmed(EConnectCmd, iSocket->State() == CClientSocket::EConnected);
//        aMenuPane->SetItemDimmed(EDisconnectCmd, !(iSocket->State() == CClientSocket::EConnected));
    }
}

void CtcptestAppUi::HandleCommandL(TInt aCommand)
{
    switch (aCommand)
    {
        case EEikCmdExit:
        case EAknSoftkeyExit:
            Exit();
            break;
            //    default:
            //      Panic(L"Resource me");
            //      break;
    }
}

