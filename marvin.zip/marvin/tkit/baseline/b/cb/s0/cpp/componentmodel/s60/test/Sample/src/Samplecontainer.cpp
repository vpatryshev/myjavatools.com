////////////////////////////////////////////////////////////////////////////////
// Implementation of CSampleContainer
////////////////////////////////////////////////////////////////////////////////

#include <aknutils.h>
#include <Sample.rsg>
#include <uikon.hrh>
#include "Samplecontainer.h"


CSampleContainer* CSampleContainer::NewL(const TRect& aRect)
{
  CSampleContainer* self = CSampleContainer::NewLC(aRect);
  CleanupStack::Pop(self);
  return self;
}

CSampleContainer* CSampleContainer::NewLC(const TRect& aRect)
{
  CSampleContainer* self = new (ELeave) CSampleContainer;
  CleanupStack::PushL(self);
  self->ConstructL(aRect);
  return self;
}

CSampleContainer::CSampleContainer()
{
  iFocusIndex = -1;
}


CSampleContainer::~CSampleContainer()
{
  CleanupComponents();
  iCtrlArray.Reset();
}

/**
 * Routine that creates and initializes designed components
 * NOTE: Maintained by CBuilder Designer
 */
void CSampleContainer::InitComponentsL()
{
  /* 2/21/04 6:12 PM */
  iEikonEnv->AppUiFactory()->StatusPane()->SwitchLayoutL( R_AVKON_STATUS_PANE_LAYOUT_USUAL );
  TabGroup = CAknTabGroup::NewL( * this );

  iBackgroundColor = iEikonEnv->Color( EColorControlBackground );
}

/**
 * Routine that cleans up designed components
 * NOTE: Maintained by CBuilder Designer
 */
void CSampleContainer::CleanupComponents()
{
  /* 2/21/04 6:12 PM */
  delete TabGroup;

}

void CSampleContainer::ConstructL(const TRect& aRect)
{
  CreateWindowL();
  SetRect(aRect);
  InitComponentsL();
  ActivateL();
}

void CSampleContainer::Draw(const TRect& aRect) const
{
  CWindowGc& gc = SystemGc();
  gc.SetPenStyle(CGraphicsContext::ENullPen);
  gc.SetBrushColor(iBackgroundColor);
  gc.SetBrushStyle(CGraphicsContext::ESolidBrush);
  gc.DrawRect(aRect);
}

TInt CSampleContainer::CountComponentControls() const
{
  return iCtrlArray.Count();
}

CCoeControl* CSampleContainer::ComponentControl(TInt aIndex) const
{
  return (CCoeControl*)iCtrlArray[aIndex];
}

TKeyResponse CSampleContainer::OfferKeyEventL(const TKeyEvent& aKeyEvent, TEventCode aType)
{
  /**
  * You may place code here to act on the users key event, or pass this to a child control
  * to be handled internally by that control.
  *
  * For example:
  *   return myControl->OfferKeyEventL(aKeyEvent, aType);
  */
  if (DispatchKeyEvents(aKeyEvent, aType))
    return EKeyWasConsumed;
  else if(iFocusIndex < iCtrlArray.Count() && iFocusIndex >= 0)
	return iCtrlArray[iFocusIndex]->OfferKeyEventL(aKeyEvent, aType);
  else
    return EKeyWasNotConsumed;
}

void CSampleContainer::HandleControlEventL(CCoeControl * aControl, TCoeEvent aEventType)
{
  DispatchControlEvents(aControl, aEventType);
}

/**
 * The contents of this method is maintained by the CBuilder designer
 * It attemps to dispatch commands to individual handlers
 * NOTE: Maintained by CBuilder Designer
 */
bool CSampleContainer::DispatchCommandEvents(TInt aCommand)
{
  return false;
}

/**
 * Routine that attempts to dispatch Control Events
 * NOTE: Maintained by CBuilder Designer
 */
void CSampleContainer::DispatchControlEvents(CCoeControl * aControl, TCoeEvent aEventType)
{
}

/**
 * Routine that attempts to dispatch Key Events
 * NOTE: Maintained by CBuilder Designer
 */
bool CSampleContainer::DispatchKeyEvents(const TKeyEvent& aKeyEvent, TEventCode aType)
{
  return false;
}

