#ifndef wxwdciH
#define wxwdciH

#include "wx/xti.h"

class wxRootClassInfo : public wxDynamicClassInfo
{
public:
	wxRootClassInfo(const wxString &className, const wxClassInfo *superClass);
    bool SetClassName(const wxString &newClassName);

private:
	char *FClassName;
};

extern wxRootClassInfo* NewRootClassInfo(const wxString &className, const wxClassInfo *superClass);
extern void DeleteRootClassInfo(wxRootClassInfo *rci);

#endif

