#ifndef __SAMPLE_CONTAINER_H__
#define __SAMPLE_CONTAINER_H__

#include "Sample.hrh"


#include <eikappui.h>
#include <coecntrl.h>
#include <akncontext.h>
#include <aknnavi.h>
#include <akntabgrp.h>
#include <akntitle.h>
#include <avkon.rsg>
#include <eikspane.h>

// CSampleContainer
class CSampleContainer : public CCoeControl, public MCoeControlObserver {

public:
  /**
   * Creates a CSampleContainer object
   */
  static CSampleContainer * NewL(const TRect& aRect);

  /**
   * Creates a CSampleView object
   */
  static CSampleContainer * NewLC(const TRect& aRect);


  /**
   * Returns the number of controls contained in this compound control
   */
  TInt CountComponentControls()const;

  /**
   * Returns the component at the specified index
   * @param aIndex specifies index of component
   * @return Pointer to component control
   */
  CCoeControl * ComponentControl(TInt aIndex)const;

  /**
   * Draws this container
   */
  void Draw(const TRect& aRect) const;

  /**
   * Destroys container
   */
  ~CSampleContainer();

  /**
   * Handler for events sent by a control to this Observer
   */
  void HandleControlEventL(CCoeControl * aControl, TCoeEvent aEventType);

  /**
   * Overridden function used to pass key events to child controls owned by this container
   */
  TKeyResponse OfferKeyEventL(const TKeyEvent& aKeyEvent, TEventCode aType);

  /**
   * Routine that dispatches Command events to individual handlers
   */
  bool DispatchCommandEvents(TInt aCommand);

private:
  /**
  *  Constructor
  */
  CSampleContainer();

  /**
   * Performs second phase construction of this Container
   */
  void ConstructL(const TRect & aRect);


  /**
   * Routine that initializes components owned by this Container
   */
  void InitComponentsL();

  /**
   * Routine that cleans up components owned by this container
   */
  void CleanupComponents();

  /**
   * Routine that attempts to dispatch Control Events
   */
  void DispatchControlEvents(CCoeControl * aControl, TCoeEvent aEventType);

  /**
   * Routine that attempts to dispatch Key Events
   */
  bool DispatchKeyEvents(const TKeyEvent& aKeyEvent, TEventCode aType);

private:

  RPointerArray<CCoeControl> iCtrlArray;
  TInt iFocusIndex;
  TRgb iBackgroundColor;

private:
  //IDE-MANAGED-START
  /* 2/21/04 6:12 PM */
  CAknTabGroup * TabGroup;
  //IDE-MANAGED-END
};

#endif // __SAMPLE_CONTAINER_H__
