#ifdef __BORLANDC__
#include "rcmpch.h"
#endif

#include "wxwnotebook.h"
#include "wxwdesigner.h"
#include "wx/notebook.h"

#ifdef __WINDOWS__
#include <commctrl.h>
#endif

wxTabDesignRect::wxTabDesignRect(wxNotebookProxy *notebook, int index) : DesignRect(0, 0, 0, 0)
{
    FIndex = index;
    FNotebook = notebook;
}

void wxTabDesignRect::GetRect(int &left, int &top, int &width, int &height)
{
    RECT rect;
    TabCtrl_GetItemRect((HWND)FNotebook->Notebook()->GetHWND(), FIndex, &rect);
    left = rect.left;
    top = rect.top;
    width = rect.right - rect.left;
    height = rect.bottom - rect.top;
}

wxString wxTabDesignRect::Key()
{
    return wxString::Format("%d", FIndex);
}

Result* wxTabDesignRect::DoClick(int x, int y)
{
    FNotebook->SetPageIndex(FIndex);
    return new Result(true);
}

wxNotebookProxy::wxNotebookProxy(wxwDesigner *designer, wxwContainer *container)
    : wxWindowContainerT<wxNotebook>(designer, container)
{
}

void wxNotebookProxy::ObjectCreated(bool fromXRC)
{
    /*
        According to wxWindows docs, the notebook sizer is owned by the notebook
        and so will be freed by it.
    */
    new wxNotebookSizer(Notebook());
}


void wxNotebookProxy::NotifyChildInserted(wxwComponent *newChild)
{
    wxWindowContainer::NotifyChildInserted(newChild);
    // if a child is created while reading from an .xrc, the wxNotebookPage will be
    // created when the pages collection property is streamed in, and the wxNotebook
    // updated correctly (we hope).
    if (!newChild->HasState(CS_READING)) {
        wxNotebookPage *newPage = dynamic_cast<wxNotebookPage*>(newChild->Instance());
        if (!newPage) return;
        wxNotebookPageInfo *info = new wxNotebookPageInfo();
        info->Create(newPage, newChild->GetName(), false, -1);
        Notebook()->AddPageInfo(info);
        wxBoxSizer *childSizer = new wxBoxSizer(wxVERTICAL);
        newPage->SetAutoLayout(true);
        newPage->SetSizer(childSizer);
        SetPageIndex(Notebook()->GetPageCount()-1);
    }
}

void wxNotebookProxy::NotifyChildRemoved(wxwComponent *child)
{
    wxNotebookPage *page = dynamic_cast<wxNotebookPage*>(child->Instance());
    if (page) {
        unsigned int index = 0;
        while (index < Notebook()->GetPageCount()) {
            if (Notebook()->GetPage(index) == page) {
                Notebook()->RemovePage(index);
                break;
            }
            index++;
        }
    }
    wxWindowContainer::NotifyChildRemoved(child);
}

bool wxNotebookProxy::NotifyChildBoundsChanging(int &x, int &y, int &w, int &h, wxwUIComponent *child)
{
    // disallow direct children from resizing.
    wxwUIComponent *uic = dynamic_cast<wxwUIComponent*>(child);
    return uic ? false : true;
}

void wxNotebookProxy::PaintChild(wxwUIComponent *child, wxDC &dc, int x, int y)
{
    // only paint the topmost page.
    if (Notebook()->GetPageCount() > 0
        && ((wxwContainer*)this)->Components().front() == child) {
        child->Paint(dc, x, y);
    }
}

void wxNotebookProxy::SetPageIndex(int index)
{
    Notebook()->SetSelection(index);
    wxNotebookPage *page = Notebook()->GetPage(index);
    wxwComponent *pageProxy = FindComponentByInstance(page);
    if (pageProxy) {
        list_bring_to_front(Components(), (rcmComponent*)pageProxy);
        wxDesigner()->NotifyComponentChanged(this, true);
    }
}

void wxNotebookProxy::UpdateRects()
{
#ifdef __WINDOWS__
    ClearRects();
    for (unsigned int i=0; i<Notebook()->GetPageCount(); i++) {
        AddRect(new wxTabDesignRect(this, i));
    }

//                tabSize.x = rect.right - rect.left;
//                tabSize.y = rect.bottom - rect.top;

/*            if ( Notebook()->HasFlag(wxNB_LEFT) || Notebook()->HasFlag(wxNB_RIGHT) )
        {
            sizeTotal.x += tabSize.x + 7;
            sizeTotal.y += 7;
        }
        else
        {
            sizeTotal.x += 7;
            sizeTotal.y += tabSize.y + 7;
        }
*/
#endif
}

wxNotebook* wxNotebookProxy::Notebook()
{
    return dynamic_cast<wxNotebook*>(Instance());
}

class NewPageItem : public MenuItem
{
public:
    NewPageItem(wxNotebookProxy *notebook)
        : MenuItem("New Page"), FNotebook(notebook) { }
protected:
    virtual Result* DoItemClick()
    {
        wxPanel *newPage = new wxPanel(FNotebook->Notebook(), GetUniqueID());
        wxString newPageName = FNotebook->wxDesigner()->NewComponentName("Page");
        CreateComponent(FNotebook->wxDesigner(), FNotebook->Notebook(), newPage, newPageName);
        // assumes an add (new page is the last)
        int idx = FNotebook->Notebook()->GetPageCount()-1;
        FNotebook->Notebook()->SetPageText(idx, newPageName);
        FNotebook->SetPageIndex(idx);
        return new Result(true);
    }
private:
    wxNotebookProxy* FNotebook;
};

class NextPageItem : public MenuItem
{
public:
    NextPageItem(wxNotebookProxy *notebook)
        : MenuItem("Next Page"), FNotebook(notebook)
    {
        SetEnabled(FNotebook->Notebook()->GetPageCount() > 1);
    }
protected:
    virtual Result* DoItemClick()
    {
        unsigned int newIndex = FNotebook->Notebook()->GetSelection();
        newIndex++;
        if (newIndex == FNotebook->Notebook()->GetPageCount())
            newIndex = 0;
        FNotebook->SetPageIndex(newIndex);
        return new Result(true);
    }
private:
    wxNotebookProxy* FNotebook;
};

class PrevPageItem : public MenuItem
{
public:
    PrevPageItem(wxNotebookProxy *notebook)
        : MenuItem("Previous Page"), FNotebook(notebook)
    {
        SetEnabled(FNotebook->Notebook()->GetPageCount() > 1);
    }

protected:
    virtual Result* DoItemClick()
    {
        unsigned int newIndex = FNotebook->Notebook()->GetSelection();
        if (newIndex == 0)
            newIndex = FNotebook->Notebook()->GetPageCount()-1;
        else
            newIndex--;
        FNotebook->SetPageIndex(newIndex);
        return new Result(true);
    }
private:
    wxNotebookProxy* FNotebook;
};

class DeletePageItem : public MenuItem
{
public:
    DeletePageItem(wxNotebookProxy *notebook)
        : MenuItem("Previous Page"), FNotebook(notebook)
    {
        SetEnabled(FNotebook->Notebook()->GetPageCount() > 0);
    }

protected:
    virtual Result* DoItemClick()
    {
        int curIndex = FNotebook->Notebook()->GetSelection();
        rcmComponents::iterator it = list_get(FNotebook->Components(), curIndex);
        if (it != FNotebook->Components().end()) {
            delete *it;
            return new Result(true);
        }
        return new Result(false);
    }
private:
    wxNotebookProxy* FNotebook;
};

IMPLEMENT_DYNAMIC_CLASS(wxNotebookEditor, wxwComponentEditor)

void wxNotebookEditor::UpdateMenu(MenuItems &menu, int x, int y)
{
    menu.push_back(new NewPageItem(Proxy()));
    menu.push_back(new NextPageItem(Proxy()));
    menu.push_back(new PrevPageItem(Proxy()));
    menu.push_back(new DeletePageItem(Proxy()));
}


