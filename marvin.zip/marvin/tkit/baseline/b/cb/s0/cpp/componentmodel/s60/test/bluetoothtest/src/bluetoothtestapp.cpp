////////////////////////////////////////////////////////////////////////////////
// Implementation of CbluetoothtestApplication
////////////////////////////////////////////////////////////////////////////////

#include "bluetoothtestapp.h"
#include "bluetoothtestdocument.h"

const TUid KUidbluetoothtest = { 0x01004321 };

TUid CbluetoothtestApplication::AppDllUid() const
{
	return KUidbluetoothtest;
}

CApaDocument* CbluetoothtestApplication::CreateDocumentL()
{
	CApaDocument* document = CbluetoothtestDocument::NewL(*this);
  return document;
}
