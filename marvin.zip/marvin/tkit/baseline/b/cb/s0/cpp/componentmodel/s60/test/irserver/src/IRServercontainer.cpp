////////////////////////////////////////////////////////////////////////////////
// Implementation of CIRServerContainer
////////////////////////////////////////////////////////////////////////////////

#include <aknutils.h>
#include <eiklabel.h>
#include <IRServer.rsg>

#include <barsread.h>
#include <eikappui.h>
#include <eikedwin.h>
#include <txtglobl.h>
#include <coeinput.h>
#include <aknlists.h>
#include <akniconarray.h>
#include <eikclbd.h>
#include <akntitle.h>
#include <aknslider.h>
#include <eikspane.h>
#include <aknnavilabel.h>
#include <eikmfne.h>
#include <aknnumseced.h>
#include <aknipfed.h>
#include <in_sock.h>
#include <eikprogi.h>
#include <AknNumEdwin.h>
#include <eikfpne.h>
#include <aknnumed.h>
#include <aknglobalnote.h>
#include <AknNoteDialog.h>
#include <aknnotewrappers.h>
#include <aknprogressdialog.h>
#include <aknstaticnotedialog.h>
#include <aknquerydialog.h>


#include "IRServercontainer.h"

_LIT(KAlreadyConnected, "Already connected");
_LIT(KNotConnected, "Not connected");
_LIT(KConnected, "Connected");
_LIT(KConnecting, "Connecting...");
_LIT(KDisconnected, "Disconnected");
_LIT(KDisconnecting, "Disconnecting...");
_LIT(KConnectError, "Connect Error");
_LIT(KLookingUp, "Looking up host...");
_LIT(KLookupError, "Lookup failed");
_LIT(KTimeout, "Timed out");
_LIT(KQuerying, "Querying...");
_LIT(KQueryError, "Query Error");
_LIT(KListening, "Listening...");
_LIT(KBadState, "Unknown state");

_LIT(KAccepted, "Accepted connection");
_LIT(KReceived, "Recv: ");
_LIT(KSent, "Sent: ");
_LIT(Kcrlf, "\f");


CIRServerContainer* CIRServerContainer::NewL(const TRect& aRect)
{
  CIRServerContainer* self = CIRServerContainer::NewLC(aRect);
  CleanupStack::Pop(self);
  return self;
}

CIRServerContainer* CIRServerContainer::NewLC(const TRect& aRect)
{
  CIRServerContainer* self = new (ELeave) CIRServerContainer;
  CleanupStack::PushL(self);
  self->ConstructL(aRect);
  return self;
}

CIRServerContainer::~CIRServerContainer()
{
  CleanupComponents();
  iCtrlArray.Reset();
}

/**
 * Routine that creates and initializes designed components
 * NOTE: Maintained by CBuilder Designer
 */
void CIRServerContainer::InitComponents()
{
    /* 1/28/04 7:20 PM */
    /* FIXME CAknView - Missing Property Setter snippet: "In tab group" */
    /* FIXME CAknView - Missing Property Setter snippet: "Tab group" */
    CEikStatusPane * StatusPane = iEikonEnv->AppUiFactory()->StatusPane();
    StatusPane->MakeVisible( ETrue );
    CAknContextPane * cAknContextPane1 =
         ( CAknContextPane * ) iEikonEnv->AppUiFactory()->StatusPane()->ControlL( TUid::Uid( EEikStatusPaneUidContext ) );
    /* FIXME CAknContextPane - Missing Property Setter snippet: "MBM file" */
    /* FIXME CAknContextPane - Missing Property Setter snippet: "Image index" */
    /* FIXME CAknContextPane - Missing Property Setter snippet: "Mask index" */
    CAknTitlePane * cAknTitlePane1 =
         ( CAknTitlePane * ) iEikonEnv->AppUiFactory()->StatusPane()->ControlL( TUid::Uid( EEikStatusPaneUidTitle ) );
    cAknTitlePane1->SetTextL( _L( "Title Pane" ) );
    /* FIXME CAknTitlePane - Missing Property Setter snippet: "MBM file" */
    /* FIXME CAknTitlePane - Missing Property Setter snippet: "Image index" */
    CAknNavigationControlContainer * cAknNavigationControlContainer1 =
         ( CAknNavigationControlContainer * )
         iEikonEnv->AppUiFactory()->StatusPane()->ControlL( TUid::Uid( EEikStatusPaneUidNavi ) );
    /* FIXME CAknNavigationControlContainer - Missing Property Setter snippet: "MBM file" */
    /* FIXME CAknNavigationControlContainer - Missing Property Setter snippet: "Image index" */
    iBackgroundColor = iEikonEnv->Color( EColorControlBackground );
    {
        TResourceReader reader;
        iCoeEnv->CreateResourceReaderLC( reader, R_EDWIN_LAYOUT );
        cEikEdwin1 = new( ELeave )CEikEdwin;
        cEikEdwin1->SetContainerWindowL( * this );
        cEikEdwin1->ConstructFromResourceL( reader );
        CleanupStack::PopAndDestroy(); //reader
        iCtrlArray.Append( cEikEdwin1 );
    }
    cEikEdwin1->SetDimmed( EFalse );
    cEikEdwin1->SetFocus( ETrue );
    {
        TMargins8 tempMargins;
        tempMargins.iLeft = 0;
        tempMargins.iRight = 0;
        tempMargins.iTop = 0;
        tempMargins.iBottom = 0;

        cEikEdwin1->SetBorderViewMargins( tempMargins );
    }
    cEikEdwin1->SetRightWrapGutter( 0 );
    cEikEdwin1->SetExtent( TPoint( 3, 2 ), TSize( 170, 135 ) );
    cEikEdwin1->AddFlagToUserFlags( CEikEdwin::EZeroEnumValue | CEikEdwin::ENoAutoSelection | CEikEdwin::EJustAutoCurEnd );
    {
        TCharFormat format;
        Mem::FillZ( & format, sizeof( TCharFormat ) );
        TCharFormatMask mask;
        Mem::FillZ( & mask, sizeof( TCharFormatMask ) );
        format.iFontSpec.iTypeface = LatinPlain12()->FontSpecInTwips().iTypeface;
        mask.SetAttrib( EAttFontTypeface );
        format.iFontPresentation.iTextColor = iEikonEnv->Color( EColorLabelText );
        mask.SetAttrib( EAttColor );
        format.iFontPresentation.iStrikethrough = ( TFontStrikethrough )EFalse;
        mask.SetAttrib( EAttFontStrikethrough );
        format.iFontPresentation.iUnderline = ( TFontUnderline )EFalse;
        mask.SetAttrib( EAttFontUnderline );
        CCharFormatLayer * layer = CCharFormatLayer::NewL( format, mask );
        cEikEdwin1->SetCharFormatLayer( layer );
    }
    cEikEdwin1->SetTextLimit( 0 );
    cEikEdwin1->SetTextL( & _L( "" ) );
    cEikEdwin1->SetWordWrapL( ETrue );
    cEikEdwin1->SetBackgroundColorL( iEikonEnv->Color( EColorWindowBackground ) );
    cEikEdwin1->SetReadOnly( EFalse );
    cEikEdwin1->SetAllowUndo( EFalse );
    cEikEdwin1->SetOnlyASCIIChars( EFalse );
    {
        TNonPrintingCharVisibility tempNonPrintingCharVisibility;
        tempNonPrintingCharVisibility.SetTabsVisible( EFalse );
        tempNonPrintingCharVisibility.SetSpacesVisible( EFalse );
        tempNonPrintingCharVisibility.SetParagraphDelimitersVisible( EFalse );
        tempNonPrintingCharVisibility.SetLineBreaksVisible( EFalse );
        tempNonPrintingCharVisibility.SetPotentialHyphensVisible( EFalse );
        tempNonPrintingCharVisibility.SetNonBreakingHyphensVisible( EFalse );
        tempNonPrintingCharVisibility.SetNonBreakingSpacesVisible( EFalse );
        tempNonPrintingCharVisibility.SetPageBreaksVisible( EFalse );
        cEikEdwin1->SetNonPrintingCharsVisibility( tempNonPrintingCharVisibility );
    }
    cIrdaSocket1 = CIrdaSocket::NewL( 128, 128, CActive::EPriorityStandard );
    TEventT < CIRServerContainer, TInt > cIrdaSocket1_Accept( this, & CIRServerContainer::OncIrdaSocket1Accept );
//    TEventT < CIRServerContainer, TInt > cIrdaSocket1_StateChange( this, & CIRServerContainer::OncIrdaSocket1StateChange);
    cIrdaSocket1->SetOnAccept( cIrdaSocket1_Accept );
//    cIrdaSocket1->SetOnStateChange( cIrdaSocket1_StateChange );
    cIrdaSocket1->SetReadTimeout( 5000000 );
    cIrdaSocket1->SetWriteTimeout( 5000000 );
    cIrdaSocket1->SetTimeout( 5000000 );
    cIrdaSocket1->SetAutoBind( EFalse );
    cIrdaSocket1->SetLocalPort( 101 );
    cIrdaSocket1->SetServiceName( _L8("Mark Service") );
}

/**
 * Routine that cleans up designed components
 * NOTE: Maintained by CBuilder Designer
 */
void CIRServerContainer::CleanupComponents()
{
    /* 1/28/04 7:20 PM */
    delete cEikEdwin1;
    delete cIrdaSocket1;
}

void CIRServerContainer::ConstructL(const TRect& aRect)
{
  CreateWindowL();
  SetRect(aRect);
  InitComponents();
  cEikEdwin1->SetAknEditorFlags(EAknEditorFlagEnableScrollBars);

    TEventT<CIRServerContainer, TInt> OnStateChangeEvent(this, &CIRServerContainer::SocketStateChange);
    cIrdaSocket1->SetOnStateChange(OnStateChangeEvent);
    TEventT<CIRServerContainer> OnConnectEvent(this, &CIRServerContainer::SocketConnected);
    cIrdaSocket1->SetOnConnect(OnConnectEvent);
    TEventT<CIRServerContainer, TInt, const TDesC8&> OnRecvEvent(this, &CIRServerContainer::SocketRecvComplete);
    cIrdaSocket1->SetOnRecvComplete(OnRecvEvent);
    TEventT<CIRServerContainer, TInt> OnWriteEvent(this, &CIRServerContainer::SocketWriteComplete);
    cIrdaSocket1->SetOnWriteComplete(OnWriteEvent);
    TEventT<CIRServerContainer, TInt> OnErrorEvent(this, &CIRServerContainer::SocketError);
    cIrdaSocket1->SetOnError(OnErrorEvent);

  ActivateL();
}


void CIRServerContainer::Draw(const TRect& aRect) const
{
  CWindowGc& gc = SystemGc();
  gc.SetPenStyle(CGraphicsContext::ENullPen);
  gc.SetBrushColor(iBackgroundColor);
  gc.SetBrushStyle(CGraphicsContext::ESolidBrush);
  gc.DrawRect(aRect);
}

TInt CIRServerContainer::CountComponentControls() const
{
  return iCtrlArray.Count();
}

CCoeControl* CIRServerContainer::ComponentControl(TInt aIndex) const
{
  return (CCoeControl*)iCtrlArray[aIndex];
}

TKeyResponse CIRServerContainer::OfferKeyEventL(const TKeyEvent& aKeyEvent, TEventCode aType)
{
  /**
  * You may place code here to act on the users key event, or pass this to a child control
  * to be handled internally by that control.
  *
  * For example:
  *   return myControl->OfferKeyEventL(aKeyEvent, aType);
  */
  if (DispatchKeyEvents(aKeyEvent, aType))
    return EKeyWasConsumed;
  else
    return EKeyWasNotConsumed;
}

void CIRServerContainer::HandleControlEventL(CCoeControl * aControl, TCoeEvent aEventType)
{
}

/**
 * The contents of this method is maintained by the CBuilder designer
 * It attemps to dispatch commands to individual handlers
 * NOTE: Maintained by CBuilder Designer
 */
bool CIRServerContainer::DispatchCommandEvents(TInt aCommand)
{
    switch (aCommand) {
        case EListen:
//        cIrdaSocket1->SetServiceName(_L8("Mark"));
            cIrdaSocket1->ListenL();
            break;
        case EDisconnect:
            cIrdaSocket1->Disconnect();
            cIrdaSocket1->Cancel();
            break;
        default:
            return false;
    }
    return true;
}

/**
 * Routine that attempts to dispatch Control Events
 * NOTE: Maintained by CBuilder Designer
 */
void CIRServerContainer::DispatchControlEvents(CCoeControl * aControl, TCoeEvent aEventType)
{
}

/**
 * Routine that attempts to dispatch Key Events
 * NOTE: Maintained by CBuilder Designer
 */
bool CIRServerContainer::DispatchKeyEvents(const TKeyEvent& aKeyEvent, TEventCode aType)
{
    if (cEikEdwin1->IsFocused()) {
        return cEikEdwin1->OfferKeyEventL(aKeyEvent, aType);
    }
  return false;
}

void InfoNote(const TDesC &note)
{
    CAknInformationNote *dlg = new (ELeave) CAknInformationNote;
    dlg->ExecuteLD(note);
}

void CIRServerContainer::SocketConnected(CBase *sender)
{
}

void CIRServerContainer::SocketStateChange(CBase *sender, TInt state)
{
    const TDesC *text = &KBadState;
    switch (state) {
        case CIrdaSocket::ENotConnected:
            text = &KNotConnected;
            break;
        case CIrdaSocket::EDisconnected:
            text = &KDisconnected;
            break;
        case CIrdaSocket::EDisconnecting:
            cIrdaSocket1->StopListening();
            text = &KDisconnecting;
            break;
        case CIrdaSocket::EConnected:
            text = &KConnected;
            break;
        case CIrdaSocket::EConnecting:
            text = &KConnecting;
            break;
        case CIrdaSocket::EConnectError:
            text = &KConnectError;
            break;
        case CIrdaSocket::EDiscovering:
            text = &KLookingUp;
            break;
        case CIrdaSocket::EDiscoveryError:
            text = &KLookupError;
            break;
        case CIrdaSocket::ETimeout:
            text = &KTimeout;
            break;
        case CIrdaSocket::EListening:
            text = &KListening;
            break;
        default:
            break;
    }
    dispBuf.Append(*text);
    dispBuf.Append(_L("("));
    dispBuf.AppendNum(state);
    dispBuf.Append(_L(")"));
    dispBuf.Append(Kcrlf);
    cEikEdwin1->SetTextL(&dispBuf);
    cEikEdwin1->DrawNow();
}

void CIRServerContainer::SocketRecvComplete(CBase *sender, TInt state, const TDesC8 &data)
{
    dispBuf.Append(KReceived);
    TBuf16<KSocketDefaultBufferSize> tmp;
    tmp.Copy(data);
    dispBuf.Append(tmp);
    dispBuf.Append(Kcrlf);
    cEikEdwin1->SetTextL(&dispBuf);
    cEikEdwin1->DrawNow();

    _LIT(KEcho, "You said: ");
    sendBuf.Zero();
    sendBuf.Append(KEcho);
    sendBuf.Append(data);
    cIrdaSocket1->WriteL(sendBuf);
}

void CIRServerContainer::SocketWriteComplete(CBase *sender, TInt state)
{

}


void CIRServerContainer::SocketError(CBase *sender, TInt errorCode)
{
    _LIT(KError, "Error: ");
    dispBuf.Append(KError);
    dispBuf.AppendNum(errorCode);
    dispBuf.Append(Kcrlf);
    cEikEdwin1->SetTextL(&dispBuf);
}


void CIRServerContainer::OncIrdaSocket1Accept( CBase * sender, TInt errorCode )
{
    dispBuf.Append(KAccepted);
    dispBuf.Append(_L("(Code: "));
    dispBuf.AppendNum(errorCode);
    dispBuf.Append(_L(")\f"));
    cEikEdwin1->SetTextL(&dispBuf);
    cEikEdwin1->DrawNow();
    if (errorCode == KErrNone) {
        sendBuf.Zero();
        sendBuf.Append(_L("Go Ahead"));
        cIrdaSocket1->WriteL(sendBuf);
        cIrdaSocket1->Recv();
    }
}





