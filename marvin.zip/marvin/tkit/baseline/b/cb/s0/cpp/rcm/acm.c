#include "soapH.h"
#include "soapWSComponentModelServerService.nsmap"
main()
{
	struct soap soap;
	soap_init(&soap);


	if (soap_call_impl__comp_USCORE_GetContextTags ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  compInstanceKey, xsd__int  x, xsd__int  y, impl__comp_USCORE_GetContextTagsResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__result_USCORE_TagInvoked ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  compInstanceKey, xsd__string  designRectKey, xsd__string  resultKey, ArrayOf_USCORE_xsd_USCORE_string * tagKeyPath, impl__result_USCORE_TagInvokedResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__designer_USCORE_CreateComponent ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  containerInstanceKey, xsd__string  compTypeKey, xsd__base64Binary * persistData, impl__designer_USCORE_CreateComponentResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__uicomp_USCORE_GetAsContainer ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  compInstanceKey, impl__uicomp_USCORE_GetAsContainerResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__manager_USCORE_GetDefaultDesigner ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, impl__manager_USCORE_GetDefaultDesignerResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__prop_USCORE_Revert ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string * propKeyPath, impl__prop_USCORE_RevertResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__uidesignrect_USCORE_ResizeCompleted ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  compInstanceKey, xsd__string  designRectKey, xsd__int  x, xsd__int  y, xsd__int  width, xsd__int  height, impl__uidesignrect_USCORE_ResizeCompletedResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__comp_USCORE_SetInstanceName ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  compInstanceKey, xsd__string  name, impl__comp_USCORE_SetInstanceNameResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__manager_USCORE_GetUIDesigner ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, impl__manager_USCORE_GetUIDesignerResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__uidesignrect_USCORE_GetContextTags ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  compInstanceKey, xsd__string  designRectKey, xsd__int  x, xsd__int  y, impl__uidesignrect_USCORE_GetContextTagsResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__propinfo_USCORE_GetValueTags ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  compTypeKey, ArrayOf_USCORE_xsd_USCORE_string * propKeyPath, impl__propinfo_USCORE_GetValueTagsResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__comp_USCORE_GetAsContainer ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  compInstanceKey, impl__comp_USCORE_GetAsContainerResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__prop_USCORE_GetValueTags ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string * propKeyPath, impl__prop_USCORE_GetValueTagsResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__uidesignrect_USCORE_MouseClick ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  compInstanceKey, xsd__string  designRectKey, xsd__int  x, xsd__int  y, xsd__int  clickCount, impl__uidesignrect_USCORE_MouseClickResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__server_USCORE_GetComponentModels ( &soap, "http://RemoteComponentModelServer", "",/* impl__server_USCORE_GetComponentModelsResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__model_USCORE_GetPalettePages ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, impl__model_USCORE_GetPalettePagesResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__eventinfo_USCORE_GetHookTags ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  compTypeKey, ArrayOf_USCORE_xsd_USCORE_string * eventKeyPath, impl__eventinfo_USCORE_GetHookTagsResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__comp_USCORE_GetProperty ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string * propKeyPath, impl__comp_USCORE_GetPropertyResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__comp_USCORE_TestSetParentContainer ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  containerInstanceKey, xsd__string  compInstanceKey, impl__comp_USCORE_TestSetParentContainerResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__event_USCORE_GetHookTags ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string * eventKeyPath, impl__event_USCORE_GetHookTagsResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__uidesignrect_USCORE_MoveCompleted ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  compInstanceKey, xsd__string  designRectKey, xsd__int  x, xsd__int  y, xsd__int  width, xsd__int  height, impl__uidesignrect_USCORE_MoveCompletedResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__model_USCORE_GetDesignerManagers ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, impl__model_USCORE_GetDesignerManagersResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__methodinfo_USCORE_GetMethodInfos ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  compTypeKey, ArrayOf_USCORE_xsd_USCORE_string * parentMethodKeyPath, impl__methodinfo_USCORE_GetMethodInfosResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__manager_USCORE_GetDesignerEvents ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, impl__manager_USCORE_GetDesignerEventsResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__uidesigner_USCORE_GetRootUIComponents ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, impl__uidesigner_USCORE_GetRootUIComponentsResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__comp_USCORE_SetParentContainer ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  containerInstanceKey, xsd__string  compInstanceKey, impl__comp_USCORE_SetParentContainerResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__uicomp_USCORE_TestUIComponentRect ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  compInstanceKey, xsd__int  x, xsd__int  y, xsd__int  width, xsd__int  height, xsd__int  dragX, xsd__int  dragY, impl__uicomp_USCORE_TestUIComponentRectResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__uidesigner_USCORE_CreateComponent_ ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  containerInstanceKey, xsd__string  compTypeKey, xsd__int  x, xsd__int  y, xsd__int  width, xsd__int  height, impl__uidesigner_USCORE_CreateComponentResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__model_USCORE_CreateDesignerManager ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, impl__model_USCORE_CreateDesignerManagerResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__designer_USCORE_GetContextTags ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__int  x, xsd__int  y, impl__designer_USCORE_GetContextTagsResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__compinfo_USCORE_GetEventInfos ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  compTypeKey, impl__compinfo_USCORE_GetEventInfosResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__event_USCORE_SetDefaultHook ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string * eventKeyPath, impl__event_USCORE_SetDefaultHookResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__eventinfo_USCORE_GetEventInfos ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  compTypeKey, ArrayOf_USCORE_xsd_USCORE_string * parentEventKeyPath, impl__eventinfo_USCORE_GetEventInfosResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__designer_USCORE_TagInvoked ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, ArrayOf_USCORE_xsd_USCORE_string * tagKeyPath, impl__designer_USCORE_TagInvokedResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__container_USCORE_SetComponentIndex ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  containerInstanceKey, xsd__string  compInstanceKey, xsd__int  index, impl__container_USCORE_SetComponentIndexResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__designer_USCORE_TestCreateComponent ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  containerInstanceKey, xsd__string  compTypeKey, impl__designer_USCORE_TestCreateComponentResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__comp_USCORE_TagInvoked ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string * tagKeyPath, impl__comp_USCORE_TagInvokedResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__prop_USCORE_GetProperties ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string * parentPropKeyPath, impl__prop_USCORE_GetPropertiesResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__palette_USCORE_GetComponentInfos ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  pageKey, impl__palette_USCORE_GetComponentInfosResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__comp_USCORE_GetProperties ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  compInstanceKey, impl__comp_USCORE_GetPropertiesResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__manager_USCORE_GetPersistenceData ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  compInstanceKey, impl__manager_USCORE_GetPersistenceDataResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__model_USCORE_GetDefaultDesignerInfo ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, impl__model_USCORE_GetDefaultDesignerInfoResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__model_USCORE_DisposeDesignerManager ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, impl__model_USCORE_DisposeDesignerManagerResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__uidesignrect_USCORE_TagInvoked ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  compInstanceKey, xsd__string  designRectKey, ArrayOf_USCORE_xsd_USCORE_string * tagKeyPath, impl__uidesignrect_USCORE_TagInvokedResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__prop_USCORE_SetValueAsText ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string * propKeyPath, xsd__string  value, impl__prop_USCORE_SetValueAsTextResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__comp_USCORE_GetEvents ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  compInstanceKey, impl__comp_USCORE_GetEventsResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__designer_USCORE_CreateComponent_ ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  containerInstanceKey, xsd__string  compTypeKey, impl__designer_USCORE_CreateComponentResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__manager_USCORE_IsPersistenceDataModified ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, impl__manager_USCORE_IsPersistenceDataModifiedResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__uicomp_USCORE_SetUIComponentRect ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  compInstanceKey, xsd__int  x, xsd__int  y, xsd__int  width, xsd__int  height, xsd__int  dragX, xsd__int  dragY, impl__uicomp_USCORE_SetUIComponentRectResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__model_USCORE_GetUIDesignerInfo ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, impl__model_USCORE_GetUIDesignerInfoResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__model_USCORE_CustomDataRequest ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  key, xsd__string  data, impl__model_USCORE_CustomDataRequestResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__event_USCORE_Unhook ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string * eventKeyPath, impl__event_USCORE_UnhookResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__model_USCORE_GetComponentInfo ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  compTypeKey, impl__model_USCORE_GetComponentInfoResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__propinfo_USCORE_GetPropertyInfos ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  compTypeKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string * parentPropKeyPath, impl__propinfo_USCORE_GetPropertyInfosResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__manager_USCORE_GetComponentsOfType ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  compTypeKey, impl__manager_USCORE_GetComponentsOfTypeResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__event_USCORE_GetEvents ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string * parentEventKeyPath, impl__event_USCORE_GetEventsResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__uidesigner_USCORE_CreateComponent ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  containerInstanceKey, xsd__string  compTypeKey, xsd__int  x, xsd__int  y, xsd__base64Binary * persistData, impl__uidesigner_USCORE_CreateComponentResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__manager_USCORE_SetPersistenceData ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__base64Binary * persistData, impl__manager_USCORE_SetPersistenceDataResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__comp_USCORE_GetEvent ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string * eventKeyPath, impl__comp_USCORE_GetEventResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__designer_USCORE_GetComponent ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  compInstanceKey, impl__designer_USCORE_GetComponentResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__event_USCORE_SetHookAsText ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  compInstanceKey, ArrayOf_USCORE_xsd_USCORE_string * eventKeyPath, xsd__string  hookText, impl__event_USCORE_SetHookAsTextResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__compinfo_USCORE_GetPropertyInfos ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  compTypeKey, impl__compinfo_USCORE_GetPropertyInfosResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__designer_USCORE_DisposeComponent ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  compInstanceKey, impl__designer_USCORE_DisposeComponentResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__compinfo_USCORE_GetMethodInfos ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  compTypeKey, impl__compinfo_USCORE_GetMethodInfosResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__designer_USCORE_GetRootComponents ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, impl__designer_USCORE_GetRootComponentsResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__uidesigner_USCORE_GetUIComponent ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  managerInstanceKey, xsd__string  designerKey, xsd__string  compInstanceKey, impl__uidesigner_USCORE_GetUIComponentResponse * out*/ ))
		soap_print_fault(&soap,stderr);


	if (soap_call_impl__model_USCORE_GetDesignerInfoForComponent ( &soap, "http://RemoteComponentModelServer", "",/* xsd__string  modelKey, xsd__string  compTypeKey, impl__model_USCORE_GetDesignerInfoForComponentResponse * out*/ ))
		soap_print_fault(&soap,stderr);


}
