#ifndef __MAIN_VIEW_H__
#define __MAIN_VIEW_H__

#include <e32std.h>
#include <aknview.h>

class CMainViewContainer;


class CMainView : public CAknView
{
  public:

    /**
     * Creates a CMainView object
     */
    static CMainView* NewL();

    /**
     * Creates a CMainView object
     */
    static CMainView* NewLC();

    /**
     * Identify this view to the system
     */
    TUid Id() const;

    /**
     * Command Handler
     */
    void HandleCommandL(TInt aCommand);


    /**
     * Activates this View
     */
    void DoActivateL(const TVwsViewId &PrevViewId, TUid  aCustomMessageId, const TDesC8& aCustomMessage);

    /**
     * Deactivate this view
     */
    void DoDeactivate();

  private:
    CMainView();
   ~CMainView();

    /**
     * Performs second phase construction of this view
     */
    void ConstructL();

    /**
     * Container for this view
     */
    CMainViewContainer* iContainer;

    /**
     * Identifier for this view
     */
    TUid iUid;
};


#endif // __MAIN_VIEW_H__

