////////////////////////////////////////////////////////////////////////////////
// Implementation of CIRServerView
////////////////////////////////////////////////////////////////////////////////

#include <e32std.h>
#include <aknviewappui.h>
#include <aknconsts.h>

#include "IRServerview.h"
#include "IRServercontainer.h"
#include "IRServer.hrh"
#include <IRServer.rsg>

const TUid EDefaultViewId = { 1 };

CIRServerView* CIRServerView::NewL()
{
  CIRServerView* self = CIRServerView::NewLC();
  CleanupStack::Pop(self);
  return self;
}

CIRServerView* CIRServerView::NewLC()
{
  CIRServerView* self = new (ELeave) CIRServerView();
  CleanupStack::PushL(self);
  self->ConstructL();
  return self;
}

CIRServerView::CIRServerView()
{
}

CIRServerView::~CIRServerView()
{
}

void CIRServerView::ConstructL()
{
  BaseConstructL(R_DEFAULT_VIEW);
}

TUid CIRServerView::Id() const
{
  return EDefaultViewId;
}

void CIRServerView::DoActivateL(const TVwsViewId& aPrevViewId,
                                   TUid aCustomMessageId,
                                   const TDesC8& aCustomMessage)
{
  ASSERT(container == NULL);
  container = CIRServerContainer::NewL(ClientRect());
  container->SetMopParent(this);
  AppUi()->AddToStackL(*this, container);
}

void CIRServerView::DoDeactivate()
{
  if (container)
  {
    AppUi()->RemoveFromStack(container);
    delete container;
    container = NULL;
  }
}

void CIRServerView::HandleCommandL(TInt aCommand)
{
  if (container && container->DispatchCommandEvents(aCommand))
  {
    return;
  }
  else
  {
    AppUi()->HandleCommandL(aCommand);
  }
}

