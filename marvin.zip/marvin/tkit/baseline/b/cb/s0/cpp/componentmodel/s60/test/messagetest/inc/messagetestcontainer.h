#ifndef __MESSAGETEST_CONTAINER_H__
#define __MESSAGETEST_CONTAINER_H__

#include "messagetest.hrh"

#include <coecntrl.h>
#include <txtfmlyr.h>
#include <aknview.h>
#include <akncontext.h>
#include <akntitle.h>
#include <aknnavi.h>
#include <akntabgrp.h>
#include <aknnavide.h>
#include <eiklbo.h>

class CEikEdwin;
class CEikGlobalTextEditor;
class CEikLabel;
class CAknSlider;
class CEikColumnListBox;
class CAknSingleStyleListBox;
class CEikTimeEditor;
class CAknNumericSecretEditor;
class CAknIpFieldEditor;
class CEikTimeAndDateEditor;
class CEikRangeEditor;
class CEikProgressInfo;
class CEikDateEditor;
class CEikDurationEditor;
class CAknNumericEdwin;
class CAknIntegerEdwin;
class CEikFloatingPointEditor;
class CEikFixedPointEditor;
class CAknGlobalNote;
class CAknConfirmationNote;
class CAknInformationNote;
class CAknErrorNote;
class CAknWarningNote;
class CAknProgressDialog;
class CAknStaticNoteDialog;

#include "MessageServer.h"
#include "SmsMessageSender.h"
#include "MmsMessageSender.h"
#include "EmailMessageSender.h"
#include "MessageBoxListener.h"


// CmessagetestContainer
class CmessagetestContainer : public CCoeControl, public MCoeControlObserver {

  RPointerArray<CCoeControl> iCtrlArray;
  TRgb iBackgroundColor;

public:
  /**
   * Creates a CmessagetestContainer object
   */
  static CmessagetestContainer * NewL(const TRect& aRect);

  /**
   * Creates a CmessagetestView object
   */
  static CmessagetestContainer * NewLC(const TRect& aRect);

  /**
   * Performs second phase construction of this Container
   */
  void ConstructL(const TRect & aRect);

  /**
   * Returns the number of controls contained in this compound control
   */
  TInt CountComponentControls()const;

  /**
   * Returns the component at the specified index
   * @param aIndex specifies index of component
   * @return Pointer to component control
   */
  CCoeControl * ComponentControl(TInt aIndex)const;

  /**
   * Draws this container
   */
  void Draw(const TRect& aRect) const;

  /**
   * Destroys container
   */
  ~CmessagetestContainer();

  /**
   * Handler for events sent by a control to this Observer
   */
  void HandleControlEventL(CCoeControl * aControl, TCoeEvent aEventType);

  /**
   * Overridden function used to pass key events to child controls owned by this container
   */
  TKeyResponse OfferKeyEventL(const TKeyEvent& aKeyEvent, TEventCode aType);

  /**
   * Routine that dispatches Command events to individual handlers
   */
  bool DispatchCommandEvents(TInt aCommand);

  void SendSMS();
  void SendMMS();
  void SendEmail();

private:
  /**
   * Routine that initializes components owned by this Container
   */
  void InitComponents();

  /**
   * Routine that cleans up components owned by this container
   */
  void CleanupComponents();

  /**
   * Routine that attempts to dispatch Control Events
   */
  void DispatchControlEvents(CCoeControl * aControl, TCoeEvent aEventType);

  /**
   * Routine that attempts to dispatch Key Events
   */
  bool DispatchKeyEvents(const TKeyEvent& aKeyEvent, TEventCode aType);

private:
  //IDE-MANAGED-START
  /* 2/1/04 11:09 AM */
  CEikLabel * cEikLabel1; CEikLabel * cEikLabel2; CAknTabGroup * TabGroup;
  /* Missing declarationSnippet: MenuBar -- FIXME */
  /* Missing declarationSnippet: MenuTitle -- FIXME */
  /* Missing declarationSnippet: MenuPane -- FIXME */
  /* Missing declarationSnippet: MenuItem -- FIXME */

  //IDE-MANAGED-END

	CMessageServer * iMessageServer;
	CEmailMessageSender * iEmailMessageSender;
	CMmsMessageSender * iMmsMessageSender;
	CSmsMessageSender * iSmsMessageSender;
	CMessageBoxListener * iMessageBoxListener;


	void OnStatusChange(CBase * aMessageServer, int aStatusCode);
	void OnRecvEvent(CBase * aRecvHandler, CBaseMtm * aMtm);

	CSmsMessageContent * iSmsMessageContent;
};

#endif // __MESSAGETEST_CONTAINER_H__
