#ifdef __BORLANDC__
#include "rcmpch.h"
#endif

#include "wxwcontainer.h"

// wxwContainer

wxwContainer::wxwContainer()
{
}

wxwContainer::~wxwContainer()
{
    DeleteChildren();
}

bool wxwContainer::CanParent(wxObject *instance)
{
    return CanParentType(instance->GetClassInfo());
}

int	wxwContainer::ComponentCount()
{
    return FComponents.size();
}

void wxwContainer::DeleteChildren()
{
    for (rcmComponents::iterator it = FComponents.begin(); it != FComponents.end(); ++it) {
        wxwComponent *c = dynamic_cast<wxwComponent*>(*it);
        if (c) {
            c->SetState(CS_DESTROYING);
            delete c;
        }
    }
    FComponents.clear();
}

wxwComponent* wxwContainer::FindComponentByKey(const wxString &key)
{
    return dynamic_cast<wxwComponent*>(GetComponent(key));
}

wxwComponent* wxwContainer::FindComponentByName(const wxString &name)
{
    rcmComponents::iterator it = FComponents.begin();
    while (it != FComponents.end()) {
        if ((*it)->GetName() == name)
            return dynamic_cast<wxwComponent*>(*it);
        it++;
    }
    return 0;
}

wxwComponent* wxwContainer::FindComponentByInstance(const wxObject *instance)
{
    rcmComponents::iterator it = FComponents.begin();
    while (it != FComponents.end()) {
        if ((*it)->Instance() == instance)
            return dynamic_cast<wxwComponent*>(*it);
        it++;
    }
    return 0;
}

rcmComponent* wxwContainer::GetComponent(const wxString &key)
{
    rcmComponents::iterator it = FComponents.begin();
    for (; it != FComponents.end(); ++it) {
        if ((*it)->Key() == key) {
            return *it;
        }
    }
    return 0;
}

rcmProperty* wxwContainer::GetExtraProperty(wxwComponent *child, wxArrayString &propPath)
{
    return 0;
}

void wxwContainer::Insert(wxwComponent *component)
{
	FComponents.push_back(component);
}

void wxwContainer::NotifyChildInserted(wxwComponent *newChild)
{
    Insert(newChild);
}

void wxwContainer::NotifyChildRemoved(wxwComponent *child)
{
    Remove(child);
}

wxObject* wxwContainer::ParentInstance()
{
    wxwComponent *thisComp = dynamic_cast<wxwComponent*>(this);
    return thisComp ? thisComp->Instance() : 0;
}

void wxwContainer::Remove(wxwComponent *component)
{
    if (!component->HasState(CS_DESTROYING)) {
        for (rcmComponents::iterator it = FComponents.begin(); it != FComponents.end(); ++it) {
            if (*it == component) {
                FComponents.erase(it);
                break;
            }
        }
    }
}

Result* wxwContainer::SetComponentIndex(rcmComponent *comp, int index)
{
    return ErrorMessage("SetComponentIndex not implemented");
}


