#ifndef wxwpersistH
#define wxwpersistH

#include "wxw.h"
#include "wx/xtixml.h"
#include "wx/xml/xml.h"
#include "wx/xtistrm.h"

class wxDesignerPersister : public wxPersister
{
public:
	wxDesignerPersister(wxwDesignerManager *manager) : wxPersister(), FManager(manager) { }
    virtual bool BeforeWriteObject(wxWriter *writer, const wxObject *object,
        const wxClassInfo *classInfo, wxxVariantArray &metadata);
    virtual bool BeforeWriteDelegate(wxWriter *writer, const wxObject *object,
        const wxClassInfo* classInfo, const wxPropertyInfo *propInfo,
        const wxObject *&eventSink, const wxHandlerInfo *&handlerInfo);
    virtual bool BeforeWriteProperty(wxWriter *writer, const wxObject *object,
        const wxPropertyInfo *propInfo, wxxVariantArray &value) { return true; }
    virtual bool BeforeWriteProperty(wxWriter *writer, const wxObject *object,
        const wxPropertyInfo *propInfo, wxxVariant &value);

private:
    wxwDesignerManager *FManager;
};

class wxDesignerDepersister : public wxRuntimeDepersister
{
public:
	wxDesignerDepersister(wxwDesignerManager *manager)
		: wxRuntimeDepersister(), FManager(manager) { }

	virtual void CreateObject(int objectID, const wxClassInfo *classInfo,
		int paramCount, wxxVariant *VariantValues, int *objectIDValues,
		const wxClassInfo **objectClassInfos, wxxVariantArray &metadata);

    virtual void SetConnect(int EventSourceObjectID,
        const wxClassInfo *EventSourceClassInfo,
        const wxPropertyInfo *delegateInfo,
        const wxClassInfo *EventSinkClassInfo,
        const wxHandlerInfo* handlerInfo,
        int EventSinkObjectID );

    virtual void SetProperty(int objectID,
        const wxClassInfo *classInfo,
        const wxPropertyInfo* propertyInfo ,
        const wxxVariant &VariantValue);

protected:
    wxwComponent* CreateComponentProxy(wxObject *object,
        wxxVariant *VariantValues, const wxString &name);
	wxwDesignerManager *FManager;
};

static const char *xrcsig = "wxWindowsXTI";

class wxXrcReader
{
public:
    wxXrcReader(wxwDesignerManager *manager, wxMemoryInputStream &stream)
    {
        FManager = manager;
        FXml.Load(stream);
        FRootNode = FXml.GetRoot();
        if (FRootNode->GetName() != xrcsig)
            assert(!"Bad signature in xrc");
    }

    rcmComponent* ReadRoot();
private:
    wxXmlNode *FRootNode;
    wxXmlDocument FXml;
    wxwDesignerManager *FManager;
};

class wxXrcWriter
{
public:
    wxXrcWriter(wxwDesignerManager *manager)
    {
        FManager = manager;
        FRootNode = new wxXmlNode(wxXML_ELEMENT_NODE, xrcsig);
        FXml.SetRoot(FRootNode);
    }

    int WriteRoot(wxwRootComponent &root, const wxString &rootName, wxwDesignerManager &manager,
        wxMemoryOutputStream &stream);
    int Write(wxObject *root, const wxClassInfo *classInfo, wxMemoryOutputStream &stream,
    	const wxString &rootName, wxDesignerPersister &persister);
private:
    wxXmlNode *FRootNode;
    wxXmlDocument FXml;
    wxwDesignerManager *FManager;
};


class wxInstancePersister : public wxDesignerPersister
{
public:
	wxInstancePersister(wxwDesignerManager *manager) : wxDesignerPersister(manager) { }

  	virtual bool BeforeWriteDelegate(wxWriter *writer, const wxObject *object,
        const wxClassInfo* classInfo, const wxPropertyInfo *propInfo,
        const wxObject *&eventSink, const wxHandlerInfo *&handlerInfo);
};

// wxInstanceDepersister

class wxInstanceDepersister : public wxDesignerDepersister
{
public:
    wxInstanceDepersister(wxwDesignerManager *manager)
        : wxDesignerDepersister(manager) { }

	virtual void CreateObject(int objectID, const wxClassInfo *classInfo,
		int paramCount, wxxVariant *VariantValues, int *objectIDValues,
		const wxClassInfo **objectClassInfos, wxxVariantArray &metadata);
};

#endif
