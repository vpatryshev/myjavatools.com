#ifndef __IRSERVER_VIEW_H__
#define __IRSERVER_VIEW_H__

#include <aknview.h>
#include "IRServer.hrh"

// Forward ref. to container class
class CIRServerContainer;


// CIRServerView
class CIRServerView : public CAknView
{
  public:

    /**
     * Creates a CIRServerView object
     */
    static CIRServerView* NewL();

    /**
     * Creates a CIRServerView object
     */
    static CIRServerView* NewLC();

    /**
     * Identify of this view to the system
     */
    TUid Id() const;

    /**
     * Command Handler
     */
    void HandleCommandL(TInt aCommand);

    /**
     * Activates this View
     */
    void DoActivateL(const TVwsViewId &PrevViewId, TUid  aCustomMessageId, const TDesC8& aCustomMessage);

    /**
     * Deactivate this view
     */
    void DoDeactivate();

  private:
    CIRServerView();
   ~CIRServerView();

    /**
     * Performs second phase construction of this view
     */
    void ConstructL();

    /**
     * Container for this view
     */
    CIRServerContainer* container;

    /**
     * Identifier for this view
     */
    TUid iIdentifier;
};


#endif // __IRSERVER_VIEW_H__

