#ifdef __BORLANDC__
#include "rcmpch.h"
#endif

#include "wxwdesigner.h"
#include "wxwcomponent.h"
#include "wxwcomponentmodel.h"
#include "wxwpersist.h"
#include "wxwroot.h"
#include <functional>

typedef pair<const string_type, rcmComponent*> 	ComponentPair;

struct comp_has_name : public binary_function<ComponentPair, string_type, bool>
{
	bool operator() (const ComponentPair &__pair, const string_type &__name) const
    {
    	return __pair.second && (__pair.second->GetName() == __name);
    }
};

struct comp_has_instance : public binary_function<ComponentPair, const wxObject*, bool>
{
	bool operator() (const ComponentPair &__pair, const wxObject *__inst) const
    {
    	return __pair.second && (__pair.second->Instance() == __inst);
    }
};

// wxwDesigner

wxwDesigner::wxwDesigner(wxwDesignerManager *manager)
	: FManager(manager)
{
    FStates = 0;
}

wxwDesigner::~wxwDesigner()
{
}


bool wxwDesigner::CanCreate(rcmContainer *container, rcmComponentInfo *compType)
{
    // TODO: look up registered types next
    return !INFO_TYPEOF(compType, wxWindow) && !INFO_TYPEOF(compType, wxSizer);
}

rcmComponent* wxwDesigner::GetComponent(const wxString &key)
{
    return this->FindComponentByKey(key);
}

void wxwDesigner::Insert(wxwComponent *comp)
{
	if (!comp->Container()) {
    	FComponents.push_back(comp);
    }
}

void wxwDesigner::Remove(wxwComponent *comp)
{
    if (!comp) return;
   	FComponents.remove(comp);
}

Result* wxwDesigner::DisposeComponent(const wxString& instanceKey)
{
    return DisposeComponent(GetComponent(instanceKey)) ? new Result(true) : new Result(false);
}

bool wxwDesigner::DisposeComponent(rcmComponent *comp)
{
    bool disposed = comp && comp->CanDispose();
    if (disposed) {
        rcmContainer *cont = dynamic_cast<rcmContainer*>(comp);
        if (cont) {
            rcmComponents sc = cont->Components();
            rcmComponents::reverse_iterator it = sc.rbegin();
            for (; it != sc.rend(); it++) {
                disposed &= DisposeComponent(*it);
                if (!disposed) return false;
            }
        }
        delete comp;
    }
    return disposed;
}

void wxwDesigner::GetRootComponents(rcmComponents &roots)
{
	rcmComponents::iterator it = FComponents.begin();
    for (; it != FComponents.end(); ++it) {
    	roots.push_back(*it);
	}
}

wxwComponent* wxwDesigner::FindComponentByKey(const wxString &key)
{
    wxwComponent *c = FManager->FindComponentByKey(key);
    return c && c->Designer() == this ? c : 0;
}

wxwComponent* wxwDesigner::FindComponentByName(const wxString &name)
{
    wxwComponent *c = FManager->FindComponentByName(name);
    return c && c->Designer() == this ? c : 0;
}

wxwComponent* wxwDesigner::FindComponentByInstance(const wxObject *instance)
{
    wxwComponent *c = FManager->FindComponentByInstance(instance);
    return c && c->Designer() == this ? c : 0;
}

rcmDesignerManager* wxwDesigner::Manager()
{
    return FManager;
}

void wxwDesigner::Changed()
{
	FManager->NotifyDesignerChanged(this, true);
}

wxString wxwDesigner::NewComponentName(const wxString &baseName)
{
    return FManager->NewComponentName(baseName);
}

void wxwDesigner::NotifyComponentChanged(wxwComponent *comp, bool post)
{
	FManager->NotifyComponentChanged(this, comp, post);
}

void wxwDesigner::NotifyComponentCreated(wxwComponent *comp, wxwContainer *container, bool post)
{
	Insert(comp);
    FManager->NotifyComponentCreated(this, comp, container, post);
}

void wxwDesigner::NotifyComponentDeleted(wxwComponent *comp, bool post)
{
	Remove(comp);
    FManager->NotifyComponentDeleted(this, comp, post);
}

void wxwDesigner::NotifyComponentRecreated(wxwComponent *comp)
{
	FManager->NotifyComponentRecreated(this, comp);
}

void wxwDesigner::NotifyComponentRenamed(wxwComponent *comp, const wxString &oldName, bool post)
{
 	FManager->NotifyComponentRenamed(comp, oldName, post);
}

void wxwDesigner::NotifyEventChanged(rcmEvent *event, wxwComponent *comp, bool post)
{
	FManager->NotifyEventChanged(this, event, comp, post);
}

void wxwDesigner::NotifyEventSinkAdded(wxwEventConnection *connection)
{
	FManager->NotifyEventSinkAdded(connection);
}

void wxwDesigner::NotifyEventSinkDeleted(const wxString &handlerName)
{
	FManager->NotifyEventSinkDeleted(handlerName);
}

void wxwDesigner::NotifyEventSinkRenamed(const wxString &newName, const wxString &oldName)
{
	FManager->NotifyEventSinkRenamed(newName, oldName);
}

void wxwDesigner::NotifyPropertyChanged(rcmProperty *prop, wxwComponent *comp, bool post)
{
	FManager->NotifyPropertyChanged(this, prop, comp, post);
}

int	wxwDesigner::Persist(wxMemoryOutputStream *stream, rcmComponent *root)
{
    return 0;
}

// wxwUIDesigner

wxwUIDesigner::~wxwUIDesigner()
{
}

bool wxwUIDesigner::CanCreate(rcmContainer *container, rcmComponentInfo *compType)
{
    bool canCreate = false;
    if (compType) {
        if (container)
            canCreate = container->CanParentType(compType->ClassInfo());
        else
            canCreate = INFO_TYPEOF(compType, wxFrame);
    }
    return canCreate;
}

void wxwUIDesigner::ClientRect(int &x, int &y, int &w, int &h)
{
    x = 0;
    y = 0;
    w = wxSystemSettings::GetMetric(wxSYS_SCREEN_X);
    h = wxSystemSettings::GetMetric(wxSYS_SCREEN_Y);
}

wxString wxwUIDesigner::GetDesignerImage(void *stream)
{
    return "not implemented";
}

void wxwUIDesigner::SetImageURI(const wxString &uri)
{
    FImageURI = uri;
    Changed();
}

// wxwDesignerManager

wxwDesignerManager::wxwDesignerManager(wxwComponentModel *model)
	: FModel(model), FModified(false), FReading(false), FRoot(0)
{
    KeyGen(this, FKey);
}

wxwDesignerManager::~wxwDesignerManager()
{
    if (FRoot)
		delete FRoot;
    FRoot = 0;
}

wxwDesigner* wxwDesignerManager::GetDesigner(DesignerType type)
{
    Designers::iterator it = FDesigners.begin();
    for (; it != FDesigners.end(); ++it) {
        if ((*it).second->GetDesignerInfo()->GetType() == type)
            return (*it).second;
    }
    return 0;
}

rcmDesigner* wxwDesignerManager::GetDesigner(const wxString &key)
{
    Designers::iterator it = FDesigners.find(key);
    return it != FDesigners.end() ? (*it).second : 0;
}


void wxwDesignerManager::GetComponentsOfType(rcmComponentInfo *type, rcmComponents &comps)
{
    for (ComponentMap::iterator it = FComponentMap.begin(); it != FComponentMap.end(); ++it) {
        if ((*it).second->IsType(type)) {
            comps.push_back((*it).second);
        }
    }
}

void wxwDesignerManager::Modified()
{
    FModified = true;
}

int	wxwDesignerManager::Persist(wxMemoryOutputStream *stream, rcmComponent *root)
{
    int bytes = 0;
    // don't need to ask the designer to persist themselves, just write out
    // the root component using the streaming system.

	if (stream && FRoot) {
        wxXrcWriter writer(this);
        if (!root) {
            return writer.WriteRoot(*FRoot, FRoot->GetName(), *this, *stream);
        }
        else {
            wxDesignerPersister persister(this);
            return writer.Write(root->Instance(), root->Instance()->GetClassInfo(), *stream, root->GetName(), persister);
        }
    }
    return bytes;
}

bool wxwDesignerManager::ValidateRename(const string_type &newName)
{
	ComponentMap::iterator it = find_if(FComponentMap.begin(), FComponentMap.end(),
        bind2nd(comp_has_name(), newName));
    return it == FComponentMap.end();
}

wxString wxwDesignerManager::NewComponentName(const wxString &baseName)
{
    wxString newName;
    int i = 0;
    do {
	    newName.sprintf("%s%d", baseName, ++i);
    }
    while (!ValidateRename(newName));
	return newName;
}

bool EventsEquivalent(DesignerEvent *e1, DesignerEvent *e2)
{
    if (strcmp(e1->ManagerKey(), e2->ManagerKey()) == 0
        && strcmp(e1->DesignerKey(), e2->DesignerKey()) == 0) {
        switch (e1->Code()) {
            case MANAGER_CHANGED:
            case DESIGNER_CHANGED:
                return true;
            case COMPONENT_CREATED:
            case COMPONENT_CHANGED:
            case COMPONENT_DISPOSED:
            {
                ComponentEvent *ce1 = dynamic_cast<ComponentEvent*>(e1);
                ComponentEvent *ce2 = dynamic_cast<ComponentEvent*>(e2);
                switch (e2->Code()) {
                    case COMPONENT_CREATED:
                    case COMPONENT_DISPOSED:
                    case COMPONENT_CHANGED:
                    case PROPERTY_CHANGED:
                    case EVENT_CHANGED:
                    {
                        return ce1 && ce2 && strcmp(ce1->ComponentKey(), ce2->ComponentKey()) == 0;
                    }
                    default:
                        return false;
                }
            }
            case PROPERTY_CHANGED:
            {
                PropertyChangedEvent *pce1 = dynamic_cast<PropertyChangedEvent*>(e1);
                switch (e2->Code()) {
                    case PROPERTY_CHANGED:
                    {
                        PropertyChangedEvent *pce2 = dynamic_cast<PropertyChangedEvent*>(e2);
                        return (pce1 && pce2 && strcmp(pce1->ComponentKey(), pce2->ComponentKey()) == 0
                            && pce1->Keys() == pce2->Keys());
                    }
                    case COMPONENT_CREATED:
                    case COMPONENT_DISPOSED:
                    case COMPONENT_CHANGED:
                    {
                        ComponentEvent *ce2 = dynamic_cast<ComponentEvent*>(e2);
                        return pce1 && ce2 && strcmp(pce1->ComponentKey(), ce2->ComponentKey()) == 0;
                    }
                    default:
                        return false;
                }
            }
            case EVENT_CHANGED:
            {
                EventChangedEvent *ece1 = dynamic_cast<EventChangedEvent*>(e1);
                switch (e2->Code()) {
                    case EVENT_CHANGED:
                    {
                        EventChangedEvent *ece2 = dynamic_cast<EventChangedEvent*>(e2);
                        return (ece1 && ece2 && strcmp(ece1->ComponentKey(), ece2->ComponentKey()) == 0
                            && ece1->Keys() == ece2->Keys());
                    }
                    case COMPONENT_CREATED:
                    case COMPONENT_DISPOSED:
                    case COMPONENT_CHANGED:
                    {
                        ComponentEvent *ce2 = dynamic_cast<ComponentEvent*>(e2);
                        return ece1 && ce2 && strcmp(ece1->ComponentKey(), ce2->ComponentKey()) == 0;
                    }
                    default:
                        return false;
                }
            }
            case CUSTOM_DATA:
            {
                // TODO: compare custom data events
                return false;
            }
            default:
                return false;
        }
    }
    return false;
}

bool wxwDesignerManager::IsDuplicateEvent(DesignerEvent *event)
{
    bool dup = false;
    DesignerEvents::iterator it = FEvents.begin();
    while (!dup && it != FEvents.end()) {
        dup = dup || EventsEquivalent(event, *it);
        it++;
    }
    return dup;
}

void wxwDesignerManager::PostEvent(DesignerEvent *event)
{
    if (!IsDuplicateEvent(event)) {
    	FEvents.push_back(event);
    }
}

wxwDesigner* wxwDesignerManager::CreateDesigner(DesignerType type)
{
    wxwDesigner::wxwDesignerInfo *di = dynamic_cast<wxwDesigner::wxwDesignerInfo*>(FModel->GetDesignerInfo(type));
    if (di) {
        wxwDesigner *newD = di->CreateDesigner(this);
        if (newD) {
            FDesigners[di->DesignerKey()] = newD;
            return newD;
        }
    }
    return 0;
}

wxwDesigner* wxwDesignerManager::GetOrCreateDesigner(DesignerType type)
{
    wxwDesigner *result = GetDesigner(type);
    if (!result) {
        result = CreateDesigner(type);
        if (FReading)
            result->SetState(DS_READING);
    }
    return result;
}

rcmDesigner* wxwDesignerManager::DefaultDesigner()
{
    return GetOrCreateDesigner(dtDefault);
}

rcmDesigner* wxwDesignerManager::UIDesigner()
{
    return GetOrCreateDesigner(dtUI);
}

void wxwDesignerManager::DeleteDesigners()
{
    for (Designers::iterator it = FDesigners.begin(); it != FDesigners.end(); ++it) {
        (*it).second->SetState(DS_DESTROYING);
        delete (*it).second;
    }
    FDesigners.clear();
}

Result* wxwDesignerManager::Depersist(wxMemoryInputStream *stream)
{
    // trash the old designers, recreate the world
    wxwRootComponent *root = FRoot;
    if (root) {
        Remove(FRoot);
	    delete root;
    }
    DeleteDesigners();

    // Create new designers with the new streamed data.
    try {
    	if (stream && stream->GetSize() > 0) {
            FReading = true;
            wxXrcReader reader(this, *stream);
            reader.ReadRoot();
        }
        FReading = false;
        for (Designers::iterator it = FDesigners.begin(); it != FDesigners.end(); ++it) {
            (*it).second->ClearState(DS_READING);
        }
        for (ComponentMap::iterator it = FComponentMap.begin(); it != FComponentMap.end(); ++it) {
            (*it).second->ClearState(CS_READING);
        }
        return new Result(true);
    }
    catch (error &e) {
        return ErrorMessage("Error reading .xrc", e.what());
    }
}

rcmComponent* wxwDesignerManager::GetComponent(const wxString &instanceKey)
{
	ComponentMap::iterator it = FComponentMap.find(instanceKey);
    return it == FComponentMap.end() ? 0 : it->second;
}

void wxwDesignerManager::ClearEventQueue()
{
	for (DesignerEvents::iterator it = FEvents.begin(); it!= FEvents.end(); ++it) {
    	delete *it;
    }
    FEvents.clear();
}

void wxwDesignerManager::NotifyComponentChanged(wxwDesigner *designer, wxwComponent *comp, bool post)
{
    if (comp) {
        Modified();
        if (post) {
            PostEvent(new ComponentChangedEvent(designer, comp));
        }
    }
}

void wxwDesignerManager::NotifyComponentRecreated(wxwDesigner *designer, wxwComponent *comp)
{
	if (FRoot) {
	    FRoot->RemoveComponentProperty(comp);
	    FRoot->AddComponentProperty(comp);
    }
    NotifyComponentChanged(designer, comp, true);
}

void wxwDesignerManager::NotifyComponentRenamed(wxwComponent *comp, const wxString &oldName, bool post)
{
    if (!comp) return;
    if (!FReading && FRoot && (dynamic_cast<wxwRootComponent*>(comp)) != FRoot) {
        if (FRoot->HasProperty(oldName)) {
            FRoot->RenameComponentProperty(dynamic_cast<wxwComponent*>(comp), oldName);
        }
        else {
            FRoot->AddComponentProperty(dynamic_cast<wxwComponent*>(comp));
        }
    }
    Modified();
}

void wxwDesignerManager::NotifyComponentDeleted(wxwDesigner *designer, wxwComponent *comp, bool post)
{
	if (!comp) return;
    if (post) {
    	PostEvent(new ComponentDisposedEvent(designer, comp));
    }
    if (FRoot && comp != FRoot) {
        FRoot->RemoveComponentProperty(comp);
        // look for event handlers for which this component is the source,
        // and delete them? Not yet. Right now we'll leave the handler in the
        // metadata, but since the source is gone, a data value won't be streamed
        // or rehooked
    }
    Remove(comp);
    Modified();
}

void wxwDesignerManager::NotifyComponentCreated(wxwDesigner *designer, wxwComponent *comp, wxwContainer *container, bool post)
{
	if (!comp) return;
    Insert(comp);
    if (post) {
        PostEvent(new ComponentCreatedEvent(designer, comp));
        if (container) {
            PostEvent(new ComponentChangedEvent(designer, dynamic_cast<wxwComponent*>(container)));
        }
    }
    Modified();
}

void wxwDesignerManager::NotifyDesignerChanged(wxwDesigner *designer, bool post)
{
	if (post) {
	    PostEvent(new DesignerEvent(designer, DESIGNER_CHANGED));
    }
    Modified();
}


void wxwDesignerManager::NotifyPropertyChanged(wxwDesigner *designer, rcmProperty *prop, wxwComponent *comp, bool post)
{
    if (prop && comp) {
        if (post)
            PostEvent(new PropertyChangedEvent(designer, prop, comp));
    }
    Modified();
}


void wxwDesignerManager::NotifyEventChanged(wxwDesigner *designer, rcmEvent *event, wxwComponent *comp, bool post)
{
    if (event && comp) {
        if (post) {
            PostEvent(new EventChangedEvent(designer, event, comp));
        }
    }
    Modified();
}

void wxwDesignerManager::NotifyEventSinkRenamed(const wxString &newName, const wxString &oldName)
{
	if (FRoot) {
	    FRoot->RenameHandler(newName, oldName);
    	Modified();
    }
}

void wxwDesignerManager::NotifyEventSinkAdded(wxwEventConnection *connection)
{
	if (FRoot) {
	    FRoot->AssignHandler(connection);
    	Modified();
    }
}

void wxwDesignerManager::NotifyEventSinkDeleted(const wxString &handlerName)
{
	if (FRoot) {
	    FRoot->RemoveHandler(handlerName);
    	Modified();
    }
}

void wxwDesignerManager::Insert(wxwComponent *comp)
{
	if (comp) {
        if (dynamic_cast<wxwRootComponent*>(comp)) {
            FRoot = dynamic_cast<wxwRootComponent*>(comp);
        }
        if (comp != FRoot && FRoot) {
            FRoot->AddComponentProperty(comp);
        }
//        if (!FRoot) {
//            throw runtime_error(wxString::Format(
//                "Cannot insert component \"%s\" \n \
//                 There is no root component.",
//                 comp->GetName()).c_str());
//        }
        FComponentMap[comp->Key()] = comp;
    }
}

void wxwDesignerManager::Remove(wxwComponent *comp)
{
	if (comp) {
        if (comp == FRoot) {
            FRoot = 0;
        }
		FComponentMap.erase(comp->Key());
    }
}

wxwComponent* wxwDesignerManager::FindComponentByKey(const wxString& key)
{
	ComponentMap::iterator it = FComponentMap.find(key);
	return it == FComponentMap.end() ? 0 : (*it).second;
}

wxwComponent* wxwDesignerManager::FindComponentByName(const wxString &name)
{
	ComponentMap::iterator it = find_if(FComponentMap.begin(), FComponentMap.end(),
		bind2nd(comp_has_name(), name));
	return it == FComponentMap.end() ? 0 : (*it).second;
}

wxwComponent* wxwDesignerManager::FindComponentByInstance(const wxObject *instance)
{
	ComponentMap::iterator it = find_if(FComponentMap.begin(), FComponentMap.end(),
		bind2nd(comp_has_instance(), instance));
    return it != FComponentMap.end() ? (*it).second : 0;
}

//---------------------------------------------------------------------------

