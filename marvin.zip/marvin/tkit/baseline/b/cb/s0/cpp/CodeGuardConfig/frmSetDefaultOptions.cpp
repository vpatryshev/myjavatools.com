#include <vcl.h>
#pragma hdrstop

#include "frmSetDefaultOptions.h"

#pragma package(smart_init)
#pragma resource "*.dfm"

TfrmSetDefaultFunctionOptions *frmSetDefaultFunctionOptions;

__fastcall TfrmSetDefaultFunctionOptions::TfrmSetDefaultFunctionOptions(TComponent* Owner)

  : TForm(Owner)

{}







