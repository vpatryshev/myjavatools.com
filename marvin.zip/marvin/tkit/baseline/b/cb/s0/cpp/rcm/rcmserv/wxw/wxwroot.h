#ifndef wxwrootH
#define wxwrootH

#include "wxw.h"
#include "wxwcontainer.h"

class wxRootClassInfo;

class wxwEventConnection
{
public:
    wxwEventConnection(const wxString &sinkName, const wxPropertyInfo *sourceInfo, wxwComponent *source)
        : FName(sinkName), FSource(source), FPropInfo(sourceInfo) { }

    wxString& GetSinkName();
    wxwComponent* GetSource();
    const wxPropertyInfo* GetSourcePropInfo();
    const wxDelegateTypeInfo* GetSourceTypeInfo();
    void SetSinkName(const wxString &newName);

private:
    wxString FName;
    const wxPropertyInfo *FPropInfo;
    wxwComponent *FSource;
};

typedef hash_map<wxString, wxwEventConnection*, hash<wxString&> > eventConnections;

class wxwRootComponent : public wxwComponent, public wxwContainer
{
public:
	wxwRootComponent(const wxClassInfo *classInfo, wxwDesigner *designer, wxwContainer *container);
    virtual ~wxwRootComponent();

    virtual void AddComponentProperty(wxwComponent *comp);
    void AddHandler(const wxString &handlerName, const wxClassInfo *eventClass);
    virtual void AssignHandler(wxwEventConnection *connection);
    wxDynamicClassInfo* DynamicClassInfo();
    wxDynamicObject* DynamicInstance();
    const wxHandlerInfo* GetHandler(const wxString &handlerName);
    wxwEventConnection* GetEventConnection(const wxPropertyInfo *propInfo, const wxwComponent *source);
    bool HasHandler(const wxString &handlerName);
    bool HasProperty(const wxString &propName);
    virtual void RemoveComponentProperty(wxwComponent *comp);
    virtual void RemoveHandler(const wxString &handlerName);
    virtual void RenameComponentProperty(wxwComponent *comp, const wxString &oldName);
    virtual void RenameHandler(const wxString &oldName, const wxString &newName);

	// wxwComponent overrides

    void InternalSetParent(wxwContainer *newContainer);
    virtual void SetInstance(wxObject *instance);

    virtual bool CanDispose() { return false; }
    virtual wxObject* Instance();
    virtual bool IsContainer() { return true; }
    virtual void Recreate() { /* can't recreate the top level component yet */ }
	virtual Result* SetName(const wxString &newName);
protected:
    virtual void NewInstance();

private:
    void CheckClassName(const wxString &className);
    void RenameClass(const wxString &newClassName);
    wxxVariant GetComponentInstance(wxwComponent *component);
    wxDynamicClassInfo* FDCI;
    eventConnections FEventConnections;
};

#endif
