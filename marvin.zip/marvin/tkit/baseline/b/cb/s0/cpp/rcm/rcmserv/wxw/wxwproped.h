#ifndef wxwpropedH
#define wxwpropedH

#include "wxwproperty.h"

enum wxColourElementType { wxCET_Red, wxCET_Blue, wxCET_Green };

class wxColourElementProperty : public xtiProperty
{
public:
    wxColourElementProperty(wxColourElementType type);

protected:
    virtual void Set(const wxString &value);
    virtual wxString Get() const;

private:
    wxColourElementType FType;
};

class wxColourProperty : public xtiProperty
{
DECLARE_DYNAMIC_CLASS(wxColourProperty)
public:
    wxColourProperty();

	virtual void Create(
		const wxPropertyInfo *propInfo = 0,
		wxwDesigner *designer = 0,
		wxObject *instance = 0,
		wxPropertyBase *parent = 0,
		const wxString &name = "");


    virtual void GetChoices(PropertyChoices &choices);

protected:
   	virtual wxString Get() const;
    virtual void Set(const wxString &value);
};

class wxWindowPosProperty : public xtiProperty
{
DECLARE_DYNAMIC_CLASS(wxWindowPosProperty)
public:
	wxWindowPosProperty();
protected:
    virtual void SetAsVariant(const wxxVariant &value);
};

class wxWindowSizeProperty : public xtiProperty
{
DECLARE_DYNAMIC_CLASS(wxWindowSizeProperty)
public:
	wxWindowSizeProperty();
protected:
    virtual void SetAsVariant(const wxxVariant &value);
};

class RCMEXPORT wxFontFaceProperty : public xtiProperty
{
DECLARE_DYNAMIC_CLASS(wxFontFaceProperty)
public:
	wxFontFaceProperty();

    virtual void GetChoices(PropertyChoices &choices);
};

// Some properties are really ints, but have enums associated with them.
// So we have to deal with them specially.

class RCMEXPORT wxIntAsEnumProperty : public xtiProperty
{
DECLARE_ABSTRACT_CLASS(wxIntAsEnumProperty)
public:
	wxIntAsEnumProperty();

	virtual void Create(
		const wxPropertyInfo *propInfo = 0,
		wxwDesigner *designer = 0,
		wxObject *instance = 0,
		wxPropertyBase *parent = 0,
		const wxString &name = "");

    virtual void GetChoices(PropertyChoices &choices);

protected:
    virtual void Set(const wxString &value);
    virtual wxString Get() const;
    virtual wxTypeInfo* GetTypeInfo() = 0;
private:
    const wxEnumData *FEnumData;
};

#define INT_AS_ENUM_EDITORCLASS( enumName ) \
    wxIntAs##enumName

#define DECLARE_WX_INT_AS_ENUM_EDITOR( enumName ) \
class RCMEXPORT INT_AS_ENUM_EDITORCLASS( enumName ) : public wxIntAsEnumProperty \
{ \
DECLARE_DYNAMIC_CLASS(INT_AS_ENUM_EDITORCLASS( enumName )) \
protected: \
    virtual wxTypeInfo* GetTypeInfo() { return wxTypeInfo::FindType(#enumName); } \
}; \
IMPLEMENT_DYNAMIC_CLASS(INT_AS_ENUM_EDITORCLASS( enumName ), wxIntAsEnumProperty)

class wxControlIdProperty : public wxIntProperty
{
DECLARE_DYNAMIC_CLASS(wxControlIdProperty)
public:
	wxControlIdProperty();
};

class wxWindowFlagsProperty : public wxSetProperty
{
DECLARE_DYNAMIC_CLASS(wxWindowFlagsProperty)
public:
    wxWindowFlagsProperty();
};

#endif


