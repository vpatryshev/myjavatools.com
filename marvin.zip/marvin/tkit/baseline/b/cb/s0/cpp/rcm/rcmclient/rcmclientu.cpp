//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include <assert.h>

#include "soapWSComponentModelServerService.nsmap"
#include "soapstub.h"
#include "rcmclientu.h"
#include "compcreateform.h"
#include "messagedialog.h"
#include "imagedialog.h"
#include "sizedialog.h"
#include "sharedmem.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

#define SUCCESS(x) x == SOAP_OK

const char *signature = "rcmimage";
const char *modelImageCmd = "model";
const char *uiImageCmd = "comp";

TForm1 *Form1;
struct soap soap;

static const AnsiString None = "(none)";
AnsiString designerKey = "";
AnsiString compInfoKey = "";
AnsiString compCatKey = "";
AnsiString compKey = "";

impl__WSPalettePage *curPage = 0;
impl__WSComponentModel *curModel = 0;
ArrayOfWSComponentModel *models = 0;
impl__WSLiveDesignerManager *mgr = 0;
impl__WSLiveDesigner *designer = 0;
impl__WSLiveComponent *curComp = 0;
PPropPair curProp = 0;
PEventPair curEvent = 0;
list<impl__WSComponentInfo*> compInfos;
//compInfoHash compInfos;

class rcmTransportClient : public TTransportClient
{
public:
    rcmTransportClient(struct soap *soap, const char *host = 0, int port = 0);
    ~rcmTransportClient();

    int SoapSend(const char *data, size_t size);
    size_t SoapRecv(char *data, size_t size);
    int SoapFClose();
    int SoapFOpen(const char *endpoint, const char *host, int port);
    char* ServerURL();
private:
    size_t bytesWritten;
    size_t bytesRead;
    int FPort;
    AnsiString FHost;
    AnsiString FServerURL;
};

rcmTransportClient *transport = 0;

int mysend(struct soap *soap, const char *s, size_t n)
{
    return transport->SoapSend(s, n);
}

unsigned int myrecv(struct soap *soap, char *s, size_t n)
{
    return transport->SoapRecv(s, n);
}

int myopen(struct soap *soap, const char *s, const char *t, int n)
{
    return transport->SoapFOpen(s, t, n); // fake file descriptor, return -1 when error
}

int myclose(struct soap *soap)
{
    return transport->SoapFClose();
}

// rcmTransportClient

rcmTransportClient::rcmTransportClient(struct soap *soap, const char *host, int port)
    : TTransportClient("RCM_WXW", MAX_SHMEM_SIZE)
{
    bytesWritten = 0;
    bytesRead = 0;
    FHost = host;
    FPort = port;
	soap_init(soap);
    if (!FPort) {
        soap->fsend = mysend;
        soap->frecv = myrecv;
        soap->fopen = myopen;
        soap->fclose = myclose;
    }
    FServerURL.sprintf("http://%s:%d", FHost, FPort);
}

rcmTransportClient::~rcmTransportClient()
{
}

char* rcmTransportClient::ServerURL()
{
    return FServerURL.c_str();
}

int rcmTransportClient::SoapFClose()
{
    Unlock();
    bytesRead = 0;
    ::ResetEvent(hSoapDone);
    return SOAP_OK;
}

int rcmTransportClient::SoapFOpen(const char *endpoint, const char *host, int port)
{
    return 0;
}

int rcmTransportClient::SoapSend(const char *data, size_t size)
{
    int code = SOAP_EOF;
    if (Lock()) {
        SoapData *d = (SoapData*)pMem;
        if (bytesWritten + size < MAX_DATASIZE) {
            strncpy(d->data + bytesWritten, data, size);
            bytesWritten += size;
            code = SOAP_OK;
            if (size < SOAP_BUFLEN) {
                // done writing.
                // signal the server we have a request.
                d->key = BYTE_DATA;
                d->size = bytesWritten;
                bytesWritten = 0;
                Unlock();
                ::ResetEvent(hSoapDone);
                ::SetEvent(hSoapRequest);
            }
        }
        else
            code = SOAP_EOM;
    }
    return code;
}

size_t rcmTransportClient::SoapRecv(char *s, size_t size)
{
    size_t read = 0;
    bool signalled = (WaitForSingleObject(hSoapDone, INFINITE) == WAIT_OBJECT_0 && Lock());
    if (signalled && ((Request*)pMem)->key == BYTE_DATA) {
        // block until soap server is done.
        SoapData *data = (SoapData*)pMem;
        read = std::min(size, data->size - bytesRead);
        if (bytesRead + read < MAX_DATASIZE) {
            char *src = &(data->data[bytesRead]);
            strncpy(s, src, read);
            bytesRead += read;
        }
        else
            read = 0;
    }
    return read;
}

void ClearVLE(TValueListEditor *ve)
{
	ve->Strings->BeginUpdate();
	ve->Strings->Clear();
	ve->Strings->EndUpdate();
}

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormCreate(TObject *Sender)
{
    int port = 0;
    if (ParamCount() > 1) {
        AnsiString arg = ParamStr(1);
        int swPos = arg.Pos("-p");
        if (swPos == 1) {
	        arg.Delete(1, 2);
    	    try {
        	    port = StrToInt(arg);
        	}
       	 	catch (Exception &e) {
            	// silent.
        	}
        }
    }
    compBmp = new Graphics::TBitmap();
    transport = new rcmTransportClient(&soap, "localhost", port);
    impl__server_USCORE_GetComponentModelsResponse cmr;
	if (soap_call_impl__server_USCORE_GetComponentModels(
                &soap,
                transport->ServerURL(),
                "",
                &cmr) == SOAP_OK)
        {
    	ArrayOfWSComponentModel *models = cmr._server_USCORE_GetComponentModelsReturn;
        soap_unlink(&soap, models);
        impl__WSComponentModel *model = 0;
		for (int i=0; i<models->__size; i++) {
        	model = models->__ptr;
            curModel = model;
	    	cbModels->Items->AddObject(model->displayName, (TObject*)model);
            model++;
        }
    }
    veModel->InsertRow("", "", true);
	cbModels->ItemIndex = 0;
    cbModelsClick(this);
    CreateDesignersClick(this);
    CreateTLComponent();

}
//---------------------------------------------------------------------------
void __fastcall TForm1::cbModelsClick(TObject *Sender)
{
	ClearVLE(veModel);
    ClearVLE(veCompInfos);
    ClearVLE(veDesignerInfo);
    cbDesignerInfos->Clear();
	if (cbModels->ItemIndex >= 0) {
    	curModel = reinterpret_cast<impl__WSComponentModel*>(cbModels->Items->Objects[cbModels->ItemIndex]);
        if (curModel) {

            impl__model_USCORE_GetDefaultDesignerInfoResponse gddir;
            if (soap_call_impl__model_USCORE_GetDefaultDesignerInfo(
                &soap,
                transport->ServerURL(),
                "",
                curModel->modelKey,
                &gddir) == SOAP_OK) {
                impl__WSDesignerInfo *di = gddir._model_USCORE_GetDefaultDesignerInfoReturn;
                if (di)
                    cbDesignerInfos->Items->AddObject(di->displayName, (TObject*)di);
            }

            impl__model_USCORE_GetUIDesignerInfoResponse guidir;
            if (soap_call_impl__model_USCORE_GetUIDesignerInfo(
                &soap,
                transport->ServerURL(),
                "",
                curModel->modelKey,
                &guidir) == SOAP_OK) {
                impl__WSDesignerInfo *di = guidir._model_USCORE_GetUIDesignerInfoReturn;
                if (di)
                    cbDesignerInfos->Items->AddObject(di->displayName, (TObject*)di);
            }

            if (cbDesignerInfos->Items->Count > 0) {
                cbDesignerInfos->ItemIndex = 0;
            }

        	impl__model_USCORE_CreateDesignerManagerResponse cdmr;
       	    assert(soap_call_impl__model_USCORE_CreateDesignerManager(
            	&soap,
                transport->ServerURL(),
                "",
                curModel->modelKey,
                &cdmr) == SOAP_OK);

            mgr = cdmr._model_USCORE_CreateDesignerManagerReturn;
            assert(mgr != NULL);

            veModel->InsertRow("modelKey", curModel->modelKey, true);
            veModel->InsertRow("displayName", curModel->displayName, true);
            veModel->InsertRow("description", curModel->description, true);
            veModel->InsertRow("imageURI", curModel->displayIconURI, true);

            impl__model_USCORE_GetPalettePagesResponse gppr;
            assert(soap_call_impl__model_USCORE_GetPalettePages(
                &soap,
                transport->ServerURL(),
                "",
                curModel->modelKey,
                &gppr) == SOAP_OK);

            ArrayOfWSPalettePage *pps = gppr._model_USCORE_GetPalettePagesReturn;
            impl__WSPalettePage *pp = pps->__ptr;
            if (pp) {
                for (int i=0; i<pps->__size; i++) {
                    impl__palette_USCORE_GetComponentInfosResponse pcir;
				    if (soap_call_impl__palette_USCORE_GetComponentInfos(
                      	&soap,
                      	transport->ServerURL(),
                      	"",
                     	curModel->modelKey,
                      	pp->pageKey,
                      	&pcir) == SOAP_OK) {

        				ArrayOfWSComponentInfo *cis = pcir._palette_USCORE_GetComponentInfosReturn;
				        impl__WSComponentInfo *ci = cis->__ptr;
				        if (ci) {
				            for (int j=0; j<cis->__size; j++) {
                            	AnsiString nvp;
                                nvp.sprintf("%s=%s", ci->displayName, pp->pageTitle);
                                veCompInfos->Strings->AddObject(nvp, (TObject*)ci);
				                compInfos.push_back(ci);
			    	            ci++;
                            }
                       	}
				        soap_delete(&soap, cis);
                    }
                    pp++;
                }
            }
        }
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormDestroy(TObject *Sender)
{
 	soap_end(&soap);
    soap_done(&soap);
    delete transport;
}
//---------------------------------------------------------------------------

ArrayOf_USCORE_xsd_USCORE_string* NewTagKeys(TMenuItem *item)
{
    ArrayOf_USCORE_xsd_USCORE_string *tagKeys = soap_new_ArrayOf_USCORE_xsd_USCORE_string(&soap, -1);
    tagKeys->__ptr = (char**)soap_malloc(&soap, sizeof(char*));
    tagKeys->__size = 1; // for now.
    tagKeys->__ptr[0] = (char*)item->Tag;
    tagKeys->__offset = 0;
    return tagKeys;
}

ArrayOf_USCORE_xsd_USCORE_string* NewPropInfoKeys(impl__WSPropertyInfo *pi)
{
    ArrayOf_USCORE_xsd_USCORE_string *propInfoKeys = soap_new_ArrayOf_USCORE_xsd_USCORE_string(&soap, -1);
    propInfoKeys->__ptr = pi->propertyKeyPath;
    propInfoKeys->__size = pi->__size_;
    propInfoKeys->__offset = 0;
    return propInfoKeys;
}

ArrayOf_USCORE_xsd_USCORE_string* NewEventInfoKeys(impl__WSEventInfo *ei)
{
    ArrayOf_USCORE_xsd_USCORE_string *eventInfoKeys = soap_new_ArrayOf_USCORE_xsd_USCORE_string(&soap, -1);
    eventInfoKeys->__ptr = ei->eventKeyPath;
    eventInfoKeys->__size = ei->__size_;
    eventInfoKeys->__offset = 0;
    return eventInfoKeys;
}


void __fastcall TForm1::AddPropertyNode(TTreeNode *node, impl__WSLiveProperty *pi, impl__WSLiveComponent *c)
{
	assert(pi);
	PPropPair propPair = new TPropPair;
    propPair->pInfo = pi;
    propPair->pLive = pi;
    TTreeNode *newNode = tvProps->Items->AddChildObject(node, pi->valueAsText, propPair);
    newNode->HasChildren = pi->hasChildren;
}

void __fastcall TForm1::AddPropertyNode(TTreeNode *node, impl__WSPropertyInfo *pi, impl__WSLiveComponent *c)
{
	assert(pi);
	PPropPair propPair = new TPropPair;
    propPair->pInfo = pi;
    propPair->pLive = 0;
    TTreeNode *newNode = tvProps->Items->AddChildObject(node, pi->displayName, propPair);

    ArrayOf_USCORE_xsd_USCORE_string *propKeys = NewPropInfoKeys(pi);
    impl__comp_USCORE_GetPropertyResponse cgpr;
    if (soap_call_impl__comp_USCORE_GetProperty(
        &soap,
        transport->ServerURL(),
        "",
        mgr->modelKey,
        mgr->managerInstanceKey,
        c->instanceKey,
        propKeys,
        &cgpr) == SOAP_OK)
    {
        (reinterpret_cast<PPropPair>(newNode->Data))->pLive = cgpr._comp_USCORE_GetPropertyReturn;
    }
    if (propKeys) soap_delete(&soap, propKeys);
    newNode->HasChildren = pi->hasChildren;
//    if (newNode->HasChildren)
//        ExpandPropNode(newNode);
}

void __fastcall TForm1::AddEventNode(TTreeNode *node, impl__WSEventInfo *ei, impl__WSLiveComponent *c)
{
	assert(ei);
	PEventPair EventPair = new TEventPair;
    EventPair->eInfo = ei;
    EventPair->eLive = 0;
    TTreeNode *newNode = tvEvents->Items->AddChildObject(node, ei->displayName, EventPair);

    ArrayOf_USCORE_xsd_USCORE_string *EventKeys = NewEventInfoKeys(ei);
    impl__comp_USCORE_GetEventResponse cgpr;
    if (soap_call_impl__comp_USCORE_GetEvent(
        &soap,
        transport->ServerURL(),
        "",
        mgr->modelKey,
        mgr->managerInstanceKey,
        c->instanceKey,
        EventKeys,
        &cgpr) == SOAP_OK)
    {
        (reinterpret_cast<PEventPair>(newNode->Data))->eLive = cgpr._comp_USCORE_GetEventReturn;
    }
    if (EventKeys) soap_delete(&soap, EventKeys);
    newNode->HasChildren = ei->hasChildren;
}

void __fastcall TForm1::AddEventNode(TTreeNode *node, impl__WSLiveEvent *ei, impl__WSLiveComponent *c)
{
}

void __fastcall TForm1::ExpandPropNode(TTreeNode *node)
{
	assert(node && node->Data);
	PPropPair pp = reinterpret_cast<PPropPair>(node->Data);
    impl__WSPropertyInfo *pi = pp->pInfo;
    impl__WSLiveProperty *p = pp->pLive;
    if (pi->hasChildren) {
//    	assert(p->hasChildren);
        ArrayOf_USCORE_xsd_USCORE_string *propInfoKeys = NewPropInfoKeys(pi);

/*        impl__prop_USCORE_GetPropertiesResponse gpr;
        if (
            soap_call_impl__prop_USCORE_GetProperties(
                &soap,
                transport->ServerURL(),
                "",
                mgr->modelKey,
                mgr->managerInstanceKey,
                curComp->instanceKey,
                propInfoKeys,
                &gpr
            ) == SOAP_OK)
            {
            ArrayOfWSLiveProperty *ps = gpr._prop_USCORE_GetPropertiesReturn;
            if (ps) {
                for (int i=0; i<ps->__size; i++) {
                    AddPropertyNode(node, &(ps->__ptr[i]), curComp);
                }
            }
*/
        impl__propinfo_USCORE_GetPropertyInfosResponse gpir;
        if (
        	soap_call_impl__propinfo_USCORE_GetPropertyInfos(
        		&soap,
	            transport->ServerURL(),
    	        "",
        	    mgr->modelKey,
            	curComp->componentTypeKey,
                mgr->managerInstanceKey,
                designer->designerKey,
                curComp->instanceKey,
	            propInfoKeys,
    	        &gpir) == SOAP_OK)
            {
        	ArrayOfWSPropertyInfo *pis = gpir._propinfo_USCORE_GetPropertyInfosReturn;
            if (pis) {
            	for (int i=0; i<pis->__size; i++) {
					AddPropertyNode(node, &(pis->__ptr[i]), curComp);
            	}
                node->AlphaSort(false);
            }

        }
        soap_delete(&soap, propInfoKeys);
    }

}

void __fastcall TForm1::ListProperties(impl__WSLiveComponent *c)
{
    assert(curModel != NULL);

    TTreeNode *node = tvProps->Items->GetFirstNode();
    while (node) {
    	PPropPair pp = reinterpret_cast<PPropPair>(node->Data);
    	soap_delete(&soap, pp->pInfo);
    	soap_delete(&soap, pp->pLive);
        delete pp;
        node = node->GetNext();
    }
    tvProps->Items->Clear();

    if (!c) return;

    impl__model_USCORE_GetComponentInfoResponse gcir;
    if (!(soap_call_impl__model_USCORE_GetComponentInfo(
        &soap,
        transport->ServerURL(),
        "",
        mgr->modelKey,
        c->componentTypeKey,
        &gcir) == SOAP_OK)) {
        return;
    }

    impl__WSComponentInfo *ci = gcir._model_USCORE_GetComponentInfoReturn;
    if (!ci) return;

    impl__comp_USCORE_GetPropertiesResponse pir;
	soap_call_impl__comp_USCORE_GetProperties(
        &soap,
        transport->ServerURL(),
        "",
        curModel->modelKey,
        mgr->managerInstanceKey,
        c->instanceKey,
        &pir);

/*    impl__compinfo_USCORE_GetPropertyInfosResponse pir;
	soap_call_impl__compinfo_USCORE_GetPropertyInfos(
    	&soap,
        transport->ServerURL(),
        "",
        curModel->modelKey,
        ci->compTypeKey,
        &pir);
*/
    ArrayOfWSLiveProperty *pis = pir._comp_USCORE_GetPropertiesReturn;
    if (pis && pis->__size > 0) {
        impl__WSLiveProperty *pi = pis->__ptr;
       	tvProps->Items->BeginUpdate();
        try {
	        for (int i=0; i<pis->__size; i++) {
            	AddPropertyNode(NULL, (impl__WSPropertyInfo*)pi, c);
	            pi++;
        	}
        }
        __finally {
	       	tvProps->Items->EndUpdate();
        }
    }
}

void __fastcall TForm1::ListEvents(impl__WSLiveComponent *c)
{
    assert(curModel != NULL);

    TTreeNode *node = tvEvents->Items->GetFirstNode();
    while (node) {
    	PEventPair ep = reinterpret_cast<PEventPair>(node->Data);
    	soap_delete(&soap, ep->eInfo);
    	soap_delete(&soap, ep->eLive);
        delete ep;
        node = node->GetNext();
    }
    tvEvents->Items->Clear();

    if (!c) return;

    impl__model_USCORE_GetComponentInfoResponse gcir;
    if (!(soap_call_impl__model_USCORE_GetComponentInfo(
        &soap,
        transport->ServerURL(),
        "",
        mgr->modelKey,
        c->componentTypeKey,
        &gcir) == SOAP_OK)) {
        return;
    }

    impl__WSComponentInfo *ci = gcir._model_USCORE_GetComponentInfoReturn;
    if (!ci) return;

    impl__compinfo_USCORE_GetEventInfosResponse eir;
	soap_call_impl__compinfo_USCORE_GetEventInfos(
    	&soap,
        transport->ServerURL(),
        "",
        curModel->modelKey,
        ci->compTypeKey,
        &eir);

    ArrayOfWSEventInfo *eis = eir._compinfo_USCORE_GetEventInfosReturn;
    if (eis && eis->__size > 0) {
        impl__WSEventInfo *ei = eis->__ptr;
       	tvProps->Items->BeginUpdate();
        try {
	        for (int i=0; i<eis->__size; i++) {
            	AddEventNode(NULL, ei, c);
	            ei++;
        	}
        }
        __finally {
	       	tvProps->Items->EndUpdate();
        }
    }
}

//---------------------------------------------------------------------------

void __fastcall TForm1::CreateDesignersClick(TObject *Sender)
{
	assert(mgr != NULL);

    impl__manager_USCORE_GetDefaultDesignerResponse mddr;
    assert(soap_call_impl__manager_USCORE_GetDefaultDesigner(
    	&soap,
        transport->ServerURL(),
        "",
        mgr->modelKey,
        mgr->managerInstanceKey,
        &mddr) == SOAP_OK);

    designer = mddr._manager_USCORE_GetDefaultDesignerReturn;
    if (designer)
	    cbDesigners->Items->Add(strcat("Default: ", designer->displayName));
    else
	    cbDesigners->Items->Add("Default: None");


	impl__manager_USCORE_GetUIDesignerResponse muidr;
    assert(soap_call_impl__manager_USCORE_GetUIDesigner(
        &soap,
        transport->ServerURL(),
        "",
        mgr->modelKey,
        mgr->managerInstanceKey,
        &muidr) == SOAP_OK);

    designer = muidr._manager_USCORE_GetUIDesignerReturn;
    if (designer)
		cbDesigners->Items->Add(strcat("UI: ", designer->displayName));
    else
		cbDesigners->Items->Add("UI: None");

    cbDesigners->ItemIndex = 1;
    cbDesignersClick(this);

}
//---------------------------------------------------------------------------

void __fastcall TForm1::cbDesignersClick(TObject *Sender)
{
	assert(mgr != NULL);

    switch (cbDesigners->ItemIndex) {
        case 0: // default
		{
		    impl__manager_USCORE_GetDefaultDesignerResponse mddr;
		    assert(SUCCESS(soap_call_impl__manager_USCORE_GetDefaultDesigner(
    			&soap,
		        transport->ServerURL(),
		        "",
		        mgr->modelKey,
		        mgr->managerInstanceKey,
		        &mddr))
		    );
		    designer = mddr._manager_USCORE_GetDefaultDesignerReturn;
            break;
        }
        case 1: // ui
		{
        	impl__manager_USCORE_GetUIDesignerResponse muidr;
		    assert(SUCCESS(soap_call_impl__manager_USCORE_GetUIDesigner(
		        &soap,
		        transport->ServerURL(),
		        "",
		        mgr->modelKey,
		        mgr->managerInstanceKey,
        		&muidr))
		    );
		    designer = muidr._manager_USCORE_GetUIDesignerReturn;
            break;
        }
        default:
        	ShowMessage("Invalid designer");
            return;
    }

    if (designer) {
		ClearVLE(veDesigner);
        veDesigner->InsertRow("Key", designer->designerKey, true);
        veDesigner->InsertRow("DisplayName", designer->displayName, true);
        veDesigner->InsertRow("Description", designer->description, true);
        veDesigner->InsertRow("IconURI", designer->displayIconURI, true);
        veDesigner->InsertRow("ManagerKey", designer->managerInstanceKey, true);

		impl__WSLiveUIDesigner *uid = dynamic_cast<impl__WSLiveUIDesigner*>(designer);
        if (uid) {
            AnsiString crStr = "None";
            if (uid->designerClientRect)
                crStr.sprintf("%d %d %d %d",
    	           	uid->designerClientRect, uid->designerClientRect->y,
        	        uid->designerClientRect->width, uid->designerClientRect->height);
            veDesigner->InsertRow("clientRect", crStr, true);
            veDesigner->InsertRow("DesignerImageURI", uid->designerImageURI, true);
			veDesigner->InsertRow("ConstrainChildren", uid->constrainChildrenToClientRect ? "true" : "false", true);
            veDesigner->InsertRow("DesignRectCount", uid->__size_, true);
	    }
        PopulateComponentsTree();
    }
}


void __fastcall TForm1::PopulateComponentsTree()
{
	assert(designer != NULL);
    AnsiString selectedName = tvComps->Selected ? tvComps->Selected->Text : AnsiString("");
    TTreeNode *node = tvComps->Items->GetFirstNode();
    while (node) {
    	soap_delete(&soap, node->Data);
        node = node->GetNext();
    }
    tvComps->Items->Clear();

    if (dynamic_cast<impl__WSLiveUIDesigner*>(designer)) {

        impl__uidesigner_USCORE_GetRootUIComponentsResponse rcr;
        assert(SUCCESS(
            soap_call_impl__uidesigner_USCORE_GetRootUIComponents(
                &soap,
                transport->ServerURL(),
                "",
                mgr->modelKey,
                mgr->managerInstanceKey,
                designer->designerKey,
                &rcr)));

        ArrayOfWSLiveUIComponent *roots = rcr._uidesigner_USCORE_GetRootUIComponentsReturn;

        if (roots && roots->__size > 0) {
            impl__WSLiveUIComponent *c = roots->__ptr;
            for (int i=0; i<roots->__size; i++) {
                if (c->container)
                    RecurseComponents(c, 0);
                c++;
            }
        }
    }
    else {
        impl__designer_USCORE_GetRootComponentsResponse rcr;
        assert(SUCCESS(
            soap_call_impl__designer_USCORE_GetRootComponents(
                &soap,
                transport->ServerURL(),
                "",
                mgr->modelKey,
                mgr->managerInstanceKey,
                designer->designerKey,
                &rcr)));

        ArrayOfWSLiveComponent *roots = rcr._designer_USCORE_GetRootComponentsReturn;

        if (roots && roots->__size > 0) {
            impl__WSLiveComponent *c = roots->__ptr;
            for (int i=0; i<roots->__size; i++) {
                if (c->container)
                    RecurseComponents(c, 0);
                c++;
            }
        }
    }
    // restore selection if possible.
    if (selectedName.Length() > 0) {
        for (int i=0; i<tvComps->Items->Count; i++) {
            if (tvComps->Items->Item[i]->Text == selectedName) {
                tvComps->Selected = tvComps->Items->Item[i];
                this->tvPropsClick(this);
                break;
            }
        }
    }
}

void __fastcall TForm1::RecurseComponents(impl__WSLiveComponent *comp, TTreeNode *parentNode)
{
	assert(comp != NULL && mgr != NULL);
	TTreeNode *newNode = tvComps->Items->AddChildObject(parentNode, comp->instanceName, comp);
    AnsiString s;
    s.sprintf("%s : %s", comp->instanceName, comp->componentTypeKey);

    // stupid architecture makes this necessary.
    impl__WSLiveUIComponent *uic = dynamic_cast<impl__WSLiveUIComponent*>(comp);
    if (uic) {
        impl__uicomp_USCORE_GetAsContainerResponse gacr;
        soap_call_impl__uicomp_USCORE_GetAsContainer(
            &soap,
            transport->ServerURL(),
            "",
            mgr->modelKey,
            mgr->managerInstanceKey,
            comp->designerKey,
            comp->instanceKey,
            &gacr);

        impl__WSLiveUIContainer *cont = gacr._uicomp_USCORE_GetAsContainerReturn;
        if (cont && cont->__size__ > 0) {
            impl__WSLiveUIComponent *child = cont->uiComponents;
            for (int i=0; i<cont->__size__; i++) {
                if (child)
                    RecurseComponents(child, newNode);
                child++;
            }
        }
    }
    else {
        impl__comp_USCORE_GetAsContainerResponse gacr;
        soap_call_impl__comp_USCORE_GetAsContainer(
            &soap,
            transport->ServerURL(),
            "",
            mgr->modelKey,
            mgr->managerInstanceKey,
            comp->designerKey,
            comp->instanceKey,
            &gacr);

        impl__WSLiveContainer *cont = gacr._comp_USCORE_GetAsContainerReturn;
        if (cont && cont->__size_ > 0) {
            impl__WSLiveComponent *child = cont->components;
            for (int i=0; i<cont->__size_; i++) {
                if (child)
                    RecurseComponents(child, newNode);
                child++;
            }
        }
    }
}

//---------------------------------------------------------------------------


void DrawDesignRects(impl__WSLiveUIComponent *c, Graphics::TBitmap *b)
{
    if (!c || !(c->designRects)) return;
    b->Canvas->Pen->Color = clFuchsia;
    b->Canvas->Brush->Style = bsClear;
    impl__WSUIDesignRect *dr;
    int mid = b->Height / 2;
    dr = c->designRects;
    for (int i=0; i<c->__size_; i++) {
        impl__WSRect *r = dr->rect;
        int top = r->y;
        int bottom = r->y + r->height;
//        int bottom = r->y + (2 * (mid - r->y));
//        int top = (r->y + r->height) + (2 * (mid - (r->y + r->height)));
        b->Canvas->Rectangle(r->x, top, r->x + r->width, bottom);
        dr++;
    }
}

typedef struct {
    BITMAPV4HEADER    bmiHeader;
    RGBQUAD           bmiColors[1];
} BITMAPV4INFO;


BITMAPV4INFO BitmapV4Info(int w, int h)
{
    BITMAPV4HEADER bih;
    bih.bV4Size = sizeof(BITMAPV4HEADER);
    bih.bV4Width = w;
    bih.bV4Height = -h; // create top-down
    bih.bV4Planes = 1;
    bih.bV4BitCount = 32;
    bih.bV4V4Compression = BI_BITFIELDS;
    bih.bV4SizeImage = w * h * 4;
    bih.bV4XPelsPerMeter = 0;
    bih.bV4YPelsPerMeter = 0;
    bih.bV4ClrUsed = 0;
    bih.bV4ClrImportant = 0;
    bih.bV4AlphaMask =  0xFF000000;
    bih.bV4RedMask =    0x00FF0000;
    bih.bV4GreenMask =  0x0000FF00;
    bih.bV4BlueMask =   0x000000FF;
    bih.bV4CSType = LCS_sRGB;
    bih.bV4GammaRed = 0;
    bih.bV4GammaGreen = 0;
    bih.bV4GammaBlue = 0;

    BITMAPV4INFO bi;
    bi.bmiHeader = bih;
    bi.bmiColors[0].rgbBlue = 0;
    bi.bmiColors[0].rgbGreen = 0;
    bi.bmiColors[0].rgbRed = 0;
    bi.bmiColors[0].rgbReserved = 0;
    return bi;
}


void __fastcall TForm1::PaintUIComponent(impl__WSLiveUIComponent *uic, TRect &rect)
{
    int time = ::GetTickCount();
#ifdef USE_SOCKETS
    TCPClient->Connect();
    TMemoryStream *command = new TMemoryStream();
    try {
    	command->Write(signature, strlen(signature)+1);
        command->Write(uiImageCmd, strlen(uiImageCmd)+1);
        command->Write(mgr->modelKey, strlen(mgr->modelKey)+1);
        command->Write(mgr->managerInstanceKey, strlen(mgr->managerInstanceKey)+1);
        command->Write(designer->designerKey, strlen(designer->designerKey)+1);
        command->Write(c->instanceKey, strlen(c->instanceKey)+1);
        int i = rect.Left;
        command->Write(&i, sizeof(int));
        i = rect.Top;
        command->Write(&i, sizeof(int));
        i = rect.Width;
        command->Write(&i, sizeof(int));
        i = rect.Height;
        command->Write(&i, sizeof(int));
        command->Write("\n", 1);
        TCPClient->WriteStream(command, true, false);
    } __finally {
        delete command;
    }
    AnsiString mimeType;
    char ch;
    TCPClient->ReadBuffer(&ch, 1);
    if (!ch) return;
    while (ch) {
        mimeType += ch;
	    TCPClient->ReadBuffer(&ch, 1);
    }
    int size = TCPClient->ReadInteger(true);
    if (size > 0) {
        TMemoryStream *ms = new TMemoryStream;
        try {
            TCPClient->ReadStream(ms, size, false);
            ms->Position = 0;
            Image->Picture->Bitmap->LoadFromStream(ms);
        } __finally {
            delete ms;
        }
    }
    TCPClient->Disconnect();
#else
    transport->Lock();
    try {
        ImageResponse *ir;
        if (transport->RequestCompImage(mgr->modelKey, mgr->managerInstanceKey,
            designer->designerKey, uic->instanceKey, rect.Left, rect.Top, rect.Width(), rect.Height(), ir)) {

            Graphics::TBitmap *b = Image->Picture->Bitmap;
            b->Width = ir->scanWidth;
            b->Height = ir->size / ir->scanWidth / sizeof(int);
            BITMAPV4INFO b4i = BitmapV4Info(b->Width, b->Height);
            if (!(SetDIBits(
                b->Canvas->Handle,
                b->Handle,
                0,
                b->Height,
                (void*)(ir->data),
                (BITMAPINFO*)&b4i,
                0))) {
                ShowMessage(AnsiString().sprintf("SetDIBits failed: %d", GetLastError()));
                return;
            }
        }
    }
    __finally {
        transport->Unlock();
    }
#endif
    Caption = IntToStr(::GetTickCount() - time);

}

void __fastcall TForm1::tvCompsClick(TObject *Sender)
{
    TTreeNode *node = tvComps->Selected;
    curComp = 0;
    curProp = 0;
    if (!node)
    {
        ListProperties(0);
        ListEvents(0);
        return;
    }

	impl__WSLiveComponent *c = reinterpret_cast<impl__WSLiveComponent*>(node->Data);
    if (c) {
        if (dynamic_cast<impl__WSLiveUIDesigner*>(designer)) {
            // refresh component instance data
            impl__uidesigner_USCORE_GetUIComponentResponse guicr;
            soap_call_impl__uidesigner_USCORE_GetUIComponent(
                &soap,
                transport->ServerURL(),
                "",
                mgr->modelKey,
                mgr->managerInstanceKey,
                designer->designerKey,
                c->instanceKey,
                &guicr
            );
            curComp = guicr._uidesigner_USCORE_GetUIComponentReturn;
        }
        else {
            // refresh component instance data
            impl__designer_USCORE_GetComponentResponse gcr;
            soap_call_impl__designer_USCORE_GetComponent(
                &soap,
                transport->ServerURL(),
                "",
                mgr->modelKey,
                mgr->managerInstanceKey,
                designer->designerKey,
                c->instanceKey,
                &gcr
            );
            curComp = gcr._designer_USCORE_GetComponentReturn;
        }
        ListProperties(curComp);
        ListEvents(curComp);
        impl__WSLiveUIComponent *uic = dynamic_cast<impl__WSLiveUIComponent*>(curComp);
        if (uic) {
//            TRect r = Rect(uic->rect->x, uic->rect->y, uic->rect->x + uic->rect->width,
//            uic->rect->y + uic->rect->height);
            TRect r = Rect(0, 0, uic->rect->width, uic->rect->height);
            PaintUIComponent(uic, r);
        }
    }
}

void __fastcall TForm1::ComponentsOfType1Click(TObject *Sender)
{
/*	int ARow = veComponents->Selection.Top;
    if (ARow > 0 && ARow < veComponents->RowCount) {
        AnsiString typeKey = veComponents->Values[veComponents->Keys[ARow]];
        impl__designer_USCORE_getComponentsOfTypeResponse cotr;
        if (soap_call_impl__designer_USCORE_getComponentsOfType(
        	&soap,
            transport->ServerURL(),
            "",
            modelKey.c_str(),
            designerKey.c_str(),
            typeKey.c_str(),
            &cotr) == SOAP_OK && cotr._designer_USCORE_getComponentsOfTypeReturn) {

            ArrayOfWSComponent *arc = cotr._designer_USCORE_getComponentsOfTypeReturn;
	        AnsiString s;
            if (arc && arc->__size > 0) {
	        	impl__WSComponent *c = arc->__ptr;
                for (int i=0; i<arc->__size; i++) {
        			s += c->displayName;
                    s += "\n";
    	           	c++;
                }
            }
	        s.Length() ? ShowMessage(s) : ShowMessage("None");
            soap_delete(&soap, arc);
        }
		soap_end(&soap);
    }*/
}

//---------------------------------------------------------------------------

static const char LF = '\xA';
static const char CR = '\xD';
static const char CRLF[2] = { ::CR, ::LF };


void __fastcall TForm1::PageControl1Change(TObject *Sender)
{
	if (PageControl1->ActivePage == tsPersist && mgr != NULL) {
		impl__manager_USCORE_GetPersistenceDataResponse pdr;
        if (soap_call_impl__manager_USCORE_GetPersistenceData(
        	&soap,
            transport->ServerURL(),
            "",
            mgr->modelKey,
            mgr->managerInstanceKey,
            0,
            &pdr) == SOAP_OK) {
            xsd__base64Binary *data = pdr._manager_USCORE_GetPersistenceDataReturn;
            if (data) {
            	TStringStream *s = new TStringStream("");
                s->Write(data->__ptr, data->__size);
                s->Position = 0;
                TReplaceFlags rf;
                rf << rfReplaceAll;
                mPersist->Text = StringReplace(s->DataString, ::LF, CRLF, rf);
                delete s;
            }
        }
    }
    if (PageControl1->ActivePage == tsModel && mgr != NULL && designer != NULL && mPersist->Text.Length() > 0) {
        TReplaceFlags rf;
        rf << rfReplaceAll;
        AnsiString data(StringReplace(mPersist->Text, CRLF, ::LF, rf));
        xsd__base64Binary *pd = soap_new_xsd__base64Binary(&soap, -1);
        pd->__ptr = (unsigned char*)soap_malloc(&soap, data.Length());
        pd->__size = data.Length();
        memcpy(pd->__ptr, &(data[1]), data.Length());
        impl__manager_USCORE_SetPersistenceDataResponse spdr;
        if (soap_call_impl__manager_USCORE_SetPersistenceData(
            &soap,
            transport->ServerURL(),
            "",
            mgr->modelKey,
            mgr->managerInstanceKey,
            pd,
            &spdr) == SOAP_OK)
        {
            impl__WSResult *r = spdr._manager_USCORE_SetPersistenceDataReturn;
            if (r && r->success) {
                PopulateComponentsTree();
            }
            else {
                ShowMessage(r);
            }
        }

    }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Persist1Click(TObject *Sender)
{
	if (SaveDialog1->Execute()) {
		impl__manager_USCORE_GetPersistenceDataResponse pdr;
        if (soap_call_impl__manager_USCORE_GetPersistenceData(
        	&soap,
            transport->ServerURL(),
            "",
            mgr->modelKey,
            mgr->managerInstanceKey,
            0,
            &pdr) == SOAP_OK) {
            xsd__base64Binary *data = pdr._manager_USCORE_GetPersistenceDataReturn;
            if (data) {
                TFileStream *fs = new TFileStream(SaveDialog1->FileName, fmCreate);
                fs->Write(data->__ptr, data->__size);
				delete fs;
                soap_delete(&soap, data);
            }
        }
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Depersist1Click(TObject *Sender)
{
	if (OpenDialog1->Execute()) {
    	TFileStream *fs = new TFileStream(OpenDialog1->FileName, fmOpenRead);
        xsd__base64Binary *persistData = soap_new_xsd__base64Binary(&soap, -1);
	    persistData->__size = fs->Size;
    	persistData->__ptr = (unsigned char*)soap_malloc(&soap, persistData->__size);
        fs->Read(persistData->__ptr, fs->Size);
        delete fs;
    	impl__manager_USCORE_SetPersistenceDataResponse pdr;
        if (soap_call_impl__manager_USCORE_SetPersistenceData(
        	&soap,
            transport->ServerURL(),
            "",
            mgr->modelKey,
            mgr->managerInstanceKey,
            persistData,
            &pdr) == SOAP_OK) {

            impl__WSResult *r = pdr._manager_USCORE_SetPersistenceDataReturn;
			if (r->success) {
				CreateDesignersClick(this);
            }
            else
            	ShowMessage(r);
            soap_delete(&soap, r);
        }
        soap_delete_xsd__base64Binary(&soap, persistData);
    }
}
//---------------------------------------------------------------------------


void __fastcall TForm1::tvPropsExpanding(TObject *Sender, TTreeNode *Node,
      bool &AllowExpansion)
{
	if (!Node || Node->getFirstChild()) return;
    ExpandPropNode(Node);
}
//---------------------------------------------------------------------------


void __fastcall TForm1::tvPropsClick(TObject *Sender)
{
	if (!tvProps->Selected) return;
    cbProp->Items->Clear();
	PPropPair pp = reinterpret_cast<PPropPair>(tvProps->Selected->Data);
    curProp = pp;
    curEvent = 0;
    impl__WSPropertyInfo *pi = pp->pInfo;

    if (curComp && pi) {

	    ArrayOf_USCORE_xsd_USCORE_string *propInfoKeys = NewPropInfoKeys(pi);

        impl__comp_USCORE_GetPropertyResponse cgpr;
        soap_call_impl__comp_USCORE_GetProperty(
            &soap,
            transport->ServerURL(),
            "",
            mgr->modelKey,
            mgr->managerInstanceKey,
            curComp->instanceKey,
            propInfoKeys,
            &cgpr);
        pp->pLive = cgpr._comp_USCORE_GetPropertyReturn;

        if (pp->pLive->hasValueTags) {
            impl__prop_USCORE_GetValueTagsResponse gvtr;
            soap_call_impl__prop_USCORE_GetValueTags(
                &soap,
                transport->ServerURL(),
                "",
                mgr->modelKey,
                mgr->managerInstanceKey,
                curComp->instanceKey,
                propInfoKeys,
                &gvtr);
            if (gvtr._prop_USCORE_GetValueTagsReturn) {
                ArrayOfWSTag *tags = gvtr._prop_USCORE_GetValueTagsReturn;
                if (tags && tags->__size > 0) {
                    impl__WSTag *tag = tags->__ptr;
                    for (int i=0; i<tags->__size; i++) {
                        cbProp->Items->Add(tag->displayName);
                        soap_delete(&soap, tag);
                        tag++;
                    }
                soap_delete(&soap, tags);
                }
            }
        }

        if (pp->pInfo->hasValueTags) {
            impl__propinfo_USCORE_GetValueTagsResponse pigvtr;
            soap_call_impl__propinfo_USCORE_GetValueTags(
                &soap,
                transport->ServerURL(),
                "",
                mgr->modelKey,
                curComp->componentTypeKey,
                propInfoKeys,
                &pigvtr);
            if (pigvtr._propinfo_USCORE_GetValueTagsReturn) {
                ArrayOfWSTag *tags = pigvtr._propinfo_USCORE_GetValueTagsReturn;
                if (tags->__size > 0) {
                    if (cbProp->Items->Count > 0)
                        cbProp->Items->Add("----");
                    impl__WSTag *tag = tags->__ptr;
                    for (int i=0; i<tags->__size; i++) {
                        cbProp->Items->Add(tag->displayName);
                        soap_delete(&soap, tag);
                        tag++;
                    }
                soap_delete(&soap, tags);
                }
            }

        }
        soap_delete(&soap, propInfoKeys);

        if (pp->pInfo->constrainedToTags && !(pp->pInfo->readOnly) && pp->pInfo->hasValueTags) {
	        cbProp->Style = csDropDownList;
        	cbProp->ItemIndex = cbProp->Items->IndexOf(pp->pLive->valueAsText);
      	}
        else {
        	cbProp->Style = csDropDown;
	        cbProp->Text = pp->pLive->valueAsText;
        }

    	cbProp->Enabled = !(pp->pInfo->readOnly);        
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::SetCurrentPropValue(AnsiString &value)
{
    impl__WSPropertyInfo *pi = curProp->pInfo;
	if (pi) {
		ArrayOf_USCORE_xsd_USCORE_string *propKeys = NewPropInfoKeys(pi);
        if (!propKeys) return;
        impl__prop_USCORE_SetValueAsTextResponse svatr;
        if (soap_call_impl__prop_USCORE_SetValueAsText(
        	&soap,
            transport->ServerURL(),
            "",
            mgr->modelKey,
            mgr->managerInstanceKey,
            curComp->instanceKey,
            propKeys,
            value.c_str(),
            &svatr) == SOAP_OK)
        {
        	impl__WSResult *r = svatr._prop_USCORE_SetValueAsTextReturn;
            if (!r)
            	ShowMessage(soap.fault->detail);
            else if (!r->success) {
            	impl__WSTag *selTag = ShowMessage(r);
            } else {
				// refresh pointers to values.
            }
        }
        soap_delete(&soap, propKeys);
	}
}


void __fastcall TForm1::SetCurrentEventValue(AnsiString &value)
{
    impl__WSEventInfo *ei = curEvent->eInfo;
	if (ei) {
		ArrayOf_USCORE_xsd_USCORE_string *eventKeys = NewEventInfoKeys(ei);
        if (!eventKeys) return;
        impl__event_USCORE_SetHookAsTextResponse shatr;
        if (soap_call_impl__event_USCORE_SetHookAsText(
        	&soap,
            transport->ServerURL(),
            "",
            mgr->modelKey,
            mgr->managerInstanceKey,
            curComp->instanceKey,
            eventKeys,
            value.c_str(),
            &shatr) == SOAP_OK)
        {
        	impl__WSResult *r = shatr._event_USCORE_SetHookAsTextReturn;
            if (!r)
            	ShowMessage(soap.fault->detail);
            else if (!r->success) {
            	impl__WSTag *selTag = ShowMessage(r);
            } else {
				// refresh pointers to values.
            }
        }
        soap_delete(&soap, eventKeys);
	}
}

void __fastcall TForm1::cbPropKeyPress(TObject *Sender, char &Key)
{
	if (((int)Key) != 13) return;
    Key = 0;
    if (pcProps->ActivePage == tsProps && curProp) {
	    SetCurrentPropValue(cbProp->Text);
    }
    else if (pcProps->ActivePage == tsCompEvents && curEvent) {
    	SetCurrentEventValue(cbProp->Text);
    }
}
//---------------------------------------------------------------------------


void __fastcall TForm1::cbPropSelect(TObject *Sender)
{
	if (cbProp->Text != curProp->pLive->valueAsText)
	    SetCurrentPropValue(cbProp->Text);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Create3Click(TObject *Sender)
{
	int ARow = veCompInfos->Selection.Top;
    if (ARow > 0 && ARow < veCompInfos->RowCount) {
		impl__WSComponentInfo *ci = reinterpret_cast<impl__WSComponentInfo*>(veCompInfos->Strings->Objects[ARow-1]);
        if (ci) {
            impl__designer_USCORE_TestCreateComponentResponse dtccr;
            assert(
                soap_call_impl__designer_USCORE_TestCreateComponent(
                    &soap,
                    transport->ServerURL(),
                    "",
                    mgr->modelKey,
                    mgr->managerInstanceKey,
                    designer->designerKey,
                    0,
                    ci->compTypeKey,
                    &dtccr
                ) == SOAP_OK
            );
            if (!dtccr._designer_USCORE_TestCreateComponentReturn) {
                AnsiString msg;
                msg.sprintf("%s cannot create a %s", designer->displayName,
                    ci->displayName);
                ShowMessage(msg);
                return;
            }

            impl__WSCreateResult *r = 0;
            // is current designer a ui designer?
    		if (dynamic_cast<impl__WSLiveUIDesigner*>(designer))
            {
                impl__uidesigner_USCORE_CreateComponentResponse uidccr;
                assert(
                    soap_call_impl__uidesigner_USCORE_CreateComponent_(
                        &soap,
                        transport->ServerURL(),
                        "",
                        mgr->modelKey,
                        mgr->managerInstanceKey,
                        designer->designerKey,
                        0,
                        ci->compTypeKey,
                        0,
                        0,
                        -1,
                        -1,
                        &uidccr
                    ) == SOAP_OK
                );
                r = uidccr._uidesigner_USCORE_CreateComponentReturn;
            }
            else {
                impl__designer_USCORE_CreateComponentResponse dccr;
                assert(
                    soap_call_impl__designer_USCORE_CreateComponent_(
                        &soap,
                        transport->ServerURL(),
                        "",
                        mgr->modelKey,
                        mgr->managerInstanceKey,
                        designer->designerKey,
                        0,
                        ci->compTypeKey,
                        &dccr
                   ) == SOAP_OK);
                r = dccr._designer_USCORE_CreateComponentReturn;
            }
            if (r && r->success) {
                PopulateComponentsTree();
            }
            if (r && !r->success) {
                if (r->__size_) {
                    ShowMessage(r->messages->messageText);
                } else {
                    ShowMessage("Create failed. No response message");
                }
            }
            if (!r) {
               ShowMessage("Create failed. No response");
            }
        }
    }
}

void __fastcall TForm1::Image1Click(TObject *Sender)
{
	int ARow = veCompInfos->Selection.Top;
    if (ARow > 0 && ARow < veCompInfos->RowCount) {
		impl__WSComponentInfo *ci = reinterpret_cast<impl__WSComponentInfo*>(veCompInfos->Strings->Objects[ARow-1]);
       	int time = ::GetTickCount();
#ifdef USE_SOCKETS
		TCPClient->Connect();
		TMemoryStream *command = new TMemoryStream();
        try {
			command->Write(modelImageCmd, strlen(modelImageCmd)+1);
    	    command->Write(curModel->modelKey, strlen(curModel->modelKey)+1);
        	command->Write(ci->paletteIconURI, strlen(ci->paletteIconURI)+1);
            command->Write("\n", 1);
	    	TCPClient->WriteStream(command, true, true);
        } __finally {
        	delete command;
        }
        int size = TCPClient->ReadInteger(true);
        if (size > 0) {
	        TMemoryStream *ms = new TMemoryStream;
            try {
	    	    TCPClient->ReadStream(ms, size, false);
    	    	ms->Position = 0;
        	  	Image->Picture->Bitmap->LoadFromStream(ms);
            } __finally {
    		    delete ms;
	        }
        }
        TCPClient->Disconnect();
        Caption = IntToStr(::GetTickCount() - time);
#else
        transport->Lock();
        try {
            ImageResponse *ir;
            if (transport->RequestModelImage(mgr->modelKey, ci->paletteIconURI, ir)) {
                ShowMessage(ir->mimeType);
            }
        }
        __finally {
            transport->Unlock();
        }
#endif
    }
}
//---------------------------------------------------------------------------


void __fastcall TForm1::cbDesignerInfosClick(TObject *Sender)
{
    TObject *obj = cbDesignerInfos->Items->Objects[cbDesignerInfos->ItemIndex];
    if (obj) {
        impl__WSDesignerInfo *di = reinterpret_cast<impl__WSDesignerInfo*>(obj);
        if (di) {
            ClearVLE(veDesignerInfo);
            veDesignerInfo->InsertRow("designerKey", di->designerKey, true);
            veDesignerInfo->InsertRow("displayName", di->displayName, true);
            veDesignerInfo->InsertRow("description", di->description, true);
            veDesignerInfo->InsertRow("imageURI", di->displayIconURI, true);
        }
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Timer1Timer(TObject *Sender)
{
    if (mgr) {
        impl__manager_USCORE_GetDesignerEventsResponse gde;
        if (soap_call_impl__manager_USCORE_GetDesignerEvents(
            &soap,
            transport->ServerURL(),
            "",
            mgr->modelKey,
            mgr->managerInstanceKey,
            &gde) == SOAP_OK)
        {
            ArrayOfWSDesignerEvent *des = gde._manager_USCORE_GetDesignerEventsReturn;
            if (des) {
                impl__WSDesignerEvent *e = des->__ptr;
                for (int i=0; i<des->__size; i++) {
                    HandleDesignerEvent(e);
                    e++;
                }
            }
        }
    }
}

// from rcmdesigner.h
#define MANAGER_CHANGED 1
// The designer manager has changed in some way (reset palette, etc) 
#define DESIGNER_CHANGED MANAGER_CHANGED+1
// A designer has changed in some way
#define COMPONENT_CREATED MANAGER_CHANGED+2
// A component has been created
#define COMPONENT_CHANGED MANAGER_CHANGED+3
// A component has changed in some way
#define COMPONENT_DISPOSED MANAGER_CHANGED+4
// A live component has been disposed
#define PROPERTY_CHANGED MANAGER_CHANGED+5
// A live property has been edited
#define EVENT_CHANGED MANAGER_CHANGED+6
// A live event has been hooked, unhooked, or changed
#define CUSTOM_DATA MANAGER_CHANGED+7
// transport->ServerURL() has some custom data to send back to the code manager


AnsiString CharArrayToString(char **array, int size)
{
    AnsiString retval("    Keys: ");
    for (int i=0; i<size; i++) {
        retval += array[i];
        retval += " ";
    }
    return retval;
}

void __fastcall TForm1::HandleDesignerEvent(impl__WSDesignerEvent *e)
{
    mEvents->Lines->Add("");
    switch (e->designerEventID) {
        case DESIGNER_CHANGED:
        // A designer has changed in some way
        {
            mEvents->Lines->Add("Designer Changed:");
            mEvents->Lines->Add(AnsiString().sprintf("   Designer Key: %s", e->designerKey));
            break;
        }
        case COMPONENT_CREATED:
        // A component has been created
        {
            mEvents->Lines->Add("Component Created:");
            mEvents->Lines->Add(AnsiString().sprintf("   Designer Key: %s", e->designerKey));
            mEvents->Lines->Add(AnsiString().sprintf("   Component Key: %s", e->compInstanceKey));
            impl__designer_USCORE_GetComponentResponse gcr;
            if (soap_call_impl__designer_USCORE_GetComponent(
                &soap,
                transport->ServerURL(),
                "",
                mgr->modelKey,
                mgr->managerInstanceKey,
                designer->designerKey,
                e->compInstanceKey,
                &gcr) == SOAP_OK)
            {
                impl__model_USCORE_GetComponentInfoResponse gcir;
                if (soap_call_impl__model_USCORE_GetComponentInfo(
                    &soap,
                    transport->ServerURL(),
                    "",
                    mgr->modelKey,
                    gcr._designer_USCORE_GetComponentReturn->componentTypeKey,
                    &gcir) == SOAP_OK)
                {
                    impl__WSComponentInfo *newCi = gcir._model_USCORE_GetComponentInfoReturn;
                    int i = veCompInfos->Strings->Count - 1;
                    while (i>=0) {
                        impl__WSComponentInfo *ci = reinterpret_cast<impl__WSComponentInfo*>(veCompInfos->Strings->Objects[i]);
                        if (ci && strcmp(ci->compTypeKey, newCi->compTypeKey) == 0) {
                            break;
                        }
                        i--;
                    }
                    if (i < 0) {
                        compInfos.push_back(newCi);
                        AnsiString nvp;
                        nvp.sprintf("%s=%s", newCi->displayName, "dynamic");
                        veCompInfos->Strings->AddObject(nvp, (TObject*)newCi);
                    }
                }
            }
            PopulateComponentsTree();
            break;
        }
        case COMPONENT_CHANGED:
        // A component has changed in some way
        {
            mEvents->Lines->Add("Component Changed:");
            mEvents->Lines->Add(AnsiString().sprintf("   Designer Key: %s", e->designerKey));
            mEvents->Lines->Add(AnsiString().sprintf("   Component Key: %s", e->compInstanceKey));
            PopulateComponentsTree();
            break;
        }
        case COMPONENT_DISPOSED:
        // A live component has been disposed
        {
            mEvents->Lines->Add("Component Disposed:");
            mEvents->Lines->Add(AnsiString().sprintf("   Designer Key: %s", e->designerKey));
            mEvents->Lines->Add(AnsiString().sprintf("   Component Key: %s", e->compInstanceKey));
            PopulateComponentsTree();
            break;
        }
        case PROPERTY_CHANGED:
        // A live property has been edited
        {
            mEvents->Lines->Add("Property Changed");
            mEvents->Lines->Add(AnsiString().sprintf("   Designer Key: %s", e->designerKey));
            mEvents->Lines->Add(CharArrayToString(e->propertyKeyPath, e->__size_));
            break;
        }
        case EVENT_CHANGED:
        {
            mEvents->Lines->Add("Event Changed");
            mEvents->Lines->Add(AnsiString().sprintf("   Designer Key: %s", e->designerKey));
            mEvents->Lines->Add(CharArrayToString(e->eventKeyPath, e->__size__));
            break;
        }
        // A live event has been hooked, unhooked, or changed
        case CUSTOM_DATA:
        {
            mEvents->Lines->Add("Custom Event");
            mEvents->Lines->Add(AnsiString().sprintf("    Key: ", e->customDataKey));
            mEvents->Lines->Add(AnsiString().sprintf("    Data: ", e->customDataValue));
            break;
        }
    }

}

//---------------------------------------------------------------------------

void __fastcall TForm1::pmCompsPopup(TObject *Sender)
{
    pmComps->Items->Clear();
    TMenuItem *item = new TMenuItem(this);
    item->Caption = "Create Child...";
    item->OnClick = this->CreateChild1Click;
    pmComps->Items->Add(item);
    item = new TMenuItem(this);
    item->Caption = "Partial Image...";
    item->OnClick = this->PartialImage1Click;
    pmComps->Items->Add(item);
    item = new TMenuItem(this);
    item->Caption = "Persist...";
    item->OnClick = this->Persist2Click;
    pmComps->Items->Add(item);

    impl__comp_USCORE_GetContextTagsResponse cgctr;
    if (mgr && designer && curComp && soap_call_impl__comp_USCORE_GetContextTags(
        &soap,
        transport->ServerURL(),
        "",
        mgr->modelKey,
        mgr->managerInstanceKey,
        designer->designerKey,
        curComp->instanceKey,
        -1,
        -1,
        &cgctr) == SOAP_OK)
    {
        ArrayOfWSTag *tags = cgctr._comp_USCORE_GetContextTagsReturn;
        if (tags) {
            item = new TMenuItem(this);
            item->Caption = "-";
            pmComps->Items->Add(item);
            impl__WSTag *tag = tags->__ptr;
            for (int i=0; i<tags->__size; i++) {
                item = new TMenuItem(this);
                item->Caption = tag->displayName;
                char *key = (char*)malloc(25);
                item->Tag = (int)strncpy(key, tag->tagKey, 25);
                item->OnClick = this->CompTagClicked;
                pmComps->Items->Add(item);
                tag++;
            }
        }
    }
}

void __fastcall TForm1::CompTagClicked(TObject *Sender)
{
    TMenuItem *item = dynamic_cast<TMenuItem*>(Sender);
    if (item) {
        ArrayOf_USCORE_xsd_USCORE_string *tagKeys = NewTagKeys(item);
         impl__comp_USCORE_TagInvokedResponse ctir;
         soap_call_impl__comp_USCORE_TagInvoked(
            &soap,
            transport->ServerURL(),
            "",
            mgr->modelKey,
            mgr->managerInstanceKey,
            designer->designerKey,
            curComp->instanceKey,
            tagKeys,
            &ctir);
    }
}

//---------------------------------------------------------------------------

void __fastcall TForm1::PartialImage1Click(TObject *Sender)
{
    if (!tvComps->Selected) return;
    TTreeNode *node = tvComps->Selected;
   	impl__WSLiveUIComponent *c = reinterpret_cast<impl__WSLiveUIComponent*>(node->Data);
    if (c) {
        TRect r = Rect(c->rect->x, c->rect->y, c->rect->x + c->rect->width,
            c->rect->y + c->rect->height);
        if (PSDlg->GetSize(r)) {
            PaintUIComponent(c, r);
        }
    }

}
//---------------------------------------------------------------------------


AnsiString KeysToString(char **keys, int size)
{
    AnsiString retval;
    for (int i=0; i<size; i++) {
        retval += keys[i];
        retval += ", ";
    }
    return retval;
}

void __fastcall TForm1::PropertyInfos1Click(TObject *Sender)
{
	int ARow = veCompInfos->Selection.Top;
    if (ARow > 0 && ARow < veCompInfos->RowCount) {
		impl__WSComponentInfo *ci = reinterpret_cast<impl__WSComponentInfo*>(veCompInfos->Strings->Objects[ARow-1]);
        impl__compinfo_USCORE_GetPropertyInfosResponse gpir;
        if (soap_call_impl__compinfo_USCORE_GetPropertyInfos(
        	&soap,
            transport->ServerURL(),
            "",
            mgr->modelKey,
            ci->compTypeKey,
            &gpir) == SOAP_OK) {

            AnsiString s;
            ArrayOfWSPropertyInfo *pis = gpir._compinfo_USCORE_GetPropertyInfosReturn;
            if (pis) {
                impl__WSPropertyInfo *pi = pis->__ptr;
                for (int i=0; i<pis->__size; i++) {
                    s += AnsiString().sprintf("%s (%s)\n", pi->displayName, KeysToString(pi->propertyKeyPath, pi->__size_));
                    pi++;
                }
                ShowMessage(s);
            }
        }
    }
}
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------

void __fastcall TForm1::CreateChild1Click(TObject *Sender)
{
	TTreeNode *node = tvComps->Selected;
    assert(curModel != NULL && mgr != NULL && designer != NULL);
    if (node) {
    	impl__WSLiveComponent *container = reinterpret_cast<impl__WSLiveComponent*>(node->Data);
        if (!container)
        	throw new Exception("Can't get container");
        CreateComponent(container->instanceKey);
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::CreateComponent(char *containerKey)
{
    assert(curModel != NULL && mgr != NULL && designer != NULL);
    AnsiString compType = GetComponentType(&soap, compInfos);
    if (compType.Length() > 0) {
        impl__uidesigner_USCORE_CreateComponentResponse ccr;
        soap_call_impl__uidesigner_USCORE_CreateComponent_(
            &soap,
            transport->ServerURL(),
            "",
            mgr->modelKey,
            mgr->managerInstanceKey,
            designer->designerKey,
            containerKey,
            compType.c_str(),
            0,
            0,
            -1,
            -1,
            &ccr
        );
        if (ccr._uidesigner_USCORE_CreateComponentReturn->success &&
            ccr._uidesigner_USCORE_CreateComponentReturn->uiComponent) {
            PopulateComponentsTree();
            if (tvComps->Items->GetFirstNode()) {
                impl__WSLiveUIComponent *uic = reinterpret_cast<impl__WSLiveUIComponent*>(tvComps->Items->GetFirstNode()->Data);
                PaintUIComponent(uic, Rect(uic->rect->x, uic->rect->y, uic->rect->x + uic->rect->width,
                    uic->rect->y + uic->rect->height));

            }
        }
    }
}

//---------------------------------------------------------------------------

void __fastcall TForm1::Create2Click(TObject *Sender)
{
    CreateComponent(0);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::CreateTLComponent()
{
        impl__uidesigner_USCORE_CreateComponentResponse ccr;
        soap_call_impl__uidesigner_USCORE_CreateComponent_(
            &soap,
            transport->ServerURL(),
            "",
            mgr->modelKey,
            mgr->managerInstanceKey,
            designer->designerKey,
            0,
#ifdef _WXWIN_
            "wxFrame",
#endif
            0,
            0,
            -1,
            -1,
            &ccr
        );
        if (ccr._uidesigner_USCORE_CreateComponentReturn->success &&
            ccr._uidesigner_USCORE_CreateComponentReturn->uiComponent) {
            PopulateComponentsTree();
        }
}

void __fastcall TForm1::CreateChildComponentClick(TObject *Sender)
{
    TMenuItem *item = dynamic_cast<TMenuItem*>(Sender);
    if (!item) return;
    assert(curModel != NULL && mgr != NULL && designer != NULL);
   	impl__WSLiveComponent *container = reinterpret_cast<impl__WSLiveComponent*>(item->Tag);
    if (container)
        CreateComponent(container->instanceKey);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Component1Click(TObject *Sender)
{
    CreateChild2->Clear();
    assert(curModel && mgr && designer);
    TTreeNode *node = tvComps->Items->GetFirstNode();
    while (node) {
        impl__WSLiveComponent *container = reinterpret_cast<impl__WSLiveComponent*>(node->Data);
        TMenuItem *newItem = new TMenuItem(CreateChild2);
        newItem->Caption = AnsiString(container->instanceName) + "...";
        newItem->Tag = (int)container;
        newItem->OnClick = CreateChildComponentClick;
        CreateChild2->Add(newItem);
        node = node->GetNext();
    }
}
//---------------------------------------------------------------------------


void __fastcall TForm1::tvCompsEdited(TObject *Sender, TTreeNode *Node,
      AnsiString &S)
{
	TTreeNode *cnode = tvComps->Selected;
    if (cnode) {
        impl__WSLiveComponent *comp = reinterpret_cast<impl__WSLiveComponent*>(cnode->Data);
        if (comp) {
        	impl__comp_USCORE_SetInstanceNameResponse sinr;
            if (soap_call_impl__comp_USCORE_SetInstanceName(
            	&soap,
                transport->ServerURL(),
                "",
                mgr->modelKey,
                mgr->managerInstanceKey,
                comp->instanceKey,
                S.c_str(),
                &sinr) == SOAP_OK) {
                if (sinr._comp_USCORE_SetInstanceNameReturn &&
                 	sinr._comp_USCORE_SetInstanceNameReturn->success) {
	                return;
                }
            }
        }
        ShowMessage("Cannot rename to " + S);
    }
;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::tvEventsClick(TObject *Sender)
{
	if (!tvEvents->Selected) return;
    cbProp->Items->Clear();
	PEventPair ep = reinterpret_cast<PEventPair>(tvEvents->Selected->Data);
    curEvent = ep;
    curProp = 0;
    impl__WSEventInfo *ei = ep->eInfo;

    if (curComp && ei) {

	    ArrayOf_USCORE_xsd_USCORE_string *eventInfoKeys = NewEventInfoKeys(ei);

        impl__comp_USCORE_GetEventResponse cger;
        soap_call_impl__comp_USCORE_GetEvent(
            &soap,
            transport->ServerURL(),
            "",
            mgr->modelKey,
            mgr->managerInstanceKey,
            curComp->instanceKey,
            eventInfoKeys,
            &cger);
        ep->eLive = cger._comp_USCORE_GetEventReturn;
        cbProp->Text = ep->eLive->hookAsText;

/*        if (ep->eLive->hasValueTags) {
            impl__prop_USCORE_GetValueTagsResponse gvtr;
            soap_call_impl__prop_USCORE_GetValueTags(
                &soap,
                transport->ServerURL(),
                "",
                mgr->modelKey,
                mgr->managerInstanceKey,
                curComp->instanceKey,
                propInfoKeys,
                &gvtr);
            if (gvtr._prop_USCORE_GetValueTagsReturn) {
                ArrayOfWSTag *tags = gvtr._prop_USCORE_GetValueTagsReturn;
                if (tags->__size > 0) {
                    impl__WSTag *tag = tags->__ptr;
                    for (int i=0; i<tags->__size; i++) {
                        cbProp->Items->Add(tag->displayName);
                        soap_delete(&soap, tag);
                        tag++;
                    }
                soap_delete(&soap, tags);
                }
            }
        }

        if (pp->pInfo->hasValueTags) {
            impl__propinfo_USCORE_GetValueTagsResponse pigvtr;
            soap_call_impl__propinfo_USCORE_GetValueTags(
                &soap,
                transport->ServerURL(),
                "",
                mgr->modelKey,
                curComp->componentTypeKey,
                propInfoKeys,
                &pigvtr);
            if (pigvtr._propinfo_USCORE_GetValueTagsReturn) {
                ArrayOfWSTag *tags = pigvtr._propinfo_USCORE_GetValueTagsReturn;
                if (tags->__size > 0) {
                    if (cbProp->Items->Count > 0)
                        cbProp->Items->Add("----");
                    impl__WSTag *tag = tags->__ptr;
                    for (int i=0; i<tags->__size; i++) {
                        cbProp->Items->Add(tag->displayName);
                        soap_delete(&soap, tag);
                        tag++;
                    }
                soap_delete(&soap, tags);
                }
            }

        }
        soap_delete(&soap, propInfoKeys);
    }
*/
}
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Dispose2Click(TObject *Sender)
{
    if (!tvComps->Selected) return;
    TTreeNode *node = tvComps->Selected;
   	impl__WSLiveUIComponent *c = reinterpret_cast<impl__WSLiveUIComponent*>(node->Data);
    if (c) {
        impl__designer_USCORE_DisposeComponentResponse ddcr;
        soap_call_impl__designer_USCORE_DisposeComponent(
            &soap,
            transport->ServerURL(),
            "",
            mgr->modelKey,
            mgr->managerInstanceKey,
            designer->designerKey,
            c->instanceKey,
            &ddcr);
        PopulateComponentsTree();
    }
}
//---------------------------------------------------------------------------


void __fastcall TForm1::Persist2Click(TObject *Sender)
{
    if (!tvComps->Selected) return;
    TTreeNode *node = tvComps->Selected;
   	impl__WSLiveUIComponent *c = reinterpret_cast<impl__WSLiveUIComponent*>(node->Data);
    if (c && designer) {
		impl__manager_USCORE_GetPersistenceDataResponse pdr;
        if (soap_call_impl__manager_USCORE_GetPersistenceData(
        	&soap,
            transport->ServerURL(),
            "",
            mgr->modelKey,
            mgr->managerInstanceKey,
            c->instanceKey,
            &pdr) == SOAP_OK) {
            xsd__base64Binary *data = pdr._manager_USCORE_GetPersistenceDataReturn;
            if (data) {
            	TStringStream *s = new TStringStream("");
                s->Write(data->__ptr, data->__size);
                s->Position = 0;
                TReplaceFlags rf;
                rf << rfReplaceAll;
                ShowMessage(StringReplace(s->DataString, ::LF, CRLF, rf));
                delete s;
            }
        }
    }
}
//---------------------------------------------------------------------------


void __fastcall TForm1::pcPropsChange(TObject *Sender)
{
    if (Sender == pcProps && ((TPageControl*)Sender)->ActivePage == tsCompEvents) {
        cbProp->Style = csDropDown;
        cbProp->Enabled = true;
    }

}
//---------------------------------------------------------------------------

