////////////////////////////////////////////////////////////////////////////////
// Implementation of CSampleApplication
////////////////////////////////////////////////////////////////////////////////

#include "Sampleapp.h"
#include "Sampledocument.h"

const TUid KUidSample = { 0x01000001 };

TUid CSampleApplication::AppDllUid() const
{
	return KUidSample;
}

CApaDocument* CSampleApplication::CreateDocumentL()
{
	CApaDocument* document = CSampleDocument::NewL(*this);
  return document;
}
