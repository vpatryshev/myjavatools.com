#ifndef wxwcontainerH
#define wxwcontainerH

#include "rcm.h"
#include "wxwcomponent.h"
#include "wxwproperty.h"

class RCMEXPORT wxwContainer : public rcmContainer
{
public:
    wxwContainer();
    virtual ~wxwContainer();

    void DeleteChildren();
    /* Child component access helpers */
    wxwComponent* FindComponentByKey(const wxString &key);
   	wxwComponent* FindComponentByName(const wxString &name);
    wxwComponent* FindComponentByInstance(const wxObject *instance);

    /*
        Hook to allow additional properties to be displayed by a child component
        on behalf of its parent.
    */
    virtual void GetExtraProperties(wxwComponent *child, rcmProperties &props) { }
    virtual rcmProperty* GetExtraProperty(wxwComponent *child, wxArrayString &propPath);

    /* Notifications */
    virtual void NotifyChildInserted(wxwComponent *newChild);
    virtual void NotifyChildRemoved(wxwComponent *child);

    /*
        Return the wxObject which will be the *actual* parent of a child wxObject.
        In most cases this will be this container's FInstance, but may not be
        as in the case of a wxSizer which must parent the child control to the
        wxWindow to which the wxSizer belongs
    */
    virtual wxObject* ParentInstance();

    // rcmContainer methods
  	virtual bool CanParent(wxObject *instance);
    int	ComponentCount();
	rcmComponents& Components() { return FComponents; }
    rcmComponent* GetComponent(const wxString &key);
	virtual Result* SetComponentIndex(rcmComponent *comp, int index);
protected:
	void Insert(wxwComponent *component);
    void Remove(wxwComponent *component);
private:
    rcmComponents FComponents;
//    bool FDeleting;
};

#endif
