#ifndef wxwH
#define wxwH

#include "rcm.h"

// Additional property flags
#define PE_RECREATECOMP         0x4000 // recreate the component instance when property value changes
#define PE_NESTED               0x8000 // property relies on its parent's typeinfo and instance ("fake" properties)

// forward class declarations

class wxwComponent;
class wxwContainer;
class wxwRootComponent;
class wxPropertyBase;
class wxwEventConnection;
class wxwComponentModel;
class wxwComponentEditor;
class wxwDesignerManager;
class wxwComponentInfo;
class wxwDesigner;
class wxwUIDesigner;
class wxwComponentFactory;
class wxPainter;

#define REGISTER_COMPONENT(wxClass, proxyClass, page, description) \
    RegisterComponent(CLASSINFO(wxClass), new wxwComponentFactoryT<proxyClass >(), \
        wxT(#page), wxT(#description));

#define REGISTER_WXCONTROL(wxClass, page, description) \
    REGISTER_COMPONENT(wxClass, wxWindowComponentT<wxClass>, page, description)

#define REGISTER_WXCONTAINER(wxClass, page, description) \
    REGISTER_COMPONENT(wxClass, wxWindowContainerT<wxClass>, page, description)

#define REGISTER_CLASS(wxClass) \
    RegisterClass(CLASSINFO(wxClass));

#define REGISTER_PAINTER(painterClass, wxClass) \
    RegisterPainter(CLASSINFO(wxClass), CLASSINFO(painterClass));

#define REGISTER_PROPERTY_EDITOR(propertyTypeInfo, componentClass, propertyName, propertyEditorClass) \
    RegisterPropertyEditor(propertyTypeInfo, CLASSINFO(componentClass), #propertyName, \
        CLASSINFO(propertyEditorClass));

#define REGISTER_COMPONENT_EDITOR(wxClass, editorClass) \
    RegisterComponentEditor(CLASSINFO(wxClass), CLASSINFO(editorClass));

#define TYPEOF(instance, type) \
    instance->IsKindOf(CLASSINFO(type))

#define INFO_TYPEOF(compInfo, type) \
    compInfo->ClassInfo()->IsKindOf(CLASSINFO(type))

class error : public runtime_error
{
public:
	error(const wxString &msg) : runtime_error(msg.c_str()) { }
};

template <typename _WXT>
void ConstructWXObject(wxObject *parent, _WXT *o, wxString &name)
{
    wxASSERT_MSG(0, "ConstructWXObject must be specialized for a particular type");
}


#ifndef SHOW_SLAVE
static const int FrameOffsetX = -32767;
#else
static const int FrameOffsetX = 0;
#endif
static const int FrameOffsetY = FrameOffsetX;

struct wxSysColorEntry {
    wxSystemColour index;
    char *name;
};

struct wxStdColorEntry {
    char *name;
    unsigned char red, green, blue;
};

#define STD_COLOR_MAX 22

extern wxSysColorEntry SysColors[wxSYS_COLOUR_MAX];
extern wxStdColorEntry StdColors[STD_COLOR_MAX];

typedef hash_map<const wxClassInfo*, const wxClassInfo*, hash<const wxClassInfo*> > ClassInfos;

_STLP_TEMPLATE_NULL struct hash<const wxClassInfo*>
{
  	size_t operator()(const wxClassInfo* __ci) const { _STLP_FIX_LITERAL_BUG(__ci) return (__stl_hash_string(__ci->GetClassName())); }
};

class RCMEXPORT wxPainter : public wxObject
{
    DECLARE_ABSTRACT_CLASS(wxPainter)
public:
    virtual void PaintObject(wxObject *object, wxDC &dc) = 0;
};

extern int GetUniqueID();
char* StrAlloc(char *&dest, const char *src);
wxString StringArrayToString(wxArrayString &path);

// construction of wxControl descendants with ctor args of wxControl
void ConstructWXControl(wxObject *parent, wxControl *c, const wxString &name);

// Registration and model lookup routines

extern wxwComponentEditor* FindComponentEditor(const wxClassInfo *classInfo);
extern wxwComponentInfo* FindComponentInfo(const wxClassInfo* classInfo);
extern wxPainter* FindPainter(const wxClassInfo *classInfo);
extern wxwComponentInfo* RegisterClass(const wxClassInfo *classInfo);

extern wxwComponent* CreateComponent(
    wxwDesigner *designer,
    wxObject *parent,
    wxObject *object,
    const wxString &name);

extern void RegisterComponent(
    const wxClassInfo *classInfo,
    wxwComponentFactory *factory,
    const wxString &pageTitle = wxT(""),
    const wxString &description = wxT(""));

extern void RegisterComponentEditor(
    const wxClassInfo *componentClass,
    const wxClassInfo *editorClass);

extern void RegisterPropertyEditor(
    const wxTypeInfo *typeInfo,
    const wxClassInfo *componentClass,
    const wxString &propertyName,
    const wxClassInfo *editorClass);

extern void RegisterPainter(
    const wxClassInfo *objectClass,
    const wxClassInfo *painterClass);

#endif
