#ifdef __BORLANDC__
#include "rcmpch.h"
#endif

#pragma hdrstop

#include "wxwproperty.h"
#include "wxwcomponentinfo.h"
#include "wxwcomponenteditor.h"
#include "wxwproped.h"
#include "wxwuicontainer.h"
#include "wxwframe.h"
#include "wxwsizer.h"
#include "wxwnotebook.h"

#include "wx/grid.h"
#include "wx/calctrl.h"
#include "wx/gbsizer.h"
#include "wx/generic/dirctrlg.h"
#include "wx/statline.h"
#include "wx/listctrl.h"
#include "wx/html/htmlwin.h"
#include "wx/sizer.h"
#include "wx/spinbutt.h"
#include "wx/spinctrl.h"
#include <commctrl.h>

// Special "Frame position" property editor to fix up offscreen frame

class wxFramePositionProperty : public wxWindowPosProperty
{
DECLARE_DYNAMIC_CLASS(wxFramePositionProperty)
public:
	wxFramePositionProperty() : wxWindowPosProperty()
    {
    }

    virtual wxxVariant GetAsVariant() const
    {
        wxxVariant value = wxWindowPosProperty::GetAsVariant();
        wxPoint pt = value.Get<wxPoint>();
        pt.x -= FrameOffsetX;
        pt.y -= FrameOffsetY;
        return wxxVariant(pt);
    }

    virtual void SetAsVariant(const wxxVariant &value)
    {
        wxPoint pt = value.Get<wxPoint>();
        pt.x += FrameOffsetX;
        pt.y += FrameOffsetY;
        wxWindowPosProperty::SetAsVariant(wxxVariant(pt));
    }
};

IMPLEMENT_DYNAMIC_CLASS(wxFramePositionProperty, wxWindowPosProperty)

class wxGenericDirPathProperty : public xtiProperty
{
DECLARE_DYNAMIC_CLASS(wxGenericDirPathProperty)
public:
    wxGenericDirPathProperty() : xtiProperty()
    {
        FFlags |= PE_RECREATECOMP;
    }
};

IMPLEMENT_DYNAMIC_CLASS(wxGenericDirPathProperty, xtiProperty)

// REGISTRATION AND WXOBJECT CREATION

// wxButton construction

template <>
void ConstructWXObject(wxObject *parent, wxButton *o, const wxString &name)
{
    ConstructWXControl(parent, o, name);
}

//wxCheckBox construction

template <>
void ConstructWXObject(wxObject *parent, wxCheckBox *o, const wxString &name)
{
    return ConstructWXControl(parent, o, name);
}

// wxGauge95 construction

template <>
void ConstructWXObject(wxObject *parent, wxGauge95 *o, const wxString &name)
{
    wxxVariant params[6];
    params[0] = wxxVariant(dynamic_cast<wxWindow*>(parent));
    params[1] = wxxVariant((wxWindowID)GetUniqueID());
    params[2] = wxxVariant((int)100);
    params[3] = wxxVariant(wxDefaultPosition);
    params[4] = wxxVariant(wxDefaultSize);
    params[5] = wxxVariant((long)wxGA_HORIZONTAL | wxBORDER_SUNKEN);
    o->GetClassInfo()->Create(o, 6, params);
    o->Show();
}

// wxRadioButton construction

template <>
void ConstructWXObject(wxObject *parent, wxRadioButton *o, const wxString &name)
{
    return ConstructWXControl(parent, o, name);
}

// wxStaticBox construction

template <>
void ConstructWXObject(wxObject *parent, wxStaticBox *o, const wxString &name)
{
    return ConstructWXControl(parent, o, name);
}

// wxStaticText construction

template <>
void ConstructWXObject(wxObject *parent, wxStaticText *o, const wxString &name)
{
    return ConstructWXControl(parent, o, name);
}

// wxTextCtrl construction

template <>
void ConstructWXObject(wxObject *parent, wxTextCtrl *o, const wxString &name)
{
    wxxVariant params[6];
    params[0] = wxxVariant(dynamic_cast<wxWindow*>(parent));
    params[1] = wxxVariant((wxWindowID)GetUniqueID());
    params[2] = wxxVariant(wxString(name));
    params[3] = wxxVariant(wxDefaultPosition);
    params[4] = wxxVariant(wxDefaultSize);
    params[5] = wxxVariant((long)wxBORDER_SUNKEN);
    o->GetClassInfo()->Create(o, 6, params);
    o->Show();
}

// wxSpinButton construction

template <>
void ConstructWXObject(wxObject *parent, wxSpinButton *o, const wxString &name)
{
    wxxVariant params[5];
    params[0] = wxxVariant(dynamic_cast<wxWindow*>(parent));
    params[1] = wxxVariant((wxWindowID)GetUniqueID());
    params[2] = wxxVariant(wxDefaultPosition);
    params[3] = wxxVariant(wxDefaultSize);
    params[4] = wxxVariant((long)wxSP_VERTICAL | wxSP_ARROW_KEYS);
    o->GetClassInfo()->Create(o, 5, params);
    o->Show();
}

// wxSpinCtrl construction

template <>
void ConstructWXObject(wxObject *parent, wxSpinCtrl *o, const wxString &name)
{
    wxxVariant params[6];
    params[0] = wxxVariant(dynamic_cast<wxWindow*>(parent));
    params[1] = wxxVariant((wxWindowID)GetUniqueID());
    params[2] = wxxVariant(name);
    params[3] = wxxVariant(wxDefaultPosition);
    params[4] = wxxVariant(wxDefaultSize);
    params[5] = wxxVariant((long)wxSP_ARROW_KEYS);
    o->GetClassInfo()->Create(o, 6, params);
    o->Show();
}

// wxNotebookPageInfo construction

template <>
void ConstructWXObject(wxObject *parent, wxNotebookPageInfo *o, const wxString &name)
{
    wxxVariant params[4];
    params[0] = wxxVariant(dynamic_cast<wxWindow*>(parent));
    params[1] = wxxVariant((wxWindowID)GetUniqueID());
    params[2] = wxxVariant(wxDefaultPosition);
    params[3] = wxxVariant(wxDefaultSize);
    o->GetClassInfo()->Create(o, 4, params);
}

// wxListBox construction

template <>
void ConstructWXObject(wxObject *parent, wxListBox *o, const wxString &name)
{
    wxxVariant params[4];
    params[0] = wxxVariant(dynamic_cast<wxWindow*>(parent));
    params[1] = wxxVariant((wxWindowID)GetUniqueID());
    params[2] = wxxVariant(wxDefaultPosition);
    params[3] = wxxVariant(wxDefaultSize);
    o->GetClassInfo()->Create(o, 4, params);
    o->Append(name);
    o->Show();
}

// wxGenericDirCtrl construction

template <>
void ConstructWXObject(wxObject *parent, wxGenericDirCtrl *o, const wxString &name)
{
    wxxVariant params[8];
    params[0] = wxxVariant(dynamic_cast<wxWindow*>(parent));
    params[1] = wxxVariant((wxWindowID)GetUniqueID());
    params[2] = wxxVariant(wxString(wxDirDialogDefaultFolderStr));
    params[3] = wxxVariant(wxDefaultPosition);
    params[4] = wxxVariant(wxSize(200, 150));
    params[5] = wxxVariant((long)wxDIRCTRL_3D_INTERNAL|wxSUNKEN_BORDER);
    params[6] = wxxVariant(wxString(""));
    params[7] = wxxVariant((int)0);
    o->GetClassInfo()->Create(o, 8, params);
    o->Show();
}

// wxCalendarCtrl construction

template <>
void ConstructWXObject(wxObject *parent, wxCalendarCtrl *o, const wxString &name)
{
    wxxVariant params[6];
    params[0] = wxxVariant(dynamic_cast<wxWindow*>(parent));
    params[1] = wxxVariant((wxWindowID)GetUniqueID());
    params[2] = wxxVariant(wxDateTime(wxDefaultDateTime));
    params[3] = wxxVariant(wxDefaultPosition);
    params[4] = wxxVariant(wxDefaultSize);
    params[5] = wxxVariant((long)wxCAL_SHOW_HOLIDAYS);
    o->GetClassInfo()->Create(o, 6, params);
    o->Show();
}

// wxGrid construction

template <>
void ConstructWXObject(wxObject *parent, wxGrid *o, const wxString &name)
{
    wxxVariant params[5];
    params[0] = wxxVariant(dynamic_cast<wxWindow*>(parent));
    params[1] = wxxVariant((wxWindowID)GetUniqueID());
    params[2] = wxxVariant(wxDefaultPosition);
    params[3] = wxxVariant(wxDefaultSize);
    params[4] = wxxVariant((long)0);
    o->GetClassInfo()->Create(o, 5, params);
    o->Show();
}

// wxTreeCtrl construction

template <>
void ConstructWXObject(wxObject *parent, wxTreeCtrl *o, const wxString &name)
{
    wxxVariant params[5];
    params[0] = wxxVariant(dynamic_cast<wxWindow*>(parent));
    params[1] = wxxVariant((wxWindowID)GetUniqueID());
    params[2] = wxxVariant(wxDefaultPosition);
    params[3] = wxxVariant(wxDefaultSize);
    params[4] = wxxVariant((long)0);
    o->GetClassInfo()->Create(o, 5, params);
    o->AddRoot(name);
    o->Show();
}

// wxStaticLine construction

template <>
void ConstructWXObject(wxObject *parent, wxStaticLine *o, const wxString &name)
{
    wxxVariant params[5];
    params[0] = wxxVariant(dynamic_cast<wxWindow*>(parent));
    params[1] = wxxVariant((wxWindowID)GetUniqueID());
    params[2] = wxxVariant(wxDefaultPosition);
    params[3] = wxxVariant(wxSize(150, 4));
    params[4] = wxxVariant((long)0);
    o->GetClassInfo()->Create(o, 5, params);
    o->Show();
}

// wxChoice construction

template <>
void ConstructWXObject(wxObject *parent, wxChoice *o, const wxString &name)
{
    wxxVariant params[4];
    params[0] = wxxVariant(dynamic_cast<wxWindow*>(parent));
    params[1] = wxxVariant((wxWindowID)GetUniqueID());
    params[2] = wxxVariant(wxDefaultPosition);
    params[3] = wxxVariant(wxDefaultSize);
    o->GetClassInfo()->Create(o, 4, params);
    o->Show();
}

// wxListCtrl construction

template <>
void ConstructWXObject(wxObject *parent, wxListCtrl *o, const wxString &name)
{
    wxxVariant params[5];
    params[0] = wxxVariant(dynamic_cast<wxWindow*>(parent));
    params[1] = wxxVariant((wxWindowID)GetUniqueID());
    params[2] = wxxVariant(wxDefaultPosition);
    params[3] = wxxVariant(wxDefaultSize);
    params[4] = wxxVariant((long)wxLC_ICON | wxLC_NO_HEADER | wxBORDER_SUNKEN);
    o->GetClassInfo()->Create(o, 5, params);
    o->InsertItem(0, name);
    o->Show();
}

// wxScrollBar construction

template <>
void ConstructWXObject(wxObject *parent, wxScrollBar *o, const wxString &name)
{
    wxxVariant params[5];
    params[0] = wxxVariant(dynamic_cast<wxWindow*>(parent));
    params[1] = wxxVariant((wxWindowID)GetUniqueID());
    params[2] = wxxVariant(wxDefaultPosition);
    params[3] = wxxVariant(wxDefaultSize);
    params[4] = wxxVariant((long)wxSB_HORIZONTAL);
    o->GetClassInfo()->Create(o, 5, params);
    o->SetRange(100);
    o->Show();
}

// wxSlider95 construction

template <>
void ConstructWXObject(wxObject *parent, wxSlider95 *o, const wxString &name)
{
    wxxVariant params[8];
    params[0] = wxxVariant(dynamic_cast<wxWindow*>(parent));
    params[1] = wxxVariant((wxWindowID)GetUniqueID());
    params[2] = wxxVariant((int)0);
    params[3] = wxxVariant((int)0);
    params[4] = wxxVariant((int)100);
    params[5] = wxxVariant(wxDefaultPosition);
    params[6] = wxxVariant(wxDefaultSize);
    params[7] = wxxVariant((long)wxSL_HORIZONTAL);
    o->GetClassInfo()->Create(o, 8, params);
    o->Show();
}

// wxStaticBitmap construction

template <>
void ConstructWXObject(wxObject *parent, wxStaticBitmap *o, const wxString &name)
{
    wxxVariant params[5];
    params[0] = wxxVariant(dynamic_cast<wxWindow*>(parent));
    params[1] = wxxVariant((wxWindowID)GetUniqueID());
    params[2] = wxxVariant(wxBitmap(100, 100));
    params[3] = wxxVariant(wxDefaultPosition);
    params[4] = wxxVariant(wxSize(100, 100));
    o->GetClassInfo()->Create(o, 5, params);
    o->Show();
}

// wxHTMLWindow construction

template <>
void ConstructWXObject(wxObject *parent, wxHtmlWindow *o, const wxString &name)
{
    wxxVariant params[5];
    params[0] = wxxVariant(dynamic_cast<wxWindow*>(parent));
    params[1] = wxxVariant((wxWindowID)GetUniqueID());
    params[2] = wxxVariant(wxDefaultPosition);
    params[3] = wxxVariant(wxSize(200, 150));
    params[4] = wxxVariant((long)wxHW_SCROLLBAR_AUTO | wxBORDER_SUNKEN);
    o->GetClassInfo()->Create(o, 5, params);
    o->Show();
}

// wxComboBox construction

template <>
void ConstructWXObject(wxObject *parent, wxComboBox *o, const wxString &name)
{
    wxxVariant params[5];
    params[0] = wxxVariant(dynamic_cast<wxWindow*>(parent));
    params[1] = wxxVariant((wxWindowID)GetUniqueID());
    params[2] = wxxVariant(wxString(name));
    params[3] = wxxVariant(wxDefaultPosition);
    params[4] = wxxVariant(wxDefaultSize);
    o->GetClassInfo()->Create(o, 5, params);
    o->Show();
}

// wxGridSizer construction

template <>
void ConstructWXObject(wxObject *parent, wxGridSizer *o, const wxString &name)
{
	wxxVariant params[4];
    params[0] = wxxVariant((int)1);
    params[1] = wxxVariant((int)1);
    params[2] = wxxVariant((int)0);
    params[3] = wxxVariant((int)0);
    o->GetClassInfo()->Create(o, 4, params);
    wxWindow *window = dynamic_cast<wxWindow*>(parent);
    if (window) {
    	window->SetSizer(o, false);
    }
    else {
    	wxSizer *sizer = dynamic_cast<wxSizer*>(parent);
        if (sizer) {
        	sizer->Add(o);
        }
    }
    o->ShowItems(true);
}

DECLARE_WX_INT_AS_ENUM_EDITOR(wxFontFamily)
DECLARE_WX_INT_AS_ENUM_EDITOR(wxFontWeight)
DECLARE_WX_INT_AS_ENUM_EDITOR(wxFontStyle)

void RegisterComponents()
{
    REGISTER_PAINTER(wxWindowPainter, wxWindow)
    REGISTER_PAINTER(wxFramePainter, wxFrame)
    REGISTER_PAINTER(wxSizerPainter, wxGridBagSizer)
    REGISTER_PAINTER(wxBevelWindowPainter, wxListBox)
    REGISTER_PAINTER(wxBevelWindowPainter, wxGauge95)
    REGISTER_PAINTER(wxBevelWindowPainter, wxTextCtrl)
    REGISTER_PAINTER(wxBevelWindowPainter, wxListCtrl)
    REGISTER_PAINTER(wxBevelWindowPainter, wxTreeCtrl)
    REGISTER_PAINTER(wxBevelWindowPainter, wxHtmlWindow)
    REGISTER_PAINTER(wxBevelWindowPainter, wxPanel)
    REGISTER_PAINTER(wxBevelWindowPainter, wxStaticLine)
    REGISTER_PAINTER(wxGBSpacerPainter, wxGBSizerItem)

    REGISTER_COMPONENT(wxFrame, wxwFrameComponent, "", "")
    REGISTER_COMPONENT(wxNotebook, wxNotebookProxy, Containers, wxNotebook description)
    REGISTER_COMPONENT(wxGridBagSizer, wxGBSizerProxy, Sizers, wxGridBagSizer description)
    REGISTER_COMPONENT(wxGBSizerItem, wxGridBagSpacer, Sizers, wxGridBagSpacer description)

    REGISTER_WXCONTAINER(wxPanel, Containers, wxPanel description)

    REGISTER_WXCONTROL(wxButton, Standard, wxButton description)
    REGISTER_WXCONTROL(wxCheckBox, Standard, wxCheckBox description)
    REGISTER_WXCONTROL(wxGauge95, Additional, wxGauge95 description)
    REGISTER_WXCONTROL(wxRadioButton, Standard, wxRadioButton description)
    REGISTER_WXCONTROL(wxSpinButton, Additional, wxSpinButton description)
    REGISTER_WXCONTROL(wxStaticText, Standard, wxStaticText description)
    REGISTER_WXCONTROL(wxTextCtrl, Standard, wxTextCtrl description)
    REGISTER_WXCONTROL(wxStaticBox, Standard, wxStaticBox description)
    REGISTER_WXCONTROL(wxListBox, Standard, wxListBox description)
    REGISTER_WXCONTROL(wxStaticLine, Standard, wxStaticLine description)
	// TreeCtrl crashes when you delete it.
    REGISTER_WXCONTROL(wxTreeCtrl, Additional, wxTreeCtrl description)
    REGISTER_WXCONTROL(wxChoice, Standard, wxChoice description)
    REGISTER_WXCONTROL(wxComboBox, Additional, wxComboBox description)
    REGISTER_WXCONTROL(wxListCtrl, Additional, wxListCtrl description)
    REGISTER_WXCONTROL(wxScrollBar, Standard, wxScrollBar description)
    REGISTER_WXCONTROL(wxSlider95, Additional, wxSlider95 description)
    REGISTER_WXCONTROL(wxHtmlWindow, Additional, wxHtmlWindow description)
	//  wxStaticBitmap crashes trying to persist it's wxBitmap constructor parameter.
    REGISTER_WXCONTROL(wxStaticBitmap, Additional, wxStaticBitmap description)
    REGISTER_WXCONTROL(wxCalendarCtrl, Additional, wxCalendarCtrl description)
    REGISTER_WXCONTROL(wxGenericDirCtrl, Additional, wxGenericDirCtrl description)
    //  wxSpinCtrl is broken
    REGISTER_WXCONTROL(wxSpinCtrl, Additional, wxSpinCtrl description)
	//  wxGrid crashes copying some internal hash map on Create().
    REGISTER_WXCONTROL(wxGrid, Additional, wxGrid description)

    REGISTER_PROPERTY_EDITOR(wxGetTypeInfo((wxPoint*)NULL), wxFrame, Position, wxFramePositionProperty)
    REGISTER_PROPERTY_EDITOR(wxGetTypeInfo((wxColour*)0), wxObject, , wxColourProperty)
    REGISTER_PROPERTY_EDITOR(wxGetTypeInfo((wxPoint*)0), wxWindow, Position, wxWindowPosProperty)
    REGISTER_PROPERTY_EDITOR(wxGetTypeInfo((wxSize*)0), wxWindow, Size, wxWindowSizeProperty)
    REGISTER_PROPERTY_EDITOR(wxGetTypeInfo((wxGBSpan*)NULL), wxGBSizerItem, Span, wxSizerItemSpanProperty)
    REGISTER_PROPERTY_EDITOR(wxGetTypeInfo((wxGBPosition*)NULL), wxGBSizerItem, Pos, wxSizerItemPosProperty)
    REGISTER_PROPERTY_EDITOR(wxTypeInfo::FindType("wxString"), wxFont, Face, wxFontFaceProperty)
    REGISTER_PROPERTY_EDITOR(wxTypeInfo::FindType("int"), wxWindow, Id, wxControlIdProperty)
    REGISTER_PROPERTY_EDITOR(wxTypeInfo::FindType("wxString"), wxGenericDirCtrl, DefaultPath, wxGenericDirPathProperty)
    REGISTER_PROPERTY_EDITOR(wxTypeInfo::FindType("int"), wxFont, Style, INT_AS_ENUM_EDITORCLASS(wxFontStyle))
    REGISTER_PROPERTY_EDITOR(wxTypeInfo::FindType("int"), wxFont, Family, INT_AS_ENUM_EDITORCLASS(wxFontFamily))
    REGISTER_PROPERTY_EDITOR(wxTypeInfo::FindType("int"), wxFont, Weight, INT_AS_ENUM_EDITORCLASS(wxFontWeight))
    REGISTER_PROPERTY_EDITOR(wxTypeInfo::FindType("wxFrameStyle"), wxObject, , wxWindowFlagsProperty)
    REGISTER_PROPERTY_EDITOR(wxTypeInfo::FindType("wxPanelStyle"), wxObject, , wxWindowFlagsProperty)
    REGISTER_PROPERTY_EDITOR(wxTypeInfo::FindType("wxTextCtrlStyle"), wxObject, , wxWindowFlagsProperty)
    REGISTER_PROPERTY_EDITOR(wxTypeInfo::FindType("wxButtonStyle"), wxObject, , wxWindowFlagsProperty)
    REGISTER_PROPERTY_EDITOR(wxTypeInfo::FindType("wxCheckBoxStyle"), wxObject, , wxWindowFlagsProperty)
    REGISTER_PROPERTY_EDITOR(wxTypeInfo::FindType("wxChoiceStyle"), wxObject, , wxWindowFlagsProperty)
    REGISTER_PROPERTY_EDITOR(wxTypeInfo::FindType("wxComboBoxStyle"), wxObject, , wxWindowFlagsProperty)
    REGISTER_PROPERTY_EDITOR(wxTypeInfo::FindType("wxGaugeStyle"), wxObject, , wxWindowFlagsProperty)
    REGISTER_PROPERTY_EDITOR(wxTypeInfo::FindType("wxListBoxStyle"), wxObject, , wxWindowFlagsProperty)
    REGISTER_PROPERTY_EDITOR(wxTypeInfo::FindType("wxListCtrlStyle"), wxObject, , wxWindowFlagsProperty)
    REGISTER_PROPERTY_EDITOR(wxTypeInfo::FindType("wxNotebookStyle"), wxObject, , wxWindowFlagsProperty)
    REGISTER_PROPERTY_EDITOR(wxTypeInfo::FindType("wxRadioButtonStyle"), wxObject, , wxWindowFlagsProperty)
    REGISTER_PROPERTY_EDITOR(wxTypeInfo::FindType("wxScrollBarStyle"), wxObject, , wxWindowFlagsProperty)
    REGISTER_PROPERTY_EDITOR(wxTypeInfo::FindType("wxSliderStyle"), wxObject, , wxWindowFlagsProperty)
    REGISTER_PROPERTY_EDITOR(wxTypeInfo::FindType("wxStaticBoxStyle"), wxObject, , wxWindowFlagsProperty)
    REGISTER_PROPERTY_EDITOR(wxTypeInfo::FindType("wxStaticLineStyle"), wxObject, , wxWindowFlagsProperty)
    REGISTER_PROPERTY_EDITOR(wxTypeInfo::FindType("wxStaticTextStyle"), wxObject, , wxWindowFlagsProperty)
    REGISTER_PROPERTY_EDITOR(wxTypeInfo::FindType("wxTreeCtrlStyle"), wxObject, , wxWindowFlagsProperty)
    REGISTER_PROPERTY_EDITOR(wxTypeInfo::FindType("wxGenericDirCtrlStyle"), wxObject, , wxWindowFlagsProperty)
    REGISTER_PROPERTY_EDITOR(wxTypeInfo::FindType("wxSizerItemStyle"), wxObject, , wxSetProperty)

    REGISTER_COMPONENT_EDITOR(wxFrame, wxFrameEditor)
    REGISTER_COMPONENT_EDITOR(wxNotebook, wxNotebookEditor)
    REGISTER_COMPONENT_EDITOR(wxGridBagSizer, wxGBSizerEditor)

}






