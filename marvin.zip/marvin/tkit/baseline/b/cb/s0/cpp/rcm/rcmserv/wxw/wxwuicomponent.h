#ifndef wxwuicomponentH
#define wxwuicomponentH

#include "wxw.h"
#include "wxwcomponent.h"

class RCMEXPORT wxwUIComponent : public wxwComponent, public DesignRectProvider, public rcmUIComponent
{
public:
	wxwUIComponent(const wxClassInfo *classInfo, wxwDesigner *designer, wxwContainer *container)
        : wxwComponent(classInfo, designer, container) { }

    virtual void Paint(wxDC &dc, int x, int y);

    // rcmUIComponent methods
    virtual bool CanPaintChildren() { return true; }
    virtual bool ConstrainChildren() { return true; }
	virtual void GetClientRect(int &x, int &y, int &w, int &h);
    virtual wxString GetImageData(int x, int y, int w, int h, wxMemoryOutputStream *&stream);
	virtual void GetImageData(int x, int y, int w, int h, ImageResponse *ir);
    virtual void GetRect(int &x, int &y, int &w, int &h);
    virtual void GetSize(int &w, int &h);
   	virtual void GetTopLeft(int &t, int &l);
    virtual int GetZOrderPosition();
    virtual bool IsTopLevel() { return false; }
	virtual Result* SetParent(rcmContainer *newContainer);
    virtual void SetRect(int &x, int &y, int &w, int &h, bool testOnly = false);
    virtual void SetSize(int &w, int &h);
    virtual void SetTopLeft(int &t, int &l);
	virtual Result* SetZOrderPosition(rcmComponent *child, int z);
    virtual bool Visible() { return true; }

protected:
    virtual void DoGetRect(int &x, int &y, int &w, int &h) = 0;
    virtual void DoSetRect(int &x, int &y, int &w, int &h, bool testOnly) = 0;
    virtual void PaintChild(wxwUIComponent *child, wxDC &dc, int x, int y);
};

#endif
