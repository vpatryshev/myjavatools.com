//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "sizedialog.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TPSDlg *PSDlg;
//---------------------------------------------------------------------------
__fastcall TPSDlg::TPSDlg(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------

bool __fastcall TPSDlg::GetSize(TRect &r)
{
    LabeledEdit1->Text = IntToStr(r.Left);
    LabeledEdit2->Text = IntToStr(r.Top);
    LabeledEdit3->Text = IntToStr(r.Right);
    LabeledEdit4->Text = IntToStr(r.Bottom);
    if (ShowModal() == mrOk) {
        r.Left = StrToInt(LabeledEdit1->Text);
        r.Top = StrToInt(LabeledEdit2->Text);
        r.Right = StrToInt(LabeledEdit3->Text);
        r.Bottom = StrToInt(LabeledEdit4->Text);
        return true;
    }
    else
        return false;
}
