#ifdef __BORLANDC__
#include "rcmpch.h"
#endif

#pragma hdrstop

#include "wxwcomponenteditor.h"

IMPLEMENT_DYNAMIC_CLASS(wxwComponentEditor, wxObject)

wxwComponentEditor::wxwComponentEditor() : FComponent(0), FDesigner(0)
{
}

void wxwComponentEditor::Init(wxwComponent *component, wxwDesigner *designer)
{
    FComponent = component;
    FDesigner = designer;
}

// wxwFrameEditor

IMPLEMENT_DYNAMIC_CLASS(wxFrameEditor, wxwComponentEditor)

void wxFrameEditor::UpdateMenu(MenuItems &menu, int x, int y)
{
    MenuItem *item = new MenuItem("Maximize", 1);
    item->SetOnItemClick(MENU_CLICK_SINK(wxFrameEditor, MenuItemClicked));
    menu.push_back(item);
    item = new MenuItem("Restore", 2);
    item->SetOnItemClick(MENU_CLICK_SINK(wxFrameEditor, MenuItemClicked));
    menu.push_back(item);
}

//          FButton1->SetOnClick(TEventT<Form1>(&form1, &Form1::Button1Click));

void wxFrameEditor::MenuItemClicked(MenuItem *item, Result *&result)
{
    switch (item->GetId()) {
        case 1:
            Instance()->Maximize(true);
            result = new Result(true);
            break;
        case 2:
            Instance()->Maximize(false);
            result = new Result(true);
            break;
        default:
            result = new Result(false);
    }
}


