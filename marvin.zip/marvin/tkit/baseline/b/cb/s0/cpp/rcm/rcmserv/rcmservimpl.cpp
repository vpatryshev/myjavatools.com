#ifdef __BORLANDC__
#include "rcmpch.h"
#endif

#include "rcm.h"
#include "soapH.h"
#include <algorithm>

class soap_error : public runtime_error
{
public:
	soap_error(const string_type &fs, const string_type &fd = "") : runtime_error(CSTR(fs))
	{
	    detail = fd;
	}
	string_type detail;
};

class soap_sender_error : public soap_error
{
public:
	soap_sender_error(const string_type &fs, const string_type &fd = "") : soap_error(fs, fd) { }
};

class soap_receiver_error : public soap_error
{
public:
	soap_receiver_error(const string_type &fs, const string_type &fd = "") : soap_error(fs, fd) { }
};

class soap_bad_key : public soap_sender_error
{
public:
	soap_bad_key(const string_type &key, const string_type &keyType) : soap_sender_error("Unknown key", "")
    {
	    detail.sprintf("\"%s\" is not a valid %s key", key, keyType);
    }
};

class rcmTransportServer : public TTransportServer
{
public:
    rcmTransportServer(struct soap *soap, int port = 0);
    ~rcmTransportServer() { }

    int SoapAccept(struct soap *soap, int timeout);
    int SoapSend(const char *data, size_t size);
    size_t SoapRecv(char *data, size_t size);
    int SoapFClose();
    int SoapFOpen(const char *endpoint, const char *host, int port);

protected:
    virtual bool GetImageData(char *uri, ImageResponse *ir);
    virtual bool GetImageData(char *managerKey, char *designerKey,
        char *compInstanceKey, int x, int y, int w, int h, ImageResponse *ir);
    virtual bool ServeSoapRequest(char *request, size_t len, SoapData *response);

private:
    soap *FSoap;
    size_t bytesWritten;
    size_t bytesRead;
    int FPort;
    int lastSoapCode;
    const char *soapRequestStr;
    size_t soapRequestLen;
    SoapData *FResponse;
};

rcmTransportServer *transport = 0;

// rcmTransportServer

int soap_fsend(struct soap *soap, const char *s, size_t n)
{
    assert(transport);
    return transport->SoapSend(s, n);
}

size_t soap_frecv(struct soap *soap, char *s, size_t n)
{
    assert(transport);
    return transport->SoapRecv(s, n);
}

int soap_fopen(struct soap *soap, const char *s, const char *t, int n)
{
    assert(transport);
    return transport->SoapFOpen(s, t, n);
}

int soap_fclose(struct soap *soap)
{
    assert(transport);
    return transport->SoapFClose();
}

int soap_fposthdr(struct soap *soap, const char *key, const char *val)
{
    return SOAP_OK;
}

rcmTransportServer::rcmTransportServer(struct soap *soap, int port)
    : TTransportServer("RCM_WXW", MAX_SHMEM_SIZE)
{
    FSoap = soap;
    soap_init(FSoap);
    FPort = port;
    if (!FPort) {
        FSoap->frecv = soap_frecv;
        FSoap->fsend = soap_fsend;
        FSoap->fopen = soap_fopen;
        FSoap->fclose = soap_fclose;
        FSoap->fposthdr = soap_fposthdr;
    }
    else {
       	int m = soap_bind(FSoap, 0, FPort, 500);
       	if (m < 0) {
          	soap_print_fault(FSoap, stderr);
         }
    }
    bytesWritten = 0;
    bytesRead = 0;
}

int rcmTransportServer::SoapAccept(struct soap *soap, int timeout)
{
    lastSoapCode = SOAP_EOF;
    CheckForSoapRequest();
    return lastSoapCode;
}

bool rcmTransportServer::GetImageData(char *uri, ImageResponse *ir)
{
    rcmComponentModel *cm = Server().GetModel();
    if (cm) {
        cm->GetImageData(uri, ir);
        return true;
    }
    return false;
}

bool rcmTransportServer::GetImageData(char *managerKey, char *designerKey,
    char *compInstanceKey, int x, int y, int w, int h, ImageResponse *ir)
{
    rcmUIComponent *uic = Server().GetUIComponent(
        managerKey,
        designerKey,
        compInstanceKey);

    if (uic) {
        uic->GetImageData(
            x, y, w, h,
            ir);
        return true;
    }
    return false;
}

bool rcmTransportServer::ServeSoapRequest(char *request, size_t len, SoapData *response)
{
    soapRequestStr = request;
    soapRequestLen = len;
    FResponse = response;
    bytesWritten = 0;
    bytesRead = 0;
    lastSoapCode = soap_serve(FSoap);
    return lastSoapCode == SOAP_OK;
}
/*    if (WaitForSingleObject(hExec, timeout) == WAIT_OBJECT_0) {
        Lock();
        ::ResetEvent(hExec);
        soap_result = soap_serve(soap);
        Unlock();
        ::SetEvent(hDone);
    }
    return soap_result;
*/

int rcmTransportServer::SoapFClose()
{
    if (bytesWritten > 0) {
        FResponse->size = bytesWritten;
        FResponse->key = BYTE_DATA;
        bytesWritten = 0;
        bytesRead = 0;
    }
    return SOAP_OK;
}

int rcmTransportServer::SoapFOpen(const char *endpoint, const char *host, int port)
{
    return 0; // fake file descriptor, return -1 when error
}

size_t rcmTransportServer::SoapRecv(char *s, size_t n)
{
    size_t toRead = min(n, soapRequestLen - bytesRead);
    if (bytesRead + toRead <= soapRequestLen) {
        strncpy(s, soapRequestStr + bytesRead, toRead);
        bytesRead += toRead;
    }
    else
        toRead = 0;
    return toRead;
}

int rcmTransportServer::SoapSend(const char *s, unsigned int n)
{
    if (bytesWritten + n < MAX_DATASIZE) {
        strncpy(FResponse->data + bytesWritten, s, n);
        bytesWritten += n;
        return SOAP_OK;
    }
    else
        return SOAP_EOM;
}

int tick;

void StartTick(char *s)
{
#ifdef DUMB_PROFILE
    tick = ::GetTickCount();
    cout << s;
#endif
}

void EndTick(char *s)
{
#ifdef DUMB_PROFILE
    if (s) cout << " " << s;
    cout << " [" << ::GetTickCount() - tick << " ms]" << "\n";

#endif
}

// default exception handling to fault according to SOAP 1.2 spec.

#define DEFAULT_CATCH 														\
	catch(soap_sender_error &serr) { 									  	\
    	return soap_sender_fault(soap, serr.what(), serr.detail.c_str()); 	\
    } 																	  	\
    catch(soap_receiver_error &rerr) {										\
    	return soap_receiver_fault(soap, rerr.what(), rerr.detail.c_str());	\
    }                                                                       \
    catch(exception &e) {													\
		return soap_receiver_fault(soap, typeid(e).name(), e.what());		\
    }																		\
    catch(...) {															\
    	return soap_receiver_fault(soap, "Unhandled exception", "");		\
	}

// Allocate and assign a string to be freed by gsoap.

char* soap_strcpy(soap *soap, char *&dest, const char *src)
{
    int len = strlen(src);
    if (len > 0)
    {
        char *s = (char*)soap_malloc(soap, len+1);
        dest = strcpy(s, src);
    }
    else
        dest = NULL;
    return dest;
}

// Utilities to copy rcm classes to serializable soap classes.

void SerializeRectangle(int x, int y, int w, int h, impl__WSRect &wsr)
{
    wsr.x = x;
    wsr.y = y;
    wsr.width = w;
    wsr.height = h;
}

void SerializeMenuItem(
    struct soap *soap,
    impl__WSTag *wst,
    MenuItem &item)
{
    wst->tags = NULL;
	soap_strcpy(soap, wst->description, item.Description());
	soap_strcpy(soap, wst->displayName, item.Caption());
	soap_strcpy(soap, wst->displayIconURI, item.DisplayIconURI());
    wst->tagKey = (char*)soap_malloc(soap, 9); // max buffer size for itoa()
    sprintf(wst->tagKey, "%08X", (unsigned int)&item);
    wst->tagKey[8] = 0;

    // items with sub items will not be "invokable"
    wst->invokable = item.Count() == 0;
    wst->popup = item.Count() > 0;
    wst->enabled = item.Enabled();
    wst->__size_ = item.Count();
    wst->hasChildren = wst->__size_ > 0;
    if (wst->hasChildren) {
        wst->tags = soap_new_impl__WSTag(soap, wst->__size_);
        impl__WSTag *tag = wst->tags;
        if (item.Count() > 0) {
            list<MenuItem*>::const_iterator it = item.Items()->begin();
            for (; it != item.Items()->end(); ++it) {
                SerializeMenuItem(soap, tag, *(*it));
                tag++;
            }
        }
    }
}

void SerializeMenuItems(
    struct soap *soap,
    ArrayOfWSTag *wsts,
    MenuItems &items)
{
    wsts->__size = items.size();
    wsts->__offset = 0;
    wsts->__ptr = soap_new_impl__WSTag(soap, wsts->__size);
    impl__WSTag *wst = wsts->__ptr;
    MenuItems::const_iterator it = items.begin();
    for (; it != items.end(); ++it) {
        SerializeMenuItem(soap, wst, *(*it));
        wst++;
    }
}

void SerializeChoice(
    struct soap *soap,
    impl__WSTag *wst,
    PropertyChoice &ch)
{
    wst->tags = NULL;
    wst->description = NULL;
	soap_strcpy(soap, wst->displayName, ch.GetDisplayValue());
	soap_strcpy(soap, wst->displayIconURI, ch.GetDisplayIconURI());
    soap_strcpy(soap, wst->tagKey, ch.GetValue());
    wst->invokable = true;
    wst->popup = false;
    wst->enabled = true;
    wst->__size_ = 0;
    wst->hasChildren = false;
}

void SerializeChoices(
    struct soap *soap,
    ArrayOfWSTag *wsts,
    PropertyChoices &choices)
{
    wsts->__size = choices.size();
    wsts->__offset = 0;
    wsts->__ptr = soap_new_impl__WSTag(soap, wsts->__size);
    impl__WSTag *wst = wsts->__ptr;
    PropertyChoices::const_iterator it = choices.begin();
    for (; it != choices.end(); ++it) {
        SerializeChoice(soap, wst, *(*it));
        wst++;
    }

}

void SerializeOption(
    struct soap *soap,
    impl__WSTag *wst,
    ResultOption &o)
{
	soap_strcpy(soap, wst->description, o.Description());
	soap_strcpy(soap, wst->displayName, o.Text());
	soap_strcpy(soap, wst->displayIconURI, o.DisplayIconURI());
    wst->tagKey = (char*)soap_malloc(soap, 33); // max buffer size for itoa()
    itoa(o.Id(), wst->tagKey, 10);
    wst->invokable = true;
    wst->popup = false;
    wst->hasChildren = false;
    wst->__size_ = 0;
    wst->tags = NULL;
}

void SerializeOptions(
	struct soap *soap,
    impl__WSTag *arrayPtr,
    ResultOptions &rcmos)
{
    for (ResultOptions::iterator it = rcmos.begin(); it != rcmos.end(); ++it) {
    	SerializeOption(soap, arrayPtr, *(*it));
        arrayPtr++;
    }
}

void SerializeMessage(
	struct soap *soap,
    impl__WSResultMessage &wsrm,
    ResultMessage &m)
{
	soap_strcpy(soap, wsrm.messageText, m.Detail());
    soap_strcpy(soap, wsrm.messageTitle, m.Text());
    soap_strcpy(soap, wsrm.messageIconURI, m.IconURI());
    soap_strcpy(soap, wsrm.messageKey, m.Key());
	wsrm.messageType = (int)(m.Type());
}

void SerializeMessages(
	struct soap *soap,
    impl__WSResultMessage *arrayPtr,
    ResultMessages &rms)
{
	if (!arrayPtr) return;
    for (ResultMessages::iterator it = rms.begin(); it != rms.end(); ++it) {
    	SerializeMessage(soap, *arrayPtr, *(*it));
    	arrayPtr++;
    }
}

void SerializeResult(
	struct soap *soap,
    impl__WSResult *wsr,
    Result *r)
{
	if (!wsr) return;
    soap_strcpy(soap, wsr->resultKey, r->Key());
    wsr->success = r->Success();
    wsr->messages = NULL;
    wsr->options = NULL;
    wsr->__size_ = r->Messages().size();
    if (wsr->__size_ > 0) {
    	wsr->messages = soap_new_impl__WSResultMessage(soap, wsr->__size_);
        SerializeMessages(soap, wsr->messages, r->Messages());
    }
    wsr->__size__ = r->Options().size();
    if (wsr->__size__ > 0) {
        wsr->options = soap_new_impl__WSTag(soap, wsr->__size__);
        SerializeOptions(soap, wsr->options, r->Options());
    }
}

struct propsort : public binary_function<rcmProperty*, rcmProperty*, bool>
{
	bool operator()(const rcmProperty* p1, const rcmProperty* p2) const
	{
		return strcmp(CSTR(p1->Name()), CSTR(p2->Name())) < 0 ? true : false;
	}
};

struct eventsort : public binary_function<rcmEvent*, rcmEvent*, bool>
{
	bool operator()(const rcmEvent* e1, const rcmEvent* e2) const
	{
		return strcmp(CSTR(e1->Name()), CSTR(e2->Name())) < 0 ? true : false;
	}
};

void SerializeEvent(
	struct soap *soap,
	rcmComponent *c,
	rcmEvent &e,
	impl__WSLiveEvent &wse)
{
    soap_strcpy(soap, wse.compInstanceKey, c->Key());
    wse.eventKeyPath = StringArrayToCharArray(soap, e.Keys(), wse.__size_);
	soap_strcpy(soap, wse.hookAsText, c->GetValue(&e));
    wse.hooked = wse.hookAsText && strlen(wse.hookAsText) > 0;
	wse.hasHookTags = (e.Flags() & PE_DYNAMICVALUELIST) == PE_DYNAMICVALUELIST;
    wse.hasChildren = false;
}

void SerializeEvents(
	struct soap *soap,
	rcmComponent *c,
	ArrayOfWSLiveEvent *wses,
	list<rcmEvent*> &es)
{
	if (wses) {
    	es.sort(eventsort());
		wses->__size = es.size();
		wses->__offset = 0;
		wses->__ptr = soap_new_impl__WSLiveEvent(soap, wses->__size);
		impl__WSLiveEvent *e = wses->__ptr;
		for (list<rcmEvent*>::iterator it = es.begin(); it != es.end(); ++it) {
			SerializeEvent(soap, c, *(*it), *e);
			e++;
		}
	}
}

void SerializeDesignRect(
	struct soap *soap,
    impl__WSUIDesignRect &wsdr,
    DesignRect &dr)
{
    wsdr.rect = soap_new_impl__WSRect(soap, -1);
    int x, y, w, h = 0;
    dr.GetRect(x, y, w, h);
    SerializeRectangle(x, y, w, h, *(wsdr.rect));
    soap_strcpy(soap, wsdr.designRectKey, dr.Key());
    int flags = dr.Flags();
	wsdr.clickable = dr.CanClick();
	wsdr.moveVertical = flags & MOVE_VERT;
    wsdr.moveHorizontal = flags & MOVE_HORZ;
    wsdr.resizeTop = flags & RESIZE_TOP;
    wsdr.resizeLeft = flags & RESIZE_LEFT;
    wsdr.resizeBottom = flags & RESIZE_BOTTOM;
    wsdr.resizeRight = flags & RESIZE_RIGHT;

    // why can't joe figure this out on his side? Sheesh.
    wsdr.movable = wsdr.moveVertical || wsdr.moveHorizontal;
    wsdr.resizable = wsdr.resizeTop || wsdr.resizeLeft || wsdr.resizeBottom || wsdr.resizeRight;

    soap_strcpy(soap, wsdr.toolTipText, dr.ToolTip());
    wsdr.moveConstraintRect = NULL;
    if (wsdr.movable) {
        x = y = h = w = -1;
        dr.GetMoveConstraints(x, y, w, h);
        if (!(x == y == w == h == -1)) {
            wsdr.moveConstraintRect = soap_new_impl__WSRect(soap, -1);
            SerializeRectangle(x, y, w, h, *(wsdr.moveConstraintRect));
        }
    }
    wsdr.resizeConstraintRect = NULL;
    if (wsdr.resizable) {
        x = y = h = w = -1;
        dr.GetResizeConstraints(x, y, w, h);
        if (!(x == y == w == h == -1)) {
            wsdr.resizeConstraintRect = soap_new_impl__WSRect(soap, -1);
            SerializeRectangle(x, y, w, h, *(wsdr.resizeConstraintRect));
        }
    }
//    dr.UpdateMenu(-1, -1);
    wsdr.hasContextTags = true;//dr.MenuItemCount() > 0;
}

void SerializeComponent(
	struct soap *soap,
    impl__WSLiveComponent *wsc,
    rcmComponent *c)
{
    wsc->parentInstanceKey = NULL;
    wsc->designerKey = NULL;
    wsc->userRenamable = c->CanRename();
    soap_strcpy(soap, wsc->instanceName, c->GetName());
    soap_strcpy(soap, wsc->instanceKey, c->Key());
    rcmDesigner::Info *di = c->Designer()->GetDesignerInfo();
    if (di) {
    	soap_strcpy(soap, wsc->designerKey, di->DesignerKey());
    }
	rcmComponent* containerComp = dynamic_cast<rcmComponent*>(c->Container());
    if (containerComp) {
       soap_strcpy(soap, wsc->parentInstanceKey, containerComp->Key());
    }
	soap_strcpy(soap, wsc->componentTypeKey, c->ComponentInfo()->Key());
    wsc->container = c->IsContainer();
}

void SerializeAsContainer(
	struct soap *soap,
	impl__WSLiveContainer *wsc,
	rcmComponent *c)
{
	rcmContainer *cont = dynamic_cast<rcmContainer*>(c);
	if (!cont) return;
	SerializeComponent(soap, wsc, c);
	rcmComponents comps = cont->Components();
	wsc->__size_ = comps.size();
	if (wsc->__size_) {
		wsc->components = soap_new_impl__WSLiveComponent(soap, wsc->__size_);
		impl__WSLiveComponent *lc = wsc->components;
		for (rcmComponents::iterator it = comps.begin(); it != comps.end(); ++it) {
			SerializeComponent(soap, lc, *it);
			lc++;
		}
	}
}

void SerializeAsUIComponent(
	struct soap *soap,
    impl__WSLiveUIComponent *wsc,
    rcmComponent *c)
{
	SerializeComponent(soap, wsc, c);
	rcmUIComponent *ui = dynamic_cast<rcmUIComponent*>(c);
	if (!ui) return;
    wsc->rect = soap_new_impl__WSRect(soap, -1);
    int x, y, w, h = -1;
    ui->GetRect(x, y, w, h);
    SerializeRectangle(x, y, w, h, *(wsc->rect));
    wsc->visible = ui->Visible();
    wsc->designRects = NULL;
    wsc->__size_ = 0;
    DesignRectProvider *drs = Server().GetDesignRectProvider(c);
    if (drs) {
        drs->UpdateRects();
        wsc->__size_ = drs->RectCount();
        if (wsc->__size_) {
        	wsc->designRects = soap_new_impl__WSUIDesignRect(soap, wsc->__size_);
            impl__WSUIDesignRect *dr = wsc->designRects;
            for (DesignRects::const_iterator it = drs->Rects()->begin(); it != drs->Rects()->end(); ++it) {
        	    SerializeDesignRect(soap, *dr, *(*it));
            	dr++;
            }
        }
    }
}

void SerializeAsUIContainer(
	struct soap *soap,
	impl__WSLiveUIContainer *wsuic,
	rcmComponent *c)
{
	rcmUIComponent *ui = dynamic_cast<rcmUIComponent*>(c);
	rcmContainer *cont = dynamic_cast<rcmContainer*>(c);
	if (!ui || !cont) return;
	wsuic->uiComponents = NULL;
	SerializeAsUIComponent(soap, wsuic, c);
	wsuic->constrainedChildren = ui->ConstrainChildren();
    wsuic->canPaintChildren = ui->CanPaintChildren();
	wsuic->clientRect = soap_new_impl__WSRect(soap, -1);
    int x, y, w, h = -1;
    ui->GetClientRect(x, y, w, h);
	SerializeRectangle(x, y, w, h, *(wsuic->clientRect));
	rcmComponents comps = cont->Components();
	wsuic->__size__ = comps.size();
	if (wsuic->__size__) {
		wsuic->uiComponents = soap_new_impl__WSLiveUIComponent(soap, wsuic->__size__);
		impl__WSLiveUIComponent *uic = wsuic->uiComponents;
		for (rcmComponents::iterator it = comps.begin(); it != comps.end(); ++it) {
			SerializeAsUIComponent(soap, uic, *it);
			uic++;
		}
	}
}

void SerializeComponents(
	struct soap *soap,
    ArrayOfWSLiveComponent *wscs,
	rcmComponents &cs)
{
	wscs->__size = cs.size();
    wscs->__offset = 0;
    wscs->__ptr = soap_new_impl__WSLiveComponent(soap, cs.size());
    impl__WSLiveComponent *comp = wscs->__ptr;
    for (rcmComponents::const_iterator it = cs.begin(); it != cs.end(); ++it) {
    	SerializeComponent(soap, comp, *it);
    	comp++;
    }
}

void SerializeUIComponents(
    struct soap *soap,
    ArrayOfWSLiveUIComponent *wsuics,
    rcmComponents &cs)
{
    wsuics->__size = cs.size();
    wsuics->__offset = 0;
    wsuics->__ptr = soap_new_impl__WSLiveUIComponent(soap, cs.size());
    impl__WSLiveUIComponent *uicomp = wsuics->__ptr;
    for (rcmComponents::iterator it = cs.begin(); it != cs.end(); ++it) {
        SerializeAsUIComponent(soap, uicomp, *it);
        uicomp++;
    }
}

void SerializeCreateResult(
 	struct soap *soap,
    impl__WSCreateResult *wscr,
    CreateResult *cr)
{
	if (!wscr) return;
  	SerializeResult(soap, wscr, cr);
	wscr->component = NULL;
    if (cr->Component()) {
	    wscr->component = soap_new_impl__WSLiveComponent(soap, -1);
   		SerializeComponent(soap, wscr->component, cr->Component());
    }
}

void SerializeUICreateResult(
 	struct soap *soap,
    impl__WSUICreateResult *wscr,
    CreateResult *cr)
{
	if (!wscr) return;
   	SerializeResult(soap, wscr, cr);
	wscr->component = NULL;
    if (cr->Component()) {
	    wscr->uiComponent = soap_new_impl__WSLiveUIComponent(soap, -1);
        impl__WSLiveUIComponent *uic = dynamic_cast<impl__WSLiveUIComponent*>(wscr->uiComponent);
   		SerializeAsUIComponent(soap, uic, cr->Component());
    }
}

void SerializeDesignerInfo (
    struct soap *soap,
    impl__WSDesignerInfo *wsdi,
    rcmDesigner::Info *di)
{
    soap_strcpy(soap, wsdi->designerKey, di->DesignerKey());
    soap_strcpy(soap, wsdi->displayName, di->DisplayName());
    soap_strcpy(soap, wsdi->description, di->Description());
    soap_strcpy(soap, wsdi->displayIconURI, di->DisplayIconURI());
}

void SerializeDesigner(
	struct soap *soap,
    impl__WSLiveDesigner *wsd,
    rcmDesigner *d)
{
    soap_strcpy(soap, wsd->managerInstanceKey, d->Manager()->Key());
    SerializeDesignerInfo(soap, wsd, d->GetDesignerInfo());
}

void SerializeUIDesigner(
	struct soap *soap,
    impl__WSLiveUIDesigner *wsd,
    rcmDesigner *d)
{
	SerializeDesigner(soap, wsd, d);
	rcmUIDesigner *uid = dynamic_cast<rcmUIDesigner*>(d);
    if (uid) {
    	soap_strcpy(soap, wsd->designerImageURI, uid->ImageURI());
		wsd->constrainChildrenToClientRect = uid->ConstrainsChildren();
        if (wsd->constrainChildrenToClientRect) {
            wsd->designerClientRect = soap_new_impl__WSRect(soap, -1);
            int x, y, w, h = -1;
            uid->ClientRect(x, y, w, h);
            SerializeRectangle(x, y, w, h, *(wsd->designerClientRect));
        } else
            wsd->designerClientRect = NULL;
        wsd->designRects = NULL;
        wsd->__size_ = 0;
        DesignRectProvider *drs = Server().GetDesignRectProvider(d);
        if (drs) {
            drs->UpdateRects();
            wsd->__size_ = drs->RectCount();
            if (wsd->__size_ > 0) {
    			wsd->designRects = soap_new_impl__WSUIDesignRect(soap, wsd->__size_);
	    		impl__WSUIDesignRect *dr = wsd->designRects;
                for (DesignRects::const_iterator it = drs->Rects()->begin(); it != drs->Rects()->end(); ++it) {
                	SerializeDesignRect(soap, *dr, *(*it));
                    dr++;
                }
            }
        }
    }
}

void SerializeDesignerEvent(
	struct soap *soap,
	impl__WSDesignerEvent *wsde,
	DesignerEvent *de)
{
	// This has got to be the worst example of Joe Nuxoll's incredibly lame
    // and poorly architected ACM interfaces.
	wsde->designerEventID = de->Code();
    wsde->managerInstanceKey = 0;
	wsde->compInstanceKey = 0;
	wsde->eventKeyPath = 0;
	wsde->propertyKeyPath = 0;
    wsde->__size_ = 0;
    wsde->__size__ = 0;
    wsde->customDataKey = 0;
    wsde->customDataValue = 0;
    soap_strcpy(soap, wsde->managerInstanceKey, de->ManagerKey());
    if (wsde->designerEventID < CUSTOM_DATA)
        soap_strcpy(soap, wsde->designerKey, de->DesignerKey());
    else
        wsde->designerKey = 0;
	switch (wsde->designerEventID) {
		case COMPONENT_CREATED:
		case COMPONENT_CHANGED:
		case COMPONENT_DISPOSED:
        {
            ComponentEvent *ce = dynamic_cast<ComponentEvent*>(de);
            assert(ce);
            soap_strcpy(soap, wsde->compInstanceKey, ce->ComponentKey());
			break;
        }
		case PROPERTY_CHANGED:
        {
            PropertyChangedEvent *pce = dynamic_cast<PropertyChangedEvent*>(de);
            if (pce) {
                wsde->propertyKeyPath = StringArrayToCharArray(soap, pce->Keys(), wsde->__size_);
                soap_strcpy(soap, wsde->compInstanceKey, pce->ComponentKey());
            }
			break;
        }
        case EVENT_CHANGED:
        {
            EventChangedEvent *pce = dynamic_cast<EventChangedEvent*>(de);
            if (pce) {
                wsde->eventKeyPath = StringArrayToCharArray(soap, pce->Keys(), wsde->__size__);
                soap_strcpy(soap, wsde->compInstanceKey, pce->ComponentKey());
            }
			break;
        }
		case CUSTOM_DATA:
        {
            CustomEvent *ce = dynamic_cast<CustomEvent*>(de);
            if (ce) {
                soap_strcpy(soap, wsde->customDataKey, ce->Key());
			    soap_strcpy(soap, wsde->customDataValue, ce->Data());
            }
			break;
        }
	}
}

void SerializeDesignerEvents(
	struct soap *soap,
	ArrayOfWSDesignerEvent *wsdes,
	DesignerEvents &des)
{
	wsdes->__size = des.size();
    wsdes->__offset = 0;
    wsdes->__ptr = soap_new_impl__WSDesignerEvent(soap, des.size());
    impl__WSDesignerEvent *de = wsdes->__ptr;
    for (DesignerEvents::iterator it = des.begin(); it != des.end(); ++it) {
    	SerializeDesignerEvent(soap, de, *it);
        // TODO: delete events
    	de++;
    }
}

void SerializeLiveDesignerManager(
	struct soap *soap,
    impl__WSLiveDesignerManager *wsdm,
    rcmDesignerManager *rcdm)
{
	soap_strcpy(soap, wsdm->managerInstanceKey, rcdm->Key());
    soap_strcpy(soap, wsdm->modelKey, rcdm->Model()->Key());
}

void SerializeLiveDesignerManagers(
	struct soap *soap,
    ArrayOfWSLiveDesignerManager *wsdms,
    rcmDesignerManagers &dms)
{
	wsdms->__size = dms.size();
    wsdms->__offset = 0;
    wsdms->__ptr = soap_new_impl__WSLiveDesignerManager(soap, dms.size());
    impl__WSLiveDesignerManager *dm = wsdms->__ptr;
    for (rcmDesignerManagers::iterator it = dms.begin(); it != dms.end(); ++it) {
    	SerializeLiveDesignerManager(soap, dm, it->second);
        dm++;
    }
}

void SerializeComponentModel(
	struct soap *soap,
	impl__WSComponentModel *wscm,
    rcmComponentModel *m)
{
    if (!wscm || !m) return;
    soap_strcpy(soap, wscm->description, m->Description());
    soap_strcpy(soap, wscm->displayName, m->DisplayName());
    soap_strcpy(soap, wscm->modelKey, m->Key());
    soap_strcpy(soap, wscm->displayIconURI, m->ImageURI());
}

void SerializeEventInfo(
	struct soap *soap,
    rcmEvent &ei,
	impl__WSEventInfo *wsei)
{
    int flags = ei.Flags();
    wsei->eventKeyPath = StringArrayToCharArray(soap, ei.Keys(), wsei->__size_);
    soap_strcpy(soap, wsei->displayName, ei.Name());
    soap_strcpy(soap, wsei->description, ei.Description());
    soap_strcpy(soap, wsei->displayIconURI, ei.IconURI());
    soap_strcpy(soap, wsei->signature, ei.Signature());
    wsei->hookTags = (flags & PE_STATICVALUELIST) == PE_STATICVALUELIST;
    wsei->hasChildren = (flags & PE_SUBPROPS) == PE_SUBPROPS;
    wsei->constrainedToTags = (flags & PE_NOEDIT) == PE_NOEDIT;
    wsei->hookable = true; // false for top-level "event" in a group or set.
}

void SerializeEventInfos(
	struct soap *soap,
	ArrayOfWSEventInfo *wseis,
    list<rcmEvent*> &eis)
{
	eis.sort(eventsort());
	wseis->__size = eis.size();
    wseis->__offset = 0;
    wseis->__ptr = soap_new_impl__WSEventInfo(soap, eis.size());
    impl__WSEventInfo *ei = wseis->__ptr;
    for (list<rcmEvent*>::iterator it = eis.begin(); it != eis.end(); ++it) {
    	SerializeEventInfo(soap, *(*it), ei);
        ei++;
    }
}

void SerializePropertyInfo(
	struct soap *soap,
    rcmProperty &p,
    impl__WSPropertyInfo *wspi)
{
    wspi->propertyKeyPath = StringArrayToCharArray(soap, p.Keys(), wspi->__size_);
    soap_strcpy(soap, wspi->displayName, p.Name());
    soap_strcpy(soap, wspi->description, p.Description());
    soap_strcpy(soap, wspi->displayIconURI, p.IconURI());
    soap_strcpy(soap, wspi->propertyTypeKey, p.TypeKey());
    int flags = p.Flags();
    wspi->readOnly = (flags & PE_READONLY) == PE_READONLY;
    wspi->hasValueTags = (flags & PE_STATICVALUELIST) == PE_STATICVALUELIST;
    wspi->constrainedToTags = (flags & PE_NOEDIT) == PE_NOEDIT;
    wspi->hasChildren = (flags & PE_SUBPROPS) == PE_SUBPROPS;
}

void SerializeProperty(
	struct soap *soap,
    rcmComponent *c,
    rcmProperty &p,
    impl__WSLiveProperty *wsp)
{
    SerializePropertyInfo(soap, p, wsp);
	soap_strcpy(soap, wsp->compInstanceKey, c->Key());
    wsp->modified = false; //Ip.IsModified();
    wsp->propertyKeyPath = StringArrayToCharArray(soap, p.Keys(), wsp->__size_);
    soap_strcpy(soap, wsp->valueAsText, p.GetValue());
    wsp->hasValueTags = wsp->hasValueTags || (p.Flags() & PE_DYNAMICVALUELIST) == PE_DYNAMICVALUELIST;
}

void SerializePropertyInfos(
	struct soap *soap,
	ArrayOfWSPropertyInfo *wspis,
    list<rcmProperty*> &pis)
{
	pis.sort(propsort());
	wspis->__size = pis.size();
    wspis->__offset = 0;
    wspis->__ptr = soap_new_impl__WSPropertyInfo(soap, pis.size());
    impl__WSPropertyInfo *pi = wspis->__ptr;
    for (list<rcmProperty*>::iterator it = pis.begin(); it != pis.end(); ++it) {
    	SerializePropertyInfo(soap, *(*it), pi);
        pi++;
    }
}

void SerializeProperties(
	struct soap *soap,
    rcmComponent *c,
    ArrayOfWSLiveProperty *wsps,
    list<rcmProperty*> &ps)
{
	if (wsps) {
    	ps.sort(propsort());
    	wsps->__size = ps.size();
        wsps->__offset = 0;
        wsps->__ptr = soap_new_impl__WSLiveProperty(soap, ps.size());
        impl__WSLiveProperty *p = wsps->__ptr;
        for (list<rcmProperty*>::iterator it = ps.begin(); it != ps.end(); ++it) {
        	SerializeProperty(soap, c, *(*it), p);
            p++;
        }
    }
}

void SerializeMethodInfo(
	struct soap *soap,
    impl__WSMethodInfo &wspi,
    rcmMethod &mi)
{
	//TODO: implement method info serialization
	soap_strcpy(soap, wspi.description, mi.Description());
    soap_strcpy(soap, wspi.displayName, mi.Name());
    wspi.methodKeyPath = NULL;
    // TODO: wspi.returnTypeKey, parameters, etc.
}

void SerializeMethodInfos(
	struct soap *soap,
	ArrayOfWSMethodInfo *wsmis,
    list<rcmMethod*> &mis)
{
	wsmis->__size = mis.size();
    wsmis->__offset = 0;
    wsmis->__ptr = soap_new_impl__WSMethodInfo(soap, mis.size());
    impl__WSMethodInfo *mi = wsmis->__ptr;
    for (list<rcmMethod*>::iterator it = mis.begin(); it != mis.end(); ++it) {
    	SerializeMethodInfo(soap, *mi, *(*it));
        mi++;
    }
}

void SerializeComponentInfo(
	struct soap* soap,
	impl__WSComponentInfo &wsci,
    rcmComponentInfo *ci)
{
	soap_strcpy(soap, wsci.compTypeKey, ci->Key());
    soap_strcpy(soap, wsci.description, ci->Description());
    soap_strcpy(soap, wsci.displayName, ci->Name());
    soap_strcpy(soap, wsci.treeIconURI, ci->IconURI());
    soap_strcpy(soap, wsci.paletteIconURI, ci->PaletteIconURI());
    soap_strcpy(soap, wsci.defaultEventKey, ci->DefaultEventKey());
    soap_strcpy(soap, wsci.defaultMethodKey, ci->DefaultMethodKey());
    soap_strcpy(soap, wsci.defaultPropertyKey, ci->DefaultPropertyKey());
    soap_strcpy(soap, wsci.hdrFileName, ci->Filename());
	wsci.container = true; // TODO: make it optional.
}

void SerializeComponentInfos(
	struct soap *soap,
    ArrayOfWSComponentInfo* wscis,
    list<rcmComponentInfo*> &cis)
{
	wscis->__size = cis.size();
    wscis->__offset = 0;
    wscis->__ptr = soap_new_impl__WSComponentInfo(soap, cis.size());
    impl__WSComponentInfo* ci = wscis->__ptr;
    for (list<rcmComponentInfo*>::iterator it = cis.begin(); it != cis.end(); ++it) {
    	SerializeComponentInfo(soap, *ci, *it);
    	ci++;
    }
}

void SerializePalettePage(
	struct soap *soap,
    impl__WSPalettePage &wspp,
    rcmPalettePage *pp)
{
	soap_strcpy(soap, wspp.pageKey, pp->Key());
    soap_strcpy(soap, wspp.pageDescription, pp->Description());
    soap_strcpy(soap, wspp.pageTitle, pp->Title());
    soap_strcpy(soap, wspp.pageIconURI, pp->IconURI());
}

void SerializePalettePages(
	struct soap *soap,
    ArrayOfWSPalettePage *wspps,
    rcmPalettePages &pps)
{
	wspps->__size = pps.size();
    wspps->__offset = 0;
    wspps->__ptr = soap_new_impl__WSPalettePage(soap, pps.size());
    impl__WSPalettePage *wspp = wspps->__ptr;
    for (rcmPalettePages::iterator it = pps.begin(); it != pps.end(); ++it) {
    	SerializePalettePage(soap, *wspp, it->second);
        wspp++;
    }
}

// Server implementation

int rcmServer::server_GetComponentModels(
    impl__server_USCORE_GetComponentModelsResponse *out)
{
    StartTick("server_GetComponentModels");
	try {
        out->_server_USCORE_GetComponentModelsReturn = NULL;
        rcmComponentModel *model = GetModel();
        if (model) {
	        out->_server_USCORE_GetComponentModelsReturn = soap_new_ArrayOfWSComponentModel(soap, -1);
		    out->_server_USCORE_GetComponentModelsReturn->__size = 1;
		    out->_server_USCORE_GetComponentModelsReturn->__offset = 0;
      	    out->_server_USCORE_GetComponentModelsReturn->__ptr = soap_new_impl__WSComponentModel(soap, 1);
   	        SerializeComponentModel(soap, out->_server_USCORE_GetComponentModelsReturn->__ptr, model);
        }
        EndTick(0);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::model_CustomDataRequest(
    char *requestKey,
    char *data,
    impl__model_USCORE_CustomDataRequestResponse *out)
{
    StartTick("model_CustomDataRequest");
    try {
        out->_model_USCORE_CustomDataRequestReturn = NULL;
        rcmComponentModel *model = GetModel();
        if (model) {
        	char *response = 0;
        	model->CustomDataRequest(requestKey, data, response);
            if (response) {
	            soap_strcpy(soap, out->_model_USCORE_CustomDataRequestReturn, response);
            }
        } 
        EndTick(0);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::manager_GetDefaultDesigner(
    char *managerKey,
    impl__manager_USCORE_GetDefaultDesignerResponse *out)
{
    StartTick("GetDefaultDesigner");
	try {
    	out->_manager_USCORE_GetDefaultDesignerReturn = NULL;
    	rcmDesignerManager *mgr = GetManager(managerKey);
        if (mgr) {
        	rcmDesigner *defD = mgr->DefaultDesigner();
            if (defD) {
				out->_manager_USCORE_GetDefaultDesignerReturn = soap_new_impl__WSLiveDesigner(soap, -1);
				SerializeDesigner(soap, out->_manager_USCORE_GetDefaultDesignerReturn, defD);
            }
        }
        EndTick(0);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::manager_GetUIDesigner(
    char *managerKey,
    impl__manager_USCORE_GetUIDesignerResponse *out)
{
    StartTick("GetUIDesigner");
	try {
    	out->_manager_USCORE_GetUIDesignerReturn = NULL;
    	rcmDesignerManager *mgr = Server().GetManager(managerKey);
        if (mgr) {
        	rcmDesigner *uiD = mgr->UIDesigner();
            if (uiD) {
            	out->_manager_USCORE_GetUIDesignerReturn = soap_new_impl__WSLiveUIDesigner(soap, -1);
                SerializeUIDesigner(soap, out->_manager_USCORE_GetUIDesignerReturn, uiD);
            }
        }
        EndTick(0);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::manager_GetDesignerEvents(
    char *managerKey,
    impl__manager_USCORE_GetDesignerEventsResponse *out)
{
//    StartTick("GetDesignerEvents");
    try {
        out->_manager_USCORE_GetDesignerEventsReturn = NULL;
        rcmDesignerManager *dm = Server().GetManager(managerKey);
        if (dm) {
			DesignerEvents &events = dm->GetEvents();
			if (events.size()) {
				out->_manager_USCORE_GetDesignerEventsReturn = soap_new_ArrayOfWSDesignerEvent(soap, -1);
				SerializeDesignerEvents(soap, out->_manager_USCORE_GetDesignerEventsReturn, events);
                dm->ClearEventQueue();
			}
        }
//        EndTick();
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::model_GetPalettePages(
    impl__model_USCORE_GetPalettePagesResponse *out)
{
    StartTick("GetPalettePages");
	try {
        out->_model_USCORE_GetPalettePagesReturn = NULL;
    	rcmComponentModel *model = GetModel();
        if (model) {
			out->_model_USCORE_GetPalettePagesReturn = soap_new_ArrayOfWSPalettePage(soap, -1);
            SerializePalettePages(soap, out->_model_USCORE_GetPalettePagesReturn, model->PalettePages());
        }
        EndTick(0);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::model_GetDesignerManagers(
    impl__model_USCORE_GetDesignerManagersResponse *out)
{
    StartTick("model_GetDesignerManagers");
	try {
    	out->_model_USCORE_GetDesignerManagersReturn = NULL;
        rcmComponentModel *model = GetModel();
        if (model) {
        	out->_model_USCORE_GetDesignerManagersReturn = soap_new_ArrayOfWSLiveDesignerManager(soap, -1);
			SerializeLiveDesignerManagers(soap, out->_model_USCORE_GetDesignerManagersReturn, model->DesignerManagers());
        }
        EndTick(0);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::model_CreateDesignerManager(
    impl__model_USCORE_CreateDesignerManagerResponse *out)
{
    StartTick("CreateDesignerManager");
	try {
    	out->_model_USCORE_CreateDesignerManagerReturn = NULL;
        rcmComponentModel *model = GetModel();
        if (model) {
        	rcmDesignerManager *dm = model->CreateDesignerManager();
            if (dm) {
				out->_model_USCORE_CreateDesignerManagerReturn = soap_new_impl__WSLiveDesignerManager(soap, -1);
				SerializeLiveDesignerManager(soap, out->_model_USCORE_CreateDesignerManagerReturn, dm);
            }
        }
        EndTick(0);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::palette_GetComponentInfos(
    char *pageKey,
    impl__palette_USCORE_GetComponentInfosResponse *out)
{
    StartTick("GetComponentInfos");
	try {
    	out->_palette_USCORE_GetComponentInfosReturn = NULL;
    	rcmComponentModel *model = GetModel();
        rcmPalettePage *page = Server().GetPalettePage(pageKey);
        if (model && page) {
            rcmComponentInfos &cihash = model->ComponentInfos();
   	     	list<rcmComponentInfo*> cilist;
            for (rcmComponentInfos::iterator it = cihash.begin(); it != cihash.end(); ++it)
				if ((*it).second->PalettePage() == page)
                   	cilist.push_front((*it).second);
			out->_palette_USCORE_GetComponentInfosReturn = soap_new_ArrayOfWSComponentInfo(soap, -1);
			SerializeComponentInfos(soap, out->_palette_USCORE_GetComponentInfosReturn, cilist);
        }
        EndTick(0);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::model_DisposeDesignerManager(
    char *managerKey,
    impl__model_USCORE_DisposeDesignerManagerResponse *out)
{
    StartTick("DisposeDesignerManager");
	try {
    	out->_model_USCORE_DisposeDesignerManagerReturn = NULL;
    	rcmComponentModel *model = GetModel();
        if (model) {
        	Result *r = model->DisposeDesignerManager(managerKey);
            if (r) {
				out->_model_USCORE_DisposeDesignerManagerReturn = soap_new_impl__WSResult(soap, -1);
                SerializeResult(soap, out->_model_USCORE_DisposeDesignerManagerReturn, r);
            }
        }
        EndTick(0);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::manager_GetPersistenceData(
    char *managerKey,
    char *compInstanceKey,
    impl__manager_USCORE_GetPersistenceDataResponse *out)
{
    StartTick("GetPersistenceData");
	try {
    	out->_manager_USCORE_GetPersistenceDataReturn = NULL;
		rcmDesignerManager *dm = GetManager(managerKey);
        if (dm) {
            rcmComponent *comp = 0;
            if (compInstanceKey)
                comp = GetComponent(managerKey, 0, compInstanceKey);
			output_stream_type *stream = NewOutputStream();
        	if (dm->Persist(stream, comp) > 0) {
    			out->_manager_USCORE_GetPersistenceDataReturn = soap_new_xsd__base64Binary(soap, -1);
	    		SerializeStream(soap, out->_manager_USCORE_GetPersistenceDataReturn, stream);
            }
            delete stream;
        }
        EndTick(0);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::manager_IsPersistenceDataModified(


    char *managerKey,
    impl__manager_USCORE_IsPersistenceDataModifiedResponse *out)
{
    StartTick("IsPersistenceDataModified");
	try {
    	out->_manager_USCORE_IsPersistenceDataModifiedReturn = NULL;
        rcmDesignerManager *dm = Server().GetManager(managerKey);
        if (dm) {
	    	out->_manager_USCORE_IsPersistenceDataModifiedReturn = dm->IsModified();
        }
        EndTick(0);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::manager_GetComponentsOfType(
    char *managerKey,
    char *typeKey,
    impl__manager_USCORE_GetComponentsOfTypeResponse *out)
{
    StartTick("manager_GetComponentsOfType");
	try {
    	out->_manager_USCORE_GetComponentsOfTypeReturn = NULL;
        rcmDesignerManager *dm = GetManager(managerKey);
        rcmComponentInfo *ci = GetComponentInfo(typeKey);
        if (dm && ci) {
			rcmComponents comps;
			dm->GetComponentsOfType(ci, comps);
            if (comps.size()) {
		    	out->_manager_USCORE_GetComponentsOfTypeReturn = soap_new_ArrayOfWSLiveComponent(soap, -1);
				SerializeComponents(soap, out->_manager_USCORE_GetComponentsOfTypeReturn, comps);
            }
        }
        EndTick(0);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::manager_SetPersistenceData(
    char *managerKey,
    xsd__base64Binary *data,
    impl__manager_USCORE_SetPersistenceDataResponse *out)
{
    StartTick("SetPersistenceData");
	try {
    	out->_manager_USCORE_SetPersistenceDataReturn = NULL;
		rcmDesignerManager *dm = GetManager(managerKey);
        if (dm) {
			input_stream_type *stream = NewInputStream(data);
        	Result *r = dm->Depersist(stream);
            if (stream)
			    delete stream;
            if (r) {
				out->_manager_USCORE_SetPersistenceDataReturn = soap_new_impl__WSResult(soap, -1);
				SerializeResult(soap, out->_manager_USCORE_SetPersistenceDataReturn, r);
            }
        }
        EndTick(0);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::designer_CreateComponent(
    char *managerInstanceKey,
    char *designerKey,
    char *containerInstanceKey,
    char *compTypeKey,
    impl__designer_USCORE_CreateComponentResponse *out)
{
    return designer_CreateComponent(managerInstanceKey, designerKey,
        containerInstanceKey, compTypeKey, NULL, out);
}

int rcmServer::designer_CreateComponent(
    char *managerKey,
    char *designerKey,
    char *containerInstanceKey,
    char *compTypeKey,
    xsd__base64Binary *persistData,
    impl__designer_USCORE_CreateComponentResponse *out)
{
    StartTick("designer_CreateComponent");
    try {
		out->_designer_USCORE_CreateComponentReturn = NULL;
        rcmDesigner *d = GetDesigner(managerKey, designerKey);
		rcmComponentInfo *ci = GetComponentInfo(compTypeKey);
        if (ci && d) {
			rcmContainer *container = 0;
            if (containerInstanceKey && strlen(containerInstanceKey))
	       		container = dynamic_cast<rcmContainer*>(d->GetComponent(containerInstanceKey));
			input_stream_type *stream = NewInputStream(persistData);
//	        CreateResult *r = d->CreateComponent(container, ci, stream);
            CreateResult *r = GetModel()->CreateComponent(ci, d, container, stream);
            if (stream) delete stream;
    	    if (r) {
        		out->_designer_USCORE_CreateComponentReturn = soap_new_impl__WSCreateResult(soap, -1);
				SerializeCreateResult(soap, out->_designer_USCORE_CreateComponentReturn, r);
	        }
        }
        EndTick(compTypeKey);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::uidesigner_CreateComponent(
    char *managerKey,
    char *designerKey,
    char *containerInstanceKey,
    char *compTypeKey,
    int x,
    int y,
    int w,
    int h,
    xsd__base64Binary *persistData,
    impl__uidesigner_USCORE_CreateComponentResponse *out)
{
    StartTick("uidesigner_CreateComponent");
    try {
		out->_uidesigner_USCORE_CreateComponentReturn = NULL;
        rcmDesigner *d = GetDesigner(managerKey, designerKey);
        rcmUIDesigner *uid = dynamic_cast<rcmUIDesigner*>(d);
        if (d && uid) {
    		rcmComponentInfo *ci = GetComponentInfo(compTypeKey);
            if (ci && d) {
			    rcmContainer *container = 0;
                if (containerInstanceKey && strlen(containerInstanceKey))
	           		container = dynamic_cast<rcmContainer*>(d->GetComponent(containerInstanceKey));
		    	input_stream_type *stream = NewInputStream(persistData);
                CreateResult *res = GetModel()->CreateComponent(ci, d, container, stream);
                if (stream) delete stream;
                if (res->Success() && res->Component()) {
                    rcmUIComponent *uic = dynamic_cast<rcmUIComponent*>(res->Component());
                    if (uic) {
                        uic->SetRect(x, y, w, h);
                        out->_uidesigner_USCORE_CreateComponentReturn = soap_new_impl__WSUICreateResult(soap, -1);
                        SerializeUICreateResult(soap, out->_uidesigner_USCORE_CreateComponentReturn, res);
                    }
    	        }
            }
        }
        EndTick(compTypeKey);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::designer_GetContextTags(
    char *managerKey,
    char *designerKey,
    int x,
    int y,
    impl__designer_USCORE_GetContextTagsResponse *out)
{
    StartTick("designer_GetContextTags");
    try {
		out->_designer_USCORE_GetContextTagsReturn = NULL;
        rcmDesigner *d = GetDesigner(managerKey, designerKey);
        MenuItemProvider *ims = dynamic_cast<MenuItemProvider*>(d);
        if (ims) {
            MenuItems items;
            ims->UpdateMenu(items, x, y);
            if (items.size() > 0) {
            	out->_designer_USCORE_GetContextTagsReturn = soap_new_ArrayOfWSTag(soap, -1);
                SerializeMenuItems(soap, out->_designer_USCORE_GetContextTagsReturn, items);
            }
            FMenuItemCache.splice(FMenuItemCache.end(), items); 
        }
        EndTick(0);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

// TODO: move these somewhere else.

void rcmServer::ClearMenuItemCache()
{
    MenuItems::iterator it = FMenuItemCache.begin();
    while (it != FMenuItemCache.end()) {
        MenuItem *item = *it;
        if (item && item->FAutoFree)
            delete item;
        it++;
    }
    FMenuItemCache.clear();
}

MenuItem* rcmServer::FindMenuItemInCache(const char *key)
{
    MenuItem *theItem = 0;
    unsigned int tmp;
    if (sscanf(key, "%08X", &tmp)) {
        MenuItem* itemAddr = (MenuItem*)(tmp);
        if (itemAddr) {
            MenuItems::iterator it = FMenuItemCache.begin();
            while (!theItem && it != FMenuItemCache.end()) {
                if (*it == itemAddr) {
                    return *it;
                }
                else {
                    theItem = (*it)->Find(itemAddr, true);
                }
                it++;
            }
        }
    }
    return theItem;
}

int rcmServer::designer_TagInvoked(
    char *managerKey,
    char *designerKey,
    ArrayOf_USCORE_xsd_USCORE_string *tagKeys,
    impl__designer_USCORE_TagInvokedResponse *out)
{
    StartTick("designer_TagInvoked");
    try {
		out->_designer_USCORE_TagInvokedReturn = NULL;
        // just a sanity check...
        rcmDesigner *d = GetDesigner(managerKey, designerKey);
        //TODO: make sub menu items work!!!
        if (d && tagKeys && tagKeys->__size > 0) {
            MenuItem *item = FindMenuItemInCache(tagKeys->__ptr[0]);
            if (item) {
                Result *r = item->DoItemClick();
                if (r) {
        			out->_designer_USCORE_TagInvokedReturn = soap_new_impl__WSResult(soap, -1);
	        		SerializeResult(soap, out->_designer_USCORE_TagInvokedReturn, r);
                }
            }
        }
        ClearMenuItemCache();
        EndTick(0);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::designer_DisposeComponent(
    char *managerKey,
    char *designerKey,
    char *compInstanceKey,
    impl__designer_USCORE_DisposeComponentResponse *out)
{
    StartTick("designer_DisposeComponent");
    try {
		out->_designer_USCORE_DisposeComponentReturn = NULL;
        rcmDesigner *d = GetDesigner(managerKey, designerKey);
        if (d) {
			Result *r = d->DisposeComponent(compInstanceKey);
			if (r) {
            	out->_designer_USCORE_DisposeComponentReturn = soap_new_impl__WSResult(soap, -1);
            	SerializeResult(soap, out->_designer_USCORE_DisposeComponentReturn, r);
            }
        }
        EndTick(compInstanceKey);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::designer_GetRootComponents(
    char *managerKey,
    char *designerKey,
    impl__designer_USCORE_GetRootComponentsResponse *out)
{
    StartTick("designer_GetRootComponents");
   	try {
		out->_designer_USCORE_GetRootComponentsReturn = NULL;
		rcmDesigner* d = GetDesigner(managerKey, designerKey);
        if (d) {
            rcmComponents roots;
            d->GetRootComponents(roots);
            if (roots.size() > 0) {
           	   	out->_designer_USCORE_GetRootComponentsReturn = soap_new_ArrayOfWSLiveComponent(soap, -1);
                SerializeComponents(soap, out->_designer_USCORE_GetRootComponentsReturn, roots);
            }
        }
        EndTick(0);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::compinfo_GetEventInfos(


    char *compTypeKey,
    impl__compinfo_USCORE_GetEventInfosResponse *out)
{
    StartTick("compinfo_GetEventInfos");
    try {
    	out->_compinfo_USCORE_GetEventInfosReturn = NULL;
		rcmComponentInfo *ci = GetComponentInfo(compTypeKey);
        if (ci) {
            list<rcmEvent*> events;
            ci->GetEvents(events, 0);
            if (events.size() > 0) {
            	out->_compinfo_USCORE_GetEventInfosReturn = soap_new_ArrayOfWSEventInfo(soap, -1);
                SerializeEventInfos(soap, out->_compinfo_USCORE_GetEventInfosReturn, events);
            }
        }
        EndTick(compTypeKey);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::eventinfo_GetEventInfos(


	char *compTypeKey,
	ArrayOf_USCORE_xsd_USCORE_string *eventKeyPath,
	impl__eventinfo_USCORE_GetEventInfosResponse *out)
{
    StartTick("eventinfo_GetEventInfos");
	try {
		out->_eventinfo_USCORE_GetEventInfosReturn = NULL;
        EndTick(compTypeKey);
		return SOAP_OK;
	}
	DEFAULT_CATCH
}

int rcmServer::compinfo_GetPropertyInfos(
    char *compTypeKey,
    impl__compinfo_USCORE_GetPropertyInfosResponse *out)
{
    StartTick("compinfo_GetPropertyInfos");
    try {
		out->_compinfo_USCORE_GetPropertyInfosReturn = NULL;
        rcmComponentInfo *ci = GetComponentInfo(compTypeKey);
        if (ci) {
            list<rcmProperty*> props;
            ci->GetProperties(props);
            if (props.size() > 0) {
              	out->_compinfo_USCORE_GetPropertyInfosReturn = soap_new_ArrayOfWSPropertyInfo(soap, -1);
              	SerializePropertyInfos(soap, out->_compinfo_USCORE_GetPropertyInfosReturn, props);
          	}
        }
        EndTick(compTypeKey);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::propinfo_GetPropertyInfos(
	char *compTypeKey,
    char *managerKey,
    char *designerKey,
    char *compInstanceKey,
	ArrayOf_USCORE_xsd_USCORE_string *propertyKeyPath,
	impl__propinfo_USCORE_GetPropertyInfosResponse *out)
{
    StartTick("propinfo_GetPropertyInfos");
	try {
		out->_propinfo_USCORE_GetPropertyInfosReturn = NULL;
        rcmProperty *p = 0;
        if (compInstanceKey) {
            p = GetProperty(managerKey, designerKey, compInstanceKey, propertyKeyPath);
        }
        else if (compTypeKey) {
    		p = GetProperty(compTypeKey, propertyKeyPath);
        }
		if (p) {
            list<rcmProperty*> subProps;
            p->GetChildren(subProps);
            if (subProps.size() > 0) {
   				out->_propinfo_USCORE_GetPropertyInfosReturn = soap_new_ArrayOfWSPropertyInfo(soap, -1);
    			SerializePropertyInfos(soap, out->_propinfo_USCORE_GetPropertyInfosReturn, subProps);
            }
		}
        EndTick(compTypeKey);
		return SOAP_OK;
	}
	DEFAULT_CATCH
}

int rcmServer::prop_GetProperties(
	char *managerKey,
	char *compInstanceKey,
	ArrayOf_USCORE_xsd_USCORE_string *propertyKeyPath,
	impl__prop_USCORE_GetPropertiesResponse *out)
{
    StartTick("prop_GetProperties");
	try {
		out->_prop_USCORE_GetPropertiesReturn = NULL;
		rcmComponent *c = GetComponent(managerKey, 0, compInstanceKey);
		if (c) {
			rcmProperty *p = GetProperty(managerKey, NULL, compInstanceKey, propertyKeyPath);
			if (p) {
                list<rcmProperty*> subProps;
                p->GetChildren(subProps);
                if (subProps.size() > 0) {
                    out->_prop_USCORE_GetPropertiesReturn = soap_new_ArrayOfWSLiveProperty(soap, -1);
	    			SerializeProperties(soap, c, out->_prop_USCORE_GetPropertiesReturn, subProps);
                }
			}
		}
        EndTick(compInstanceKey);
		return SOAP_OK;
	}
	DEFAULT_CATCH
}

int rcmServer::compinfo_GetMethodInfos(
    char *compTypeKey,
    impl__compinfo_USCORE_GetMethodInfosResponse *out)
{
    StartTick("compinfo_GetMethodInfos");
    try {
        out->_compinfo_USCORE_GetMethodInfosReturn = NULL;
        rcmComponentInfo *ci = GetComponentInfo(compTypeKey);
        if (ci) {
            list<rcmMethod*> methods;
            ci->GetMethods(methods, 0);
            if (methods.size() > 0) {
            	out->_compinfo_USCORE_GetMethodInfosReturn = soap_new_ArrayOfWSMethodInfo(soap, -1);
                SerializeMethodInfos(soap, out->_compinfo_USCORE_GetMethodInfosReturn, methods);
            }
        }
        EndTick(compTypeKey);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::propinfo_GetValueTags(
    char *compTypeKey,
    ArrayOf_USCORE_xsd_USCORE_string *propKeys,
    impl__propinfo_USCORE_GetValueTagsResponse *out)
{
    StartTick("propinfo_GetValueTags");
    try {
        out->_propinfo_USCORE_GetValueTagsReturn = NULL;
        rcmProperty *p = GetProperty(compTypeKey, propKeys);
        if (p && (p->Flags() & PE_STATICVALUELIST)) {
            ChoiceProvider *cp = dynamic_cast<ChoiceProvider*>(p);
            if (cp) {
                PropertyChoices pcs;
                cp->GetChoices(pcs);
            	if (pcs.size() > 0) {
                	out->_propinfo_USCORE_GetValueTagsReturn = soap_new_ArrayOfWSTag(soap, -1);
                    SerializeChoices(soap, out->_propinfo_USCORE_GetValueTagsReturn, pcs);
                }
            }
        }
        EndTick(compTypeKey);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::comp_GetContextTags(
	char *managerKey,
	char *designerKey,
	char *compInstanceKey,
    int x,
    int y,
	impl__comp_USCORE_GetContextTagsResponse *out)
{
    StartTick("comp_GetContextTags");
    try {
    	out->_comp_USCORE_GetContextTagsReturn = NULL;
        MenuItems items;
		rcmComponent *c = GetComponent(managerKey, designerKey, compInstanceKey);
		if (c) {
        	rcmComponentEditor *ed = c->Editor();
            if (ed) {
                ed->UpdateMenu(items, x, y);
            }
		}
        if (items.size() > 0) {
            out->_comp_USCORE_GetContextTagsReturn = soap_new_ArrayOfWSTag(soap, -1);
            SerializeMenuItems(soap, out->_comp_USCORE_GetContextTagsReturn, items);
            FMenuItemCache.splice(FMenuItemCache.end(), items);
        }
        EndTick(compInstanceKey);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}


int rcmServer::uicomp_GetAsContainer(
	char *managerKey,
	char *designerKey,
	char *instanceKey,
	impl__uicomp_USCORE_GetAsContainerResponse *out)
{
    StartTick("uicomp_GetAsContainer");
    try {
		out->_uicomp_USCORE_GetAsContainerReturn = NULL;
		rcmComponent *c = GetComponent(managerKey, designerKey, instanceKey);
		if (c && dynamic_cast<rcmUIComponent*>(c) && dynamic_cast<rcmContainer*>(c)) {
			out->_uicomp_USCORE_GetAsContainerReturn = soap_new_impl__WSLiveUIContainer(soap, -1);
			SerializeAsUIContainer(soap, out->_uicomp_USCORE_GetAsContainerReturn, c);
		}
        EndTick(instanceKey);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::uicomp_SetUIComponentRect(
    char *managerKey,
    char *designerKey,
    char *compInstanceKey,
    int x,
    int y,
    int w,
    int h,
    int dragX,
    int dragY,
    impl__uicomp_USCORE_SetUIComponentRectResponse *out)
{
    StartTick("uicomp_SetUIComponentRect");
    try {
        // TODO: deal with dragX and dragY
        out->_uicomp_USCORE_SetUIComponentRectReturn = NULL;
        rcmUIComponent *uic = GetUIComponent(managerKey, designerKey, compInstanceKey);
        if (uic) {
            uic->SetRect(x, y, w, h);
            out->_uicomp_USCORE_SetUIComponentRectReturn = soap_new_impl__WSRect(soap, -1);
            SerializeRectangle(x, y, w, h, *(out->_uicomp_USCORE_SetUIComponentRectReturn));
        }
        EndTick(compInstanceKey);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}



int rcmServer::comp_SetInstanceName(
	char *managerKey,
	char *instanceKey,
	char *newName,
	impl__comp_USCORE_SetInstanceNameResponse *out)
{
    StartTick("comp_SetInstanceName");
    try {
    	out->_comp_USCORE_SetInstanceNameReturn = NULL;
		rcmComponent *c = GetComponent(managerKey, 0, instanceKey);
		if (c) {
            Result *r = 0;
            try {
                r = c->SetName(newName);
			}
            catch (exception &e) {
                r = ErrorMessage(e.what());
            }
			out->_comp_USCORE_SetInstanceNameReturn = soap_new_impl__WSResult(soap, -1);
   			SerializeResult(soap, out->_comp_USCORE_SetInstanceNameReturn, r);
		}
        EndTick(instanceKey);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::comp_GetAsContainer(
	char *managerKey,
	char *designerKey,
	char *instanceKey,
	impl__comp_USCORE_GetAsContainerResponse *out)
 {
    StartTick("comp_GetAsContainer");
    try {
    	out->_comp_USCORE_GetAsContainerReturn = NULL;
		rcmComponent *c = GetComponent(managerKey, designerKey, instanceKey);
		if (c && dynamic_cast<rcmContainer*>(c)) {
			out->_comp_USCORE_GetAsContainerReturn = soap_new_impl__WSLiveContainer(soap, -1);
			SerializeAsContainer(soap, out->_comp_USCORE_GetAsContainerReturn, c);
		}
        EndTick(instanceKey);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::comp_TagInvoked(
	char *managerKey,
	char *designerKey,
	char *compInstanceKey,
	ArrayOf_USCORE_xsd_USCORE_string *tagKeys,
	impl__comp_USCORE_TagInvokedResponse *out)
 {
    StartTick("comp_TagInvoked");
    try {
		out->_comp_USCORE_TagInvokedReturn = NULL;
        // sanity check.
		rcmComponent *c = GetComponent(managerKey, designerKey, compInstanceKey);
		if (c && tagKeys && tagKeys->__size > 0) {
            MenuItem *item = FindMenuItemInCache(tagKeys->__ptr[0]);
            if (item) {
                Result *r = item->DoItemClick();
                if (r) {
                    out->_comp_USCORE_TagInvokedReturn = soap_new_impl__WSResult(soap, -1);
                    SerializeResult(soap, out->_comp_USCORE_TagInvokedReturn, r);
                }
            }
        }
        ClearMenuItemCache();
        EndTick(compInstanceKey);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::comp_GetProperties(
	char *managerKey,
	char *compInstanceKey,
	impl__comp_USCORE_GetPropertiesResponse *out)
 {
     StartTick("comp_GetProperties");
    try {
		out->_comp_USCORE_GetPropertiesReturn = NULL;
		rcmComponent *c = GetComponent(managerKey, 0, compInstanceKey);
		if (c) {
            list<rcmProperty*> props;
            c->GetProperties(props);
            if (props.size() > 0) {
    			out->_comp_USCORE_GetPropertiesReturn = soap_new_ArrayOfWSLiveProperty(soap, -1);
	    		SerializeProperties(soap, c, out->_comp_USCORE_GetPropertiesReturn, props);
            }
        }
        EndTick(compInstanceKey);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::comp_GetEvents(
	char *managerKey,
	char *compInstanceKey,
	impl__comp_USCORE_GetEventsResponse *out)
 {
    StartTick("comp_GetEvents");
    try {
		out->_comp_USCORE_GetEventsReturn = NULL;
		rcmComponent *c = GetComponent(managerKey, 0, compInstanceKey);
		if (c) {
            list<rcmEvent*> events;
            c->ComponentInfo()->GetEvents(events, c);
            if (events.size() > 0) {
    			out->_comp_USCORE_GetEventsReturn = soap_new_ArrayOfWSLiveEvent(soap, -1);
	    		SerializeEvents(soap, c, out->_comp_USCORE_GetEventsReturn, events);
            }
		}
        EndTick(compInstanceKey);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::event_GetEvents(
	char *managerKey,
	char *compInstanceKey,
	ArrayOf_USCORE_xsd_USCORE_string *eventKeyPath,
	impl__event_USCORE_GetEventsResponse *out)
{
    StartTick("event_GetEvents");
	try {
		out->_event_USCORE_GetEventsReturn = NULL;
        EndTick(compInstanceKey);
		return SOAP_OK;
	}
	DEFAULT_CATCH
}

int rcmServer::prop_GetValueTags(
	char *managerKey,
	char *compInstanceKey,
	ArrayOf_USCORE_xsd_USCORE_string *propertyKeyPath,
	impl__prop_USCORE_GetValueTagsResponse *out)
 {
    StartTick("prop_GetValueTags");
    try {
    	out->_prop_USCORE_GetValueTagsReturn = NULL;
		rcmComponent *c = GetComponent(managerKey, 0, compInstanceKey);
	    if (c) {
	        rcmProperty *p = GetProperty(managerKey, 0, compInstanceKey, propertyKeyPath);
        	if (p && (p->Flags() & PE_DYNAMICVALUELIST)) {
                ChoiceProvider *cp = dynamic_cast<ChoiceProvider*>(p);
                if (cp) {
                    PropertyChoices pcs;
                    cp->GetChoices(pcs);
            	    if (pcs.size() > 0) {
                	    out->_prop_USCORE_GetValueTagsReturn = soap_new_ArrayOfWSTag(soap, -1);
                        SerializeChoices(soap, out->_prop_USCORE_GetValueTagsReturn, pcs);
                    }
                }
            }
    	}
        EndTick(compInstanceKey);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::prop_SetValueAsText(
    char *managerKey,
    char *compInstanceKey,
    ArrayOf_USCORE_xsd_USCORE_string *propertyKeyPath,
    char *value,
    impl__prop_USCORE_SetValueAsTextResponse *out)
{
    StartTick("prop_SetValueAsText");
    try {
        out->_prop_USCORE_SetValueAsTextReturn = NULL;
        rcmComponent *comp = GetComponent(managerKey, 0, compInstanceKey);
        if (comp) {
            string_array keys;
            xsdStringArrayToStringArray(propertyKeyPath, keys);
	       	Result *r = comp->SetValue(keys, value);
            if (r) {
                out->_prop_USCORE_SetValueAsTextReturn = soap_new_impl__WSResult(soap, -1);
                SerializeResult(soap, out->_prop_USCORE_SetValueAsTextReturn, r);
            }
        }
        EndTick(compInstanceKey);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::prop_Revert(
    char *managerKey,
    char *compInstanceKey,
    ArrayOf_USCORE_xsd_USCORE_string *propertyKeyPath,
    impl__prop_USCORE_RevertResponse *out)
{
    StartTick("prop_Revert");
	try {
		out->_prop_USCORE_RevertReturn = NULL;
		rcmProperty *p = GetProperty(managerKey, 0, compInstanceKey, propertyKeyPath);
 		if (p) {
            Result *r = p->Revert();
			if (r) {
	 			out->_prop_USCORE_RevertReturn = soap_new_impl__WSResult(soap, -1);
    	        SerializeResult(soap, out->_prop_USCORE_RevertReturn, r);
			}
 		}
        EndTick(compInstanceKey);
		return SOAP_OK;
 	}
	DEFAULT_CATCH
}

int rcmServer::eventinfo_GetHookTags(
    char *typeKey,
    ArrayOf_USCORE_xsd_USCORE_string *eventKeyPath,
    impl__eventinfo_USCORE_GetHookTagsResponse *out)
{
    StartTick("eventinfo_GetHookTags");
    try {
        out->_eventinfo_USCORE_GetHookTagsReturn = NULL;
        rcmEvent *e = GetEvent(typeKey, eventKeyPath);
        if (e && e->Flags() & PE_STATICVALUELIST) {
            ChoiceProvider *cp = dynamic_cast<ChoiceProvider*>(e);
            if (cp) {
                PropertyChoices pcs;
                cp->GetChoices(pcs);
            	if (pcs.size() > 0) {
                	out->_eventinfo_USCORE_GetHookTagsReturn = soap_new_ArrayOfWSTag(soap, -1);
                    SerializeChoices(soap, out->_eventinfo_USCORE_GetHookTagsReturn, pcs);
                }
            }
        }
        EndTick(typeKey);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::event_GetHookTags(
    char *managerKey,
    char *compInstanceKey,
    ArrayOf_USCORE_xsd_USCORE_string *eventKeyPath,
    impl__event_USCORE_GetHookTagsResponse *out)
{
    StartTick("event_GetHookTags");
    try {
        out->_event_USCORE_GetHookTagsReturn = NULL;
		rcmComponent *c = GetComponent(managerKey, 0, compInstanceKey);
	    if (c) {
    		rcmEvent *e = GetEvent(managerKey, 0, compInstanceKey, eventKeyPath);
        	if (e && (e->Flags() & PE_DYNAMICVALUELIST)) {
               ChoiceProvider *cp = dynamic_cast<ChoiceProvider*>(e);
                if (cp) {
                    PropertyChoices pcs;
                    cp->GetChoices(pcs);
                    if (pcs.size() > 0) {
                        out->_event_USCORE_GetHookTagsReturn = soap_new_ArrayOfWSTag(soap, -1);
                        SerializeChoices(soap, out->_event_USCORE_GetHookTagsReturn, pcs);
                    }
                }
            }
        }
        EndTick(compInstanceKey);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}


int rcmServer::uidesignrect_ResizeCompleted(
	char *managerKey,
	char *designerKey,
	char *compInstanceKey,
	char *designRectKey,
	int x,
	int y,
	int w,
	int h,
	impl__uidesignrect_USCORE_ResizeCompletedResponse *out)
 {
    StartTick("uIDesignRect_ResizeCompleted");
    try {
    	out->_uidesignrect_USCORE_ResizeCompletedReturn = NULL;
		DesignRect *dr = GetDesignRect(managerKey, designerKey, compInstanceKey, designRectKey);
        if (dr) {
            out->_uidesignrect_USCORE_ResizeCompletedReturn = soap_new_impl__WSRect(soap, -1);
            dr->DoResized(x, y, w, h);
            SerializeRectangle(x, y, w, h, *(out->_uidesignrect_USCORE_ResizeCompletedReturn));
        }
        EndTick(compInstanceKey);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::uidesignrect_MoveCompleted(
    char *managerKey,
    char *designerKey,
    char *compInstanceKey,
    char *designRectKey,
    int x,
    int y,
    int w,
    int h,
    impl__uidesignrect_USCORE_MoveCompletedResponse *out)
{
    StartTick("uIDesignRect_MoveCompleted");
    try {
        out->_uidesignrect_USCORE_MoveCompletedReturn = NULL;
        DesignRect *dr = GetDesignRect(managerKey, designerKey, compInstanceKey, designRectKey);
        if (dr) {
            out->_uidesignrect_USCORE_MoveCompletedReturn = soap_new_impl__WSRect(soap, -1);
            dr->DoMoved(x, y, w, h);
            SerializeRectangle(x, y, w, h, *(out->_uidesignrect_USCORE_MoveCompletedReturn));
        }
        EndTick(compInstanceKey);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::uidesignrect_GetContextTags(
	char *managerKey,
	char *designerKey,
	char *compInstanceKey,
	char *designRectKey,
    int x,
    int y,
	impl__uidesignrect_USCORE_GetContextTagsResponse *out)
{
    StartTick("uIDesignRect_GetContextTags");
	try {
		out->_uidesignrect_USCORE_GetContextTagsReturn = NULL;
        rcmComponent *c = GetComponent(managerKey, designerKey, compInstanceKey);
        DesignRect *dr = GetDesignRect(managerKey, designerKey, compInstanceKey, designRectKey);
        if (dr && c) {
            MenuItems items;
            dr->UpdateMenu(items, x, y);
            if (items.size() > 0) {
                out->_uidesignrect_USCORE_GetContextTagsReturn = soap_new_ArrayOfWSTag(soap, -1);
                SerializeMenuItems(soap, out->_uidesignrect_USCORE_GetContextTagsReturn, items);
            }
            FMenuItemCache.splice(FMenuItemCache.end(), items);
        }
        EndTick(compInstanceKey);
		return SOAP_OK;
	}
	DEFAULT_CATCH
}

int rcmServer::uidesignrect_MouseClick(
    char *managerKey,
    char *designerKey,
    char *compInstanceKey,
    char *designRectKey,
    int x,
    int y,
    int clickCount,
    impl__uidesignrect_USCORE_MouseClickResponse *out)
{
    StartTick("UIDesignRect_MouseClick");
    try {
        out->_uidesignrect_USCORE_MouseClickReturn = NULL;
        DesignRect *dr = GetDesignRect(managerKey, designerKey, compInstanceKey, designRectKey);
        if (dr) {
            Result *r = 0;
            if (clickCount == 1)
                r = dr->DoClick(x, y);
            else if (clickCount == 2)
                r = dr->DoDblClick(x, y);
            if (r) {
                out->_uidesignrect_USCORE_MouseClickReturn = soap_new_impl__WSResult(soap, -1);
                SerializeResult(soap, out->_uidesignrect_USCORE_MouseClickReturn, r);
            }
        }
        EndTick(compInstanceKey);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::uidesignrect_TagInvoked(
    char *managerKey,
    char *designerKey,
    char *compInstanceKey,
    char *designRectKey,
    ArrayOf_USCORE_xsd_USCORE_string *tagKeys,
    impl__uidesignrect_USCORE_TagInvokedResponse *out)
{
    StartTick("UIDesignRect_TagInvoked");
    try {
        out->_uidesignrect_USCORE_TagInvokedReturn = NULL;
        // sanity check.
        DesignRect *dr = GetDesignRect(managerKey, designerKey, compInstanceKey, designRectKey);
        if (dr && tagKeys && tagKeys->__size > 0) {
            MenuItem *item = FindMenuItemInCache(tagKeys->__ptr[0]);
            if (item) {
                Result *r = item->DoItemClick();
                if (r) {
        			out->_uidesignrect_USCORE_TagInvokedReturn = soap_new_impl__WSResult(soap, -1);
	        		SerializeResult(soap, out->_uidesignrect_USCORE_TagInvokedReturn, r);
                }
            }
        }
        ClearMenuItemCache();
        EndTick(compInstanceKey);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::model_GetDefaultDesignerInfo(
	impl__model_USCORE_GetDefaultDesignerInfoResponse *out)
{
    StartTick("model_GetDefaultDesignerInfo");
	out->_model_USCORE_GetDefaultDesignerInfoReturn = NULL;
    rcmComponentModel *model = GetModel();
    if (model) {
        rcmDesigner::Info *di = model->GetDesignerInfo(dtDefault);
        if (di) {
            out->_model_USCORE_GetDefaultDesignerInfoReturn = soap_new_impl__WSDesignerInfo(soap, -1);
            SerializeDesignerInfo(soap, out->_model_USCORE_GetDefaultDesignerInfoReturn, di);
        }
    }
    EndTick(0);
    return SOAP_OK;
}

int rcmServer::event_SetDefaultHook(
	char *managerKey,
	char *compInstanceKey,
	ArrayOf_USCORE_xsd_USCORE_string *eventKeyPath,
	impl__event_USCORE_SetDefaultHookResponse *out)
{
    StartTick("event_SetDefaultHook");
	try {
		out->_event_USCORE_SetDefaultHookReturn = NULL;
		rcmEvent *event = GetEvent(managerKey, 0, compInstanceKey, eventKeyPath);
		if (event) {
			return soap_receiver_fault(soap, "no way to return default hook text", "event_SetDefaultHook");
			//out->_event_USCORE_SetDefaultHookReturn = soap_new_impl__WSResult(soap, -1);
			//SerializeResult(soap, out->_event_USCORE_SetDefaultHookReturn, *r);
		}
        EndTick(compInstanceKey);
		return SOAP_OK;
	}
	DEFAULT_CATCH
}

int rcmServer::container_SetComponentIndex(
	char *managerKey,
	char *containerKey,
	char *compInstanceKey,
	int newIndex,
	impl__container_USCORE_SetComponentIndexResponse *out)
{
    StartTick("container_SetComponentIndex");
	try {
		out->_container_USCORE_SetComponentIndexReturn = NULL;
		rcmContainer *cont = GetContainer(managerKey, 0, containerKey);
		rcmComponent *comp = GetComponent(managerKey, 0, compInstanceKey);
		if (cont && comp) {
			Result *r = cont->SetComponentIndex(comp, newIndex);
			if (r) {
				out->_container_USCORE_SetComponentIndexReturn = soap_new_impl__WSResult(soap, -1);
				SerializeResult(soap, out->_container_USCORE_SetComponentIndexReturn, r);
			}
		}
        EndTick(compInstanceKey);
		return SOAP_OK;
	}
	DEFAULT_CATCH
}

int rcmServer::result_TagInvoked(
    char *managerKey,
    char *designerKey,
    char *compInstanceKey,
    char *designRectKey,
    char *resultKey,
    ArrayOf_USCORE_xsd_USCORE_string *tagKeys,
    impl__result_USCORE_TagInvokedResponse *out)
{
    StartTick("result_TagInvoked");
    try {
        out->_result_USCORE_TagInvokedReturn = NULL;
        Result *r = FindResult(resultKey);
        if (r) {
//TODO: make sub menu items work!!!
//temp hack
			char *tagKey;
			for (int i=0; i<tagKeys->__size; i++) {
				tagKey = tagKeys->__ptr[i];
			}
// \temp hack
            ResultOption *op = r->GetOption(atoi(tagKey));
            if (op) {
                Result *result = op->Selected();
                if (result) {
	                out->_result_USCORE_TagInvokedReturn = soap_new_impl__WSResult(soap, -1);
    	            SerializeResult(soap, out->_result_USCORE_TagInvokedReturn, result);
                }
            }
        }
        EndTick(resultKey);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::event_Unhook(
    char *managerKey,
    char *compInstanceKey,
    ArrayOf_USCORE_xsd_USCORE_string *eventKeyPath,
    impl__event_USCORE_UnhookResponse *out)
{
    StartTick("event_Unhook");
    try {
        out->_event_USCORE_UnhookReturn = NULL;
        rcmComponent *comp = GetComponent(managerKey, 0, compInstanceKey);
        if (comp) {
            string_array keys;
            xsdStringArrayToStringArray(eventKeyPath, keys);
        	Result *r = comp->SetValue(keys, "");
                if (r) {
                    out->_event_USCORE_UnhookReturn = soap_new_impl__WSResult(soap, -1);
                    SerializeResult(soap, out->_event_USCORE_UnhookReturn, r);
                }
        }
        EndTick(compInstanceKey);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::model_GetUIDesignerInfo(
    impl__model_USCORE_GetUIDesignerInfoResponse *out)
{
    StartTick("model_GetUIDesignerInfo");
    try {
        out->_model_USCORE_GetUIDesignerInfoReturn = NULL;
        rcmComponentModel *model = GetModel();
        if (model) {
            rcmDesigner::Info *di = model->GetDesignerInfo(dtUI);
            if (di) {
                out->_model_USCORE_GetUIDesignerInfoReturn = soap_new_impl__WSDesignerInfo(soap, -1);
                SerializeDesignerInfo(soap, out->_model_USCORE_GetUIDesignerInfoReturn, di);
            }
        }
        EndTick(0);
        return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::event_SetHookAsText(
    char *managerKey,
    char *compInstanceKey,
    ArrayOf_USCORE_xsd_USCORE_string *eventKeyPath,
    char *value,
    impl__event_USCORE_SetHookAsTextResponse *out)
{
    StartTick("event_SetHookAsText");
    try {
        out->_event_USCORE_SetHookAsTextReturn = NULL;
        rcmComponent *comp = GetComponent(managerKey, 0, compInstanceKey);
        if (comp) {
            string_array keys;
            xsdStringArrayToStringArray(eventKeyPath, keys);
            Result *r = comp->SetValue(keys, value);
            if (r) {
             	out->_event_USCORE_SetHookAsTextReturn = soap_new_impl__WSResult(soap, -1);
                SerializeResult(soap, out->_event_USCORE_SetHookAsTextReturn, r);
            }
        }
        EndTick(compInstanceKey);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}


int rcmServer::model_GetDesignerInfoForComponent(
    char *compTypeKey,
    impl__model_USCORE_GetDesignerInfoForComponentResponse *out)
{
    out->_model_USCORE_GetDesignerInfoForComponentReturn = NULL;
	return SOAP_OK;
//	return soap_receiver_fault(soap, "not implemented", "GetDesignerInfoForComponent");
}

int rcmServer::comp_TestSetParentContainer(
    char *managerKey,
    char *designerKey,
    char *containerKey,
    char *compInstanceKey,
    impl__comp_USCORE_TestSetParentContainerResponse *out)
{
    StartTick("comp_TestSetParentContainer");
    try {
        out->_comp_USCORE_TestSetParentContainerReturn = false;
        rcmContainer *contnr = GetContainer(managerKey, designerKey, containerKey);
        rcmComponent *comp = GetComponent(managerKey, designerKey, compInstanceKey);
        if (contnr && comp) {
            out->_comp_USCORE_TestSetParentContainerReturn = contnr->CanParent(comp->Instance());
        }
        EndTick(compInstanceKey);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::comp_SetParentContainer(
    char *managerKey,
    char *designerKey,
    char *containerKey,
    char *compKey,
    impl__comp_USCORE_SetParentContainerResponse *out)
{
    StartTick("comp_SetParentContainer");
    try {
		out->_comp_USCORE_SetParentContainerReturn = NULL;
		rcmContainer *newContainer = GetContainer(managerKey, designerKey, containerKey);
		rcmComponent *comp = GetComponent(managerKey, designerKey, compKey);
		if (newContainer && comp) {
			Result *r = comp->SetParent(newContainer);
			if (r) {
				out->_comp_USCORE_SetParentContainerReturn = soap_new_impl__WSResult(soap, -1);
				SerializeResult(soap, out->_comp_USCORE_SetParentContainerReturn, r);
			}
		}
        EndTick(compKey);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::uicomp_TestUIComponentRect(
	char *managerKey,
	char *designerKey,
	char *compKey,
	int x,
	int y,
	int width,
	int height,
	int dragX,
	int dragY,
    impl__uicomp_USCORE_TestUIComponentRectResponse *out)
{
    StartTick("uicomp_TestUIComponentRect");
    try {
        out->_uicomp_USCORE_TestUIComponentRectReturn = NULL;
        rcmUIComponent *comp = GetUIComponent(managerKey, designerKey, compKey);
        if (comp) {
            comp->SetRect(x, y, width, height, true);
            out->_uicomp_USCORE_TestUIComponentRectReturn = soap_new_impl__WSRect(soap, -1);
            SerializeRectangle(x, y, width, height, *(out->_uicomp_USCORE_TestUIComponentRectReturn));
        }
        EndTick(compKey);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::designer_TestCreateComponent(
    char *managerKey,
    char *designerKey,
    char *containerKey,
    char *compTypeKey,
    impl__designer_USCORE_TestCreateComponentResponse *out)
{
    StartTick("designer_TestCreateComponent");
    try {
        out->_designer_USCORE_TestCreateComponentReturn = false;
        rcmDesigner *designer = GetDesigner(managerKey, designerKey);
        rcmContainer *container = GetContainer(managerKey, designerKey, containerKey);
        rcmComponentInfo *compInfo = GetComponentInfo(compTypeKey);
        if (designer && compInfo) {
            out->_designer_USCORE_TestCreateComponentReturn = designer->CanCreate(container, compInfo);
        }
        EndTick(containerKey);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::uidesigner_GetRootUIComponents(
    char *managerKey,
    char *designerKey,
    impl__uidesigner_USCORE_GetRootUIComponentsResponse *out)
{
    StartTick("designer_GetRootUIComponents");
   	try {
		out->_uidesigner_USCORE_GetRootUIComponentsReturn = NULL;
		rcmDesigner* d = GetDesigner(managerKey, designerKey);
        if (d) {
            rcmComponents roots;
            d->GetRootComponents(roots);
            if (roots.size() > 0) {
           	   	out->_uidesigner_USCORE_GetRootUIComponentsReturn = soap_new_ArrayOfWSLiveUIComponent(soap, -1);
                SerializeUIComponents(soap, out->_uidesigner_USCORE_GetRootUIComponentsReturn, roots);
            }
        }
        EndTick(designerKey);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::comp_GetProperty(
    char *managerKey,
    char *compInstanceKey,
    ArrayOf_USCORE_xsd_USCORE_string *propertyKeyPath,
    impl__comp_USCORE_GetPropertyResponse *out)
{
    StartTick("comp_GetProperty");
   	try {
		out->_comp_USCORE_GetPropertyReturn = NULL;
        rcmComponent *c = GetComponent(managerKey, 0, compInstanceKey);
        rcmProperty *p = GetProperty(c, propertyKeyPath);
        if (c && p) {
            out->_comp_USCORE_GetPropertyReturn = soap_new_impl__WSLiveProperty(soap, -1);
            SerializeProperty(soap, c, *p, out->_comp_USCORE_GetPropertyReturn);
        }
        EndTick(compInstanceKey);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::comp_GetEvent(
    char *managerKey,
    char *compInstanceKey,
    ArrayOf_USCORE_xsd_USCORE_string *eventKeyPath,
    impl__comp_USCORE_GetEventResponse *out)
{
    StartTick("comp_GetEvent");
   	try {
		out->_comp_USCORE_GetEventReturn = NULL;
        rcmComponent *c = GetComponent(managerKey, 0, compInstanceKey);
		rcmEvent *e = GetEvent(c, eventKeyPath);
        if (c && e) {
            out->_comp_USCORE_GetEventReturn = soap_new_impl__WSLiveEvent(soap, -1);
            SerializeEvent(soap, c, *e, *(out->_comp_USCORE_GetEventReturn));
        }
        EndTick(compInstanceKey);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::designer_GetComponent(
    char *managerKey,
    char *designerKey,
    char *compInstanceKey,
    impl__designer_USCORE_GetComponentResponse *out)
{
    StartTick("designer_GetComponent");
    try {
        out->_designer_USCORE_GetComponentReturn = NULL;
        rcmDesigner *d = GetDesigner(managerKey, designerKey);
        if (d) {
            rcmComponent *c = d->GetComponent(compInstanceKey);
            if (c) {
                out->_designer_USCORE_GetComponentReturn = soap_new_impl__WSLiveComponent(soap, -1);
                SerializeComponent(soap, out->_designer_USCORE_GetComponentReturn, c);
            }
        }
        EndTick(compInstanceKey);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}


int rcmServer::uidesigner_GetUIComponent(
    char *managerKey,
    char *designerKey,
    char *compInstanceKey,
    impl__uidesigner_USCORE_GetUIComponentResponse *out)
{
    StartTick("uidesigner_GetUIComponent");
    try {
        out->_uidesigner_USCORE_GetUIComponentReturn = NULL;
        rcmComponent *c = GetComponent(managerKey, designerKey, compInstanceKey);
        if (c && dynamic_cast<rcmUIComponent*>(c)) {
            out->_uidesigner_USCORE_GetUIComponentReturn = soap_new_impl__WSLiveUIComponent(soap, -1);
            SerializeAsUIComponent(soap, out->_uidesigner_USCORE_GetUIComponentReturn, c);
        }
        EndTick(compInstanceKey);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::model_GetComponentInfo(
    char *compTypeKey,
    impl__model_USCORE_GetComponentInfoResponse *out)
{
    StartTick("model_GetComponentInfo");
    try {
        out->_model_USCORE_GetComponentInfoReturn = NULL;
        rcmComponentInfo *ci = GetComponentInfo(compTypeKey);
        if (ci) {
            out->_model_USCORE_GetComponentInfoReturn = soap_new_impl__WSComponentInfo(soap, -1);
            SerializeComponentInfo(soap, *(out->_model_USCORE_GetComponentInfoReturn), ci);
        }
        EndTick(compTypeKey);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

int rcmServer::methodinfo_GetMethodInfos(
    char *compTypeKey,
    ArrayOf_USCORE_xsd_USCORE_string *methodKeyPath,
    impl__methodinfo_USCORE_GetMethodInfosResponse *out)
{
    StartTick("methodinfo_GetMethodInfos");
	try {
    	// TODO: implement method info stuff.
    	out->_methodinfo_USCORE_GetMethodInfosReturn = NULL;
        EndTick(compTypeKey);
		return SOAP_OK;
    }
    DEFAULT_CATCH
}

// rcmServer

//struct soap soap;

rcmServer::rcmServer(rcmComponentModel *model, int port, bool useSharedMem)
{
    FModel = model;
    // TODO: port negotiation.
    if (port <= 0) {
        port = 5050;
    }
    FPort = port;
    soap = soap_new();
    transport = new rcmTransportServer(soap, useSharedMem ? 0 : FPort);
}

rcmServer::~rcmServer()
{
    if (FModel)
        delete FModel;
    if (transport)
        delete transport;
    if (soap) {
        soap_destroy(soap);
        soap_end(soap);
        soap_done(soap);
        free((void*)soap);
    }
}

rcmComponentModel* rcmServer::GetModel()
{
    return FModel;
}

int rcmServer::ProcessRequest(int timeout)
{
#ifdef DUMB_PROFILE
    int lastTime = ::GetTickCount();
#endif
    int s = SOAP_EOF;
    if (FUseSharedMem) {
        s = transport->SoapAccept(soap, timeout);
    }
    else {
        // convert to gsoap's timeout units.
        // gsoap timeout in uSec if negative, sec if positive.
        soap->accept_timeout = timeout * -1000;
        s = soap_accept(soap);
    }

    if (s == SOAP_EOF) {
        // timed out - no SOAP requests.
        if (FModel) {
            FModel->SpinEventLoop();
        }
        if (transport) {
            transport->CheckForImageRequest();
        }
    }
    else if (s < SOAP_EOF)
    {
        soap_print_fault(soap, stderr);
    } else {
        if (!FUseSharedMem) {
            soap_serve(soap); // process RPC request
        }
        else {
            soap_destroy(soap); // clean up class instances
            soap_end(soap); // clean up everything and close socket
        }
    }
    return s;
}

rcmPalettePage* rcmServer::GetPalettePage(const char *pageKey)
{
	rcmComponentModel *model = GetModel();
    if (model) {
       	rcmPalettePages::iterator pit = model->PalettePages().find(pageKey);
        if (pit != model->PalettePages().end())
        	return pit->second;
    }
    return 0;
}

rcmComponentInfo* rcmServer::GetComponentInfo(const char *typeKey)
{
	rcmComponentModel *model = GetModel();
    rcmComponentInfo *retval = model->GetComponentInfo(typeKey);
    return retval;
}

rcmDesignerManager* rcmServer::GetManager(const char *managerKey)
{
    return GetModel()->GetDesignerManager(managerKey);
}

rcmDesigner* rcmServer::GetDesigner(const char *managerKey, const char *designerKey)
{
	rcmDesignerManager* mgr = GetManager(managerKey);
    if (mgr) {
		rcmDesigner *designer = mgr->GetDesigner(designerKey);
        if (designer)
        	return designer;
    }
    return 0;
}

rcmUIDesigner* rcmServer::GetUIDesigner(const char *managerKey, const char *designerKey)
{
    rcmUIDesigner* retval = dynamic_cast<rcmUIDesigner*>(GetDesigner(managerKey, designerKey));
    if (retval)
        return retval;
    return 0;
}

rcmComponent* rcmServer::GetComponent(char *managerKey, char *designerKey, char *instanceKey)
{
	if (designerKey) {
		rcmDesigner *d = GetDesigner(managerKey, designerKey);
	    if (d)
			return d->GetComponent(instanceKey);
	} else {
		rcmDesignerManager *dm = GetManager(managerKey);
	    if (dm)
			return dm->GetComponent(instanceKey);
	}
    return 0;
}

rcmUIComponent* rcmServer::GetUIComponent(char *managerKey, char *designerKey, char *instanceKey)
{
	rcmUIComponent *retval = dynamic_cast<rcmUIComponent*>(GetComponent(managerKey, designerKey, instanceKey));
	if (retval)
		return retval;
    return 0;
}

rcmUIComponent* rcmServer::GetUIContainer(char *managerKey, char *designerKey, char *instanceKey)
{
    rcmUIComponent *retval = GetUIComponent(managerKey, designerKey, instanceKey);
    if (retval && dynamic_cast<rcmContainer*>(retval))
        return retval;
    return 0;
}

DesignRectProvider* rcmServer::GetDesignRectProvider(rcmComponent *c)
{
    return dynamic_cast<DesignRectProvider*>(c);
}

DesignRectProvider* rcmServer::GetDesignRectProvider(rcmDesigner *d)
{
    return dynamic_cast<DesignRectProvider*>(d);
}

DesignRect* rcmServer::GetDesignRect(char *managerKey, char *designerKey, char *compInstanceKey, char *designRectKey)
{
    rcmDesigner *d = GetDesigner(managerKey, designerKey);
    if (d) {
        DesignRectProvider *drs;
        DesignRect *dr = 0;
        if (compInstanceKey) {
            drs = GetDesignRectProvider(d->GetComponent(compInstanceKey));
            if (drs)
                dr = drs->FindRect(string_type(designRectKey));
            else
                throw soap_bad_key(compInstanceKey, "component");
        }
        else {
            drs = GetDesignRectProvider(d);
            if (drs)
                dr = drs->FindRect(string_type(designRectKey));
            else
                throw soap_bad_key(designerKey, "designer");
        }
        if (dr)
            return dr;
    }
    return 0;
}

rcmContainer* rcmServer::GetContainer(char *managerKey, char *designerKey, char *containerKey)
{
	rcmContainer *container = dynamic_cast<rcmContainer*>(GetComponent(managerKey, designerKey, containerKey));
	if (container || containerKey == 0)
		return container;
    return 0;
}

rcmProperty* rcmServer::GetProperty(char *compTypeKey, ArrayOf_USCORE_xsd_USCORE_string *propKeys)
{
	rcmComponentInfo *ci = GetComponentInfo(compTypeKey);
    if (ci) {
        string_array keys;
        xsdStringArrayToStringArray(propKeys, keys);
    	rcmProperty *p = ci->GetProperty(keys, 0);
    	if (p) return p;
    }
    return 0;
}

rcmProperty* rcmServer::GetProperty(rcmComponent *comp, ArrayOf_USCORE_xsd_USCORE_string *propKeys)
{
    if (!comp) return 0;
    string_array keys;
    xsdStringArrayToStringArray(propKeys, keys);
    return comp->GetProperty(keys);
}

rcmProperty* rcmServer::GetProperty(char *managerKey, char *designerKey, char *compInstanceKey,
    ArrayOf_USCORE_xsd_USCORE_string *propKeys)
{
    rcmComponent *c = GetComponent(managerKey, designerKey, compInstanceKey);
    if (c) {
        return GetProperty(c, propKeys);
    }
    return 0;
}

rcmEvent* rcmServer::GetEvent(rcmComponent *comp, ArrayOf_USCORE_xsd_USCORE_string *eventKeys)
{
    if (!comp) return 0;
    rcmComponentInfo *ci = comp->ComponentInfo();
    string_array keys;
    xsdStringArrayToStringArray(eventKeys, keys);
    return ci->GetEvent(keys, comp);
}

rcmEvent* rcmServer::GetEvent(char *compTypeKey, ArrayOf_USCORE_xsd_USCORE_string *eventKeys)
{
	rcmComponentInfo *ci = GetComponentInfo(compTypeKey);
    if (ci) {
        string_array keys;
        xsdStringArrayToStringArray(eventKeys, keys);
    	rcmEvent *p = ci->GetEvent(keys);
    	if (p) return p;
    }
    return 0;
}

rcmEvent* rcmServer::GetEvent(char *managerKey, char *designerKey, char *componentInstanceKey,
	 ArrayOf_USCORE_xsd_USCORE_string *eventKeys)
{
    rcmComponent *c = GetComponent(managerKey, designerKey, componentInstanceKey);
    if (c) {
        rcmEvent *e = GetEvent(c, eventKeys);
        if (e) return e;
    }
    return 0;
}

// soap stubs

SOAP_FMAC1 int SOAP_FMAC2 impl__server_USCORE_GetComponentModels(
	struct soap *soap,
    impl__server_USCORE_GetComponentModelsResponse *out)
{
    return Server().server_GetComponentModels(out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__model_USCORE_CustomDataRequest(
    struct soap *soap,
    char *modelKey,
    char *requestKey,
    char *data,
    impl__model_USCORE_CustomDataRequestResponse *out)
{
    return Server().model_CustomDataRequest(requestKey, data, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__manager_USCORE_GetDefaultDesigner(
	struct soap *soap,
    char *modelKey,
    char *managerKey,
    impl__manager_USCORE_GetDefaultDesignerResponse *out)
{
    return Server().manager_GetDefaultDesigner(managerKey, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__manager_USCORE_GetUIDesigner(
	struct soap *soap,
    char *modelKey,
    char *managerKey,
    impl__manager_USCORE_GetUIDesignerResponse *out)
{
    return Server().manager_GetUIDesigner(managerKey, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__manager_USCORE_GetDesignerEvents(
    struct soap *soap,
    char *modelKey,
    char *managerKey,
    impl__manager_USCORE_GetDesignerEventsResponse *out)
{
    return Server().manager_GetDesignerEvents(managerKey, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__model_USCORE_GetPalettePages(
	struct soap *soap,
    char *modelKey,
    impl__model_USCORE_GetPalettePagesResponse *out)
{
    return Server().model_GetPalettePages(out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__model_USCORE_GetDesignerManagers(
	struct soap *soap,
    char *modelKey,
    impl__model_USCORE_GetDesignerManagersResponse *out)
{
    return Server().model_GetDesignerManagers(out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__model_USCORE_CreateDesignerManager(
	struct soap *soap,
    char *modelKey,
    impl__model_USCORE_CreateDesignerManagerResponse *out)
{
    return Server().model_CreateDesignerManager(out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__palette_USCORE_GetComponentInfos(
	struct soap *soap,
    char *modelKey,
    char *pageKey,
    impl__palette_USCORE_GetComponentInfosResponse *out)
{
    return Server().palette_GetComponentInfos(pageKey, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__model_USCORE_DisposeDesignerManager(
	struct soap *soap,
    char *modelKey,
    char *managerKey,
    impl__model_USCORE_DisposeDesignerManagerResponse *out)
{
    return Server().model_DisposeDesignerManager(managerKey, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__manager_USCORE_GetPersistenceData(
	struct soap *soap,
    char *modelKey,
    char *managerKey,
    char *compInstanceKey,
    impl__manager_USCORE_GetPersistenceDataResponse *out)
{
    return Server().manager_GetPersistenceData(managerKey, compInstanceKey, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__manager_USCORE_IsPersistenceDataModified(
	struct soap *soap,
    char *modelKey,
    char *managerKey,
    impl__manager_USCORE_IsPersistenceDataModifiedResponse *out)
{
    return Server().manager_IsPersistenceDataModified(managerKey, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__manager_USCORE_GetComponentsOfType(
	struct soap *soap,
    char *modelKey,
    char *managerKey,
    char *typeKey,
    impl__manager_USCORE_GetComponentsOfTypeResponse *out)
{
    return Server().manager_GetComponentsOfType(managerKey, typeKey, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__manager_USCORE_SetPersistenceData(
	struct soap *soap,
    char *modelKey,
    char *managerKey,
    xsd__base64Binary *data,
    impl__manager_USCORE_SetPersistenceDataResponse *out)
{
    return Server().manager_SetPersistenceData(managerKey, data, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__designer_USCORE_CreateComponent(
	struct soap *soap,
    char *modelKey,
    char *managerKey,
    char *designerKey,
    char *containerInstanceKey,
    char *compTypeKey,
    xsd__base64Binary *persistData,
    impl__designer_USCORE_CreateComponentResponse *out)
{
    return Server().designer_CreateComponent(managerKey, designerKey, containerInstanceKey, compTypeKey, persistData, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__designer_USCORE_CreateComponent_(
	struct soap *soap,
    char *modelKey,
    char *managerKey,
    char *designerKey,
    char *containerInstanceKey,
    char *compTypeKey,
    impl__designer_USCORE_CreateComponentResponse *out)
{
   	return Server().designer_CreateComponent(managerKey, designerKey, containerInstanceKey, compTypeKey, NULL, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__uidesigner_USCORE_CreateComponent_(
	struct soap *soap,
    char *modelKey,
    char *managerKey,
    char *designerKey,
    char *containerInstanceKey,
    char *compTypeKey,
    int x,
    int y,
    int w,
    int h,
    xsd__base64Binary *persistData,
    impl__uidesigner_USCORE_CreateComponentResponse *out)
{
    return Server().uidesigner_CreateComponent(managerKey, designerKey, containerInstanceKey,
        compTypeKey, x, y, -1, -1, persistData, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__uidesigner_USCORE_CreateComponent_(
	struct soap *soap,
    char *modelKey,
    char *managerKey,
    char *designerKey,
    char *containerInstanceKey,
    char *compTypeKey,
    int x,
    int y,
    int w,
    int h,
    impl__uidesigner_USCORE_CreateComponentResponse *out)
{
    return Server().uidesigner_CreateComponent(managerKey, designerKey, containerInstanceKey,
        compTypeKey, x, y, w, h, NULL, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__uidesigner_USCORE_CreateComponent(
    struct soap *soap,
    char *modelKey,
    char *managerKey,
    char *designerKey,
    char *containerInstanceKey,
    char *compTypeKey,
    int x,
    int y,
    xsd__base64Binary *persistData,
    impl__uidesigner_USCORE_CreateComponentResponse *out)
{
    return Server().uidesigner_CreateComponent(managerKey, designerKey, containerInstanceKey,
        compTypeKey, x, y, -1, -1, persistData, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__uidesigner_USCORE_CreateComponent(
	struct soap *soap,
    char *modelKey,
    char *managerKey,
    char *designerKey,
    char *containerInstanceKey,
    char *compTypeKey,
    int x,
    int y,
    int width,
    int height,
    xsd__base64Binary *persistData,
    impl__uidesigner_USCORE_CreateComponentResponse *out)
{
	return Server().uidesigner_CreateComponent(managerKey, designerKey, containerInstanceKey,
        compTypeKey, x, y, width, height, persistData, out);
}


SOAP_FMAC1 int SOAP_FMAC2 impl__uidesigner_USCORE_CreateComponent(
	struct soap *soap,
    char *modelKey,
    char *managerKey,
    char *designerKey,
    char *containerInstanceKey,
    char *compTypeKey,
    int x,
    int y,
    impl__uidesigner_USCORE_CreateComponentResponse *out)
{
    return Server().uidesigner_CreateComponent(managerKey, designerKey, containerInstanceKey,
        compTypeKey, x, y, -1, -1, NULL, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__designer_USCORE_GetContextTags(
	struct soap *soap,
    char *modelKey,
    char *managerKey,
    char *designerKey,
    int x,
    int y,
    impl__designer_USCORE_GetContextTagsResponse *out)
{
    return Server().designer_GetContextTags(managerKey, designerKey, x, y, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__designer_USCORE_TagInvoked(
	struct soap *soap,
    char *modelKey,
    char *managerKey,
    char *designerKey,
    ArrayOf_USCORE_xsd_USCORE_string *tagKeys,
    impl__designer_USCORE_TagInvokedResponse *out)
{
    return Server().designer_TagInvoked(managerKey, designerKey, tagKeys, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__designer_USCORE_DisposeComponent(
	struct soap *soap,
    char *modelKey,
    char *managerKey,
    char *designerKey,
    char *compInstanceKey,
    impl__designer_USCORE_DisposeComponentResponse *out)
{
    return Server().designer_DisposeComponent(managerKey, designerKey, compInstanceKey, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__designer_USCORE_GetRootComponents(
	struct soap *soap,
    char *modelKey,
    char *managerKey,
    char *designerKey,
    impl__designer_USCORE_GetRootComponentsResponse *out)
{
    return Server().designer_GetRootComponents(managerKey, designerKey, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__compinfo_USCORE_GetEventInfos(
	struct soap *soap,
    char *modelKey,
    char *compTypeKey,
    impl__compinfo_USCORE_GetEventInfosResponse *out)
{
    return Server().compinfo_GetEventInfos(compTypeKey, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__eventinfo_USCORE_GetEventInfos(
	struct soap *soap,
	char *modelKey,
	char *compTypeKey,
	ArrayOf_USCORE_xsd_USCORE_string *eventKeyPath,
	impl__eventinfo_USCORE_GetEventInfosResponse *out)
{
    return Server().eventinfo_GetEventInfos(compTypeKey, eventKeyPath, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__compinfo_USCORE_GetPropertyInfos(
	struct soap *soap,
    char *modelKey,
    char *compTypeKey,
    impl__compinfo_USCORE_GetPropertyInfosResponse *out)
{
    return Server().compinfo_GetPropertyInfos(compTypeKey, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__propinfo_USCORE_GetPropertyInfos(
    struct soap *soap,
	char *modelKey,
	char *compTypeKey,
	char *managerInstanceKey,
	char *designerKey,
	char *compInstanceKey,
    ArrayOf_USCORE_xsd_USCORE_string *propertyKeyPath,
    impl__propinfo_USCORE_GetPropertyInfosResponse *out)
{
    return Server().propinfo_GetPropertyInfos(compTypeKey, managerInstanceKey,
        designerKey, compInstanceKey, propertyKeyPath, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__prop_USCORE_GetProperties(
	struct soap *soap,
	char *modelKey,
	char *managerKey,
	char *compInstanceKey,
	ArrayOf_USCORE_xsd_USCORE_string *propertyKeyPath,
	impl__prop_USCORE_GetPropertiesResponse *out)
{
    return Server().prop_GetProperties(managerKey, compInstanceKey, propertyKeyPath, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__compinfo_USCORE_GetMethodInfos(
	struct soap *soap,
    char *modelKey,
    char *compTypeKey,
    impl__compinfo_USCORE_GetMethodInfosResponse *out)
{
    return Server().compinfo_GetMethodInfos(compTypeKey, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__propinfo_USCORE_GetValueTags(
	struct soap *soap,
    char *modelKey,
    char *compTypeKey,
    ArrayOf_USCORE_xsd_USCORE_string *propKeys,
    impl__propinfo_USCORE_GetValueTagsResponse *out)
{
    return Server().propinfo_GetValueTags(compTypeKey, propKeys, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__comp_USCORE_GetContextTags(
	struct soap *soap,
	char *modelKey,
	char *managerKey,
	char *designerKey,
	char *compInstanceKey,
    int x,
    int y,
	impl__comp_USCORE_GetContextTagsResponse *out)
{
    return Server().comp_GetContextTags(managerKey, designerKey, compInstanceKey, x, y, out);
}


SOAP_FMAC1 int SOAP_FMAC2 impl__uicomp_USCORE_GetAsContainer(
	struct soap *soap,
	char *modelKey,
	char *managerKey,
	char *designerKey,
	char *instanceKey,
	impl__uicomp_USCORE_GetAsContainerResponse *out)
{
    return Server().uicomp_GetAsContainer(managerKey, designerKey, instanceKey, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__uicomp_USCORE_SetUIComponentRect(
    struct soap *soap,
    char *modelKey,
    char *managerKey,
    char *designerKey,
    char *compInstanceKey,
    int x,
    int y,
    int w,
    int h,
    int dragX,
    int dragY,
    impl__uicomp_USCORE_SetUIComponentRectResponse *out)
{
    return Server().uicomp_SetUIComponentRect(managerKey, designerKey, compInstanceKey,
        x, y, w, h, dragX, dragY, out);
}



SOAP_FMAC1 int SOAP_FMAC2 impl__comp_USCORE_SetInstanceName(
	struct soap *soap,
	char *modelKey,
	char *managerKey,
	char *instanceKey,
	char *newName,
	impl__comp_USCORE_SetInstanceNameResponse *out)
{
    return Server().comp_SetInstanceName(managerKey, instanceKey, newName, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__comp_USCORE_GetAsContainer(
	struct soap *soap,
	char *modelKey,
	char *managerKey,
	char *designerKey,
	char *instanceKey,
	impl__comp_USCORE_GetAsContainerResponse *out)
 {
    return Server().comp_GetAsContainer(managerKey, designerKey, instanceKey, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__comp_USCORE_TagInvoked(
	struct soap *soap,
	char *modelKey,
	char *managerKey,
	char *designerKey,
	char *compInstanceKey,
	ArrayOf_USCORE_xsd_USCORE_string *tagKeys,
	impl__comp_USCORE_TagInvokedResponse *out)
{
    return Server().comp_TagInvoked(managerKey, designerKey, compInstanceKey,
        tagKeys, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__comp_USCORE_GetProperties(
	struct soap *soap,
	char *modelKey,
	char *managerKey,
	char *compInstanceKey,
	impl__comp_USCORE_GetPropertiesResponse *out)
{
    return Server().comp_GetProperties(managerKey, compInstanceKey, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__comp_USCORE_GetEvents(
	struct soap *soap,
	char *modelKey,
	char *managerKey,
	char *compInstanceKey,
	impl__comp_USCORE_GetEventsResponse *out)
{
    return Server().comp_GetEvents(managerKey, compInstanceKey, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__event_USCORE_GetEvents(
	struct soap *soap,
	char *modelKey,
	char *managerKey,
	char *compInstanceKey,
	ArrayOf_USCORE_xsd_USCORE_string *eventKeyPath,
	impl__event_USCORE_GetEventsResponse *out)
{
    return Server().event_GetEvents(managerKey, compInstanceKey, eventKeyPath, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__prop_USCORE_GetValueTags(
	struct soap *soap,
	char *modelKey,
	char *managerKey,
	char *compInstanceKey,
	ArrayOf_USCORE_xsd_USCORE_string *propertyKeyPath,
	impl__prop_USCORE_GetValueTagsResponse *out)
{
    return Server().prop_GetValueTags(managerKey, compInstanceKey, propertyKeyPath, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__prop_USCORE_SetValueAsText(
    struct soap *soap,
    char *modelKey,
    char *managerKey,
    char *compInstanceKey,
    ArrayOf_USCORE_xsd_USCORE_string *propertyKeyPath,
    char *value,
    impl__prop_USCORE_SetValueAsTextResponse *out)
{
    return Server().prop_SetValueAsText(managerKey, compInstanceKey, propertyKeyPath, value, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__prop_USCORE_Revert(
    struct soap *soap,
    char *modelKey,
    char *managerKey,
    char *compInstanceKey,
    ArrayOf_USCORE_xsd_USCORE_string *propertyKeyPath,
    impl__prop_USCORE_RevertResponse *out)
{
    return Server().prop_Revert(managerKey, compInstanceKey, propertyKeyPath, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__eventinfo_USCORE_GetHookTags(
    struct soap *soap,
    char *modelKey,
    char *typeKey,
    ArrayOf_USCORE_xsd_USCORE_string *eventKeyPath,
    impl__eventinfo_USCORE_GetHookTagsResponse *out)
{
    return Server().eventinfo_GetHookTags(typeKey, eventKeyPath, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__event_USCORE_GetHookTags(
    struct soap *soap,
    char *modelKey,
    char *managerKey,
    char *compInstanceKey,
    ArrayOf_USCORE_xsd_USCORE_string *eventKeyPath,
    impl__event_USCORE_GetHookTagsResponse *out)
{
    return Server().event_GetHookTags(managerKey, compInstanceKey, eventKeyPath, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__uidesignrect_USCORE_ResizeCompleted(
	struct soap *soap,
	char *modelKey,
	char *managerKey,
	char *designerKey,
	char *compInstanceKey,
	char *designRectKey,
	int x,
	int y,
	int w,
	int h,
	impl__uidesignrect_USCORE_ResizeCompletedResponse *out)
{
    return Server().uidesignrect_ResizeCompleted(managerKey, designerKey, compInstanceKey,
        designRectKey, x, y, w, h, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__uidesignrect_USCORE_MoveCompleted(
    struct soap *soap,
    char *modelKey,
    char *managerKey,
    char *designerKey,
    char *compInstanceKey,
    char *designRectKey,
    int x,
    int y,
    int w,
    int h,
    impl__uidesignrect_USCORE_MoveCompletedResponse *out)
{
    return Server().uidesignrect_MoveCompleted(managerKey, designerKey, compInstanceKey,
        designRectKey, x, y, w, h, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__uidesignrect_USCORE_GetContextTags(
	struct soap *soap,
	char *modelKey,
	char *managerKey,
	char *designerKey,
	char *compInstanceKey,
	char *designRectKey,
    int x,
    int y,
	impl__uidesignrect_USCORE_GetContextTagsResponse *out)
{
    return Server().uidesignrect_GetContextTags(managerKey, designerKey, compInstanceKey,
        designRectKey, x, y, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__uidesignrect_USCORE_MouseClick(
    struct soap *soap,
    char *modelKey,
    char *managerKey,
    char *designerKey,
    char *compInstanceKey,
    char *designRectKey,
    int x,
    int y,
    int clickCount,
    impl__uidesignrect_USCORE_MouseClickResponse *out)
{
    return Server().uidesignrect_MouseClick(managerKey, designerKey, compInstanceKey,
        designRectKey, x, y, clickCount, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__uidesignrect_USCORE_TagInvoked(
    struct soap *soap,
    char *modelKey,
    char *managerKey,
    char *designerKey,
    char *compInstanceKey,
    char *designRectKey,
    ArrayOf_USCORE_xsd_USCORE_string *tagKeys,
    impl__uidesignrect_USCORE_TagInvokedResponse *out)
{
    return Server().uidesignrect_TagInvoked(managerKey, designerKey, compInstanceKey,
        designRectKey, tagKeys, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__model_USCORE_GetDefaultDesignerInfo(
	struct soap *soap,
	char *modelKey,
	impl__model_USCORE_GetDefaultDesignerInfoResponse *out)
{
    return Server().model_GetDefaultDesignerInfo(out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__event_USCORE_SetDefaultHook(
	struct soap *soap,
	char *modelKey,
	char *managerKey,
	char *compInstanceKey,
	ArrayOf_USCORE_xsd_USCORE_string *eventKeyPath,
	impl__event_USCORE_SetDefaultHookResponse *out)
{
    return Server().event_SetDefaultHook(managerKey, compInstanceKey, eventKeyPath, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__container_USCORE_SetComponentIndex(
	struct soap *soap,
	char *modelKey,
	char *managerKey,
	char *containerKey,
	char *compInstanceKey,
	int newIndex,
	impl__container_USCORE_SetComponentIndexResponse *out)
{
    return Server().container_SetComponentIndex(managerKey, containerKey, compInstanceKey,
        newIndex, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__result_USCORE_TagInvoked(
    struct soap *soap,
    char *modelKey,
    char *managerKey,
    char *designerKey,
    char *compInstanceKey,
    char *designRectKey,
    char *resultKey,
    ArrayOf_USCORE_xsd_USCORE_string *tagKeys,
    impl__result_USCORE_TagInvokedResponse *out)
{
    return Server().result_TagInvoked(managerKey, designerKey, compInstanceKey,
        designRectKey, resultKey, tagKeys, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__event_USCORE_Unhook(
    struct soap *soap,
    char *modelKey,
    char *managerKey,
    char *compInstanceKey,
    ArrayOf_USCORE_xsd_USCORE_string *eventKeyPath,
    impl__event_USCORE_UnhookResponse *out)
{
    return Server().event_Unhook(managerKey, compInstanceKey, eventKeyPath, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__model_USCORE_GetUIDesignerInfo(
    struct soap* soap,
    char *modelKey,
    impl__model_USCORE_GetUIDesignerInfoResponse *out)
{
    return Server().model_GetUIDesignerInfo(out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__event_USCORE_SetHookAsText(
    struct soap *soap,
    char *modelKey,
    char *managerKey,
    char *compInstanceKey,
    ArrayOf_USCORE_xsd_USCORE_string *eventKeyPath,
    char *value,
    impl__event_USCORE_SetHookAsTextResponse *out)
{
    return Server().event_SetHookAsText(managerKey, compInstanceKey, eventKeyPath,
        value, out);
}


SOAP_FMAC1 int SOAP_FMAC2 impl__model_USCORE_GetDesignerInfoForComponent(
    struct soap *soap,
    char *modelKey,
    char *compTypeKey,
    impl__model_USCORE_GetDesignerInfoForComponentResponse *out)
{
    return Server().model_GetDesignerInfoForComponent(compTypeKey, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__comp_USCORE_TestSetParentContainer(
    struct soap *soap,
    char *modelKey,
    char *managerKey,
    char *designerKey,
    char *containerKey,
    char *compInstanceKey,
    impl__comp_USCORE_TestSetParentContainerResponse *out)
{
    return Server().comp_TestSetParentContainer(managerKey, designerKey, containerKey,
        compInstanceKey, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__comp_USCORE_SetParentContainer(
    struct soap *soap,
    char *modelKey,
    char *managerKey,
    char *designerKey,
    char *containerKey,
    char *compKey,
    impl__comp_USCORE_SetParentContainerResponse *out)
{
    return Server().comp_SetParentContainer(managerKey, designerKey, containerKey, compKey, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__uicomp_USCORE_TestUIComponentRect(
    struct soap *soap,
    char *modelKey,
	char *managerKey,
	char *designerKey,
	char *compKey,
	int x,
	int y,
	int width,
	int height,
	int dragX,
	int dragY,
    impl__uicomp_USCORE_TestUIComponentRectResponse *out)
{
    return Server().uicomp_TestUIComponentRect(managerKey, designerKey, compKey,
        x, y, width, height, dragX, dragY, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__designer_USCORE_TestCreateComponent(
    struct soap *soap,
    char *modelKey,
    char *managerKey,
    char *designerKey,
    char *containerKey,
    char *compTypeKey,
    impl__designer_USCORE_TestCreateComponentResponse *out)
{
    return Server().designer_TestCreateComponent(managerKey, designerKey, containerKey,
        compTypeKey, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__uidesigner_USCORE_GetRootUIComponents(
    struct soap* soap,
    char *modelKey,
    char *managerKey,
    char *designerKey,
    impl__uidesigner_USCORE_GetRootUIComponentsResponse *out)
{
    return Server().uidesigner_GetRootUIComponents(managerKey, designerKey, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__comp_USCORE_GetProperty(
    struct soap *soap,
    char *modelKey,
    char *managerKey,
    char *compInstanceKey,
    ArrayOf_USCORE_xsd_USCORE_string *propertyKeyPath,
    impl__comp_USCORE_GetPropertyResponse *out)
{
    return Server().comp_GetProperty(managerKey, compInstanceKey, propertyKeyPath, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__comp_USCORE_GetEvent(
    struct soap *soap,
    char *modelKey,
    char *managerKey,
    char *compInstanceKey,
    ArrayOf_USCORE_xsd_USCORE_string *eventKeyPath,
    impl__comp_USCORE_GetEventResponse *out)
{
    return Server().comp_GetEvent(managerKey, compInstanceKey, eventKeyPath, out);
}


SOAP_FMAC1 int SOAP_FMAC2 impl__designer_USCORE_GetComponent(
    struct soap *soap,
    char *modelKey,
    char *managerKey,
    char *designerKey,
    char *compInstanceKey,
    impl__designer_USCORE_GetComponentResponse *out)
{
    return Server().designer_GetComponent(managerKey, designerKey, compInstanceKey, out);
}


SOAP_FMAC1 int SOAP_FMAC2 impl__uidesigner_USCORE_GetUIComponent(
    struct soap *soap,
    char *modelKey,
    char *managerKey,
    char *designerKey,
    char *compInstanceKey,
    impl__uidesigner_USCORE_GetUIComponentResponse *out)
{
    return Server().uidesigner_GetUIComponent(managerKey, designerKey, compInstanceKey, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__model_USCORE_GetComponentInfo(
    struct soap *soap,
    char *modelKey,
    char *compTypeKey,
    impl__model_USCORE_GetComponentInfoResponse *out)
{
    return Server().model_GetComponentInfo(compTypeKey, out);
}

SOAP_FMAC1 int SOAP_FMAC2 impl__methodinfo_USCORE_GetMethodInfos(
	struct soap *soap,
    char *modelKey,
    char *compTypeKey,
    ArrayOf_USCORE_xsd_USCORE_string *methodKeyPath,
    impl__methodinfo_USCORE_GetMethodInfosResponse *out)
{
    return Server().methodinfo_GetMethodInfos(compTypeKey, methodKeyPath, out);
}










