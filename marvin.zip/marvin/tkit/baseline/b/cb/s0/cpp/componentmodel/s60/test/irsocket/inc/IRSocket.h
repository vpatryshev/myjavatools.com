#ifndef __IRSOCKET_H__
#define __IRSOCKET_H__

// ---------------------
// IRSOCKET
// ---------------------







#endif // __IRSOCKET_H__

