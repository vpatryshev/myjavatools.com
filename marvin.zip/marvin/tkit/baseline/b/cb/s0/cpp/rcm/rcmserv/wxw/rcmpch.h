#ifdef __WINDOWS__
#include <windows.h>
#endif

#ifdef __WXWIN__
#include <wx/wx.h>
#endif

#pragma hdrstop

