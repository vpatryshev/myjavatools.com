// ---------------------------------------------------------
//  Are we building for Linux or Windows?
// ---------------------------------------------------------
#if defined(__BORLANDC__) && defined(_Windows)
  #define __MSWINDOWS__
#endif

#include <jni.h>
#include <string.h>
#include <stdlib.h>

#if defined(__MSWINDOWS__)

#define UNICODE
# include <windows.h>

#else

/////////////////////////////////////////////////////////////
// Linux/Unix version
/////////////////////////////////////////////////////////////
#if defined(linux)
#include <unistd.h>  // __environ
#elif defined(sun)
#define __environ environ
extern char **__environ;
#endif

#define lstrcat(lpString1, lpString2) strcat((lpString1), (lpString2))
typedef char TCHAR;
typedef TCHAR* LPTSTR;

#endif

#if !defined(UNICODE)

#define NULL_CHECK0(e) if ((e) == 0) return 0

/*
 * Returns a new Java string object for the specified platform string.
 */
static jstring
NewPlatformString(JNIEnv *env, char *s)
{
    int len = (int)strlen(s);
    jclass cls;
    jmethodID mid;
    jbyteArray ary;

    NULL_CHECK0(cls = env->FindClass("java/lang/String"));
    NULL_CHECK0(mid = env->GetMethodID(cls, "<init>", "([B)V"));
    ary = env->NewByteArray(len);
    if (ary != 0) {
	jstring str = 0;
	env->SetByteArrayRegion(ary, 0, len, (jbyte *)s);
	if (!env->ExceptionOccurred()) {
	    str = (jstring) env->NewObject(cls, mid, ary);
	}
	env->DeleteLocalRef(ary);
	return str;
    }
    return 0;
}

#endif /* !defined(UNICODE) */

#include "com_borland_cbuilder_env_SysEnvironment.h"

class EnvVars {
#if defined(__MSWINDOWS__)
  LPTSTR pv;
#endif
  int count;
  int len;
  LPTSTR* vars;

public:
  EnvVars();
 ~EnvVars();

  int getCount() const {  return count; };

  int getLength() const{  return len; }

  LPTSTR operator[](int index) {  return vars[index]; }
};


EnvVars::EnvVars() : count(0), len(0), vars(0)
{
#if defined(__MSWINDOWS__)
  pv= static_cast<LPTSTR>(::GetEnvironmentStrings());
  LPTSTR str = pv;
  while (true)
  {
    if (*str == 0)
      break;
    while (*str != 0)
      str++;
    str++;
    count++;
  }

  /** Have pointers to each var */
  vars = new LPTSTR[count];
  str = pv;
  for(int i = 0; i < count; i++)
  {
   vars[i] = str;
   len += lstrlen(str);
   while (*str != 0)
     str++;
   str++;
  }

#else

  // Walk through environment variables
  char** ppch = __environ;
  while (*ppch)
  {
    count++;
    ppch++;
  }

  // Allocate an array with pointers to each entry
  vars = new LPTSTR[count];
  ppch = __environ;
  for (int i=0; i<count; i++)
  {
    vars[i] = *ppch;
    len += strlen(vars[i]);
    ppch++;
  }

#endif
}

EnvVars::~EnvVars()
{
#if defined(__MSWINDOWS__)
  ::FreeEnvironmentStrings(pv);
#endif
  delete [] vars;
}


JNIEXPORT jstring JNICALL Java_com_borland_cbuilder_env_SysEnvironment_getSysEnvironment
      (JNIEnv *env, jobject)
{
  EnvVars envVars;
  int count = envVars.getCount();

  LPTSTR vars = new TCHAR[envVars.getLength() + count + 1];
  vars[0] = 0;

  for (int i=0; i<count; i++)
  {
    lstrcat(vars, envVars[i]);
#if defined(UNICODE)
    lstrcat(vars, L"\n");
#else /* defined(UNICODE) */
    lstrcat(vars, "\n");
#endif /* defined(UNICODE) */
  }

#if defined(UNICODE)
  jstring ret = env->NewString((jchar *) vars, (jsize) lstrlen(vars));
#else /* defined(UNICODE) */
  jstring ret = NewPlatformString(env, vars);
#endif /* defined(UNICODE) */
  delete [] vars;
  return ret;
}


