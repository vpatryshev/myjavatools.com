#include <windows.h>

#pragma argsused
int main(int argc, char* argv[])
{
    if (argc > 1) {
        unsigned long pid = atoi(argv[1]);
        if (pid > 0) {
            void *hProcess = OpenProcess(PROCESS_ALL_ACCESS, 0, pid);
            if (hProcess && TerminateProcess(hProcess, 1)) {
                return 0;
            }
            else {
                return GetLastError();
            }
        }
    }
    return 0;
}
 
