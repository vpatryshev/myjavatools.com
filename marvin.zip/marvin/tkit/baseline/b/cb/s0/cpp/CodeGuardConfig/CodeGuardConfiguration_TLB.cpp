// ************************************************************************ //
// WARNING                                                                    
// -------                                                                    
// The types declared in this file were generated from data read from a       
// Type Library. If this type library is explicitly or indirectly (via        
// another type library referring to this type library) re-imported, or the   
// 'Refresh' command of the Type Library Editor activated while editing the   
// Type Library, the contents of this file will be regenerated and all        
// manual modifications will be lost.                                         
// ************************************************************************ //

// C++ TLBWRTR : $Revision: 1.35 $
// File generated on 11/8/2004 12:45:11 PM from Type Library described below.

// ************************************************************************  //
// Type Lib: C:\cbuilder\src\cpp\CodeGuardConfig\CodeGuardConfiguration.tlb (1)
// LIBID: {2A2909FE-16AC-472C-A054-60F3320C04EF}
// LCID: 0
// Helpfile: 
// HelpString: CodeGuardConfiguration Library
// DepndLst: 
//   (1) v2.0 stdole, (C:\WINDOWS\System32\stdole2.tlb)
// ************************************************************************ //

#include <vcl.h>
#pragma hdrstop

#include "CodeGuardConfiguration_TLB.h"

#if !defined(__PRAGMA_PACKAGE_SMART_INIT)
#define      __PRAGMA_PACKAGE_SMART_INIT
#pragma package(smart_init)
#endif

namespace Codeguardconfiguration_tlb
{


// *********************************************************************//
// GUIDS declared in the TypeLibrary                                      
// *********************************************************************//
//*********************************************************************//
// NOTE: This file is no longer used. GUIDS previously defined in this 
// file are now defined in the header itself, using __declspec(selectany).
//********************************************************************//

};     // namespace Codeguardconfiguration_tlb
