#ifndef wxwuicontainerH
#define wxwuicontainerH

#include "wxw.h"
#include "wxwindow.h"
#include "wxwcontainer.h"

class wxwUIContainer : public wxwContainer
{
public:
    wxwUIContainer() : wxwContainer() { }
    virtual ~wxwUIContainer() { }

    virtual bool CanParentType(const wxClassInfo *type);

    /*
        Notification that a child component has been asked to change size/position.
        Container can intervene to modify the requested values, or veto them
        outright. Return true to allow resizing/moving with the (possibly modified)
        values, false to prevent.
    */
    virtual bool NotifyChildBoundsChanging(int &x, int &y, int &w, int &h, wxwUIComponent *child) { return true; };

    /*
        Notification that a child component has successfully changed its size/position.
    */
    virtual void NotifyChildBoundsChanged(wxwUIComponent *child) { };
};

class RCMEXPORT wxWindowContainer : public wxWindowComponent, public wxwUIContainer
{
public:
	wxWindowContainer(const wxClassInfo *classInfo, wxwDesigner *designer, wxwContainer *container)
        : wxWindowComponent(classInfo, designer, container) { }
};

template <typename T>
class wxWindowContainerT : public wxWindowContainer
{
public:
	wxWindowContainerT(wxwDesigner *designer, wxwContainer *container)
        : wxWindowContainer(CLASSINFO(T), designer, container) { }

protected:
    virtual void ConstructXTIObject(wxObject *object)
    {
        wxASSERT_MSG(wxContainer(), "UI components must have a container");
        wxObject *trueParent = wxContainer()->ParentInstance();
        ConstructWXObject(trueParent, (T*)object, GetName());
    }
};

#endif
