//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "messagedialog.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TMessageForm *MessageForm;

extern impl__WSTag* ShowMessage(impl__WSResult *result)
{
	impl__WSTag *retval = 0;
    if (result) {
        TMessageForm *mfrm = new TMessageForm(Application);
        impl__WSResultMessage *rm = result->messages;
        if (rm && result->__size_ > 0) {
            for (int i=0; i<result->__size_; i++) {
                TListItem *listItem = mfrm->lvMsgs->Items->Add();
                listItem->Caption = rm->messageTitle;
                listItem->SubItems->Add(rm->messageText);
                mfrm->lvMsgs->ItemIndex = 0;
            }
        }

        impl__WSTag *tag = result->options;
        if (tag && result->__size__ > 0) {
            for (int j=0; j<result->__size__; j++) {
                mfrm->ListBox1->Items->AddObject(tag->displayName, (TObject*)tag);
                tag++;
            }
        }
        if (mfrm->ShowModal() == mrOk && mfrm->ListBox1->ItemIndex >= 0) {
            retval = reinterpret_cast<impl__WSTag*>(mfrm->ListBox1->Items->Objects[mfrm->ListBox1->ItemIndex]);
        }
        delete mfrm;
        if (retval) return retval;
    }
    return 0;
}

//---------------------------------------------------------------------------
__fastcall TMessageForm::TMessageForm(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
