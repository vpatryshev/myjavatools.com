////////////////////////////////////////////////////////////////////////////////
// Implementation of CtimercomponentDocument
////////////////////////////////////////////////////////////////////////////////

#include "timercomponentappui.h"
#include "timercomponentdocument.h"


CtimercomponentDocument::CtimercomponentDocument(CEikApplication& aApp)
                       :CAknDocument(aApp)
{
}

CtimercomponentDocument::~CtimercomponentDocument()
{
}

CtimercomponentDocument* CtimercomponentDocument::NewL(CEikApplication& aApp)
{
  CtimercomponentDocument* self = NewLC(aApp);
  CleanupStack::Pop(self);
  return self;
}

CtimercomponentDocument* CtimercomponentDocument::NewLC(CEikApplication& aApp)
{
  CtimercomponentDocument* self = new (ELeave) CtimercomponentDocument(aApp);
  CleanupStack::PushL(self);
  self->ConstructL();
  return self;
}

void CtimercomponentDocument::ConstructL()
{
}

CEikAppUi* CtimercomponentDocument::CreateAppUiL()
{
  return new(ELeave) CtimercomponentAppUi;
}

