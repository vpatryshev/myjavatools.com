////////////////////////////////////////////////////////////////////////////////
// Implementation of CIRSocketApplication
////////////////////////////////////////////////////////////////////////////////

#include "IRSocketapp.h"
#include "IRSocketdocument.h"

const TUid KUidIRSocket = { 0x01000001 };

TUid CIRSocketApplication::AppDllUid() const
{
	return KUidIRSocket;
}

CApaDocument* CIRSocketApplication::CreateDocumentL()
{
	CApaDocument* document = CIRSocketDocument::NewL(*this);
  return document;
}
