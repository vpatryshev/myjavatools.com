//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "compcreateform.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TCompTypeForm *CompTypeForm;
//---------------------------------------------------------------------------
__fastcall TCompTypeForm::TCompTypeForm(TComponent* Owner)
	: TForm(Owner)
{
}


AnsiString GetComponentType(soap *soap, list<impl__WSComponentInfo*> &compInfos)
{
    AnsiString retval("");
	TCompTypeForm *frm = new TCompTypeForm(Application);
    for (list<impl__WSComponentInfo*>::iterator it = compInfos.begin(); it != compInfos.end(); ++it) {
		frm->lbTypes->Items->AddObject((*it)->displayName, (TObject*)(*it));
    }
	if (frm->ShowModal() == mrOk) {
       	impl__WSComponentInfo *ci = reinterpret_cast<impl__WSComponentInfo*>(frm->lbTypes->Items->Objects[frm->lbTypes->ItemIndex]);
		if (ci)
           	return ci->compTypeKey;
    }
    delete frm;
    return retval;
}


//---------------------------------------------------------------------------
void __fastcall TCompTypeForm::lbTypesClick(TObject *Sender)
{
	Button1->Enabled = true;
}
//---------------------------------------------------------------------------

