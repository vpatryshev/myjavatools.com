////////////////////////////////////////////////////////////////////////////////
// Implementation of CmessagetestContainer
////////////////////////////////////////////////////////////////////////////////


#include <aknutils.h>
#include <eiklabel.h>
#include <messagetest.rsg>

#include <barsread.h>
#include <eikappui.h>
#include <eikedwin.h>
#include <txtglobl.h>
#include <coeinput.h>
#include <aknlists.h>
#include <akniconarray.h>
#include <eikclbd.h>
#include <akntitle.h>
#include <aknslider.h>
#include <eikspane.h>
#include <aknnavilabel.h>
#include <eikmfne.h>
#include <aknnumseced.h>
#include <aknipfed.h>
#include <in_sock.h>
#include <eikprogi.h>
#include <AknNumEdwin.h>
#include <eikfpne.h>
#include <aknnumed.h>
#include <aknglobalnote.h>
#include <AknNoteDialog.h>
#include <aknnotewrappers.h>
#include <aknprogressdialog.h>
#include <aknstaticnotedialog.h>
#include <aknquerydialog.h>
#include <uikon.hrh>

#include "messagetestcontainer.h"

CmessagetestContainer* CmessagetestContainer::NewL(const TRect& aRect)
{
  CmessagetestContainer* self = CmessagetestContainer::NewLC(aRect);
  CleanupStack::Pop(self);
  return self;
}

CmessagetestContainer* CmessagetestContainer::NewLC(const TRect& aRect)
{
  CmessagetestContainer* self = new (ELeave) CmessagetestContainer;
  CleanupStack::PushL(self);
  self->ConstructL(aRect);
  return self;
}

CmessagetestContainer::~CmessagetestContainer()
{
  CleanupComponents();
  iCtrlArray.Reset();

  delete iSmsMessageSender;
  delete iMmsMessageSender;
  delete iEmailMessageSender;
  delete iMessageBoxListener;
  delete iMessageServer;

  delete iSmsMessageContent;
}

/**
 * Routine that creates and initializes designed components
 * NOTE: Maintained by CBuilder Designer
 */
void CmessagetestContainer::InitComponents()
{
  /* 2/1/04 11:09 AM */
  /* FIXME CAknView - Missing Property Setter snippet: "In tab group" */
  /* FIXME CAknView - Missing Property Setter snippet: "Tab group" */
  CEikStatusPane * StatusPane = iEikonEnv->AppUiFactory()->StatusPane();
  StatusPane->MakeVisible( ETrue );
  CAknContextPane * cAknContextPane1 =
       ( CAknContextPane * ) iEikonEnv->AppUiFactory()->StatusPane()->ControlL( TUid::Uid( EEikStatusPaneUidContext ) );
  /* FIXME CAknContextPane - Missing Property Setter snippet: "MBM file" */
  /* FIXME CAknContextPane - Missing Property Setter snippet: "Image index" */
  /* FIXME CAknContextPane - Missing Property Setter snippet: "Mask index" */
  CAknTitlePane * cAknTitlePane1 =
       ( CAknTitlePane * ) iEikonEnv->AppUiFactory()->StatusPane()->ControlL( TUid::Uid( EEikStatusPaneUidTitle ) );
  cAknTitlePane1->SetTextL( _L( "Title Pane" ) );
  /* FIXME CAknTitlePane - Missing Property Setter snippet: "MBM file" */
  /* FIXME CAknTitlePane - Missing Property Setter snippet: "Image index" */
  CAknNavigationControlContainer * cAknNavigationControlContainer1 =
       ( CAknNavigationControlContainer * )
       iEikonEnv->AppUiFactory()->StatusPane()->ControlL( TUid::Uid( EEikStatusPaneUidNavi ) );
  /* FIXME CAknNavigationControlContainer - Missing Property Setter snippet: "MBM file" */
  /* FIXME CAknNavigationControlContainer - Missing Property Setter snippet: "Image index" */
  iBackgroundColor = iEikonEnv->Color( EColorControlBackground );
  cEikLabel1 = new( ELeave )CEikLabel;
  cEikLabel1->SetContainerWindowL( * this );
  iCtrlArray.Append( cEikLabel1 );
  cEikLabel1->SetDimmed( EFalse );
  cEikLabel1->SetFocus( ETrue );
  cEikLabel1->SetExtent( TPoint( 5, 33 ), TSize( 166, 41 ) );
  cEikLabel1->SetAlignment( ( TGulAlignmentValue )( EHLeft | EVTop ) );
  cEikLabel1->SetTextL( _L( "" ) );
  cEikLabel1->SetFont( LatinPlain12() );
  cEikLabel1->SetEmphasis( CEikLabel::ENoEmphasis );
  cEikLabel1->SetPixelGapBetweenLines( 1 );
  cEikLabel1->SetUnderlining( EFalse );
  cEikLabel1->SetStrikethrough( EFalse );
  cEikLabel2 = new( ELeave )CEikLabel;
  cEikLabel2->SetContainerWindowL( * this );
  iCtrlArray.Append( cEikLabel2 );
  cEikLabel2->SetDimmed( EFalse );
  cEikLabel2->SetFocus( ETrue );
  cEikLabel2->SetExtent( TPoint( 4, 80 ), TSize( 168, 43 ) );
  cEikLabel2->SetAlignment( ( TGulAlignmentValue )( EHLeft | EVTop ) );
  cEikLabel2->SetTextL( _L( "" ) );
  cEikLabel2->SetFont( LatinPlain12() );
  cEikLabel2->SetEmphasis( CEikLabel::ENoEmphasis );
  cEikLabel2->SetPixelGapBetweenLines( 1 );
  cEikLabel2->SetUnderlining( EFalse );
  cEikLabel2->SetStrikethrough( EFalse );
  TabGroup = CAknTabGroup::NewL( * this );
  /* FIXME CAknTabGroup - Missing Property Setter snippet: "Tab width" */
  /* FIXME CAknTabGroup - Missing Property Setter snippet: "Active tab index" */
  /* FIXME CAknTabGroup - Missing Property Setter snippet: "Tab data" */
}

/**
 * Routine that cleans up designed components
 * NOTE: Maintained by CBuilder Designer
 */
void CmessagetestContainer::CleanupComponents()
{
  /* 2/1/04 11:09 AM */
  delete cEikLabel1;
  delete cEikLabel2;
  delete TabGroup;
  /* Missing cleanupSnippet: MenuBar -- FIXME */
  /* Missing cleanupSnippet: MenuTitle -- FIXME */
  /* Missing cleanupSnippet: MenuPane -- FIXME */
  /* Missing cleanupSnippet: MenuItem -- FIXME */
}

void CmessagetestContainer::ConstructL(const TRect& aRect)
{
	CreateWindowL();
	SetRect(aRect);
	InitComponents();

	iMessageServer = new (ELeave) CMessageServer();

	TEventT<CmessagetestContainer, int> status(this, &CmessagetestContainer::OnStatusChange); 
	iMessageServer->SetOnStatusChange(status);

	iMessageServer->OpenAsyncL();


	iSmsMessageSender = new (ELeave) CSmsMessageSender();
	iMmsMessageSender = new (ELeave) CMmsMessageSender();
	iEmailMessageSender = new (ELeave) CEmailMessageSender();

	iMessageBoxListener = new (ELeave) CMessageBoxListener();
	TEventT<CmessagetestContainer, CBaseMtm *> recv(this, &CmessagetestContainer::OnRecvEvent); 
	iMessageBoxListener->SetOnRecv(recv);

	iSmsMessageContent = new (ELeave) CSmsMessageContent();

	ActivateL();
}

void CmessagetestContainer::Draw(const TRect& aRect) const
{
  CWindowGc& gc = SystemGc();
  gc.SetPenStyle(CGraphicsContext::ENullPen);
  gc.SetBrushColor(iBackgroundColor);
  gc.SetBrushStyle(CGraphicsContext::ESolidBrush);
  gc.DrawRect(aRect);
}

TInt CmessagetestContainer::CountComponentControls() const
{
  return iCtrlArray.Count();
}

CCoeControl* CmessagetestContainer::ComponentControl(TInt aIndex) const
{
  return (CCoeControl*)iCtrlArray[aIndex];
}

TKeyResponse CmessagetestContainer::OfferKeyEventL(const TKeyEvent& aKeyEvent, TEventCode aType)
{
  /**
  * You may place code here to act on the users key event, or pass this to a child control
  * to be handled internally by that control.
  *
  * For example:
  *   return myControl->OfferKeyEventL(aKeyEvent, aType);
  */
  if (DispatchKeyEvents(aKeyEvent, aType))
    return EKeyWasConsumed;
  else
    return EKeyWasNotConsumed;
}

void CmessagetestContainer::HandleControlEventL(CCoeControl * aControl, TCoeEvent aEventType)
{
  DispatchControlEvents(aControl, aEventType);
}

/**
 * The contents of this method is maintained by the CBuilder designer
 * It attemps to dispatch commands to individual handlers
 * NOTE: Maintained by CBuilder Designer
 */
bool CmessagetestContainer::DispatchCommandEvents(TInt aCommand)
{
	switch(aCommand)
	{
	case ESendSMS: SendSMS(); return true;
	case ESendMMS: SendMMS(); return true;
	case ESendEmail: SendEmail(); return true;
	}
  return false;
}

/**
 * Routine that attempts to dispatch Control Events
 * NOTE: Maintained by CBuilder Designer
 */
void CmessagetestContainer::DispatchControlEvents(CCoeControl * aControl, TCoeEvent aEventType)
{
}

/**
 * Routine that attempts to dispatch Key Events
 * NOTE: Maintained by CBuilder Designer
 */
bool CmessagetestContainer::DispatchKeyEvents(const TKeyEvent& aKeyEvent, TEventCode aType)
{
  return false;
}


void CmessagetestContainer::SendSMS()
{
	iSmsMessageContent->SetPhoneNumberL(_L("19253600850"));
	iSmsMessageContent->SetMessageBodyL(_L("Hello World!"));
	iSmsMessageSender->SetMessageContent(iSmsMessageContent);
	iSmsMessageSender->SendL();
}

void CmessagetestContainer::SendMMS()
{
	CMmsMessageContent * temp = new (ELeave) CMmsMessageContent();
	CleanupStack::PushL(temp);
	temp->SetAddrL(_L("ben.adams@cellsoft.com"));
	temp->SetMessageBodyL(_L("Hello World!"));
	iMmsMessageSender->SendMessageL(temp);
	CleanupStack::PopAndDestroy(1);
}

void CmessagetestContainer::SendEmail()
{
	CEmailMessageContent * temp = new (ELeave) CEmailMessageContent();
	CleanupStack::PushL(temp);
	temp->SetAddrL(_L("ben.adams@cellsoft.com"));
	temp->SetSubjectLineL(_L("Hello World!"));
	iEmailMessageSender->SendMessageL(temp);
	CleanupStack::PopAndDestroy(1);
}

void CmessagetestContainer::OnStatusChange(CBase * aMessageServer, int aStatusCode)
{
	TBuf<32> buf;
	buf.Num(aStatusCode);
	CEikonEnv::Static()->InfoWinL(_L("server event, "), buf);
	if(aStatusCode == 1)
	{
		iMessageBoxListener->SetMessageServerL(iMessageServer);
		iSmsMessageSender->SetMessageServerL(iMessageServer);
		iMmsMessageSender->SetMessageServerL(iMessageServer);
	}
}

void CmessagetestContainer::OnRecvEvent(CBase * aRecvHandler, CBaseMtm * aMtm)
{
	TPtrC text( aMtm->Body().Read( 0 ) );
    CEikonEnv::Static()->InfoWinL(_L("Received Message..."), text);
}

