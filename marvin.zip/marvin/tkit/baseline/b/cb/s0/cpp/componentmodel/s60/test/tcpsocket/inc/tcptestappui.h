#ifndef __TCPTEST_APPUI_H__
#define __TCPTEST_APPUI_H__

#include <aknViewAppUi.h>
#include <eikconso.h>


class CtcptestView;


// CtcptestAppUi
class CtcptestAppUi : public CAknViewAppUi
{
public:
    /** Performs second phase construction of this AppUi Object */
    void ConstructL();

    /** Handles user menu selection */
    void HandleCommandL(TInt aCommand);

    /*!
    @function DynInitMenuPaneL

    @discussion Initialise a menu pane before it is displayed
    @param aMenuId id of menu
    @param aMenuPane handle for menu pane
    */
    void DynInitMenuPaneL(TInt aMenuId, CEikMenuPane* aMenuPane);

private:
    CtcptestView *itcptestView;
    CEikConsoleScreen *iConsole;
};


#endif // __TCPTEST_APPUI_H__

