#ifndef __APPUI_H__
#define __APPUI_H__

#include <aknViewAppUi.h>


// CtimercomponentAppUi
class CAppUi : public CAknViewAppUi
{
public:
  /**
   * Performs second phase construction of this AppUi Object
   */
  void ConstructL();

  /**
   * Handles user menu selection
   */
  void HandleCommandL(TInt aCommand);

private:
};


#endif // __APPUI_H__

