////////////////////////////////////////////////////////////////////////////////
// Implementation of CtcptestApplication
////////////////////////////////////////////////////////////////////////////////

#include "tcptestapp.h"
#include "tcptestdocument.h"

const TUid KUidtcptest = { 0x01000001 };

TUid CtcptestApplication::AppDllUid() const
{
	return KUidtcptest;
}

CApaDocument* CtcptestApplication::CreateDocumentL()
{
	CApaDocument* document = CtcptestDocument::NewL(*this);
  return document;
}
