#ifndef wxweventH
#define wxweventH

#include "wxw.h"
#include "wxwproperty.h"

class RCMEXPORT xtiEvent : public xtiProperty
{
DECLARE_DYNAMIC_CLASS(xtiEvent)
public:
    xtiEvent() : xtiProperty()
    {
        FFlags = PE_NOEDIT | PE_DYNAMICVALUELIST;
    }

    const wxDelegateTypeInfo* GetDelegateTypeInfo();
    virtual wxString Signature();

protected:
    virtual wxString Get() const;
    virtual void Set(const wxString &value);
};

#endif
