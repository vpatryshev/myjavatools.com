//---------------------------------------------------------------------------

#pragma hdrstop

#include "sharedmem.h"
#include "stdsoap2.h"
#include <algorithm>
#include <assert.h>

static const char *SHMEM_SUFFIX = "_SharedMem";
static const char *MUTEX_SUFFIX = "_Free";
static const char *EVENT_SUFFIX_IMAGEDONE = "_ImageDone";
static const char *EVENT_SUFFIX_IMAGEREQUEST = "_ImageRequest";
static const char *EVENT_SUFFIX_SOAPDONE = "_SoapDone";
static const char *EVENT_SUFFIX_SOAPREQUEST = "_SoapRequest";

// TSharedMem

#ifdef __WIN32__

TSharedMem::TSharedMem(const char *name, unsigned int size, bool create)
{
    hImageRequest =
    hImageDone =
    hSoapRequest =
    hSoapDone =
    hFree =
    hMap =
    pMem = 0;
    iSize = size;
    locked = false;

    sName = (char*)malloc(strlen(name) + strlen(SHMEM_SUFFIX) + 1);
    sName = strcat(strcpy(sName, name), SHMEM_SUFFIX);

    char *sMutexName = (char*)malloc(strlen(name) + strlen(MUTEX_SUFFIX) + 1);
    strcat(strcpy(sMutexName, name), MUTEX_SUFFIX);

    if (create) {
      hMap = CreateFileMapping(
          (HANDLE)0xFFFFFFFF,
          NULL,
          PAGE_READWRITE,
          0,
          size,
          sName);
    }
    if (!create || (GetLastError() == ERROR_ALREADY_EXISTS)) {
        hMap = OpenFileMapping(
            FILE_MAP_WRITE,
            FALSE,
            sName);
    }

    hFree = CreateMutex(
        NULL,
        FALSE,
        sMutexName);

    // Obtain a pointer from the handle to file mapping object
    pMem = MapViewOfFile(
        hMap,
        FILE_MAP_WRITE,
        0,
        0,
        size);

    // Failed to allocate or find shared memory. No use continuing.
    assert(pMem);

    char *sImageDoneEventName = (char*)malloc(strlen(name) + strlen(EVENT_SUFFIX_IMAGEDONE) + 1);
    strcat(strcpy(sImageDoneEventName, name), EVENT_SUFFIX_IMAGEDONE);
    char *sImageRequestEventName = (char*)malloc(strlen(name) + strlen(EVENT_SUFFIX_IMAGEREQUEST) + 1);
    strcat(strcpy(sImageRequestEventName, name), EVENT_SUFFIX_IMAGEREQUEST);
    char *sSoapRequestEventName = (char*)malloc(strlen(name) + strlen(EVENT_SUFFIX_SOAPREQUEST) + 1);
    strcat(strcpy(sSoapRequestEventName, name), EVENT_SUFFIX_SOAPREQUEST);
    char *sSoapDoneEventName = (char*)malloc(strlen(name) + strlen(EVENT_SUFFIX_SOAPDONE) + 1);
    strcat(strcpy(sSoapDoneEventName, name), EVENT_SUFFIX_SOAPDONE);

    // Create events for communication with the server
    hImageRequest = CreateEvent(
        NULL,
        true,
        false,
        sImageRequestEventName);

    hImageDone = CreateEvent(
        NULL,
        true,
        false,
        sImageDoneEventName);

    hSoapRequest = CreateEvent(
        NULL,
        true,
        false,
        sSoapRequestEventName);

    hSoapDone = CreateEvent(
        NULL,
        true,
        false,
        sSoapDoneEventName);

    free(sMutexName);
    free(sImageDoneEventName);
    free(sImageRequestEventName);
    free(sSoapDoneEventName);
    free(sSoapRequestEventName);
}

TSharedMem::~TSharedMem()
{
    CloseHandle(hImageRequest);
    CloseHandle(hImageDone);
    CloseHandle(hSoapRequest);
    CloseHandle(hSoapDone);
    CloseHandle(hFree);

    UnmapViewOfFile(pMem);
    CloseHandle(hMap);
    free(sName);
};

bool TSharedMem::Lock()
{
    // Wait for mutex. Once it is obtained, no other client may
    // communicate with the server
    if (!locked) {
        locked = WaitForSingleObject(hFree, timeOut) == WAIT_OBJECT_0;
    }
    return locked;
}

void TSharedMem::Unlock()
{
    // Release mutex for others to send messages
    if (locked) {
        locked = !ReleaseMutex(hFree);
    }
}

// TTransportServer

TTransportServer::TTransportServer(const char *name, unsigned int size)
    : TSharedMem(name, size, true)
{
    SetTimeout(50);
    // initialize first byte to 0 (no request pending)
    *((char*)pMem) = 0;
}

bool TTransportServer::GetImageData(char *uri, ImageResponse *ir)
{
    return false;
}

bool TTransportServer::GetImageData(char *managerKey, char *designerKey,
    char *compInstanceKey, int x, int y, int w, int h, ImageResponse *ir)
{
    return false;
}

bool TTransportServer::ServeSoapRequest(char *request, size_t len, SoapData *response)
{
    return false;
}

bool TTransportServer::CheckForSoapRequest()
{
    bool served = false;
    bool signalled = WaitForSingleObject(hSoapRequest, GetTimeout()) == WAIT_OBJECT_0;
    if (signalled) {
        if (Lock()) {
            SoapData *data = (SoapData*)pMem;
            int len = data->size;
            char *request = (char*)malloc(len + 1);
            strncpy(request, data->data, len);
            served = ServeSoapRequest(request, len, data);
            free(request);
            Unlock();
            // notify the client data is ready.
            ::ResetEvent(hSoapRequest);
            ::SetEvent(hSoapDone);
        }
    }
    return served;
}

bool TTransportServer::CheckForImageRequest()
{
    bool served = false;
    bool signalled = WaitForSingleObject(hImageRequest, GetTimeout()) == WAIT_OBJECT_0;
    if (signalled && Lock()) {
        ::ResetEvent(hImageRequest);
        // Client signalled that data in shared memory is ready
        // Handle data
        int key = ((Request*)pMem)->key;
        if (key == MODEL_IMAGE || key == COMP_IMAGE) {
            char modelKey[MAX_KEYSIZE];
            strcpy(modelKey, ((TImageRequest*)pMem)->modelKey);
            // don't write to this until request is copied.
            switch (key) {
                case MODEL_IMAGE:
                {
                    char uri[MAX_PATH];
                    strcpy(uri, ((TImageRequest*)pMem)->uri);
                    ImageResponse *response = (ImageResponse*)pMem;
                    // set up response in shared mem region.
                    FillMemory(response->mimeType, sizeof(response->mimeType), 0);
                    served = GetImageData(uri, response);
                    break;
                }
                case COMP_IMAGE: {
                    char managerKey[MAX_KEYSIZE];
                    char designerKey[MAX_KEYSIZE];
                    char compInstanceKey[MAX_KEYSIZE];
                    strcpy(managerKey, ((TImageRequest*)pMem)->managerKey);
                    strcpy(designerKey, ((TImageRequest*)pMem)->designerKey);
                    strcpy(compInstanceKey, ((TImageRequest*)pMem)->compInstanceKey);
                    int x, y, w, h;
                    x = ((TImageRequest*)pMem)->x;
                    y = ((TImageRequest*)pMem)->y;
                    w = ((TImageRequest*)pMem)->w;
                    h = ((TImageRequest*)pMem)->h;
    #ifdef BMP_IMAGES
                    ByteSwap(x);
                    ByteSwap(y);
                    ByteSwap(w);
                    ByteSwap(h);
    #endif
                    // set up response
                    ImageResponse *response = (ImageResponse*)pMem;
                    FillMemory(response->mimeType, sizeof(response->mimeType), 0);
                    served = GetImageData(managerKey, designerKey, compInstanceKey,
                        x, y, w, h, response);
                    break;
                }
                default:
                    FillMemory(pMem, sizeof(int), 0);
            }

        }
        Unlock();
        if (served) {
           // Inform client that server is done
            ::SetEvent(hImageDone);
        }
    }
    return signalled && served;
}

// TTransportClient

TTransportClient::TTransportClient(const char *name, unsigned int size)
    : TSharedMem(name, size, false)
{
    SetTimeout(INFINITE); // wag
}

TTransportClient::~TTransportClient()
{
}

bool TTransportClient::GetImageData()
{
    bool served = false;
    // manually reset the completion event
    ::ResetEvent(hImageDone);
    Unlock();
    // Signal server to process this request
    ::SetEvent(hImageRequest);
    // Wait timeout milliseconds for a response.
    if (::WaitForSingleObject(hImageDone, GetTimeout()) == WAIT_OBJECT_0) {
        ImageResponse *ir = (ImageResponse*)pMem;
        served = ir->size > 0 && ir->mimeType[0] != 0;
    }
    ::ResetEvent(hImageDone);
    return served;
}


bool TTransportClient::RequestModelImage(char *modelKey, char *uri, ImageResponse *&ir)
{
    bool served = false;
    if (Lock()) {
        // Fill shared memory
        ((Request*)pMem)->key = MODEL_IMAGE;
        TImageRequest *request = (TImageRequest*)pMem;
        strcpy(request->modelKey, modelKey);
        strcpy(request->uri, uri);

        served = GetImageData();
    }
    return served;
}

bool TTransportClient::RequestCompImage(char *modelKey, char *managerKey, char *designerKey,
        char *compInstanceKey, int x, int y, int w, int h, ImageResponse *&ir)
{
    bool served = false;
    if (Lock()) {
        // Fill shared memory
        ((Request*)pMem)->key = COMP_IMAGE;
        TImageRequest *request = (TImageRequest*)pMem;
        strcpy(request->modelKey, modelKey);
        strcpy(request->managerKey, managerKey);
        strcpy(request->designerKey, designerKey);
        strcpy(request->compInstanceKey, compInstanceKey);
        request->x = x;
        request->y = y;
        request->w = w;
        request->h = h;

        served = GetImageData();
        ir = (ImageResponse*)pMem;
    }
    return served;
}

#endif


