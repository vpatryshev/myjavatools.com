#ifndef __IRSOCKET_CONTAINER_H__
#define __IRSOCKET_CONTAINER_H__


#include "IRSocket.hrh"

#include <coecntrl.h>
#include <txtfmlyr.h>
#include <aknview.h>
#include <akncontext.h>
#include <akntitle.h>
#include <aknnavi.h>
#include <akntabgrp.h>
#include <aknnavide.h>
#include <eiklbo.h>

#include <irdasocket.h>

class CEikEdwin;
class CEikGlobalTextEditor;
class CEikLabel;
class CAknSlider;
class CEikColumnListBox;
class CAknSingleStyleListBox;
class CEikTimeEditor;
class CAknNumericSecretEditor;
class CAknIpFieldEditor;
class CEikTimeAndDateEditor;
class CEikRangeEditor;
class CEikProgressInfo;
class CEikDateEditor;
class CEikDurationEditor;
class CAknNumericEdwin;
class CAknIntegerEdwin;
class CEikFloatingPointEditor;
class CEikFixedPointEditor;
class CAknGlobalNote;
class CAknConfirmationNote;
class CAknInformationNote;
class CAknErrorNote;
class CAknWarningNote;
class CAknProgressDialog;
class CAknStaticNoteDialog;


// CIRSocketContainer
class CIRSocketContainer : public CCoeControl, public MCoeControlObserver {

  RPointerArray<CCoeControl> iCtrlArray;
  TRgb iBackgroundColor;

public :
  /**
   * Creates a CIRSocketContainer object
   */
  static CIRSocketContainer * NewL(const TRect& aRect);

  /**
   * Creates a CIRSocketView object
   */
  static CIRSocketContainer * NewLC(const TRect& aRect);


  /**
   * Performs second pahese construction of this Container
   */
  void ConstructL(const TRect & aRect);

  /**
   * Returns the number of controls contained in this compound control
   */
  TInt CountComponentControls()const;

  /**
   * Returns the component at the specified index
   * @param aIndex specifies index of component
   * @return Pointer to component control
   */
  CCoeControl * ComponentControl(TInt aIndex)const;

  /**
   * Draws this container
   */
  void Draw(const TRect& aRect) const;

  /**
   * Destroys container
   */
  ~CIRSocketContainer();

  /**
   * Handler for events sent by a control to this Observer
   */
  void HandleControlEventL(CCoeControl * aControl, TCoeEvent aEventType);

/**
 * Overridden function used to pass key events to child controls owned by this container
 */
  TKeyResponse OfferKeyEventL(const TKeyEvent& aKeyEvent, TEventCode aType);

  /**
   * Routine that dispatches Command events to individual handlers
   */
  bool DispatchCommandEvents(TInt aCommand);

private:
  /**
   * Routine that initializes components owned by this Container
   */
  void InitComponents();

  /**
   * Routine that cleans up components owned by this container
   */
  void CleanupComponents();

  /**
   * Routine that attempts to dispatch Control Events
   */
  void DispatchControlEvents(CCoeControl * aControl, TCoeEvent aEventType);

  /**
   * Routine that attempts to dispatch Key Events
   */
  bool DispatchKeyEvents(const TKeyEvent& aKeyEvent, TEventCode aType);

private:
    enum TQueryType {
        qtQueryPort,
        qtQueryName
    };

    void DoQueryName();
    void HandleNameQuery(TIASResponse &response);
    void DoQueryPort();
    void HandlePortQuery(TIASResponse &response);

    // EventHandlers
    void SocketStateChange(CBase *sender, TInt state);
    void SocketConnected(CBase *sender);
    void SocketRecvComplete(CBase *sender, TInt state, const TDesC8 &data);
    void SocketWriteComplete(CBase *sender, TInt state);
    void SocketDiscovery(CBase *sender, TNameRecord &nameRecord);
    void SocketError(CBase *sender, TInt errorCode);
    void SocketIASQueryDone(CBase *sender, TIASResponse &response);

    TBuf16<16384> dispBuf;
    TBuf16<KSocketDefaultBufferSize> recvBuf;
    TBuf8<KSocketDefaultBufferSize> sendBuf;
    TBuf16<0x20> remoteDeviceName;
    TQueryType iQueryType;

  //IDE-MANAGED-START
    /* 1/31/04 5:22 PM */
    CEikEdwin * cEikEdwin1;
    CIrdaSocket * iIrdaSock;
  //IDE-MANAGED-END

};

#endif // __IRSOCKET_CONTAINER_H__
