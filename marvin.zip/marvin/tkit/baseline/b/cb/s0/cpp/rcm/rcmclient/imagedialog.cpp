//---------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include <assert.h>
#include "imagedialog.h"

//---------------------------------------------------------------------
#pragma resource "*.dfm"
TImageDlg *ImageDlg;

void DrawDesignRects(impl__WSLiveUIComponent *c, Graphics::TBitmap *b)
{
    if (!c || !(c->designRects)) return;
    b->Canvas->Pen->Color = clFuchsia;
    b->Canvas->Brush->Style = bsClear;
    impl__WSUIDesignRect *dr;
    int mid = b->Height / 2;
    dr = c->designRects;
    for (int i=0; i<c->__size_; i++) {
        impl__WSRect *r = dr->rect;
        int bottom = r->y + (2 * (mid - r->y));
        int top = (r->y + r->height) + (2 * (mid - (r->y + r->height)));
        b->Canvas->Rectangle(r->x, top, r->x + r->width, bottom);
        dr++;
    }
}


//---------------------------------------------------------------------
__fastcall TImageDlg::TImageDlg(TComponent* AOwner)
	: TForm(AOwner)
{
}
//---------------------------------------------------------------------
