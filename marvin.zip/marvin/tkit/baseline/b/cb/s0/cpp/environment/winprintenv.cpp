//
// winprintenv.cpp
//
#define UNICODE
#include <stdio.h>
#include <string.h>
#include <windows.h>

LPCSTR ucs2_to_utf8(LPCWSTR wstr, int wlen, LPSTR str, int len) {
   LPCSTR ostr = str;

   if (str == NULL && len == 0) {
      if ((len = WideCharToMultiByte(CP_UTF8, (DWORD) 0, wstr, wlen, str, len, NULL, NULL)) == 0) {
	 return NULL;
      }
      if ((str = (LPSTR) HeapAlloc(GetProcessHeap(), 0, len)) == NULL) {
	 return NULL;
      }
   }
   if ((len = WideCharToMultiByte(CP_UTF8, (DWORD) 0, wstr, wlen, str, len, NULL, NULL)) == 0) {
      if (str != ostr) {
	 HeapFree(GetProcessHeap(), 0, str);
      }
      return NULL;
   }
   return str;
}

#pragma argsused
int main(int argc, char *argv[])
{
   LPSTR str = NULL;
   LPTSTR lpszEnv;
   LPVOID lpvEnv;
   int size = (1 << 8);

   try {
      if ((lpvEnv = GetEnvironmentStrings()) == NULL) {
	 return 1;
      }
      if ((str = (LPSTR) HeapAlloc(GetProcessHeap(), 0, size)) == NULL) {
	 return 1;
      }
      for (lpszEnv = (LPTSTR) lpvEnv; *lpszEnv; ++lpszEnv) {
	 int wlen = wcslen(lpszEnv);
	 int len = wlen * 4 + 1;

	 if (size < len) {
	    if (str != NULL) {
	       HeapFree(GetProcessHeap(), 0, str);
	    }
	    do {
	       size <<= 1;
	    } while (size < len);
	    if ((str = (LPSTR) HeapAlloc(GetProcessHeap(), 0, size)) == NULL) {
	       return 1;
	    }
	 }
	 if (ucs2_to_utf8(lpszEnv, -1, str, len) == NULL) {
	    return 1;
	 }
	 printf("%s\n", str);
	 lpszEnv += wlen;
      }
   } __finally {
      if (lpvEnv != NULL) {
	 FreeEnvironmentStrings((LPTSTR) lpvEnv);
      }
      if (str != NULL) {
	 HeapFree(GetProcessHeap(), 0, str);
      }
   }
   return 0;
}
