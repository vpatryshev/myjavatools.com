//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "StringsRes.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TStringsResContainer *StringsResContainer;
//---------------------------------------------------------------------------
__fastcall TStringsResContainer::TStringsResContainer(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
