#include "TimerEngineContainer.h"

CTimerEngineContainer::CTimerEngineContainer(void)
{

}

CTimerEngineContainer::~CTimerEngineContainer(void)
{
  CleanComponents();
}

void CTimerEngineContainer::ConstructL(void)
{
  InitializeComponentsL();
}

void CTimerEngineContainer::InitializeComponentsL(void)
{
  iTimerWrapper = new (ELeave) CTimeOutTimer<CTimer>(0);
  iTimerWrapper->ConstructL();
  iTimerWrapper->SetOnTimer(TEventT<CTimerEngineContainer, int>(this, &CTimerEngineContainer::OnTimerEvent));
  iTimerWrapper->After(100000);


  iHeartbeat = new (ELeave) CBeatingHeartbeat<MBeating>();
  iHeartbeat->ConstructL(0);

}

void CTimerEngineContainer::CleanComponents(void)
{
  delete iTimerWrapper;
}

void CTimerEngineContainer::OnTimerEvent(CBase * aTimer, int aErrorCode)
{
  int a = 0;
}



