//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
USEFORM("rcmclientu.cpp", Form1);
USEFORM("messagedialog.cpp", MessageForm);
USEFORM("compcreateform.cpp", CompTypeForm);
USEFORM("sizedialog.cpp", PSDlg);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
	try
	{
		Application->Initialize();
		Application->CreateForm(__classid(TForm1), &Form1);
         Application->CreateForm(__classid(TMessageForm), &MessageForm);
         Application->CreateForm(__classid(TCompTypeForm), &CompTypeForm);
         Application->CreateForm(__classid(TPSDlg), &PSDlg);
         Application->Run();
	}
	catch (Exception &exception)
	{
		Application->ShowException(&exception);
	}
	catch (...)
	{
		try
		{
			throw Exception("");
		}
		catch (Exception &exception)
		{
			Application->ShowException(&exception);
		}
	}
	return 0;
}
//---------------------------------------------------------------------------
