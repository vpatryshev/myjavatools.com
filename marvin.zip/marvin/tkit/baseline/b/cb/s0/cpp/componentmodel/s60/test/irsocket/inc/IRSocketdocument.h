#ifndef __IRSOCKET_DOCUMENT_H__
#define __IRSOCKET_DOCUMENT_H__

#include <akndoc.h>

// Forward references
class IRSocketAppUi;
class CEikApplication;

// CIRSocketDocument
class CIRSocketDocument : public CAknDocument
{
public:
  /**
   * Constructs CIRSocketDocument for the AVKON application aApp
   * using two phase construction, and return a pointer to the created
   * object
   * @param aApp application creating this document
   * @result a pointer to the created instance of CIRSocketDocument
   */
  static CIRSocketDocument* NewL(CEikApplication& aApp);

  /**
   * Constructs CIRSocketDocument for the AVKON application aApp
   * using two phase construction, and return a pointer to the created
   * object
   * @param aApp application creating this document
   * @result a pointer to the created instance of CIRSocketDocument
   */
  static CIRSocketDocument* NewLC(CEikApplication& aApp);

  /**
   * Destroys this document object and releases all memory
   */
  ~CIRSocketDocument();

  /**
   * Creates a CIRSocketAppUi object and return a pointer to it
   * @result a pointer to the created instance of the AppUi created
   */
  CEikAppUi* CreateAppUiL();

private:
  /**
   * Performs second phase construction for this CIRSocketDocument object
   */
  void ConstructL();

  /**
   * Private constructor
   */
  CIRSocketDocument(CEikApplication& aApp);
};

#endif // __IRSOCKET_DOCUMENT_H__
