#ifdef __BORLANDC__
#include "rcmpch.h"
#endif

#include "wxwcomponentinfo.h"
#include "wxwcomponent.h"
#include "wxwdesigner.h"
#include "wxwevent.h"
#include "wxwproped.h"

wxwComponentInfo::wxwComponentInfo(const wxClassInfo *classInfo, const wxString &desc)
{
	FClassInfo = classInfo;
    FName = classInfo->GetClassName();
    FKey = FName;
    FDesc = desc;
    FPage = 0;
}

wxString wxwComponentInfo::Filename()
{
   return ClassInfo()->GetIncludeName();
}

wxString wxwComponentInfo::PaletteIconURI()
{
    return wxString::Format("%s.gif", FName);
}

wxString wxwComponentInfo::IconURI()
{
    return wxString::Format("%s_small.gif", FName);
}


rcmMethod* wxwComponentInfo::GetMethod(wxArrayString &path, rcmComponent *component)
{
    return 0;
}

void wxwComponentInfo::GetMethods(rcmMethods &methods, rcmComponent *component)
{
    return;
}

// TODO: Issue: component = null might return the wrong property editor.
void wxwComponentInfo::InternalGetProperties(rcmProperties &props, const wxClassInfo *classInfo,
    wxwComponent *component)
{
	// this returns on only "top-level" properties - on the wxClassInfo itself.
    const wxPropertyInfo *pi = classInfo->GetFirstProperty();
	while( pi )
	{
    	// wxT_DELEGATE properties ("events") are treated separately
    	if (!pi->GetTypeInfo()->IsDelegateType()) {
            const wxClassInfo *peClass = GetPropertyEditorClass(pi, component ? component->Instance() : 0);
            if (peClass) {
                xtiProperty *pe = dynamic_cast<xtiProperty*>(peClass->CreateObject());
                if (component)
	                pe->Create(pi, component->wxDesigner(), component ? component->Instance() : 0);
                else
	                pe->Create(pi);
                props.push_back(pe);
            }
        }
		pi = pi->GetNext() ;
	}
    const wxClassInfo **parents = classInfo->GetParents();
    int i = 0;
    while (parents[i]) {
        InternalGetProperties(props, parents[i], component);
        i++;
    }
}

void wxwComponentInfo::GetProperties(rcmProperties &props, rcmComponent *component)
{
    InternalGetProperties(props, FClassInfo, dynamic_cast<wxwComponent*>(component));
}

rcmProperty* wxwComponentInfo::GetProperty(wxArrayString &path, rcmComponent *component)
{
	// Create "root" property, drilling into it if necessary to find either static
    // property or create a dynamic instance.
    rcmProperty *p = 0;
    if (path.Count() > 0) {
    	// always dynamically create "top-level" property belonging to the component
        const wxPropertyInfo *pi = FClassInfo->FindPropertyInfo(path[0]);
        if (pi) {
            const wxClassInfo *peClass = GetPropertyEditorClass(pi, component ? component->Instance() : 0);
            if (peClass) {
                xtiProperty *pe = 0;
                pe = dynamic_cast<xtiProperty*>(peClass->CreateObject());
                if (component) {
                    pe->Create(pi, dynamic_cast<wxwDesigner*>(component->Designer()), component ? component->Instance() : 0);
                }
                else
                    pe->Create(pi);
                p = pe;
            }
            else
                return 0;
            // if key path indicates a nested property, call the newly created property
            // editor object to get a sub-property of the given name.
            // instance needs to be of the object the subproperties will act on, e.g.,
            // Component.Font.Size property created with Component.Font as instance.
            unsigned int i = 1;
            while (p && i < path.Count()) {
                p = p->GetChildProperty(path[i]);
                i++;
            }
        }
    }
    return p;
}

rcmEvent* wxwComponentInfo::GetEvent(wxArrayString &path, rcmComponent *component)
{
	wxASSERT_MSG(path.Count() == 1, wxString::Format("Invalid KeyPath: ", StringArrayToString(path)));
    xtiEvent *ee = 0;
	const wxPropertyInfo *pi = FClassInfo->FindPropertyInfo(path[0]);
    if (pi) {
        const wxClassInfo *eeClass = GetPropertyEditorClass(pi, component ? component->Instance() : 0);
        if (eeClass) {
            ee = dynamic_cast<xtiEvent*>(eeClass->CreateObject());
            ee->Create(pi, dynamic_cast<wxwDesigner*>(component->Designer()), component ? component->Instance() : 0);
        }
    }
    return ee;
}

void wxwComponentInfo::InternalGetEvents(rcmEvents &events, const wxClassInfo *classInfo,
    wxwComponent *component)
{
    const wxPropertyInfo *pi = classInfo->GetFirstProperty();
	while( pi )
	{
    	if (pi->GetTypeInfo()->IsDelegateType()) {
            const wxClassInfo *eeClass = GetPropertyEditorClass(pi, component ? component->Instance() : 0);
            if (eeClass) {
                xtiEvent *ee = dynamic_cast<xtiEvent*>(eeClass->CreateObject());
                if (ee) {
                    if (component)
                        ee->Create(pi, component->wxDesigner(), component ? component->Instance() : 0);
                    else
                        ee->Create(pi);
                    events.push_back(ee);
                }
            }
        }
		pi = pi->GetNext();
	}
    const wxClassInfo **parents = classInfo->GetParents();
    int i = 0;
    while (parents[i]) {
        InternalGetEvents(events, parents[i], component);
        i++;
    }
}

void wxwComponentInfo::GetEvents(rcmEvents &events, rcmComponent *component)
{
	InternalGetEvents(events, FClassInfo, dynamic_cast<wxwComponent*>(component));
}

void wxwComponentInfo::SetPalettePage(rcmPalettePage *page)
{
    if (page) {
        FPage = page;
    }
}

void wxwComponentInfo::SetDefaultEvent(const wxString &eventName)
{
    FDefaultEventName = eventName;
}

wxString wxwComponentInfo::DefaultEventKey()
{
    if (FDefaultEventName.IsEmpty()) {
        const wxPropertyInfo *eventInfo = GetFirstEvent(FClassInfo);
        if (eventInfo) {
            FDefaultEventName = eventInfo->GetName();
        }
    }
    return FDefaultEventName;
}

const wxPropertyInfo* wxwComponentInfo::GetFirstEvent(const wxClassInfo *classInfo)
{
    const wxPropertyInfo *pi = classInfo->GetFirstProperty();
	while( pi )
	{
    	if (pi->GetTypeInfo()->IsDelegateType()) {
            return pi;
        }
		pi = pi->GetNext();
	}
    const wxClassInfo **parents = classInfo->GetParents();
    int i = 0;
    while (parents[i]) {
        pi = GetFirstEvent(parents[i]);
        if (pi) {
            return pi;
        }
        i++;
    }
    return 0;
}


