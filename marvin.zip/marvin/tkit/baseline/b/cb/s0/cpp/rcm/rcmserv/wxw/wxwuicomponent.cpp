#ifdef __BORLANDC__
#include "rcmpch.h"
#endif

#include "wxwuicomponent.h"
#include "wxwcontainer.h"
#include "wxwuicontainer.h"
#include "wxwgraphics.h"

// wxwUIComponent

string_type wxwUIComponent::GetImageData(int x, int y, int w, int h, output_stream_type *&stream)
{
    return "wxwUIComponent::GetImageData(stream) not implemented";
}

#ifdef __WINDOWS__

void wxwUIComponent::PaintChild(wxwUIComponent *child, wxDC &dc, int x, int y)
{
    child->Paint(dc, x, y);
}

void wxwUIComponent::Paint(wxDC &dc, int x, int y)
{
	HDC hdc = (HDC)dc.GetHDC();
    int saveIdx = SaveDC(hdc);
    MoveWindowOrg(hdc, x, y);
    int cx, cy, cw, ch;
    GetRect(cx, cy, cw, ch);
    IntersectClipRect(hdc, 0, 0, cw, ch);

    // Paint this object first
    wxPainter *painter = FindPainter(Instance()->GetClassInfo());
    if (painter)
        painter->PaintObject(Instance(), dc);

    // now paint its child components, if it can.
    wxwContainer *contnr = dynamic_cast<wxwContainer*>(this);
    if (contnr && CanPaintChildren()) {
        rcmComponents &list = contnr->Components();
        rcmComponents::reverse_iterator it = list.rbegin();
        GetClientRect(cx, cy, cw, ch);
        while (it != list.rend()) {
            wxwUIComponent *child = dynamic_cast<wxwUIComponent*>(*it);
            if (child) {
                int t, l;
                child->GetTopLeft(t, l);
                PaintChild(child, dc, l+cx, t+cy);
            }
            it++;
        }
    }
    RestoreDC(hdc, saveIdx);
}

void wxwUIComponent::GetImageData(int x, int y, int w, int h, ImageResponse *ir)
{
#ifndef _DEBUG
    assert(0); // this method should never be called in production code.
#else
    void *bits = 0;
    int myw, myh;
    GetSize(myw, myh);
    HBITMAP hbAll = CreateDIB(myw, myh, bits);
    if (hbAll && bits) {
        HDC memDC = CreateCompatibleDC(0);
        if (memDC) {
	        wxDC dc;
            dc.SetHDC((unsigned long)memDC);
            HGDIOBJ oldObj = SelectObject(memDC, hbAll);

            Paint(dc, 0, 0);

            if (w < myw || h < myh) {
                void *partialBits = 0;
                HBITMAP hbPartial = CreateDIB(w, h, partialBits);
                if (hbPartial && partialBits) {
                    HDC partialDC = CreateCompatibleDC(0);
                    if (partialDC) {
                        HGDIOBJ oldObj2 = SelectObject(partialDC, hbPartial);
                        if (BitBlt(partialDC, 0, 0, w, h, memDC, x, y, SRCCOPY)) {
                            strncpy(ir->mimeType, mtRaw32, min(strlen(mtRaw32), sizeof(ir->mimeType)));
                            ir->scanWidth = w;
                            ir->size = w * h * sizeof(int);
                            memcpy(ir->data, partialBits, min(ir->size, MAX_DATASIZE));
                        }
                        SelectObject(partialDC, oldObj2);
                    }
                    DeleteDC(partialDC);
                }
                DeleteObject(hbPartial);
            }
            else {
                strncpy(ir->mimeType, mtRaw32, min(strlen(mtRaw32), sizeof(ir->mimeType)));
                ir->scanWidth = w;
                ir->size = min(w * h * sizeof(int), MAX_DATASIZE);
                memcpy(ir->data, bits, min(ir->size, MAX_DATASIZE));
            }
            SelectObject(memDC, oldObj);
            DeleteDC(memDC);
        }
        DeleteObject(hbAll);
    }
#endif
}

#endif // __WINDOWS__

void wxwUIComponent::GetClientRect(int &x, int &y, int &w, int &h)
{
    GetRect(x, y, w, h);
}
    
void wxwUIComponent::GetSize(int &w, int &h)
{
    int x, y;
    GetRect(x, y, w, h);
}

void wxwUIComponent::GetTopLeft(int &t, int &l)
{
    int w, h;
    GetRect(l, t, w, h);
}

int wxwUIComponent::GetZOrderPosition()
{
    //TODO: Implement this for wxWindows, which doesn't keep z-order in any child window list like vcl.
    return 0;
}

Result* wxwUIComponent::SetZOrderPosition(rcmComponent *child, int z)
{
    return ErrorMessage("wxWindows doesn't appear to support explicit Z-ordering");
}

Result* wxwUIComponent::SetParent(rcmContainer *newContainer)
{
    return ErrorMessage(wxT("Not implemented"));
}

void wxwUIComponent::SetSize(int &w, int &h)
{
    int dummy = -1;
    SetRect(dummy, dummy, w, h);
    GetRect(dummy, dummy, w, h);
}

void wxwUIComponent::SetTopLeft(int &t, int &l)
{
    int dummy = -1;
    SetRect(t, l, dummy, dummy);
    GetRect(t, l, dummy, dummy);
}

void wxwUIComponent::GetRect(int &x, int &y, int &w, int &h)
{
    DoGetRect(x, y, w, h);
}

void wxwUIComponent::SetRect(int &x, int &y, int &w, int &h, bool testOnly)
{
    wxwUIContainer *container = dynamic_cast<wxwUIContainer*>(Container());
    bool resizeOk = true;
    if (container) {
        resizeOk = container->NotifyChildBoundsChanging(x, y, w, h, this);
    }
    if (resizeOk) {
        DoSetRect(x, y, w, h, testOnly);
        if (container) {
            container->NotifyChildBoundsChanged(this);
        }
    }
    GetRect(x, y, w, h);
}
