#ifdef __BORLANDC__
#include "rcmpch.h"
#endif

#include "wxwsizer.h"
#include "wxwproperty.h"
#include "wxwdesigner.h"

// wxArrayInt helpers
bool ArrayIntHasValue(const wxArrayInt &array, int value)
{
    for (unsigned int i=0; i<array.Count(); i++) {
        if (array[i] == value)
            return true;
    }
    return false;
}

class wxSizerItemProperty : public wxPropertyBase
{
public:
	wxSizerItemProperty(wxGBSizerItem *item, wxGBSizerProxy *sizer, wxwDesigner *designer)
        : wxPropertyBase()
    {
        Init(designer, item, 0, "SizerItem");
        FSizer = sizer;
        FFlags = PE_READONLY;
        FItem = item;
        if (FItem) {
            FFlags |= PE_SUBPROPS;
        }
    }

	virtual void ChildChanged(wxPropertyBase *child)
    {
        if (FSizer)
            FSizer->ForceLayout();
    }

	virtual void GetChildren(rcmProperties &subProps)
    {
        if (FItem)
            RecurseObjectProperties(subProps, this, FItem->GetClassInfo(), FItem, wxDesigner());
    }

	virtual rcmProperty* GetChildProperty(const wxString &propName)
    {
        xtiProperty *result = 0;
        const wxPropertyInfo *pi = 0;
        if (FItem) {
            pi = FItem->GetClassInfo()->FindPropertyInfo(propName);
            if (pi) {
                const wxClassInfo *peClass = GetPropertyEditorClass(pi, FItem);
                if (peClass) {
                    result = dynamic_cast<xtiProperty*>(peClass->CreateObject());
                    result->Create(pi, wxDesigner(), FItem, this);
                }
            }
        }
        return result;
    }

protected:
	virtual wxString Get() const
    {
    	return "wxGBSizerItem";
    }

	virtual void Set(const wxString &value) { }
    wxGBSizerItem* FItem;
    wxGBSizerProxy* FSizer;
};

// wxSizerItemSpanProperty

IMPLEMENT_DYNAMIC_CLASS(wxSizerItemSpanProperty, xtiProperty)

void wxSizerItemSpanProperty::SetAsVariant(const wxxVariant &value)
{
    wxGridBagSizer *gbs = Item()->GetGBSizer();
    if (!gbs->CheckForIntersection(Item()->GetPos(), value.Get<wxGBSpan>(), Item())) {
        xtiProperty::SetAsVariant(value);
    }
}

// wxSizerItemPosProperty

IMPLEMENT_DYNAMIC_CLASS(wxSizerItemPosProperty, xtiProperty)

void wxSizerItemPosProperty::SetAsVariant(const wxxVariant &value)
{
    wxGridBagSizer *gbs = Item()->GetGBSizer();
    if (!gbs->CheckForIntersection(value.Get<wxGBPosition>(), Item()->GetSpan(), Item())) {
        xtiProperty::SetAsVariant(value);
    }
}

class wxColumnProportions;
class wxRowProportions;

class wxColumnProportion : public wxPropertyBase
{
public:
    wxColumnProportion(wxColumnProportions *parent, int index, wxwDesigner *designer);

protected:
	virtual wxString Get() const;
	virtual void Set(const wxString &value);

private:
    int FIndex;
    wxGridBagSizer *FSizer;
};

class wxRowProportion : public wxPropertyBase
{
public:
    wxRowProportion(wxRowProportions *parent, int index, wxwDesigner *designer);

protected:
	virtual wxString Get() const;
	virtual void Set(const wxString &value);

private:
    int FIndex;
    wxGridBagSizer *FSizer;
};

class wxColumnProportions : public wxPropertyBase
{
friend class wxColumnProportion;
public:
    wxColumnProportions(wxGridBagSizer *sizer, wxwDesigner *designer)
        : wxPropertyBase()
    {
        Init(designer, sizer, 0, "ColProportions");
        FSizer = sizer;
        if (FSizer->GetCols() > 0)
            FFlags |= PE_SUBPROPS;
        FFlags |= PE_READONLY;
    }

	virtual void GetChildren(rcmProperties &subProps)
    {
        for (int i=0; i<FSizer->GetCols(); i++) {
            subProps.push_back(new wxColumnProportion(this, i, wxDesigner()));
        }
    }

	virtual rcmProperty* GetChildProperty(const wxString &propName)
    {
        wxPropertyBase *result = 0;
        int index;
        if (wxSscanf(propName, "Column %d", &index))
            result = new wxColumnProportion(this, index, wxDesigner());
        return result;
    }

protected:
	virtual wxString Get() const
    {
    	return "";
    }

	virtual void Set(const wxString &value) { }

private:
    wxGridBagSizer *FSizer;
};

// wxRowProportions

class wxRowProportions : public wxPropertyBase
{
friend class wxRowProportion;
public:
    wxRowProportions(wxGridBagSizer *sizer, wxwDesigner *designer)
        : wxPropertyBase()
    {
        Init(designer, sizer, 0, "RowProportions");
        FSizer = sizer;
        if (FSizer->GetRows() > 0)
            FFlags |= PE_SUBPROPS;
        FFlags |= PE_READONLY;
    }

	virtual void GetChildren(rcmProperties &subProps)
    {
        for (int i=0; i<FSizer->GetRows(); i++) {
            subProps.push_back(new wxRowProportion(this, i, wxDesigner()));
        }
    }

	virtual rcmProperty* GetChildProperty(const wxString &propName)
    {
        wxPropertyBase *result = 0;
        int index;
        if (wxSscanf(propName, "Row %d", &index))
            result = new wxRowProportion(this, index, wxDesigner());
        return result;
    }

protected:
	virtual wxString Get() const
    {
    	return "";
    }

	virtual void Set(const wxString &value) { }

private:
    wxGridBagSizer *FSizer;
};

// wxColumnProportion

wxColumnProportion::wxColumnProportion(wxColumnProportions *parent, int index, wxwDesigner *designer)
    : wxPropertyBase()
{
    FIndex = index;
    FSizer = parent->FSizer;
    Init(designer, parent->FSizer, parent, wxString::Format("Column %d", index));
}

wxString wxColumnProportion::Get() const
{
    return wxString::Format("%d", FSizer->GetGrowableColProportion(FIndex));
}

void wxColumnProportion::Set(const wxString &value)
{
    int val;
    if (wxSscanf(value, "%d", &val)) {
        if (val >= 0) {
            // make column growable with the given proportion.
            FSizer->AddGrowableCol(FIndex, val);
        }
        else {
            FSizer->RemoveGrowableCol(FIndex);
        }
    }
}

// wxRowProportion

wxRowProportion::wxRowProportion(wxRowProportions *parent, int index, wxwDesigner *designer)
    : wxPropertyBase()
{
    FIndex = index;
    FSizer = parent->FSizer;
    Init(designer, parent->FSizer, parent, wxString::Format("Row %d", index));
}

wxString wxRowProportion::Get() const
{
    return wxString::Format("%d", FSizer->GetGrowableRowProportion(FIndex));
}

void wxRowProportion::Set(const wxString &value)
{
    int val;
    if (wxSscanf(value, "%d", &val)) {
        if (val >= 0) {
            // make Row growable with the given proportion.
            FSizer->AddGrowableRow(FIndex, val);
        }
        else {
            FSizer->RemoveGrowableRow(FIndex);
        }
    }
}

// wxGBSizerProxy

template <>
void ConstructWXObject(wxObject *parent, wxGridBagSizer *o, const wxString &name)
{
    wxxVariant params[5];
    params[0] = wxxVariant(dynamic_cast<wxWindow*>(parent));
    params[1] = wxxVariant((int)1);
    params[2] = wxxVariant((int)1);
    params[3] = wxxVariant((int)0);
    params[4] = wxxVariant((int)0);
    o->GetClassInfo()->Create(o, 5, params);
}

wxGBSizerProxy::wxGBSizerProxy(wxwDesigner *designer, wxwContainer *container)
    : wxwUIComponent(CLASSINFO(wxGridBagSizer), designer, container), wxwUIContainer()
{
}

wxGBSizerProxy::~wxGBSizerProxy()
{
	//delete the contained objects, or reparent them to my container?
    wxSizerItemList &items = FSizer->GetChildren();
    wxSizerItemList::Node *node = items.GetFirst();
    for (; node; node = node->GetNext()) {
        if (node->GetData()->GetWindow()) {
            FSizer->Detach(node->GetData()->GetWindow());
        }
    }
}

wxObject* wxGBSizerProxy::ParentInstance()
{
    wxwComponent *pComp = dynamic_cast<wxwComponent*>(wxContainer());
    return pComp ? pComp->Instance() : 0;
}

void wxGBSizerProxy::ObjectCreated(bool fromXRC)
{
    FSizer = (wxGridBagSizer*)Instance();
    FSizer->SetEmptyCellSize(wxSize(75, 25));
}


void wxGBSizerProxy::ConstructXTIObject(wxObject *object)
{
    wxASSERT_MSG(wxContainer(), "GridBagSizer must have a container");
    wxWindow *parentWin = dynamic_cast<wxWindow*>(wxContainer()->ParentInstance());
    wxASSERT_MSG(parentWin, "wxGridBagSizer must be parented to a wxWindow");
    ConstructWXObject(parentWin, (wxGridBagSizer*)object, GetName());
}

bool wxGBSizerProxy::CanParentType(const wxClassInfo *type)
{
    return type->IsKindOf(wxClassInfo::FindClass("wxWindow"))
        || type->IsKindOf(wxClassInfo::FindClass("wxGBSizerItem"));
}

wxGBSizerItem* wxGBSizerProxy::GetSizerItem(wxwComponent *child)
{
	if (FSizer && child) {
		return FSizer->FindItem(dynamic_cast<wxWindow*>(child->Instance()));
	}
	else
	    return 0;
}

rcmProperty* wxGBSizerProxy::GetProperty(wxArrayString &propPath)
{
    rcmProperty *p = wxwUIComponent::GetProperty(propPath);
    if (!p && propPath.Count() > 0) {
        if (propPath[0] == "ColProportions")
            p = new wxColumnProportions(FSizer, wxDesigner());
        else if (propPath[0] == "RowProportions")
            p = new wxRowProportions(FSizer, wxDesigner());
        unsigned int i = 0;
        while (p && ++i < propPath.Count()) {
            p = p->GetChildProperty(propPath[i]);
        }
    }
    return p;
}

void wxGBSizerProxy::GetProperties(rcmProperties &props)
{
    wxwUIComponent::GetProperties(props);
    props.push_back(new wxColumnProportions(FSizer, wxDesigner()));
    props.push_back(new wxRowProportions(FSizer, wxDesigner()));
}

void wxGBSizerProxy::GetExtraProperties(wxwComponent *child, rcmProperties &props)
{
	wxGBSizerItem* item = GetSizerItem(child);
	if (item && !item->IsSpacer()) {
	    props.push_front(new wxSizerItemProperty(item, this, wxDesigner()));
	}
}

rcmProperty* wxGBSizerProxy::GetExtraProperty(wxwComponent *child, wxArrayString &propPath)
{
    if (child && propPath.Count() > 0 && propPath[0] == "SizerItem") {
		wxGBSizerItem *item = GetSizerItem(child);
		if (item) {
			rcmProperty *p = new wxSizerItemProperty(item, this, wxDesigner());
			unsigned int i = 1;
			while (p && i < propPath.Count()) {
				p = p->GetChildProperty(propPath[i]);
				i++;
			}
			return p;
		}
    }
    return 0;
}

void wxGBSizerProxy::GetSize(int &w, int &h)
{
    wxArrayInt rowHeights = FSizer->GetRowHeights();
    wxArrayInt colWidths = FSizer->GetColWidths();
    w = 0;
    h = 0;
    // calculate max extent of rows & cols
    for (unsigned int i=0; i<colWidths.Count(); i++) {
        w += colWidths[i];
    }
    for (unsigned int i=0; i<rowHeights.Count(); i++) {
        h += rowHeights[i];
    }
}

wxGBPosition wxGBSizerProxy::FindEmptyCell()
{
    int row, col;
    for (row=0; row<FSizer->GetRows(); row++) {
        for (col=0; col<FSizer->GetCols(); col++) {
            wxGBPosition pos(row, col);
            if ( !FSizer->CheckForIntersection(pos, wxDefaultSpan) )
                return pos;
        }
    }
    return wxGBPosition(-1, -1);
}

void wxGBSizerProxy::PropertyChanged(const wxPropertyBase *property)
{
    ForceLayout();
    wxwComponent::PropertyChanged(property);
}

void wxGBSizerProxy::ForceLayout()
{
    if (FSizer && FSizer->GetWindow()) {
        FSizer->GetWindow()->Layout();
    }
}

wxGBPosition wxGBSizerProxy::GetPositionFromPoint(int x, int y)
{
    if (FSizer) {
        wxArrayInt rh = FSizer->GetRowHeights();
        wxArrayInt cw = FSizer->GetColWidths();
        int x0 = 0, y0 = 0;
        if (rh.Count() > 0 && cw.Count() > 0) {
            for (unsigned int r=0; r<rh.Count(); r++) {
                for (unsigned int c=0; c<cw.Count(); c++) {
                    int w = cw[c];
                    int h = rh[r];
                    wxRect rect(x0, y0, w, h);
                    if (rect.Inside(x, y)) {
                        return wxGBPosition(r, c);
                    }
                    x0 += cw[c];
                }
                y0 += rh[r];
                x0 = 0;
            }
        }
    }
    return wxGBPosition(-1, -1);
}

bool wxGBSizerProxy::Valid(const wxGBPosition &pos)
{
	return pos.GetRow() >= 0 && pos.GetCol() >= 0;
}

bool wxGBSizerProxy::Valid(const wxGBSpan &span)
{
	return span.GetRowspan() >= 0 && span.GetColspan() >= 0;
}

wxGBPosition wxGBSizerProxy::CalcNewPosition(int x, int y)
{
    wxGBPosition pos = GetPositionFromPoint(x, y);
    if (Valid(pos)) return pos;

    int r, c, rows, cols;
    wxArrayInt rh = FSizer->GetRowHeights();
    wxArrayInt cw = FSizer->GetColWidths();
    rows = rh.GetCount();
    cols = cw.GetCount();
    r = -1;
    c = -1;
    wxSize esz = FSizer->GetEmptyCellSize();

    do {
    	r++;
    	y -= r < rows ? rh[r] : esz.y;
    }
    while (y >= 0);

    do {
    	c++;
    	x -= c < cols ? cw[c] : esz.x;
    }
    while (x >= 0);

    return wxGBPosition(r, c);
}

bool wxGBSizerProxy::NotifyChildBoundsChanging(int &x, int &y, int &w, int &h, wxwUIComponent *child)
{
    wxGBSizerItem *item = GetSizerItem(child);
    if (!item) return true;

    // Get current position to decide whether to resize or move contained items.
    int x0, y0, w0, h0;
    child->GetRect(x0, y0, w0, h0);

    // Give priority to resizing. Keep span fixed.
    // Here strictly resize the control by resizing the sizer item.
    if ( (w > -1 && w0 != w) || (h > -1 && h0 != h) ) {
        wxGBSpan span = item->GetSpan();
        if (span.GetRowspan() > 1)
        	h = -1;
        if (span.GetColspan() > 1)
        	w = -1;
    	//dont set init size in the direction of a multiple cell span
        item->SetInitSize(w, h);
        return true;
    }

    // cell position changes
    if (x != x0 || y != y0) {
        wxGBPosition newTL = CalcNewPosition(x, y);

        if (Valid(newTL)) {
            if (FSizer->CheckForIntersection(newTL, item->GetSpan(), item)) {
                // there's an item in the way. Let's swap them.
                wxGBSizerItem *blocker = FSizer->FindItemAtPosition(newTL);
                if (blocker) {
                    // swap both position and span, to guarantee no collisions.
                    wxGBPosition itemPos = item->GetPos();
                    wxGBSpan itemSpan = item->GetSpan();
                    wxGBSpan blockerSpan = blocker->GetSpan();
                    int blockerEndRow;
                    int blockerEndCol;
                    blocker->GetEndPos(blockerEndRow, blockerEndCol);
                    // don't use wxSizer::Detach, it will delete the sizer item.
                    // go through the back door and manipulate the sizer list directly.
                    wxwxSizerItemListNode *itemNode = FSizer->GetChildren().Find(item);
                    wxwxSizerItemListNode *blockerNode = FSizer->GetChildren().Find(blocker);
                    // remove "item" from the sizer.
                    if (itemNode && blockerNode && FSizer->GetChildren().DeleteNode(itemNode)
                    && FSizer->GetChildren().DeleteNode(blockerNode)) {
                        // why should I have to do this? They oughta know...
                        item->SetGBSizer(0);
                        blocker->SetGBSizer(0);
                        if (item->IsWindow())
                            item->GetWindow()->SetContainingSizer(0);
                        if (blocker->IsWindow())
                            blocker->GetWindow()->SetContainingSizer(0);
                        // move the blocking item there, after setting it's span.
                        blocker->SetSpan(itemSpan);
                        blocker->SetPos(itemPos);
                        // now set the item's span to the blocker's old span and reinsert it.
                        // ensure that if the item is moving "inside" the blockers spanned
                        // area that the item's span is adjusted so it doesn't lie outside
                        // the blocker's old end position.
                        blockerSpan.SetColspan(blockerEndCol - newTL.GetCol() + 1);
                        blockerSpan.SetRowspan(blockerEndRow - newTL.GetRow() + 1);
                        item->SetSpan(blockerSpan);
                        item->SetPos(newTL);
                        FSizer->Add(item);
                        FSizer->Add(blocker);
                        return true;
                    }
                }
            }
            else
            	return item->SetPos(newTL);
        }
        else {
            return false;
        }
    }

    return false; // keep the old size and position.
}

void wxGBSizerProxy::NotifyChildBoundsChanged(wxwUIComponent *child)
{
    ForceLayout();
}

void wxGBSizerProxy::NotifyChildInserted(wxwComponent *newChild)
{
    wxWindowComponent *winChild = dynamic_cast<wxWindowComponent*>(newChild);
    wxGBSizerItem *newItem = 0;
    wxGBPosition pos = FindEmptyCell();

    // add a new column by default.
    if (pos == wxGBPosition(-1, -1)) {
        pos = wxGBPosition(FSizer->GetRows()-1, FSizer->GetCols());
    }

    if (winChild) {
        // inserting a window
        if (!(winChild->IsType(CLASSINFO(wxWindow)))) {
            throw new runtime_error(wxString::Format("Cannot add a %s to a wxGridBagSizer",
                winChild->GetName()).c_str());
        }

        newItem = new wxGBSizerItem(
            winChild->Window(),
            pos,
            wxDefaultSpan,
            wxEXPAND,
            0, // for now.
            0);
    }
    else {
        wxGBSizerItem *spacer = dynamic_cast<wxGBSizerItem*>(newChild->Instance());
        if (spacer && spacer->IsSpacer()) {
            // inserting a spacer
            newItem = spacer;
            newItem->SetPos(pos);   
        }
    }
    if (newItem) {
        FSizer->Add(newItem);
        wxwContainer::NotifyChildInserted(newChild);
        ForceLayout();
    }
}

void wxGBSizerProxy::NotifyChildRemoved(wxwComponent *child)
{
    if (child && FSizer) {
        wxWindow *win = dynamic_cast<wxWindow*>(child->Instance());
        if (win) {
            FSizer->Detach(win);
        }
        else {
            // child is a wxGridBagSpacer
            wxGBSizerItem *item = dynamic_cast<wxGBSizerItem*>(child->Instance());
            if (item) {
                wxSizerItemList::compatibility_iterator node = FSizer->GetChildren().Find(item);
                FSizer->GetChildren().Erase(node);
            }
        }
    }
    wxwContainer::NotifyChildRemoved(child);
}

// rcmUIComponent

bool wxGBSizerProxy::ConstrainChildren()
{
	return false;
}

void wxGBSizerProxy::DoGetRect(int &x, int &y, int &w, int &h)
{
    ForceLayout();
	wxPoint tl = FSizer->GetPosition();
    wxSize size = FSizer->GetSize();//FSizer->CalcMin();
    x = tl.x;
    y = tl.y;
    w = size.x;
    h = size.y;
}

void wxGBSizerProxy::DoSetRect(int &x, int &y, int &w, int &h, bool testOnly)
{
	FSizer->SetDimension(x, y, w, h);
	GetRect(x, y, w, h);
}

int wxGBSizerProxy::GetZOrderPosition()
{
	// TODO: ZOrder
	return 0;
}

Result* wxGBSizerProxy::SetZOrderPosition(rcmComponent *child, int z)
{
	// TODO: ZOrder
	return 0;
}

bool wxGBSizerProxy::Visible()
{
	// this is probably wrong
	return true;//FSizer->IsShown((wxSizer*)Instance());
}

bool wxGBSizerProxy::IsColumnGrowable(int col)
{
    return ArrayIntHasValue(FSizer->GetGrowableCols(), col);
}

bool wxGBSizerProxy::IsRowGrowable(int row)
{
    return ArrayIntHasValue(FSizer->GetGrowableRows(), row);
}

void wxGBSizerProxy::SetColGrowable(int col, bool growable)
{
    if (growable) {
        if (!IsColumnGrowable(col))
            FSizer->AddGrowableCol(col);
    }
    else {
        if (IsColumnGrowable(col))
            FSizer->RemoveGrowableCol(col);
    }
}

void wxGBSizerProxy::SetRowGrowable(int row, bool growable)
{
    if (growable) {
        if (!IsRowGrowable(row))
            FSizer->AddGrowableRow(row);
    }
    else {
        if (IsRowGrowable(row))
            FSizer->RemoveGrowableRow(row);
    }
}

// wxSizerPainter

IMPLEMENT_DYNAMIC_CLASS(wxSizerPainter, wxPainter)

void wxSizerPainter::PaintObject(wxObject *object, wxDC &dc)
{
    wxGridBagSizer *sizer = dynamic_cast<wxGridBagSizer*>(object);
    if (!sizer) return;
    wxWindow *sizerWin = sizer->GetWindow();
    if (!sizerWin) return;
    wxColour bkg = sizerWin->GetBackgroundColour();
    wxColour gridColor(bkg.Red()^0xFF, bkg.Green()^0xFF, bkg.Blue()^0xFF);

    wxPen *pen = wxThePenList->FindOrCreatePen(gridColor, 1, wxDOT);
    dc.SetPen(*pen);
    dc.SetBrush(*wxTRANSPARENT_BRUSH);
    dc.BeginDrawing();

    sizer->GetWindow()->Layout();
    wxArrayInt rowHeights = sizer->GetRowHeights();
    wxArrayInt colWidths = sizer->GetColWidths();

    if (rowHeights.Count() < 1) return;
    if (colWidths.Count() < 1) return;
    int x = 0; int y = 0;
    int w = 0; int h = 0;
    unsigned int i = 0;

    // calculate max extent of rows & cols
    for (i=0; i<colWidths.Count(); i++) {
        w += colWidths[i];
    }
    for (i=0; i<rowHeights.Count(); i++) {
        h += rowHeights[i];
    }

    // draw vert & horz lines for each cell. wxDC::DrawRectangle() doesn't
    // provide satisfying results.
    dc.DrawLine(x, 0, x, h);
    for (i=0; i<colWidths.Count(); i++) {
        x += colWidths[i];
        dc.DrawLine(x, 0, x, h);
    }

    dc.DrawLine(0, y, w, y);
    for (i=0; i<rowHeights.Count(); i++) {
        y += rowHeights[i];
        dc.DrawLine(0, y, w, y);
    }

    dc.EndDrawing();
}

// wxGBSizerEditor

class GrowableColItem : public MenuItem
{
public:
    GrowableColItem(int col, bool growable)
        : MenuItem(""), FCol(col), FGrowable(growable)
    {
        if (growable)
            SetCaption(wxString("Make column ungrowable"));
        else
            SetCaption(wxString("Make column growable"));
    }

    int FCol;
    bool FGrowable;
};

class GrowableRowItem : public MenuItem
{
public:
    GrowableRowItem(int row, bool growable)
        : MenuItem(""), FRow(row), FGrowable(growable)
    {
        if (growable)
            SetCaption(wxString("Make row ungrowable"));
        else
            SetCaption(wxString("Make row growable"));
    }

    int FRow;
    bool FGrowable;
};


IMPLEMENT_DYNAMIC_CLASS(wxGBSizerEditor, wxwComponentEditor)

void wxGBSizerEditor::UpdateMenu(MenuItems &menu, int x, int y)
{
 	wxGBPosition pos = SizerProxy()->GetPositionFromPoint(x, y);
    if (pos != wxGBPosition(-1, -1)) {
    	unsigned int col = pos.GetCol();
        unsigned int row = pos.GetRow();

        MenuItem *item = new GrowableColItem(col, SizerProxy()->IsColumnGrowable(col));
        item->SetOnItemClick(MENU_CLICK_SINK(wxGBSizerEditor, MenuItemClicked));
        menu.push_back(item);
        item = new GrowableRowItem(row, SizerProxy()->IsRowGrowable(row));
        item->SetOnItemClick(MENU_CLICK_SINK(wxGBSizerEditor, MenuItemClicked));
        menu.push_back(item);
    }
}

void wxGBSizerEditor::MenuItemClicked(MenuItem *item, Result *&result)
{
    GrowableColItem *colItem = dynamic_cast<GrowableColItem*>(item);
    if (colItem) {
        SizerProxy()->SetColGrowable(colItem->FCol, !colItem->FGrowable);
    }
    else {
        GrowableRowItem *rowItem = dynamic_cast<GrowableRowItem*>(item);
        if (rowItem) {
            SizerProxy()->SetRowGrowable(rowItem->FRow, !rowItem->FGrowable);
        }
    }
    SizerProxy()->ForceLayout();
    Designer()->NotifyComponentChanged(Component(), true);
    result = new Result(true);
}

// wxGridBagSpacer

template <>
void ConstructWXObject(wxObject *parent, wxGBSizerItem *o, const wxString &name)
{
    o->SetInitSize(40, 30);
    o->SetPos(wxGBPosition(0, 0));
    o->SetSpan(wxDefaultSpan);
    o->SetFlag(wxEXPAND);
    o->SetBorder(0);
}

wxGridBagSpacer::wxGridBagSpacer(wxwDesigner *designer, wxwContainer *container)
	: wxwUIComponent(CLASSINFO(wxGBSizerItem), designer, container)
{
	
}

wxGridBagSpacer::~wxGridBagSpacer()
{
}

void wxGridBagSpacer::ConstructXTIObject(wxObject *object)
{
    wxGBSizerProxy *sizer = dynamic_cast<wxGBSizerProxy*>(wxContainer());
    wxASSERT_MSG(sizer, "wxGridBagSpacer must be parented to a wxGridBagSizer");
    ConstructWXObject(NULL, (wxGBSizerItem*)object, GetName());
}

void wxGridBagSpacer::DoGetRect(int &x, int &y, int &w, int &h)
{
    wxPoint pt = Item()->GetPosition();
    wxSize size = Item()->GetSize();
    x = pt.x;
    y = pt.y;
    w = size.x;
    h = size.y;
}

void wxGridBagSpacer::DoSetRect(int &x, int &y, int &w, int &h, bool testOnly)
{
    // should be able to get away with doing nothing for x & y, as the sizer
    // will take care of it.
    Item()->SetInitSize(w, h);
}


// wxGBSpacerPainter

IMPLEMENT_DYNAMIC_CLASS(wxGBSpacerPainter, wxPainter)

void wxGBSpacerPainter::PaintObject(wxObject *object, wxDC &dc)
{
    wxGBSizerItem *item = dynamic_cast<wxGBSizerItem*>(object);
    if (!item || !item->IsSpacer()) return;
    wxGridBagSizer *sizer = item->GetGBSizer();
    if (!sizer) return;
    wxWindow *sizerWin = sizer->GetWindow();
    if (!sizerWin) return;
    wxColour bkg = sizerWin->GetBackgroundColour();

    unsigned char tRed = bkg.Red();
    tRed -= tRed > 20 ? 20 : -20;
    unsigned char tGreen = bkg.Green();
    tGreen -= tGreen > 20 ? 20 : -20;
    unsigned char tBlue = bkg.Blue();
    tBlue -= tBlue > 20 ? 20 : -20;

    wxColour tint(tRed, tGreen, tBlue);

    wxPen *pen = wxThePenList->FindOrCreatePen(tint, 1, wxDOT);
    dc.SetPen(*pen);
    wxBrush *brush = wxTheBrushList->FindOrCreateBrush(tint, wxSOLID);
    dc.SetBrush(*brush);

    dc.BeginDrawing();

    dc.DrawRectangle(wxPoint(0, 0), item->GetSize());

    dc.EndDrawing();
}


