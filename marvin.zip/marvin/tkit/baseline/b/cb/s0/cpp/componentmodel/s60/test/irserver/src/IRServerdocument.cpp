////////////////////////////////////////////////////////////////////////////////
// Implementation of CIRServerDocument
////////////////////////////////////////////////////////////////////////////////

#include "IRServerappui.h"
#include "IRServerdocument.h"


CIRServerDocument::CIRServerDocument(CEikApplication& aApp)
                       :CAknDocument(aApp)
{
}

CIRServerDocument::~CIRServerDocument()
{
}

CIRServerDocument* CIRServerDocument::NewL(CEikApplication& aApp)
{
  CIRServerDocument* self = NewLC(aApp);
  CleanupStack::Pop(self);
  return self;
}

CIRServerDocument* CIRServerDocument::NewLC(CEikApplication& aApp)
{
  CIRServerDocument* self = new (ELeave) CIRServerDocument(aApp);
  CleanupStack::PushL(self);
  self->ConstructL();
  return self;
}

void CIRServerDocument::ConstructL()
{
}

CEikAppUi* CIRServerDocument::CreateAppUiL()
{
  return new(ELeave) CIRServerAppUi;
}

