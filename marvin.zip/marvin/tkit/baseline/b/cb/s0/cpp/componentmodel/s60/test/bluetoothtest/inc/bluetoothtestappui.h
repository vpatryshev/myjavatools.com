#ifndef __BLUETOOTHTEST_APPUI_H__
#define __BLUETOOTHTEST_APPUI_H__

#include <aknViewAppUi.h>

class CbluetoothtestView;


// CbluetoothtestAppUi
class CbluetoothtestAppUi : public CAknViewAppUi
{
public:
  /**
   * Performs second phase construction of this AppUi Object
   */
  void ConstructL();

  /**
   * Handles user menu selection
   */
  void HandleCommandL(TInt aCommand);

private:
  CbluetoothtestView * ibluetoothtestView;
};


#endif // __BLUETOOTHTEST_APPUI_H__

