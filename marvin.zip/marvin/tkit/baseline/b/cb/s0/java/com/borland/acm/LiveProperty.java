package com.borland.acm;

/**
 * The LiveProperty interface represents a live property instance on a live component.  The live
 * property stores the text value setting of the property on this component.
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public interface LiveProperty /*extends PropertyInfo*/ {

  /**
   * Returns the property info associated with this live property
   *
   * @return The PropertyInfo associated with this live property
   */
  public PropertyInfo getPropertyInfo();


  /**
   * Returns the live component that 'owns' this live property
   *
   * @return The LiveComponent associated with this live property
   */
  public LiveComponent getComponent();

  /**
   * Returns the current property value as text.  This is the string displayed in the property
   * inspector - unless there are supplied value tags.  If value tags are supplied, this text will
   * be the 'key' of the selected value tag.
   *
   * @return The current property value as text, or the key of the selected value tag
   * @see getValueTags()
   * @see PropertyInfo#getValueTags()
   * @see PropertyInfo#isConstrainedToTags()
   * @see Tag#getKey()
   */
  public String getValueAsText();

  /**
   * Sets the current value for this live property.  If value tags are supplied, this may be a key
   * from a value tag.  If the property info specified that the property is constrained to tags,
   * this value *must* be a key from a value tag.  If the value is a key to a value tag, the value
   * tag's displayName will be displayed in the inspector, rather than the value text itself.  A
   * 'propertyChanged' event should be fired via the DesignerListener interface.
   *
   * @param value The desired property value - or key from the desired value tag
   * @return A standard Result object, indicating success or failure, and any number of messages
   *         for the user
   * @see getValueTags()
   * @see PropertyInfo#getValueTags()
   * @see PropertyInfo#isConstrainedToTags()
   * @see Tag#getKey()
   * @see DesignerListener#propertyChanged(LiveProperty)
   */
  public Result setValueAsText(String value);

  /**
   * Returns true if value of this live property can be reverted to original
   */
  public boolean canRevert();

  /**
   * Reverts the property value to the initial value read from the persistence buffer.  This should
   * fire a 'propertyChanged' event via the DesignerListener interface.
   *
   * @return A standard Result object, indicating success or failure, and any number of messages
   *         for the user
   * @see DesignerListener#propertyChanged(LiveProperty)
   */
  public Result revert();

  /**
   * Returns true if this live property has been modified since it was read in from persistence
   * data.
   *
   * @return <b>true</b> if the live property value has been changed since it was read in from
   *         persistence data, <b>false</b> if not
   */
  public boolean isModified();

  /**
   * <p>Returns a set of value tags to show in a drop-down list for the property.  Value tags
   * represent valid value settings for this property.  If the user selects a value tag from the
   * drop-down list, the Tag object's key will be passed to the setValueAsText(String) method.
   * Both the live property and the property info have an opportunity to supply value tags.
   * Typically, value tags supplied by the live property are dynamic values derived from some
   * aspect of the live component, while value tags supplied by the property info are static items
   * that show for all properties of the same type.  If no value tags are supplied for a property,
   * no drop-down list will be shown to the user.</p>
   *
   * <p>For this use of the Tag interface, methods will be used as follows:</p>
   * <table border=1>
   * <tr><th> Method                     <th> Purpose
   * <tr><td> Object getKey()            <td> Passed as text to the 'setValueText(String)' method
   * <tr><td> String getDisplayName()    <td> Text of the drop-down item (uses 'key.toString()' if null)
   * <tr><td> String getDescription()    <td> Status text of the drop-down item (optional)
   * <tr><td> ImageData getDisplayIcon() <td> Icon of the drop-down item (optional)
   * <tr><td> TagGroup getParentTag()    <td> Tag hierarchy shown as expanded list in drop-down
   * <tr><td> void tagInvoked()          <td> (not used)
   * </table>
   *
   * @return An array of Tag objects representing the items in the drop-down list for the property
   * @see PropertyInfo#getValueTags()
   * @see PropertyInfo#isConstrainedToTags()
   */
  public Tag[] getValueTags();

  /**
   * Returns the parent property for this live property.  If this is a top-level property, this
   * method should return null.
   *
   * @return The LiveProperty that contains this live property, or null if this is a top-level
   *         property
   */
  public LiveProperty getParentProperty();

  /**
   * Returns <b>true</b> if this property has child properties, <b>false</b> if not
   *
   * @return <b>true</b> if this property has child properties, <b>false</b> if not
   */
  public boolean hasChildren();

  /**
   * Returns the array of live properties contained by this live property
   *
   * @return The array of LiveProperty objects contained by this live property group
   */
  public LiveProperty[] getProperties();

  /**
   * Returns the child property with the specified propertyKey, or null the specified child is not
   * a child of this property.
   *
   * @param propertyKey The desired property key
   * @return The LiveProperty
   */
  public LiveProperty getProperty(Object propertyKey);

  /**
   * Returns true if inserting <code>textToInsert</code> into <code>currentText</code> at <code>offset</code> position leave possibility of completing result string to valid for this <code>LiveProperty<\code> value-as-text
   * This method can be used by Object Inspector to prohibit input of invalid symbols, even before value is applied
   * @param currentText string to be tested
   * @param textToInsert the string to insert
   * @param offset the starting offset >= 0
   * @return true if new input is valid
   */
  public boolean isValidInput(String currentText, String textToInsert, int offset);

}
