package com.borland.acm.util;

import java.util.*;

import com.borland.acm.*;

/**
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public class BasicResult
  implements Result {

  protected boolean success;
  protected List messages = null;
  protected List options = null;

  public static BasicResult create(boolean success) {
    return new BasicResult(success);
  }

  public static BasicResult create(boolean success, String message, String title, int type) {
    ResultMessage msg = new BasicResultMessage(type, title, message);
    return new BasicResult(success, new ResultMessage[] {
      msg});
  }

  public static BasicResult create(Result result, String message, String title, int type) {
    ResultMessage msg = new BasicResultMessage(type, title, message);
    BasicResult bresult = new BasicResult(result);
    bresult.addMessage(msg);
    return bresult;
  }

  public static BasicResult create(Result result, boolean success, String message, String title, int type) {
    BasicResult bresult = (result != null) ? new BasicResult(result) : new BasicResult(success);
    ResultMessage msg = new BasicResultMessage(type, title, message);
    bresult.addMessage(msg);
    return bresult;
  }

  public static BasicResult create(boolean success, ResultMessage[] messages) {
    return new BasicResult(success, messages);
  }

  public static BasicResult create(boolean success, ResultMessage[] messages, Tag[] options) {
    return new BasicResult(success, messages, options);
  }

  protected BasicResult() {
    this.success = true;
  }

  public BasicResult(Result result) {
    this.success = result.isSuccess();
    this.addMessages(result.getMessages());
    this.addOptionTags(result.getOptionTags());
  }

  public BasicResult(boolean success) {
    this.success = success;
  }

  public BasicResult(boolean success, ResultMessage[] messages) {
    this(success);
    for (int i = 0; messages != null && i < messages.length; i++) {
      addMessage(messages[i]);
    }
  }

  public BasicResult(boolean success, ResultMessage[] messages, Tag[] options) {
    this(success, messages);
    for (int i = 0; options != null && i < options.length; i++) {
      addOptionTag(options[i]);
    }
  }

  public void setSuccess(boolean success) {
    this.success = success;
  }

  public boolean isSuccess() {
    return success;
  }

  public void addMessage(ResultMessage message) {
    if (message == null) {
      return;
    }
    if (messages == null) {
      messages = new ArrayList();
    }
    if (!messages.contains(message)) {
      messages.add(message);
    }
  }

  public void addMessages(ResultMessage[] messages) {
    if (messages == null || messages.length < 1) {
      return;
    }
    if (this.messages == null) {
      this.messages = new ArrayList();
    }
    for (int i = 0; i < messages.length; i++) {
      if (!this.messages.contains(messages[i])) {
        this.messages.add(messages[i]);
      }
    }
  }

  public void removeMessage(ResultMessage message) {
    if (messages == null || message == null) {
      return;
    }
    messages.remove(message);
    if (messages.size() == 0) {
      messages = null;
    }
  }

  public void removeMessages(ResultMessage[] messages) {
    if (this.messages == null || messages == null || messages.length < 1) {
      return;
    }
    for (int i = 0; i < messages.length; i++) {
      this.messages.remove(messages[i]);
    }
    if (this.messages.size() == 0) {
      this.messages = null;
    }
  }

  public int getMessageCount() {
    return messages != null ? messages.size() : 0;
  }

  public ResultMessage[] getMessages() {
    return messages != null ? (ResultMessage[]) messages.toArray(new ResultMessage[messages.size()]) : null;
  }

  public void addOptionTag(Tag option) {
    if (option == null) {
      return;
    }
    if (options == null) {
      options = new ArrayList();
    }
    if (!options.contains(option)) {
      options.add(option);
    }
  }

  public void addOptionTags(Tag[] options) {
    if (options == null || options.length < 1) {
      return;
    }
    if (this.options == null) {
      this.options = new ArrayList();
    }
    for (int i = 0; i < options.length; i++) {
      if (!this.options.contains(options[i])) {
        this.options.add(options[i]);
      }
    }
  }

  public void removeOptionTag(Tag option) {
    if (options == null || option == null) {
      return;
    }
    options.remove(option);
    if (options.size() == 0) {
      options = null;
    }
  }

  public void removeOptionTags(Tag[] options) {
    if (this.options == null || options == null || options.length < 1) {
      return;
    }
    for (int i = 0; i < options.length; i++) {
      this.options.remove(options[i]);
    }
    if (this.options.size() == 0) {
      this.options = null;
    }
  }

  public int getOptionTagCount() {
    return options != null ? options.size() : 0;
  }

  public Tag[] getOptionTags() {
    return options != null ? (Tag[]) options.toArray(new Tag[options.size()]) : null;
  }
}
