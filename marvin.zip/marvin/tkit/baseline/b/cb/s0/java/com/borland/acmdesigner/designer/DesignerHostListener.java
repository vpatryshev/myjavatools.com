package com.borland.acmdesigner.designer;

import java.util.*;
import com.borland.acm.*;

public interface DesignerHostListener extends DesignerListener {
  public void componentInfoSelected(ComponentInfo compInfo);
  public void designerActivated(LiveDesigner designer);
  public void componentSelected(LiveComponent comp);
}