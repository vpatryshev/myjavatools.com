package com.borland.acm;

/**
 * A standard event adapter class to simplify usage of the DesignerListener interface.
 *
 * @see DesignerListener
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public class DesignerAdapter implements DesignerListener {
  public void managerChanged(LiveDesignerManager manager) {}
  public void designerChanged(LiveDesigner designer) {}
  public void designerCleared(LiveDesigner designer) {}
  public void componentCreated(LiveComponent comp) {}
  public void componentChanged(LiveComponent comp) {}
  public void componentDisposing(LiveDesigner designer, LiveComponent comp) {}
  public void componentDisposed(LiveDesigner designer, Object compInstanceKey) {}
  public void propertyChanged(LiveProperty prop) {}
  public void eventChanged(LiveEvent event, String oldHook) {}
}