package com.borland.acm;

import java.util.EventListener;

/**
 * The DesignerListener interface is the event set fired by the
 * LiveDesignerManager and LiveDesigner classes to prompt the visual designer
 * to update it's information as appropriate.  It is up to
 * the implementor of a ComponentModel to properly fire these events to keep
 * the visual designer in sync with what is happening in the ComponentModel
 * and ACM designers.
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public interface DesignerListener extends EventListener {

  /**
   * The "whole world" has changed, and everything should be re-build.
   * This includes the palette, designer list, etc.
   *
   * @param manager The live designer manager that has changed
   */
  public void managerChanged(LiveDesignerManager manager);

  /**
   * A live designer has changed in some way, and the IDE should update
   * everything it knows about the live designer.
   * For example, the background image of a LiveUIDesigner may have changed,
   * so it should be re-requested and cached.
   *
   * @param designer The live designer that changed
   */
  public void designerChanged(LiveDesigner designer);

  /**
   * A live designer removed all components, and the IDE should clean-up
   * everything it knows about the live components of this designer.
   *
   * @param designer The live designer
   */
  public void designerCleared(LiveDesigner designer);

  /**
   * A live component has been created.
   *
   * @param comp The newly created component
   */
  public void componentCreated(LiveComponent comp);

  /**
   * A live component has changed in some way, and the IDE should update
   * everything it knows about it.
   * For example, the image may have changed on a LiveUIComponent,
   * so the image should be re-requested and cached.
   *
   * @param comp The live component that has changed
   */
  public void componentChanged(LiveComponent comp);

    /**
   * A live component is going to be disposed, the IDE should do any preparation
   * necessary prior to actual removal being done.
   * The to-be-disposed component should be expected to be in an indeterminate
   * (possibly hollowed) state wrt the Component Model at the point the
   * acm gets it.
   *
   * @param designer The designer that owns the to be disposed component
   * @param comp The live component that is going to be deleted.
   */
  public void componentDisposing(LiveDesigner designer, LiveComponent comp);

  /**
   * A live component has been disposed, and the IDE should remove it from
   * its cache and make sure everything is in sync.
   *
   * @param designer The designer that owned the disposed component
   * @param compInstanceKey The unique instance key of the disposed component
   */
  public void componentDisposed(LiveDesigner designer, Object compInstanceKey);

  /**
   * A property (value) has changed, and the IDE should update its cache and
   * display the correct information about it.
   *
   * @param prop The live property that changed
   */
  public void propertyChanged(LiveProperty prop);

  /**
   * An event (hook) has changed, and the IDE should update its cache and
   * display the correct information about it.
   *
   * @param event The live event that changed
   */
  public void eventChanged(LiveEvent event, String oldValue);
}