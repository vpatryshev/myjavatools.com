package com.borland.acmdesigner.designer;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import com.borland.primetime.actions.*;

import com.borland.acm.*;
import com.borland.acmdesigner.designer.*;
import com.borland.acmdesigner.PanelActionEvent;
import com.borland.acmdesigner.PanelAction;
import com.borland.acmdesigner.util.*;
import com.borland.acmdesigner.DesignerPropertyPage;
import com.borland.primetime.properties.GlobalPropertyListener;
import com.borland.primetime.properties.GlobalProperty;
import com.borland.acmdesigner.PanelActionPaste;

/**
 *
 * <p>Title: BaseDesignSurface</p>
 * <p>Abstract baseclass for Design surface implmentations
 * </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @version 1.0
 */
abstract public class BaseDesignSurface
  extends JPanel {

  public static final int MOUSE_RESIZING_ZONE = 4;
  public static final int SHIFT_STEP_INCR = 10;

  public static boolean _GLOBAL_DRAGGING = false;

  static final int STROKE_WIDTH = 2;
  static final int SHADOW_OFFSET = 5;
  public static final int OUTER_OFFSET = (STROKE_WIDTH > SHADOW_OFFSET
    ? STROKE_WIDTH : SHADOW_OFFSET) + 1;
  static final Color SELECTED_STROKE_COLOR = new Color(0, 0, 255);
  public static final Color DRAGGING_STROKE_COLOR = new Color(0, 0, 255);
  static final Color CREATING_STROKE_COLOR = new Color(255, 0, 0, 127);
  static final Color SHADOW_COLOR = new Color(20, 20, 20, 50);

  static final float[] CREATING_STROKE_DOTS = new float[] {
    8f, 5f, 1f, 5f};
  static final protected float CREATING_STROKE_SIZE = 19f; // sum of above pixels

//  static final float[] DRAGGING_STROKE_DOTS = new float[] { 8f, 5f, 1f, 5f };
//  static final protected float DRAGGING_STROKE_SIZE = 19f; // sum of above pixels

  protected float CREATING_STROKE_PHASE = 0f;
//  protected float DRAGGING_STROKE_PHASE = 0f;
  protected Stroke CREATING_STROKE = new BasicStroke(STROKE_WIDTH,
    BasicStroke.CAP_SQUARE, BasicStroke.JOIN_MITER, 2f,
    CREATING_STROKE_DOTS, CREATING_STROKE_PHASE);
//  protected Stroke DRAGGING_STROKE = new BasicStroke(STROKE_WIDTH,
//                     BasicStroke.CAP_SQUARE, BasicStroke.JOIN_MITER, 2f,
//                     DRAGGING_STROKE_DOTS, DRAGGING_STROKE_PHASE);

  protected DesignerHost host;
  protected LiveDesigner designer;

  protected Map awtCompHash = new HashMap();

  protected boolean debugPaint = false;
//  protected Utils.ColorWheel cw = new Utils.ColorWheel();

  private Component dragging_comp = null;
  private Rectangle dragging_rect = null;
  private boolean paintDragImg = false;

  protected Point select_point = null;
  protected Rectangle select_rect = null;

  protected Component lastSelectedAWTComp = null;

//  private boolean showGrid;
//  private boolean showShadow;

  private FatEdgeHitHandler myEdgeHitHandler;
  private GlobalPropertyListener myGlobalPropertyListener;

  public BaseDesignSurface(DesignerHost host, LiveDesigner designer) {
    this.host = host;
    this.designer = designer;
    try {
      jbInit();
    }
    catch (Exception e) {
      e.printStackTrace();
    }

    myGlobalPropertyListener=new  GlobalPropertyListener() {
          public void globalPropertyChanged(GlobalProperty property, String oldValue, String newValue) {
            if (BaseDesignSurface.this.isVisible()) {
              BaseDesignSurface.this.repaint();
            }
          }
        };

    DesignerPropertyPage.PROP_SHOW_GRID.addPropertyListener(myGlobalPropertyListener);

    enableEvents(AWTEvent.MOUSE_EVENT_MASK | AWTEvent.MOUSE_MOTION_EVENT_MASK);
  }

  public void destroy() {
    cleanUp();
  }

  public void cleanUp() {
    DesignerPropertyPage.PROP_SHOW_GRID.removePropertyListener(myGlobalPropertyListener);
    myGlobalPropertyListener=null;
    awtCompHash=null;
    lastSelectedAWTComp=null;
    dragging_comp=null;
    host=null;
    designer=null;
  }

  public DesignerHost getDesignerHost() {
    return host;
  }

  public LiveDesigner getDesigner() {
    return designer;
  }

  private void jbInit() throws Exception {
    this.setBackground(SystemColor.window);
    this.setLayout(null);
  }

  /**
   * Create or return existing AWT Component for given LiveComponent
   * @param comp LiveComponent to get AWTComponent for
   * @param create boolean indicating create AWTCOmp if not exist
   * @return (AWT)Component for give LiveComponent
   */
  public Component getAWTComponent(LiveComponent comp, boolean create) {
    if (comp == null) {
      return null;
    }
    Component awtComp = (Component) awtCompHash.get(comp.getInstanceKey());
    if (awtComp == null && create) {
      awtComp = createAWTComponent(comp);
      awtCompHash.put(comp.getInstanceKey(), awtComp);
    }
    return awtComp;
  }

  protected Component getAWTCompByInstanceKey(Object instanceKey) {
    return (Component) awtCompHash.get(instanceKey);
  }

  /**
   * Lazily create and return FatEdgeHit handler for this design surface.
   * @see processMouseEvent(), LiveUIContainerPanel.processMouseEvent()
   * @return FatEdgeHitHandler
   */
  public FatEdgeHitHandler getFatEdgeHitHandler() {
    if (myEdgeHitHandler == null) {
      myEdgeHitHandler = new FatEdgeHitHandler(this);
    }
    return myEdgeHitHandler;
  }

  /**
   * Provide AWT component representing live component currently selected
   * @return Component for selected LiveUIComponent or null
   */
  public Component getSelectedAWTComponent() {
    LiveComponent sel = host.getSelectedComponent();
    if (sel == null) {
      return null;
    }

    Component c = getAWTCompByInstanceKey(sel.getInstanceKey());
    if (c != null) {
      return c;
    }
    return lastSelectedAWTComp;
  }

  // Construct DesignSurface specific AWT component for given LiveComponent
  abstract protected Component createAWTComponent(LiveComponent comp);

  public void setRootComponents(LiveComponent[] comps) {
    this.removeAll();
    for (int i = 0; comps != null && i < comps.length; i++) {
      Component awtComp = getAWTComponent(comps[i], true);
      this.add(awtComp);
      syncComponent(awtComp);
    }
    validate();
    doLayout();
    repaint(100);
  }

  // Synchronize awtComp with its model info.
  abstract protected void syncComponent(Component awtComp);

  // Regen Layout calculation of children
  abstract public void doLayout();

  public Dimension getPreferredSize() {
    Rectangle rect = new Rectangle();
    Component[] comps = getComponents();
    for (int i = 0; i < comps.length; i++) {
      rect = rect.union(comps[i].getBounds());
    }
    return new Dimension(rect.x + rect.width, rect.y + rect.height);
  }

  public boolean refreshComponent(LiveComponent liveComponent) {
    Component awtComp = getAWTComponent(liveComponent, false);
    if (awtComp == null) {
      return false;
    }
    refreshAWTComponent(awtComp);
    repaint(100); /** @todo optimise this repaint - always done by caller ? */
    return true;
  }

  //override in subclass
  abstract protected void refreshAWTComponent(Component comp);

// {
//    if (comp instanceof LiveUIComponentPanel) {
//      LiveUIComponentPanel uicp = (LiveUIComponentPanel) comp;
//      if (uicp.getParent() != null
//          && uicp.getParent().getParent()instanceof LiveUIComponentPanel) {
//        uicp = (LiveUIComponentPanel) uicp.getParent().getParent();
//      }
//      uicp.syncComponent();
//    }
//  }

  public void componentSelected(LiveComponent comp) {
    repaint(100); // selection redraw done in paint.

  }

  public void designerCleared() {
    this.removeAll();
    awtCompHash.clear();
    dragging_comp = null;
    dragging_rect = null;
    paintDragImg = false;
    select_point = null;
    select_rect = null;
    lastSelectedAWTComp = null;
  }

  /* Handle Response to receiving componentDisposed on UIDesignerPanel.
   * Find liveUICompPanel for deleted component and tell it to do
   * its deletion action.
   */
  public void componentDispose(Object compInstanceKey) {
    Component comp = getAWTCompByInstanceKey(compInstanceKey);
    if (comp == null) {
      return;
    }
    disposeAWTComponent(comp);
    // awtCompHash.remove(compInstanceKey); // and any contained children ??
  }

  //remove AWTcomp from designSurface
  abstract protected void disposeAWTComponent(Component comp);

  // override in subclass
  public void componentChanged(LiveComponent comp) {}

  // override in subclass
  public void propertyChanged(LiveProperty prop) {}

  // override in subclass
  public void eventChanged(LiveEvent event, String oldHook) {}

  public void setCursor(Cursor cursor) {
    if (cursor == getCursor()) {
      return;
    }
    super.setCursor(cursor);
  }

  public void setSelectRect(Component owner, Rectangle rect) {
    Rectangle r = null;
    if (select_rect != null) {
      r = new Rectangle(select_rect);
//      if (!selectStrokeTimer.isRunning()) {
//        selectStrokeTimer.start();
//      }
    }
//    else if (selectStrokeTimer.isRunning()) {
//      selectStrokeTimer.stop();
//    }
    if (rect != null) {
      if (owner != null && owner != this) {
        rect = SwingUtilities.convertRectangle(owner, rect, this);
      }
      r = r != null ? r.union(rect) : new Rectangle(rect);
    }
    this.select_rect = rect;
    if (r != null) {
      repaint(100,
        r.x - STROKE_WIDTH,
        r.y - STROKE_WIDTH,
        r.width + STROKE_WIDTH * 2,
        r.height + STROKE_WIDTH * 2);
    }
  }

  public void setDraggingRect(Component comp, Rectangle rect, boolean paintDragImg) {
    if (dragging_rect != null) {
//      if (!draggingStrokeTimer.isRunning()) {
//        draggingStrokeTimer.start();
//      }
      repaint(100, dragging_rect.x - OUTER_OFFSET, dragging_rect.y - OUTER_OFFSET,
        dragging_rect.width + 2 * OUTER_OFFSET,
        dragging_rect.height + 2 * OUTER_OFFSET);
    }
//    else if (draggingStrokeTimer.isRunning()) {
//      draggingStrokeTimer.stop();
//    }
    if (rect != null && comp != null && comp.getParent() != null) {
      dragging_rect = SwingUtilities.convertRectangle(comp.getParent(), rect, this);
      this.paintDragImg = paintDragImg;
    }
    else {
      dragging_rect = null;
    }
    if (dragging_rect != null) {
      repaint(100, dragging_rect.x - OUTER_OFFSET, dragging_rect.y - OUTER_OFFSET,
        dragging_rect.width + 2 * OUTER_OFFSET,
        dragging_rect.height + 2 * OUTER_OFFSET);
    }
  }

  public Rectangle getDraggingRect(Component comp) {
    if (dragging_rect == null || comp != dragging_comp) {
      return null;
    }
    return SwingUtilities.convertRectangle(this, dragging_rect, comp.getParent());
  }

  public void finishDragRepaint(Component comp, Rectangle oldRect, Rectangle newRect,
    Rectangle finalRect, Image img) {
    oldRect = SwingUtilities.convertRectangle(comp.getParent(), oldRect, this);
    newRect = SwingUtilities.convertRectangle(comp.getParent(), newRect, this);
    finalRect = SwingUtilities.convertRectangle(comp.getParent(), finalRect, this);
    repaint(100, oldRect.x - OUTER_OFFSET, oldRect.y - OUTER_OFFSET,
      oldRect.width + 2 * OUTER_OFFSET, oldRect.height + 2 * OUTER_OFFSET);
    repaint(100, finalRect.x - OUTER_OFFSET, finalRect.y - OUTER_OFFSET,
      finalRect.width + 2 * OUTER_OFFSET, finalRect.height + 2 * OUTER_OFFSET);
    if (!newRect.equals(finalRect)) {
      animateRectangle(newRect, finalRect, img);
    }
  }

  //override in subclass for providing animated Rectangle for dragging
  protected void animateRectangle(Rectangle newRect, Rectangle finalRect, Image img) {
//    if (host.getComponentModel().isRemote()) {
//      new AnimateRect(newRect, finalRect);
//    }
//    else {
//      new AnimateRect(newRect, finalRect, img);
//    }
  }

  public void setDraggingAWTComponent(Component comp) {
    setDraggingAWTComponent(comp, null);
  }

  public void setDraggingAWTComponent(Component comp, Rectangle repaintRect) {
    if (dragging_comp != null && isLiveDrag()) {
      Rectangle r = dragging_comp.getBounds();
      r = SwingUtilities.convertRectangle(dragging_comp.getParent(), r, this);
      repaint(100, r.x - OUTER_OFFSET, r.y - OUTER_OFFSET,
        r.width + 2 * OUTER_OFFSET,
        r.height + 2 * OUTER_OFFSET);
    }
    this.dragging_comp = comp;
    if (dragging_comp != null && isLiveDrag()) {
      Rectangle r = dragging_comp.getBounds();
      if (repaintRect != null) {
        r = r.union(repaintRect);
      }
      r = SwingUtilities.convertRectangle(dragging_comp.getParent(), r, this);
      repaint(100, r.x - OUTER_OFFSET, r.y - OUTER_OFFSET,
        r.width + 2 * OUTER_OFFSET, r.height + 2 * OUTER_OFFSET);
    }
  }

  public Component getDraggingAWTComponent() {
    return dragging_comp;
  }

  public void doPopup(Point p) {
    if (BaseDesignSurface.showContextMenu(designer, host, null, this, this, p)) {
      repaint(100);
    }
  }

  protected void processMouseEvent(MouseEvent me) {
    super.processMouseEvent(me);
    switch (me.getID()) {
      case MouseEvent.MOUSE_PRESSED:
        if (getFatEdgeHitHandler().hitFatBounds(me)) {
          return;
        }

        this.requestFocus();
        host.setSelectedComponent(null);
        select_point = me.getPoint();

        if (me.isPopupTrigger()) {
          doPopup(me.getPoint());
        }

        // PAINT DEBUGGING
        if (me.isAltDown() && me.isMetaDown() && me.getClickCount() == 3) {
          if (me.isShiftDown() && me.isControlDown()) {
            debugPaint = !debugPaint;
          }
        }
        break;

      case MouseEvent.MOUSE_RELEASED:
        if (getFatEdgeHitHandler().redirectEnd(me)) {
          return;
        }

        _GLOBAL_DRAGGING = false;
        if (host.getSelectedComponentInfo() != null) {
          Point p1 = select_point;
          Point p2 = me.getPoint();

          Rectangle create_rect = setupRect(p1, p2);
          createComponent(create_rect);
          setCursor(Cursor.getDefaultCursor());
        }
        else if (me.isPopupTrigger()) {
          doPopup(me.getPoint());
        }

        select_point = null;
        setSelectRect(null, null);
        break;
    }
  }

  abstract protected void createComponent(Rectangle create_rect);

  private Rectangle setupRect(Point p1, Point p2) {
    setSelectRect(null, new Rectangle(
      p1.x < p2.x ? p1.x : p2.x,
      p1.y < p2.y ? p1.y : p2.y,
      Math.abs(p2.x - p1.x),
      Math.abs(p2.y - p1.y)));

    Rectangle create_rect = new Rectangle(select_rect);
    if (create_rect.width < 10) {
      create_rect.width = -1;
    }
    if (create_rect.height < 10) {
      create_rect.height = -1;
    }
    return create_rect;
  }

  protected void processMouseMotionEvent(MouseEvent me) {
    super.processMouseMotionEvent(me);
    switch (me.getID()) {
      case MouseEvent.MOUSE_DRAGGED:
        if (getFatEdgeHitHandler().redirect(me)) {
          return;
        }

        _GLOBAL_DRAGGING = true;
        setCursor(Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR));
        if (host.getSelectedComponentInfo() != null) {
          Point p1 = select_point;
          Point p2 = me.getPoint();
          setSelectRect(null, new Rectangle(
            p1.x < p2.x ? p1.x : p2.x,
            p1.y < p2.y ? p1.y : p2.y,
            Math.abs(p2.x - p1.x),
            Math.abs(p2.y - p1.y)));
        }
        break;

      case MouseEvent.MOUSE_MOVED:
        if (_GLOBAL_DRAGGING) {
          return;
        }
        ComponentInfo selCompInfo = host.getSelectedComponentInfo();
        setDropCursor(selCompInfo);
        break;
    }
  }

  private void setDropCursor(ComponentInfo selCompInfo) {

    if (selCompInfo == null) {
      setCursor(Cursor.getDefaultCursor());
      return;
    }

    if (canCreateComponentOfType(selCompInfo)) {
      setCursor(Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));
      return;
    }

    try {
      setCursor(Cursor.getSystemCustomCursor("Invalid.32x32")); // NORES
    }
    catch (Exception x) {
      setCursor(Cursor.getDefaultCursor());
    }
  }

  // override in subclass to determine if should display
  // drop crosshair cursor
  protected boolean canCreateComponentOfType(ComponentInfo selCompInfo) {
    return true;
  }

  public boolean isLiveDrag() {
    return!host.getComponentModel().isRemote();
  }

  //----------- Design Surface rendering and selection painting ------------

  public void paintComponent(Graphics g) {
    //super.paintComponent(g);
    g.setColor(SystemColor.window);
    Rectangle clip = g.getClipBounds();
    g.fillRect(clip.x, clip.y, clip.width, clip.height); //clearRect?
    drawGrid(g, clip);
//    if (debugPaint) {
//      g.setColor(cw.next());
//      g.drawRect(clip.x, clip.y, clip.width - 1, clip.height - 1);
//    }
  }

  protected void drawGrid(Graphics g, Rectangle clip) {
//    g.setColor(new Color(0, 0, 0, 80));
//These flags also make AlphaComposite operations hardware accelerated.
//System.setProperty("sun.java2d.translaccel", "true");
//System.setProperty("sun.java2d.ddforcevram", "true");
    boolean showGrid = com.borland.acmdesigner.DesignerPropertyPage.isShowGrid();
    if (showGrid) {
      g.setColor(Color.black);
      final int height = getHeight();
      final int width = getWidth();
      for (int y = 10; y < height && y < clip.y + clip.height; y += 10) {
        for (int x = 10; x < width && x < clip.x + clip.width; x += 10) {
          if (clip.x > x || clip.y > y) {
            continue;
          }
          g.fillRect(x, y, 1, 1);
          //g.drawRect(x, y, 1, 1); //?
        }
      }
    }
  }

  public void paint(Graphics g) {
    paintDesignSurface(g);
  }

  public void paintDesignSurface(Graphics g) {
    Graphics2D g2d = (Graphics2D) g;
//  AlphaComposite alphaComposite=(AlphaComposite)g2d.getComposite();
//  System.out.println(" g2d.getComposite() getAlpha()="+alphaComposite.getAlpha()); //NORES
//    System.out.println(" g2d.getComposite() getRule()="+alphaComposite.getRule()); //NORES
//    g2d.setComposite(AlphaComposite.Src);
    super.paint(g);
  }

  public void paintChildren(Graphics g) {
    super.paintChildren(g);
    final Rectangle clip = g.getClipBounds();
    Component selectedAWTComp = getSelectedAWTComponent();
    if (selectedAWTComp != null) {
      paintCurrSelect(g, clip, selectedAWTComp);
    }
    if (dragging_comp != null) {
      paintDrag(g, clip);
    }
    if (select_rect != null && host.getSelectedComponentInfo() != null) {
      paintSelectRect(g, clip, select_rect);
    }
  }

  private void paintCurrSelect(Graphics g, Rectangle clip, Component selComp) {
    Rectangle r = selComp.getBounds();
    r = SwingUtilities.convertRectangle(selComp.getParent(), r, this);
    Rectangle clipCheck = new Rectangle(r);
    clipCheck.add(r.x - OUTER_OFFSET, r.y - OUTER_OFFSET);
    clipCheck.add(r.x + r.width + OUTER_OFFSET, r.y + r.width + OUTER_OFFSET);
    if (clip.intersects(clipCheck)) {
      g.setColor(SELECTED_STROKE_COLOR);
      paintStrokeRect(g, r);
    }
  }

  private void paintSelectRect(Graphics g, Rectangle clip, Rectangle r) {
    if (clip.intersects(r)) {
      g.setColor(CREATING_STROKE_COLOR);
      //System.out.println(" UIDesignSurface paint CREATING_STROKE clip="+clip+" r="+r); //NORES
      if (g instanceof Graphics2D) {
        Graphics2D g2d = (Graphics2D) g;
        Stroke oldStroke = g2d.getStroke();
        g2d.setStroke(CREATING_STROKE);
        g2d.draw(r);
        g2d.setStroke(oldStroke);
      }
      else {
        /** @todo investigate*/
        System.out.println("!!!!!!!!!!!! g not instanceof Graphics2D=" + g); //NORES
        paintStrokeRect(g, r);
      }
    }
  }

  private void paintDrag(Graphics g, final Rectangle clip) {
//    System.out.println("UIDesignSurface paintDrag clip=" + clip); //NORES
    Rectangle r = null;
    boolean dlive = isLiveDrag();
    if (dragging_rect != null) {
      r = (Rectangle) dragging_rect.clone();
    }
    else {
      r = SwingUtilities.convertRectangle(dragging_comp.getParent(),
        dragging_comp.getBounds(), this);
      dlive = true; //?
    }

    if (clip.intersects(r)) {
      if (dlive) {
        if (showDragRect(dragging_comp)) {
          drawShadow(g, r);
        }
      }
      else {
        //paint label
//          if (paintDragImg && dragging_comp instanceof LiveUIComponentPanel) {
//            g.translate(r.x, r.y);
//            ((LiveUIComponentPanel)dragging_comp).drawTransparentString(g);
//            g.translate(-r.x, -r.y);
//          }

        drawShadow(g, r);

        g.setColor(DRAGGING_STROKE_COLOR);
//          Graphics2D g2d = (Graphics2D) g;
//          Stroke oldStroke = g2d.getStroke();
//System.out.println(" draw! oldStroke="+oldStroke); //NORES
        //g2d.setStroke(DRAGGING_STROKE);
        g.drawRect(r.x, r.y, r.width, r.height);
        g.setColor(Color.white);
        g.drawRect(r.x + 1, r.y + 1, r.width - 2, r.height - 2);
      }
    }
  }

  // override in subclass to suppress
  protected boolean showDragRect(Component drgComp) {
    return true;
  }

  // paint strokes around rectangle
  protected void paintStrokeRect(Graphics g, Rectangle r) {
    g.fillRect(r.x - STROKE_WIDTH, r.y - STROKE_WIDTH,
      r.width + 2 * STROKE_WIDTH, STROKE_WIDTH);
    // top bar
    g.fillRect(r.x - STROKE_WIDTH, r.y + r.height,
      r.width + 2 * STROKE_WIDTH, STROKE_WIDTH);
    // bottom bar
    g.fillRect(r.x - STROKE_WIDTH, r.y, STROKE_WIDTH, r.height);
    // left bar (clipped at top and bottom)
    g.fillRect(r.x + r.width, r.y, STROKE_WIDTH, r.height);
    // right bar (clipped at top and bottom)
  }

  protected void drawShadow(Graphics g, Rectangle r) {
    boolean showShadow = com.borland.acmdesigner.DesignerPropertyPage.isShowShadow();
    if (!showShadow) {
      return;
    }
    g.setColor(SHADOW_COLOR);
    g.fillRect(r.x + r.width, r.y + SHADOW_OFFSET,
      SHADOW_OFFSET, r.height); // right shadow bar
    g.fillRect(r.x + SHADOW_OFFSET, r.y + r.height,
      r.width - SHADOW_OFFSET, SHADOW_OFFSET); // bottom shadow bar (clipped at right)
  }

// ----------- Utility methods -------------------

  /**
   * Accumulate Context info groups and display context menu.
   * @param dsgnr  LiveDesigner working with
   * @param host   DesignerHost using
   * @param lcomp  LiveComponent popup menu is for (null for designSurface)
   * @param surface AWT Component  for DesignSurface ( for point adjustment)
   * @param src    AWT Component that is src of context menu
   * @param p      Point on src at which we want context menu.
   * @return true if menu was shown.
   */
  static public boolean showContextMenu(LiveDesigner designer,
    DesignerHost host,
    LiveComponent lcomp,
    Component surface,
    Component src,
    Point p) {
    // list of context actions
    ActionGroup tags = new ActionGroup();

    // Menu items for clipbd actions on Designers/LiveComponents/LiveContainers
    ActionGroup clip_group = new ActionGroup();
    addClipGpItems(designer, clip_group, host, lcomp, src, p);
    tags.add(clip_group);

    // liveComponent context items
    Tag[] cts = null;
    if (lcomp != null) {
      cts = lcomp.getContextTags(p.x, p.y);
    }
    if (cts != null && cts.length > 0) {
      tags.add(Utils.createActionGroup(host, cts));
    }

    Point dPt = new Point(p);
    if (src != surface) {
      SwingUtilities.convertPointToScreen(dPt, src);
      SwingUtilities.convertPointFromScreen(dPt, surface);
    }

    // designer context items
    Tag[] dts = designer.getContextTags(dPt.x, dPt.y);
    if (dts != null && dts.length > 0) {
      tags.add(Utils.createActionGroup(host, dts));
    }
    // designer info context items
    Tag[] dits = designer.getDesignerInfo().getContextTags();
    if (dits != null && dits.length > 0) {
      tags.add(Utils.createActionGroup(host, dits));
    }
    dPt = null;

    // host context items
    Tag[] htags = host.getHostContextTags();
    if (htags != null && htags.length > 0) {
      tags.add(Utils.createActionGroup(host, htags));
    }
    // if we have tags, show them in a context menu
    if (tags.getActionCount() > 0) {
      ActionPopupMenu apm = new ActionPopupMenu(src, tags);
      apm.show(src, p.x, p.y);
      return true;
    }
    return false;
  }

  private static void addClipGpItems(LiveDesigner designer, ActionGroup cgp, DesignerHost host,
    LiveComponent comp, Component src,
    Point dropPt) {
    LiveComponent[] lca = new LiveComponent[] {
      comp};
    if (comp == null) { // DesignSurface - paste only
      PanelActionPaste pa = (PanelActionPaste)PanelAction.factory(PanelActionEvent.ACTN_PASTE, src, host, lca);
      pa.setPasteInfo(designer, dropPt);
      cgp.add(pa);
      return;
    }

    cgp.add(PanelAction.factory(PanelActionEvent.ACTN_CUT, src, host, lca));
    cgp.add(PanelAction.factory(PanelActionEvent.ACTN_COPY, src, host, lca));
    PanelActionPaste pa = (PanelActionPaste)PanelAction.factory(PanelActionEvent.ACTN_PASTE, src, host, lca);
    if (comp instanceof LiveContainer) { // allow paste only on containers
      pa.setPasteInfo(comp, dropPt);
    }
    cgp.add(pa);
    cgp.add(PanelAction.factory(PanelActionEvent.ACTN_DEL, src, host, lca));
  }
}
