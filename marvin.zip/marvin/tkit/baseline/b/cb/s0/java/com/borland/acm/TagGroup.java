package com.borland.acm;

/**
 * A TagGroup is an extension of a Tag that has children - effectively creating a tree of tags. The
 * 'isPopup()' method controls whether to show the Tags in the TagGroup in its own section (between
 * separators), or as a popup menu.
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public interface TagGroup extends Tag {

  /**
   * Returns an array of tags contained by this tag group.
   *
   * @return An array of Tag objects contained by this tag group
   */
  public Tag[] getTags();

  /**
   * Returns true if the tag group itself can be selected or invoked in UI - or if it is just a
   * group descriptor to contain other tags.
   *
   * @return <b>true</b> if this tag group should be invokable, or <b>false</b> if it is merely a
   *         collection of tags
   */
  public boolean isInvokable();

  /**
   * Returns true if this tag group should be displayed as a pop-up in a menu, or false if it
   * should remain 'flat' between separators.
   *
   * @return <b>true</b> if this tag group should be displayed as a pop-up in a menu, or
   *         <b>false</b> if it should remain 'flat' between separators
   */
  public boolean isPopup();
}
