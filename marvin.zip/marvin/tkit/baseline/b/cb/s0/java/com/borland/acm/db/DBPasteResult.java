package com.borland.acm.db;

import com.borland.acm.*;

/**
 * The DBPasteResult interface is used as a return value from the method:
 * LiveDBDesigner.pasteComponent(LiveComponent parent, byte[] persistData).
 *
 * @see LiveDBDesigner#pasteComponent(LiveComponent, byte[])
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public interface DBPasteResult extends PasteResult {

  /**
   * Returns the set of live DB component(s) that were created as the result of the
   * LiveDBDesigner.pasteComponent(...) method call.  This may be null if the paste operation
   * resulted in failure, or created zero DB components.
   *
   * @return An array of LiveDBComponent(s) resulting from the paste operation
   */
  public LiveDBComponent[] getDBComponents();
}