package com.borland.acmdesigner;

/**
 * <p>Title: ComponentModelListener</p>
 * <p>Description: Interface to allow custom tweeking of arbitrary component
 * models through the lifetime of the component model in the designer.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Borland Software Corporation</p>
 * @author Eli Boling
 * @version 1.0
 */

public interface ComponentModelListener {
  /**
   * Called when the component model is truly about to be used for the first
   * time.  It is useful when the component model has significant, and possibly
   * disruptive setup work to do that we wouldn't want to do, say, at open tool
   * init time.
   */
  void Register();

  /**
   * If this is a fragile designer, it may disappear periodically.  We address
   * this by polling such listeners everytime we ask to find the component
   * model for a given node.  This is allows us to bail out and restart the
   * component models associated with this listener if something terrible
   * happened, or at the very least pull out the rug and prevent the IDE from
   * destabilizing.
   */
  void HeartBeat();

  /**
   * Mostly this is for debugging support - we'd like to be able to print
   * something about the thing at times.
   * @return
   */
  String GetName();
}
