package com.borland.acmdesigner.designer;

import com.borland.acm.*;
import com.borland.acmdesigner.PanelActionEvent;
import com.borland.primetime.ide.*;
import com.borland.primetime.node.*;

/**
 * <p>DesignerHost Interface</p>
 * <p>Interface for interactions with (IDE) Designer control point
 * including both notifications from ComponentModel and
 * notifications and queries from the IDE designer components.
 * Some of these cause interaction with Host/Server.
 *
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Borland Inc </p>
 * @author Joe Nuxoll not attributable
 * @version 1.0
 */
public interface DesignerHost extends DesignerListener {

  /**
   * Get the Primetime Browser for this DesignerHost
   * @return Browser
   */
  public Browser getBrowser();

  /**
   * Get the Primetime Node for the design file associated with this DesignHost
   * @return Node for this Designer file
   */
  public Node getNode();

  /**
   * Get acm ComponentModel for this DesignerHost.
   * @return ComponentModel for this DesignFile
   */
  public ComponentModel getComponentModel();

  /**
   * Get acm LiveDesignerManager for this DesignerHost.
   * @return LiveDesignerManager for this DesignFile
   */
  public LiveDesignerManager getLiveDesignerManager();

  /**
   * Provide generic handling of the result from a acm request.
   * Display Dialog message and status bar update for errors.
   *
   * @param operation Descriptive string for the request made.
   * @param result Result from ComponentModel request
   */
  public void handleResult(String operation, Result result);

  /**
   * Get ContextTags (popup Menu entries) for designers known by the Host.
   * These are the Popup menu items for switching to a different
   * designer (usually).
   *
   * @return Array of tags for DesignerInfo from each designer.
   */
  public Tag[] getHostContextTags();

  /**
   * Set a record of the currently active Designer in the IDE
   * @param designer LiveDesigner now active
   */
  public void setActiveDesigner(LiveDesigner designer);

  /**
   * Get the current activeDesigner for the IDE.
   * @return LiveDesigner currently set as active
   */
  public LiveDesigner getActiveDesigner();

  /**
   * Returns the Panel associated with the Specified Designer
   * @param designer Designer whose panel we're after
   * @return Panel of the specified designer
   */
  public DesignerPanel getDesignerPanel(LiveDesigner designer);

  /**
   * Set the ComponentInfo for the currently selected component
   * @param compInfo ComponentInfo of the currently selected Component
   */
  public void setSelectedComponentInfo(ComponentInfo compInfo);

  /**
   * Get the ComponentInfo recorded for the currently selected component.
   * Non null indicates something selected (??)
   * @return ComponentInfo recorded.
   */
  public ComponentInfo getSelectedComponentInfo();

  /**
   * Set the record of the currently selected componenent within the designer
   *
   * @param comp LiveComponent selected
   */
  public void setSelectedComponent(LiveComponent comp);

  /**
   * Get the value of the currently recorded selected component.
   *
   * @return LiveComponent currently recorded as selected
   */
  public LiveComponent getSelectedComponent();

  /**
   * Set the selected component from a tree representation of the designs
   * component structure recording the path hierarchy to the (selected)
   * leaf component.
   *
   * @param comp LiveComponent selected
   * @param selectionPath array of LiveComponent's from root down to selected component
   *
   */
  public void setSelectedComponent(LiveComponent comp, LiveComponent[] selectionPath);

  /**
   * Get the current record of the path hierarchy to the selected LiveComponent.
   *
   * @return array of LiveComponents corresponding to selection path hier.
   */
  public LiveComponent[] getSelectedPath();

//  // DesignerListener interface methods
//  public void managerChanged(LiveDesignerManager manager);
//
//  public void designerChanged(LiveDesigner designer);
//
//  public void componentCreated(LiveComponent comp);
//
//  public void componentChanged(LiveComponent comp);
//
  public void componentRenamed(LiveComponent comp, String oldName);
//
//  public void componentDisposing(LiveDesigner designer, LiveComponent lc);
//
//  public void componentDisposed(LiveDesigner designer, Object compInstanceKey);
//
//  public void propertyChanged(LiveProperty prop);
//
//  public void eventChanged(LiveEvent event, String oldHook);

  /**
   * Get an update of the EventHook Tags (matching signature) for a given
   * Live Event. CodeManager request
   * @param le - Live event to query update on
   * @return array of Tags for Event
   */
  public Tag[] getEventTags(LiveEvent le);

  /**
   * Get a new hookname for given LiveEvent. CodeManager request
   * @param le Live Event to get new hookname for
   * @return String value for new hookname
   */
  public String createEventHandler(LiveEvent le);

  /**
   * Notify anything specifically interested that a LiveEvents'
   * event hook is being cleared. CodeManager notification.
   * @param le Live event whose hook is being cleared
   * @param oldHook - hookname prior to clearing
   */
  public void clearEventHandler(LiveEvent le, String oldHook);

  /**
   * Indicate that want to see LiveEvent hook text source/code.
   * @param le     LiveEvent to see hok for
   * @param hook   String hook value
   */
  public void navigateToEventHandler(LiveEvent le, String hook);

  /**
   * Tell code manager that an event has been renamed
   * @param liveEvent
   * @param oldName
   */
  public void eventHandlerRenamed(LiveEvent liveEvent, String oldName);

  /**
   * Add a DesignerHost Listener for notifications from this DesignerHost.
   * @see {@link DesignerHostListener}.
   *
   * @param dhl DesignerHostListener to add
   */
  public void addDesignerHostListener(DesignerHostListener dhl);

  /**
   * Remove a DesignerHostListener from the notificationlist of this DesignerHost
   *
   * @param dhl Designer host listener to remove (may be null or not in ListenerList)
   */
  public void removeDesignerHostListener(DesignerHostListener dhl);
}
