package com.borland.acm.ui;

import com.borland.acm.*;

/**
 *
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public interface UICreateResult extends CreateResult {

  /**
   *
   * @return
   */
  public LiveUIComponent getUIComponent();
}