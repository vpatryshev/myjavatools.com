package com.borland.acm.util;

import com.borland.acm.*;
import com.borland.acm.menu.*;

/**
 *
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public class BasicMenuCreateResult extends BasicResult implements MenuCreateResult {

  public static BasicMenuCreateResult create(boolean success, LiveMenuComponent menuComp) {
    return new BasicMenuCreateResult(success, menuComp);
  }

  public static BasicMenuCreateResult create(boolean success, LiveMenuComponent menuComp, ResultMessage[] messages) {
    return new BasicMenuCreateResult(success, menuComp, messages);
  }

  public static BasicMenuCreateResult create(boolean success, LiveMenuComponent menuComp, ResultMessage[] messages, Tag[] options) {
    return new BasicMenuCreateResult(success, menuComp, messages, options);
  }

  protected LiveMenuComponent menuComp;

  public BasicMenuCreateResult(LiveMenuComponent menuComp) {
    this.menuComp = menuComp;
  }

  public BasicMenuCreateResult(boolean success, LiveMenuComponent menuComp) {
    super(success);
    this.menuComp = menuComp;
  }

  public BasicMenuCreateResult(boolean success, LiveMenuComponent menuComp, ResultMessage[] messages) {
    super(success, messages);
    this.menuComp = menuComp;
  }

  public BasicMenuCreateResult(boolean success, LiveMenuComponent menuComp, ResultMessage[] messages, Tag[] options) {
    super(success, messages, options);
    this.menuComp = menuComp;
  }

  public LiveComponent getComponent() {
    return menuComp;
  }

  public void setMenuComponent(LiveMenuComponent menuComp) {
    this.menuComp = menuComp;
  }

  public LiveMenuComponent getMenuComponent() {
    return menuComp;
  }
}