package com.borland.acm;

/**
 * The ResultMessage interface encapsulates a message for the user based on the results of an
 * operation.
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 * @see Result
 */
public interface ResultMessage {

  /**
   * A convenience for returning an empty array of ResultMessage objects
   */
  public static final ResultMessage[] EMPTY_ARRAY = new ResultMessage[0];

  /**
   * Informational message - will not prompt a dialog box unless there are option tags supplied by
   * the Result object.
   */
  public static final int TYPE_INFORMATION = 0;

  /**
   * Warning message - will not prompt a dialog box unless there are option tags supplied by the
   * Result object.
   */
  public static final int TYPE_WARNING = 1;

  /**
   * Critical message - this will prompt a dialog box even if there are no option tags supplied by
   * the Result object.
   */
  public static final int TYPE_CRITICAL = 2;

  /**
   * Returns the message type.  Can be TYPE_INFORMATION (0), TYPE_WARNING (1), or TYPE_CRITICAL (2).
   */
  public int getMessageType();

  /**
   * Returns the title of the result message.
   *
   * @return the message title
   */
  public String getMessageTitle();

  /**
   * Returns the text body of the message for the user
   *
   * @return the message text
   */
  public String getMessageText();

  /**
   * Returns an icon for the user message.  This should be a 16x16 or 32x32 color icon.
   *
   * @return ImageData representing an icon for this message
   */
  public ImageData getMessageIcon();
}