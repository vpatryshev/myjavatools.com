package com.borland.acm.util;

import com.borland.acm.*;

/**
 *
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public class BasicPersistenceResult extends BasicResult implements PersistenceResult {

  public static BasicPersistenceResult create(boolean success, byte[] bytes) {
    return new BasicPersistenceResult(success, bytes);
  }

  public static BasicPersistenceResult create(boolean success, byte[] bytes, ResultMessage[] messages) {
    return new BasicPersistenceResult(success, bytes, messages);
  }

  public static BasicPersistenceResult create(boolean success, byte[] bytes, ResultMessage[] messages, Tag[] options) {
    return new BasicPersistenceResult(success, bytes, messages, options);
  }

  protected byte[] bytes;

  public BasicPersistenceResult(byte[] bytes) {
    this.bytes = bytes;
  }

  public BasicPersistenceResult(boolean success, byte[] bytes) {
    super(success);
    this.bytes = bytes;
  }

  public BasicPersistenceResult(boolean success, byte[] bytes, ResultMessage[] messages) {
    super(success, messages);
    this.bytes = bytes;
  }

  public BasicPersistenceResult(boolean success, byte[] bytes, ResultMessage[] messages, Tag[] options) {
    super(success, messages, options);
    this.bytes = bytes;
  }

  public void setBytes(byte[] bytes) {
    this.bytes = bytes;
  }

  public byte[] getBytes() {
    return bytes;
  }
}