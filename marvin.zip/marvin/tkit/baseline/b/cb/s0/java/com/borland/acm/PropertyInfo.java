package com.borland.acm;

/**
 * The PropertyInfo interface represents the meta-data for a specific property type.  Live
 * properties are represented by instances of the LiveProperty interface, which each make reference
 * to a PropertyInfo class.
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 * @see LiveProperty
 */
public interface PropertyInfo {

  /**
   * Returns a unique property key.  The implementor must ensure that this key be a unique value
   * across all property types for a given component info.
   *
   * @return A key to uniquely identify this property
   */
  public Object getPropertyKey();

  /**
   * Returns the human-readable name of this property.  For example, "Font" or "Backgound Color".
   *
   * @return A human-readable name for this property
   */
  public String getDisplayName();

  /**
   * Returns a description of this property.  For example, "Sets the background color".
   *
   * @return A description of this property
   */
  public String getDescription();

  /**
   * Returns image data representing a display icon for this property.  This should be a 16x16
   * color image.  If null is returned, a default image will be used.
   *
   * @return ImageData representing a display icon for this property, or null for a default image
   */
  public ImageData getDisplayIcon();

  /**
   * Returns true if this property may be modified by the user.
   *
   * @return <b>true</b> if this property is read-only, or <b>false</b> if not
   */
  public boolean isReadOnly();

  /**
   * <p>Returns an array of tags representing a static list of pre-defined property values.  This
   * list will appear in the drop-down list for this property in the inspector.  Any tags supplied
   * by the LiveProperty object will also appear in the list.</p>
   *
   * <p>For this use of the Tag interface, methods will be used as follows:</p>
   * <table border=1>
   * <tr><th> Method                     <th> Purpose
   * <tr><td> Object getKey()            <td> Passed as text to the 'LiveProperty.setValueText(String)' method
   * <tr><td> String getDisplayName()    <td> Text of the drop-down item (uses 'key.toString()' if null)
   * <tr><td> String getDescription()    <td> Status text of the drop-down item (optional)
   * <tr><td> ImageData getDisplayIcon() <td> Icon of the drop-down item (optional)
   * <tr><td> TagGroup getParentTag()    <td> Tag hierarchy shown as expanded list in drop-down
   * <tr><td> void tagInvoked()          <td> (not used)
   * </table>
   *
   * @return An array of Tag objects representing the static items to place in every property of
   *         this type's drop-down list
   * @see LiveProperty#getValueTags()
   * @see LiveProperty#setValueAsText(String)
   */
  public Tag[] getValueTags();

  /**
   * Returns true if the user is not allowed to type in the property value, and should be
   * constrained to selecting an item from the value tags in the drop-down list.  These tags may be
   * supplied by both the LiveProperty and the PropertyInfo for the property.
   *
   * @return <b>true</b> if the user should be forced to select a value from the drop-down for the
   *         property, <b>false</b> if they should be allowed to type in any text
   * @see getValueTags()
   * @see LiveProperty#getValueTags()
   */
  public boolean isConstrainedToTags();

  /**
   * Returns the model-specific property type key for this property.  This key is used to associate
   * custom property editors with instances of live properties being edited.
   *
   * @return The property type key
   */
  public Object getPropertyTypeKey();

  /**
   * Returns the parent property info, if this property info is a sub-property of a group.
   * This method is used to enabled a property hierarchy with nesting of properties.  In some
   * component models, properties are grouped in this way - in others, they are not.
   *
   * @return The parent PropertyInfo object, or null if this is a top-level property
   */
  public PropertyInfo getParentPropertyInfo();

  /**
   * Returns <b>true</b> if this property info has child property infos, <b>false</b> if not
   *
   * @returns <b>true</b> if this property info has child property infos, <b>false</b> if not
   */
  public boolean hasChildren();

  /**
   * Returns the contained PropertyInfo classes
   *
   * @return An array of PropertyInfo classes
   */
  public PropertyInfo[] getPropertyInfos();

  /**
   * Returns the property info with the specified key if it is contained by this group.
   *
   * @param propertyKey The desired property info's unique key
   * @return The PropertyInfo with the specified key, or null if it is not contained by this group
   */
  public PropertyInfo getPropertyInfo(Object propertyKey);
}
