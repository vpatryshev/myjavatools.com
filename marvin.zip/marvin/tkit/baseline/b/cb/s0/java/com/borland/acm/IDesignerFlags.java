package com.borland.acm;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Borland Software Corporation</p>
 * @author not attributable
 * @version 1.0
 */
public interface IDesignerFlags {

  public static int STRUCTURE_EXPAND_ALL_NODES_AT_STARTUP = (1 << 0);

  public static int DESIGNER_DRAW_BORDER_AROUND_COMPONENTS = (1 << 1);

  public static int INSPECTOR_MAKE_EDITFIELDS_AUTOSELECT = (1 << 2);
}