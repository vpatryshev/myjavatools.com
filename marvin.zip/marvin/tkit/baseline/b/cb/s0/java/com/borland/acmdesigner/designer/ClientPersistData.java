package com.borland.acmdesigner.designer;

import java.awt.Point;
import java.util.*;
import java.io.*;

import com.borland.primetime.node.Node;
import com.borland.primetime.node.FileNode;
import com.borland.primetime.util.Strings;
import com.borland.primetime.vfs.Url;

/**
 * ClientPersistData
 * <p>
 * Persistance controller for persisted data that is not part of the Component
 * model - i.e data specific to Designer Client use. <br>
 * Presently thats position info for nonVisual components on Design surface.
 * This info stored in file with same name as  component persistance file
 * ( *.akn, *.xrc) with appended suffix .nUI.
 * </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Borland Inc</p>
 * @author hops
 * @version 1.0
 */

public class ClientPersistData
  extends Observable {
  private Url myUrl;
  private Properties ourPositionProperties = new Properties(); // name -> Point
  private static Map ourInstanceMap = new HashMap(); // filename -> ClientPersistData
  private final static Point NULL_POINT = new Point(0, 0);

  // construct and load accessor
  public static ClientPersistData load(Node node) {
    String pathName = ( (FileNode) node).getUrl().getFullName();
    ClientPersistData cpd = (ClientPersistData) ourInstanceMap.get(pathName);
    if (cpd == null) {
      cpd = new ClientPersistData(pathName);
      ourInstanceMap.put(pathName, cpd);
      cpd.load();
    }
    return cpd;
  }

  // post construct accessor
  public static ClientPersistData getInstance(String k) {
    return (ClientPersistData) ourInstanceMap.get(k);
  }

  // cleanup an instance
  public static ClientPersistData removeInstance(String k) {
    return (ClientPersistData) ourInstanceMap.remove(k);
  }

  // cleanup everything
  public static void clear() {
    ourInstanceMap.clear();
  }

  // store client persist Data for a node.
  public static void store(String k) {
    ClientPersistData cpd = getInstance(k);
    if (cpd != null) {
      cpd.store();
      // removeInstance(node); //??
    }
  }

  // ---------- instance methods ----------
  public void addObserver(Observer o) {
    deleteObservers(); // only one observer per cpd
    super.addObserver(o);
  }

  public void setPosition(String key, Point p) {
    if (p == null) {
      ourPositionProperties.remove(key);
      return;
    }

    String value = Strings.format("{0},{1}", // NORES
      new Integer(p.x),
      new Integer(p.y));
    ourPositionProperties.setProperty(key, value);
  }

  public Point getPosition(String key) {
    String s = ourPositionProperties.getProperty(key);
    if (s == null) {
      return NULL_POINT;
    }
    return makePoint(s);
  }

  private ClientPersistData(String pathName) {
    String f = pathName + ".nUI"; // NORES
    myUrl = new Url(new File(f));
  }

  private void load() {
    if (myUrl == null) {
      return;
    }

    ourPositionProperties.clear();
    InputStream is = null;
    try {
      is = myUrl.getFilesystem().getInputStream(myUrl);
      is = new BufferedInputStream(is);
      ourPositionProperties.load(is); // load as properties file
    }
    catch (FileNotFoundException e) {}
    catch (IOException e) {
      System.out.println(
        Strings.format("IOException on load {0} {1}", // NORES
        myUrl.getFullName(), e));
    }
    finally {
      if (is != null) {
        try {
          is.close();
        }
        catch (IOException ce) {}
      }
    }
  }

  private void store() {
    if (myUrl == null) {
      return;
    }

    ourPositionProperties.clear();
    setChanged();
    notifyObservers(); // force Observers to update us.

    String hdr = "CBuilder Designer Client Persistant Info. \n" // NORES
      + "# Position Info for Non UI Objects on DefaultDesignSurface\n" // NORES
      + "# String representation of Point keyed by Object Name\n" // NORES
      + "#  Written: "; // NORES
    OutputStream os = null;
    try {
      os = myUrl.getFilesystem().getOutputStream(myUrl);
      os = new BufferedOutputStream(os);
      ourPositionProperties.store(os, hdr); // store as properties file
    }
    catch (IOException e) {
      System.out.println("IOException on load " + myUrl.getFullName()); // NORES
    }
    finally {
      if (os != null) {
        try {
          os.close();
        }
        catch (IOException ce) {}
      }
    }

  }

  // ---------- utility methods ----------
  private static Point makePoint(String s) {
    // expect 2 vals comma separated
    StringTokenizer t = new StringTokenizer(s, ",");
    int x = 0;
    int y = 0;
    if (t.hasMoreTokens()) {
      x = toInteger(t.nextToken());
    }
    if (t.hasMoreTokens()) {
      y = toInteger(t.nextToken());
    }
    return new Point(x, y);
  }

  private static int toInteger(String s) {
    int v = 0;
    try {
      v = Integer.parseInt(s);
    }
    catch (NumberFormatException e) {}
    return v;
  }
}
