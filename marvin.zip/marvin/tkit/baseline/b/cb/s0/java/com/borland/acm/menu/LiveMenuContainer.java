package com.borland.acm.menu;

import com.borland.acm.*;

/**
 *
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public interface LiveMenuContainer extends LiveMenuComponent, LiveContainer {

  /**
   *
   * @param index
   * @return
   */
  public LiveMenuComponent getMenuComponent(int index);

  /**
   *
   * @return
   */
  public LiveMenuComponent[] getMenuComponents();

  /**
   *
   * @param compInstanceKey
   * @return
   */
  public LiveMenuComponent getMenuComponent(Object compInstanceKey);
}
