package com.borland.acm.util;

import java.awt.*;
import com.borland.acm.*;
import com.borland.acm.ui.*;

/**
 *
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public class BasicUIDesignRect implements UIDesignRect {

  public BasicUIDesignRect() {}

  public BasicUIDesignRect(Rectangle rect) {
    this.rect = rect;
  }

  public BasicUIDesignRect(Rectangle rect, String tooltip) {
    this(rect);
    this.toolTipText = tooltip;
  }

  protected Rectangle rect;
  public void setRectangle(Rectangle rect) {
    this.rect = rect;
  }
  public Rectangle getRectangle() {
    return rect;
  }

  protected String toolTipText;
  public void setToolTipText(String toolTipText) {
    this.toolTipText = toolTipText;
  }
  public String getToolTipText() {
    return toolTipText;
  }

  public boolean isClickable() {
    return false;
  }
  public Result designMouseClick(Point p, int clickCount) {
    return null;
  }

  public boolean hasContextTags() {
    return false;
  }
  public Tag[] getContextTags(int x, int y) {
    return null;
  }

  public boolean isMovable() {
    return false;
  }
  public int getMoveConstraintFlags() {
    return -1;
  }
  public Rectangle getMoveConstraintRect() {
    return null;
  }
  public Rectangle moveCompleted(Rectangle newRect) {
    return null;
  }

  public boolean isResizable() {
    return false;
  }
  public int getResizeConstraintFlags() {
    return -1;
  }
  public Rectangle getResizeConstraintRect() {
    return null;
  }
  public Rectangle resizeCompleted(Rectangle newRect) {
    return null;
  }

  public boolean isLive() {
    return false;
  }
  public boolean liveDesignMouseDown(Point down) {
    return false;
  }
  public boolean liveDesignMouseDrag(Point down, Point drag) {
    return false;
  }
  public boolean liveDesignMouseUp(Point down, Point up) {
    return false;
  }
}