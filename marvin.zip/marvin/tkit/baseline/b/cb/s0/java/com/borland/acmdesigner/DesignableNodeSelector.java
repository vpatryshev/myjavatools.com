package com.borland.acmdesigner;

import com.borland.acm.*;
import com.borland.primetime.node.*;

public interface DesignableNodeSelector extends ComponentModel {
  public boolean isDesignableNode(Node node);
}
