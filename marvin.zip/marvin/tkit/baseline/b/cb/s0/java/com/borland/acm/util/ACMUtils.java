package com.borland.acm.util;

import com.borland.acm.LiveComponent;
import com.borland.acm.PropertyInfo;
import com.borland.acm.Tag;
import com.borland.acm.LiveEvent;
import java.util.List;
import java.util.ArrayList;
import com.borland.acmdesigner.designer.DesignerHost;
import com.borland.acm.ImageData;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class ACMUtils {

  public static Object getUniquePropertyKey(PropertyInfo propInfo) {
    StringBuffer sbuf = new StringBuffer();
    sbuf.append(propInfo.getPropertyKey());
    while (propInfo.getParentPropertyInfo() != null) {
      propInfo = propInfo.getParentPropertyInfo();
      sbuf.append(propInfo.getPropertyKey());
    }
    return sbuf.toString();
  }

  public static Object getUniquePropertyKey(LiveComponent component, PropertyInfo propInfo) {
    return getUniquePropertyKey(component.getInstanceKey(), propInfo);
  }

  public static Object getUniquePropertyKey(Object componentInstanceKey, PropertyInfo propInfo) {
    StringBuffer sbuf = new StringBuffer();
    sbuf.append(componentInstanceKey);
    sbuf.append(getUniquePropertyKey(propInfo));
    return sbuf.toString();
  }

  public static Tag[] stringsToTags(String[] stags, ImageData[] images) {
    if (stags != null && stags.length > 0) {
      BasicTagGroup tags = new BasicTagGroup();
      for (int i = 0; i < stags.length; i++) {
        if ( (images != null) && (images[i] != null)) {
          tags.addTag(new BasicTag(stags[i], images[i]));
        }
        else {
          tags.addTag(new BasicTag(stags[i]));
        }
      }
      return tags.getTags();
    }
    return null;
  }

  public static Tag[] stringsToTags(String[] stags) {
    return stringsToTags(stags, null);
  }

  public static Tag[] getAllEventTags(LiveEvent event, DesignerHost host) {
    List list = null;
    for (int i = 0; i < 3; i++) {
      Tag[] tags = null;
      switch (i) {
        case 0:
          tags = event.getHookTags();
          break;
        case 1:
          tags = event.getEventInfo().getHookTags();
          break;
        case 2:
          tags = host.getEventTags(event);
          break;
      }
      if (tags != null) {
        if (list == null) {
          list = new ArrayList();
        }
        for (int j = 0; j < tags.length; j++) {
          list.add(tags[j]);
        }
      }
    }
    return (list == null) ? null : (Tag[]) (list.toArray(new Tag[list.size()]));
  }

  public static boolean hasTags(LiveEvent event, DesignerHost host) {
    Tag[] tags = event.getHookTags();
    if (tags != null && tags.length > 0) {
      return true;
    }
    tags = event.getEventInfo().getHookTags();
    if (tags != null && tags.length > 0) {
      return true;
    }
    tags = host.getEventTags(event);
    if (tags != null && tags.length > 0) {
      return true;
    }
    return false;
  }
}