package com.borland.acmdesigner.designer.db;

import java.awt.*;
import javax.swing.*;
import com.borland.acm.*;
import com.borland.acm.db.*;
import com.borland.acmdesigner.*;
import com.borland.acmdesigner.designer.*;

public class DBDesignerPanel extends DesignerPanel {

  protected LiveDBDesigner dbDesigner;

  public DBDesignerPanel(DesignerHost host, LiveDesigner designer) {
    super(host, designer);
    this.dbDesigner = (LiveDBDesigner)designer;
  }

  protected BaseDesignSurface makeDesignSurface(DesignerHost host, LiveDesigner designer) {
    this.dbDesigner = (LiveDBDesigner)designer;
    //myDesignSurface = new DBDesignSurface(host, dbDesigner);
    //this.scroller = null;
    //this.scroller.getVerticalScrollBar().addAdjustmentListener(this);
    return null;  // must override all baseclass designSurface handling methods
 }

  public LiveDBDesigner getDBDesigner() {
    return dbDesigner;
  }


  public void componentSelected(LiveComponent comp) {
    System.out.println("DBDesignerPanel.eventChanged");  //NORES
  }

  public void designerChanged(LiveDesigner designer) {
    System.out.println("DBDesignerPanel.designerChanged");  //NORES
  }


  public void componentChanged(LiveComponent comp) {
    System.out.println("DBDesignerPanel.componentChanged");  //NORES
  }

  public void propertyChanged(LiveProperty prop) {
    System.out.println("DBDesignerPanel.propertyChanged");  //NORES
  }

  public void eventChanged(LiveEvent event, String oldHook) {
    System.out.println("DBDesignerPanel.eventChanged");  //NORES
  }

  protected void jbInit() throws Exception {
    this.setBackground(SystemColor.window);
    this.setLayout(new BorderLayout());
    JLabel j = new JLabel("Database Designer"); // RES LabelDatabaseDesigner
    this.add(j, BorderLayout.CENTER);
    j.setVerticalAlignment(JLabel.CENTER);
    j.setHorizontalAlignment(JLabel.CENTER);
  }
}
