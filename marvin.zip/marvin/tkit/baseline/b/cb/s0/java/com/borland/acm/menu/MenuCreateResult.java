package com.borland.acm.menu;

import com.borland.acm.*;

/**
 *
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public interface MenuCreateResult extends CreateResult {

  /**
   *
   * @return
   */
  public LiveMenuComponent getMenuComponent();
}