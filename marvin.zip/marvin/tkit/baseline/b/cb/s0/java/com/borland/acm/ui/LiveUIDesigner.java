package com.borland.acm.ui;

import java.awt.*;
import com.borland.acm.*;

/**
 *
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public interface LiveUIDesigner extends LiveDesigner {

  /**
   *
   * @param parent
   * @param compInfo
   * @param rect
   * @return
   */
  public UICreateResult createComponent(LiveUIContainer parent, ComponentInfo compInfo, Rectangle rect);

  /**
   * Creates a component or set of components using the specified persistence data.  This method is
   * used when component(s) have been 'cut' or 'copied' to the clipboard and 'pasted' onto the design
   * surface at a different location.  A new live component(s) should be created using any attributes
   * that apply from the persistence data, as well as new versions of any contained components in
   * the persistence data.  The new live component(s) (and contained components) should have new
   * unique instance keys.
   *
   * @param parent The ui container parent
   * @param point the desired location point (may be null)
   * @param persistData The persistence data
   * @return A UICreateResult
   */
  public UICreateResult pasteComponent(LiveUIContainer parent, Point point,
                                          byte[] persistData);

  /**
   * Returns the live UI component with the specified instance key
   *
   * @param compInstanceKey The desired live UI component's instance key
   * @return The live UI component with the specified instance key
   */
  public LiveUIComponent getUIComponent(Object compInstanceKey);

  /**
   * Returns the root UI components (top-level) of this live designer.
   *
   * @return An array of LiveUIComponent instances representing the top-level components in this
   *         UI designer.
   */
  public LiveUIComponent[] getRootUIComponents();

  /**
   *
   * @return
   */
  public ImageData getDesignerImage();  // background image for the designer

  /**
   *
   * @return
   */
  public Rectangle getDesignerClientRect(); // null --> unbounded design surface

  /**
   *
   * @return
   */
  public boolean constrainChildrenToClientRect(); // if there is a client-rect, kids can't move out

  /**
   *
   * @return
   */
  public UIDesignRect[] getDesignRects(); // mouse interaction with the design surface
}
