package com.borland.acm;

/**
 * <p>The LiveDesignerManager is instantiated when a node (buffer) is being
 * designed for the first time in an IDE session.
 * The LiveDesignerManager manages the persistence (buffer) data, holds the
 * LiveDesigner instances, and manages all interactions between the different
 * designers and the persistence data.
 * One LiveDesignerManager instance exists for each 'Design' tab that shows up
 *  in the IDE - basically, one per designing node (buffer).</p>
 *
 * <p>When the LiveDesignerManager is created, one of each of the LiveDesigner
 * instances corresponding to the DesignerInfo list supplied by the
 * ComponentModel should be created (or be ready for creation when they are
 * requested).  It is expected that each instance of LiveDesignerManager has
 * access to the same set of LiveDesigner classes.
 * For example, if a ComponentModel specifies that there are three DesignerInfo
 * classes, there should be three LiveDesigner instances accessible
 * from each LiveDesignerManager instance.</p>
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public interface LiveDesignerManager {

  /**
   * Returns a unique key identifying this designer manager instance.
   * This key will be used to uniquely identify this instance
   * of LiveDesignerManager.  It is up to the implementor to work
   * out the key scheme and maintain uniqueness.
   *
   * @return The unique manager instance key
   */
  public Object getManagerInstanceKey();

  /**
   * Returns indicator as to whether Manager has lost its server connection.
   * @return boolean
   */
  public boolean isLost();

  /**
   * Returns the ComponentModel associated with this LiveDesignerManager
   *
   * @return The ComponentModel associated with this LiveDesignerManager
   */
  public ComponentModel getComponentModel();

  /**
   * Returns all the live designers accessible from this LiveDesignerManager
   *  instance.
   *
   * @return An array of LiveDesigner instances
   */
  public LiveDesigner[] getAllDesigners();

  /**
   * Returns the LiveDesigner corresponding to the specified designer key.
   *
   * @param designerKey The designer key that corresponds to the desired
   * LiveDesigner.
   * @return The requested LiveDesigner
   */
  public LiveDesigner getDesigner(Object designerKey);

  /**
   * Returns the default designer key for this designer manager.
   * This is the live designer that will be 'activated' when the
   * node (buffer) is first put into design mode.
   *
   * @return The default designer key
   * @see LiveDesigner#getDesignerKey()
   */
  public Object getDefaultDesignerKey();

  /**
   * Returns the live components that match the specified type key.
   * This method is called when populating a drop-down list in a
   * property editor to find instance variables of a specific
   * type.
   *
   * <p><b>Note:</b>  This is typically not just a simple string match,
   * but a functional match based on logic inside the component model itself.
   * For example, in an ACM implemenation for the JavaBeans component model,
   * the type key for a component might be "javax.swing.JPanel".
   * When this method is called, one would not only want to return instances
   * of JPanel, but also instances of subclasses of JPanel.
   * Thus, the implementation would need to scan all of the
   * live components and use Java's reflection mechanism to find
   * which live components to return.
   *
   * @param compTypeKey The unique type key of the desired component
   * @return An array of LiveComponent objects that match the passed type key
   */
  public LiveComponent[] getComponentsOfType(Object compTypeKey);

  /**
   * Searches all designers and all components therein for the component
   * of the given instance name.  There is an implicit invariant that across
   * all designers, components have unique names, so this interface will return
   * at most one component.
   * @param instanceName
   * @return
   */
  public LiveComponent getComponentOfName(String instanceName);

  /**
   * Sets the persistence data for this LiveDesignerManager.
   * At this point, the LiveDesignerManager needs to notify all its designers
   * that a new buffer has been read, and they need to update themselves to
   * reflect the changes.
   * This method is called each time the user makes changes in the source view,
   * then switches back to the designer view.  It is up to the implementation to
   * flush and rebuild, or to merge changes.
   *
   * @param persistData The new persistence data (buffer contents)
   * @return A standard Result object, which may represent success or failure,
   *  and may contain any number of messages for the user
   */
  public Result setPersistenceData(byte[] persistData);

  /**
   * Returns true if the persistence data has been modified since last being set.
   * This method is called when the user clicks off of the designer view onto
   * the source (or other) view.  If the peristence data has been modified,
   * it will be requested via the 'getPersistenceData' method.
   *
   * @return <b>true</b> if the perisistence data has been modified,
   *    <b>false</b> if not.
   * @see getPersistenceData()
   */
  public boolean isPersistenceDataModified();

  /**
   * Returns the current persistence data.
   * The LiveDesignerManager must return persistence data for all of its
   * live designers.  This method is called when the user has made
   * changes in the designer,and they are now switching to the
   * source (or other) view.
   *
   * @return A byte array with the current persistence data
   * @see isPersistenceDataModified()
   */
  public byte[] getPersistenceData();

  /**
   * Returns the current persistence data for the specified live component(s).
   *  This method used to effectively 'cut' or 'copy' a selection of
   * components from the designer.
   *
   * @param comps The live component(s) to get persistence data for
   * @return A byte array with the current persistence data for the
   *   specified live component(s)
   */
  public byte[] getPersistenceData(LiveComponent[] comps);

  /**
   * Returns the typeKey for persistedlive component
   * This method could be used with LiveContainer.canPaste(), LiveDesigner.canPaste()
   *
   * @param the persistence data for live component
   * @return typeKey for persisted live component
   */
  public Object getComponentTypeKey(byte[] persistenceData);

  /**
   * Adds a designer listener event group hook
   * @param listener The listener to add
   */
  public void addDesignerListener(DesignerListener listener);

  /**
   * Removes a designer listener event group hook
   * @param listener The listener to remove
   */
  public void removeDesignerListener(DesignerListener listener);

  /**
   * Switch Manager into the activated or active state
   */
  public void activated();

  /**
   * Switch manager into the deactivated or inactive state
   */
  public void deactivated();


}
