//NOTTRANSLATABLE

package com.borland.acm;

/**
 * <p>The LiveDesigner interface encapsulates a live designer.  This interface owns and controls a
 * 'tree' of live components of a particular type.  Usually, a sub-interface of LiveDesigner is
 * actually used - that knows about specific types of live components.  For example, an instance
 * of LiveUIDesigner would be used for any UI components, and would own and control the UI
 * containership 'tree' of live UI components.  At the same time (within the same LiveDesignerManager),
 * a LiveMenuDesigner would be used for any menu components.  These methods are common to all live
 * designers, and are thus in this LiveDesigner base interface.</p>
 *
 * <p>An instance of the LiveDesigner interface (or any sub-interface) will control a live tree
 * of components in the visual designer.  Any open tool could implement a new type of live designer,
 * and it would show up in the visual designer as a first-class citizen - like the others.</p>
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 * @see LiveDesignerManager
 */
public interface LiveDesigner {

  /**
   * Default Key of a non-GUI Designer
   */
  public static final String DEFAULT_DESIGNER_KEY = "DEFAULT";

  /**
   * Default Key of a UI (GUI) Designer
   */
  public static final String UI_DESIGNER_KEY = "UI";

  /**
   * Default Key of a Menu Designer
   */
  public static final String MENU_DESIGNER_KEY = "MENU";

  /**
   * Default Key of a String Table Designer
   */
  public static final String STRING_TABLE_DESIGNER_KEY = "STRINGTABLE";

  /**
   * Returns the DesignerInfo associated with this live designer.
   *
   * @return The DesignerInfo associated with this live designer
   */
  public DesignerInfo getDesignerInfo();

  /**
   * A flag that can be inspected by the palette to determine if the palette should
   * be displayed or hidden.
   *
   * @return boolean True to display the palette, false otherwise.
   */
  public boolean showPalette();

  /**
   * Returns the LiveDesignerManager that 'owns' this live designer
   *
   * @return The LiveDesignerManager that 'owns' this live designer
   */
  public LiveDesignerManager getDesignerManager();

  /**
   * Tests if the specified component type can be created within the specified parent container.
   * This method is called when the user has selected a component info from the palette and is
   * moving the mouse around the screen to find a place to 'drop' it.  Valid drop targets will be
   * those that return <b>true</b> from this method.
   *
   * @param parent The parent live container to create the component within (may be null)
   * @param compInfo The component type info
   * @return <b>true</b> if the specified component info may be created using the specified parent
   *         as it's parent, or <b>false</b> if not.
   */
  public boolean testCreateComponent(LiveContainer parent, ComponentInfo compInfo);

  /**
   * Creates a component of the specified type as a child of the specified live container.  This
   * method is used when a component is 'dropped' from the component palette onto the design
   * surface.  Different flavors of createComponent(...) exist in different live designer types.
   *
   * @param parent The desired container of the new live component, or null if this is to be a top-
   *        level live component
   * @param compInfo The ComponentInfo of the desired component
   * @return A CreateResult object indicating success or failure, the resultant LiveComponent, and
   *         any messages for the user
   */
  public CreateResult createComponent(LiveContainer parent, ComponentInfo compInfo);

  /**
   * Creates a component or set of components as a child of the specified live container, using the
   * specified persistence data.  This method is used when a component or group of components have
   * been 'cut' or 'copied' to the clipboard and 'pasted' onto the design surface at a different
   * location.  The set of new live component(s) should be created using any attributes that apply
   * from the persistence data, as well as new versions of any contained components in the
   * persistence data.  The new live component(s) (and their contained components) should have new
   * unique instance keys.
   *
   * @param parent The desired container of the new live component(s), or null if they are to be
   *        top-level live component(s)
   * @param persistData The stream of persistence data
   * @return A CreateResult including any live components that were created
   */
  //public PasteResult pasteComponent(LiveContainer parent, byte[] persistData);
  public CreateResult pasteComponent(LiveContainer parent, byte[] persistData);

  /**
   * Disposes the live component with the specified instance key.  A successfully disposed component
   * will not be referenced again.
   *
   * @param compInstanceKey The desired live component's instance key
   * @return A standard Result object, indication success or failure, as well as any messages for
   *         the user
   */
  public Result disposeComponent(Object compInstanceKey);

  /**
   * Returns the live component with the specified instance key
   *
   * @param compInstanceKey The desired live component's instance key
   * @return The live component with the specified instance key
   */
  public LiveComponent getComponent(Object compInstanceKey);

  /**
   * Returns the root components (top-level) of this live designer.
   *
   * @return An array of LiveComponent instances representing the top-level components in this
   *         designer.
   */
  public LiveComponent[] getRootComponents();

  /**
   * <p>Returns a list of context tags to display when the user right-clicks on the designer.  These
   * tags will be merged with the context tags supplied by the DesignerInfo.</p>
   *
   * <p>For this use of the Tag interface, methods will be used as follows:</p>
   * <table border=1>
   * <tr><th> Method                     <th> Purpose
   * <tr><td> Object getKey()            <td> (not used - unless 'displayName' is null)
   * <tr><td> String getDisplayName()    <td> Text of the menu item (uses 'key.toString()' if null)
   * <tr><td> String getDescription()    <td> Status text of the menu item (optional)
   * <tr><td> ImageData getDisplayIcon() <td> Icon of the menu item (optional)
   * <tr><td> TagGroup getParentTag()    <td> Full hierarchy will be displayed in menu
   * <tr><td> void tagInvoked()          <td> Called if the menu item is selected
   * </table>
   *
   * @return An array of Tag objects to display on the right-click menu for this designer
   */
  public Tag[] getContextTags(int x, int y);

  /**
  * Returns true if given persistData can be pasted directly onto this designer
  * as root component(s)
  */
  public boolean canPaste(byte[] persistData);
}
