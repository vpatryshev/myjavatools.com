package com.borland.acm.ui;

import java.awt.*;
import com.borland.acm.*;

/**
 *
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public interface LiveUIComponent extends LiveComponent {

  /**
   * Get LiveUIDesigner for this UIComponent
   * @return LiveUIDesigner
   */
  public LiveUIDesigner getUIDesigner();

  /**
   * get Parent Container of this LiveUIComponent
   * @return LiveUIContainer for parent
   */
  public LiveUIContainer getParentUIContainer();


  /**
   * Returns true if location of this component can be changed.
   * Design surface can show some visual feedback i.e. "move" cursor only if true is returned
   */
  public boolean canMove();

  /**
   * Returns true if size of this component can be changed.
   * Design surface can show some visual feedback i.e. "resize" cursor only if true is returned
   */
  public boolean canResize();

  /**
   * Get Rectangle describing position and bounds of Component.
   * @return component bounds Rectangle.
   */
  public Rectangle getUIComponentRect();

  /**
   *
   * @param rect
   * @param dragPoint
   * @return
   */
  public Rectangle testUIComponentRect(Rectangle rect, Point dragPoint);

  /**
   * Set new Rectangle for this component.
   * @param rect  Component new bounds
   * @param dragPoint  current drag point for resizing bounds (??)
   * @return
   */
  public Rectangle setUIComponentRect(Rectangle rect, Point dragPoint);

  /**
   *
   * @return
   */
  public boolean isVisible();

  /**
   *
   * @return
   */
  public ImageData getComponentImage();

  /**
   * get Image for component bounded by given clipRect
   * @param clipRect
   * @return
   */
  public ImageData getComponentImage(Rectangle clipRect);

  /**
   * Provide UIDesignRects for this Component.
   * list of mouse interactable areas of component
   * @return aray of UIDesignRects
   */
  public UIDesignRect[] getDesignRects();
}
