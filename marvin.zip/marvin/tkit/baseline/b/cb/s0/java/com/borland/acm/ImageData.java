package com.borland.acm;

/**
 * <p>The ImageData interface represents an image or icon for display in some part of the designer.
 * ImageData is used *everywhere* that an image needs to be represented - including icons and
 * live UI component images.  ImageData consists of an array of pixels, a scan width, and a boolean
 * to indicate if an alpha channel is used.  The pixels are represented as a linear int array, each
 * pixel represented as an int (32-bits, or 4-bytes) in the format described below.  The scan width
 * is the 'width' of the image, and index to jump in the pixel array to the next vertical line of
 * the image.  The 'height' of the image is calculated by taking the length of the pixel array and
 * dividing it by the scan width:  height = (pixels.length / scan).  Alpha is a measure of
 * transparency, with 0xFF indicating fully opaque, and 0x00 indicating fully transparent.  Both
 * transparent (alpha) and non-transparent (non-alpha) images are supported.</p>
 *
 * <p>The pixel formats required to render the images are as follows:</p>
 *
 * <p><b>With alpha channel</b>  ( isAlphaIncluded() returns <b>true</b> ) :
 *   0x<b>Aa<font color=red>Rr</font><font color=green>Gg</font><font color=blue>Bb</font></b><br>
 *   32-bits used per pixel (all 4 bytes of int)<br>
 *   Highest byte is alpha, then red byte, then green byte, lowest byte is blue<br>
 *   For alpha (Aa): 0xFF is max alpha (fully opaque), 0x00 is no alpha (fully transparent)<br>
 *   For each color (Rr, Gg, and Bb): 0xFF is max of color, 0x00 is zero of color
 *
 * <p>Examples:<br>
 *
 * Fully opaque red : 0x<b>FF<font color=red>FF</font><font color=green>00</font><font color=blue>00</font></b><br>
 * Semi-transparent dark green : 0x<b>A0<font color=red>00</font><font color=green>A0</font><font color=blue>00</font></b><br>
 * Semi-transparent black (shadow gray) : 0x<b>99<font color=red>00</font><font color=green>00</font><font color=blue>00</font></b><br>
 * White : 0x<b>FF<font color=red>FF</font><font color=green>FF</font><font color=blue>FF</font></b><br>
 *
 * <p><b>Without alpha channel</b>  ( isAlphaIncluded() returns <b>false</b> ) :
 *   0x<b><font color=red>Rr</font><font color=green>Gg</font><font color=blue>Bb</font></b><br>
 *   24-bits used per pixel (lower 3 bytes of int)<br>
 *   Highest byte ignored (assumed max alpha 0xFF), then red byte, then green byte, lowest byte is blue<br>
 *   For each color (Rr, Gg, and Bb): 0xFF is max of color, 0x00 is zero of color
 *
 * <p>Examples:<br>
 *
 * Purple : 0x<b><font color=red>FF</font><font color=green>00</font><font color=blue>FF</font></b><br>
 * Dark yellow : 0x<b><font color=red>A0</font><font color=green>A0</font><font color=blue>00</font></b><br>
 * Greenish red : 0x<b><font color=red>FF</font><font color=green>99</font><font color=blue>00</font></b><br>
 * White : 0x<b><font color=red>FF</font><font color=green>FF</font><font color=blue>FF</font></b>
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public interface ImageData {

  /**
   * Returns the scan width of the image data.  The scan width is the 'width' of the image, and
   * index to jump in the pixel array to the next vertical line of the image.  The 'height' of the
   * image is calculated by taking the length of the pixel array and dividing it by the scan width:
   * height = (pixels.length / scan).
   *
   * @return an int representing the pixel scan width
   */
  public int getScanWidth();

  /**
   * <p>Returns an array of int, representing the pixel data for this image.  Each pixel is
   * represented as an int (32-bits, or 4-bytes) in the following format:</p>
   *
   * <p><b>With alpha channel</b>  ( isAlphaIncluded() returns <b>true</b> ) :
   *   0x<b>Aa<font color=red>Rr</font><font color=green>Gg</font><font color=blue>Bb</font></b><br>
   *   32-bits used per pixel (all 4 bytes of int)<br>
   *   Highest byte is alpha, then red byte, then green byte, lowest byte is blue<br>
   *   For alpha (Aa): 0xFF is max alpha (fully opaque), 0x00 is no alpha (fully transparent)<br>
   *   For each color (Rr, Gg, and Bb): 0xFF is max of color, 0x00 is zero of color
   *
   * <p><b>Without alpha channel</b>  ( isAlphaIncluded() returns <b>false</b> ) :
   *   0x<b><font color=red>Rr</font><font color=green>Gg</font><font color=blue>Bb</font></b><br>
   *   24-bits used per pixel (lower 3 bytes of int)<br>
   *   Highest byte ignored (assumed max alpha 0xFF), then red byte, then green byte, lowest byte is blue<br>
   *   For each color (Rr, Gg, and Bb): 0xFF is max of color, 0x00 is zero of color
   *
   * @return An array of int representing the pixel data of this image
   */
  public int[] getPixels();

  /**
   * Returns true if the pixel data includes alpha channel information, or false if there is none
   * or it should be ignored.  If this method returns false, all pixels will be treated as fully
   * opaque (alpha = 0xFF).
   *
   * @return <b>true</b> if there is alpha information in the pixel data, <b>false</b> if not or to
   *         force all pixels to fully opaque
   */
  public boolean isAlphaIncluded();
}
