package com.borland.acmdesigner;

import com.borland.primetime.node.*;
import com.borland.acm.*;
import com.borland.primetime.ide.*;
import com.borland.acmdesigner.designer.*;

public interface CodeManagerFactory {
  public boolean canManageCode(Node node, ComponentModel model);
  public ICodeManager createCodeManager(Context context, LiveDesignerManager manager, DesignerHost host);
}