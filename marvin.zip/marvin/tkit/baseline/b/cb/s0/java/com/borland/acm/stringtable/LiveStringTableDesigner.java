package com.borland.acm.stringtable;

import com.borland.acm.LiveDesigner;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * Stub interface to provide a type key so that we can implement a different
 * designer for Symbian string tables.
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Borland Software Corporation</p>
 * @author Eli Boling
 * @version 1.0
 */

public interface LiveStringTableDesigner extends LiveDesigner {
}
