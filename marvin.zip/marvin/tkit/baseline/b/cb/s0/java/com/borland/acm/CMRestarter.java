package com.borland.acm;

/**
 * <p> </p>
 * <p> </p>
 * <p>Copyright: Copyright (c) 2003 Borland Software Corporation</p>
 * <p> </p>
 * @author Eli Boling (and bruneau, too, let's be fair).
 * @version 1.0
 */

public interface CMRestarter {
  public void Restart(ComponentModel cm);
}
