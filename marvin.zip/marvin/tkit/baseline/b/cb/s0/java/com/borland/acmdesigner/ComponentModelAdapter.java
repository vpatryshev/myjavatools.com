package com.borland.acmdesigner;

/**
 * <p>Title: ComponentModelAdapter</p>
 * <p>Description: Adapter for ComponentModelListener</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Borland Software Corporation</p>
 * @author Eli Boling
 * @version 1.0
 */

public class ComponentModelAdapter implements ComponentModelListener {
  public ComponentModelAdapter() {
  }
  public void Register() {}
  public void HeartBeat() {}
  public String GetName() { return ""; }
}