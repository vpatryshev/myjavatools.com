package com.borland.acm.util;

import java.util.*;
import com.borland.acm.*;

/**
 *
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public class BasicResultMessage
  implements ResultMessage {

  public static BasicResultMessage create(int type, String title, String text) {
    return new BasicResultMessage(type, title, text);
  }

  public static BasicResultMessage create(int type, String title, String text, ImageData icon) {
    return new BasicResultMessage(type, title, text, icon);
  }

  protected int type;
  protected String title;
  protected String text;
  protected ImageData icon;

  public BasicResultMessage(int type, String title, String text) {
    if (type == TYPE_INFORMATION || type == TYPE_WARNING || type == TYPE_CRITICAL) {
      this.type = type;
    }
    else {
      throw new IllegalArgumentException("Message type must be TYPE_INFORMATION (0), TYPE_WARNING (1), or TYPE_CRITICAL (2)"); // RES IllegalMessageType
    }
    this.type = type;
    this.title = title;
    this.text = text;
  }

  public BasicResultMessage(int type, String title, String text, ImageData icon) {
    this(type, title, text);
    this.icon = icon;
  }

  public void setMessageType(int type) {
    if (type == TYPE_INFORMATION || type == TYPE_WARNING || type == TYPE_CRITICAL) {
      this.type = type;
    }
    else {
      throw new IllegalArgumentException("Message type must be TYPE_INFORMATION (0), TYPE_WARNING (1), or TYPE_CRITICAL (2)"); // RES IllegalMessageType
    }
  }

  public int getMessageType() {
    return type;
  }

  public void setMessageTitle(String title) {
    this.title = title;
  }

  public String getMessageTitle() {
    return title;
  }

  public void setMessageText(String text) {
    this.text = text;
  }

  public String getMessageText() {
    return text;
  }

  public void setMessageIcon(ImageData icon) {
    this.icon = icon;
  }

  public ImageData getMessageIcon() {
    return icon;
  }
}
