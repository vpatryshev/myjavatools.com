package com.borland.acm.util;

import com.borland.acm.*;

/**
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public class BasicCreateResult
  extends BasicResult
  implements CreateResult {

  protected LiveComponent comp;

  public BasicCreateResult(CreateResult createResult) {
    this(createResult.isSuccess(), createResult.getComponent());
    addMessages(createResult.getMessages());
    addOptionTags(createResult.getOptionTags());
  }

  public BasicCreateResult(boolean success, LiveComponent comp) {
    super(success);
    this.comp = comp;
  }

  public BasicCreateResult(boolean success, LiveComponent comp, ResultMessage[] messages) {
    super(success, messages);
    this.comp = comp;
  }

  public BasicCreateResult(boolean success, LiveComponent comp, ResultMessage[] messages, Tag[] options) {
    super(success, messages, options);
    this.comp = comp;
  }

  public void setComponent(LiveComponent comp) {
    this.comp = comp;
  }

  public LiveComponent getComponent() {
    return comp;
  }

  public static BasicCreateResult create(boolean success, LiveComponent comp) {
    return new BasicCreateResult(success, comp);
  }

  public static BasicCreateResult create(boolean success, LiveComponent comp, String message, String title, int type) {
    ResultMessage msg = new BasicResultMessage(type, title, message);
    return new BasicCreateResult(success, comp, new ResultMessage[] {
      msg});
  }

  public static BasicCreateResult create(boolean success, LiveComponent comp, ResultMessage[] messages) {
    return new BasicCreateResult(success, comp, messages);
  }

  public static BasicCreateResult create(boolean success, LiveComponent comp, ResultMessage[] messages, Tag[] options) {
    return new BasicCreateResult(success, comp, messages, options);
  }

  public BasicCreateResult(LiveComponent comp) {
    this.comp = comp;
  }

  public static BasicCreateResult handleCreateResult(CreateResult res, BasicCreateResult currentResult) {
    if (currentResult == null) {
      if (res != null) {
        currentResult = new BasicCreateResult(res);
      }
    }
    else {
      if (res != null) {
        if (!res.isSuccess()) {
          currentResult.setSuccess(false);
          currentResult.addMessages(res.getMessages());
          currentResult.addOptionTags(res.getOptionTags());
        }
      }
    }
    return currentResult;
  }
}
