package com.borland.acm;

/**
 * The CreateResult interface is used as a return value from the method:
 * LiveDesigner.createComponent(LiveComponent parent, ComponentInfo compInfo).
 *
 * @see LiveDesigner#createComponent(LiveComponent, ComponentInfo)
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public interface CreateResult extends Result {

  /**
   * Returns the live component that was the result of the LiveDesigner.createComponent(...) method
   * call.  This may be null if the create operation resulted in failure.
   *
   * @return The LiveComponent result of the create operation
   */
  public LiveComponent getComponent();
}