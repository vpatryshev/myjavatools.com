package com.borland.acm;

/**
 * The Result interface describes a standard response to an interaction that might succeed or fail,
 * and potentially have some resulting context messages for the user.  A few sub-interfaces exist
 * that contain more detailed information about the results of a specific operation.  A result may
 * contain option tags, which will 'promote' the result into a dialog box, with the option tags
 * displayed as option buttons.
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public interface Result {

  /**
   * Returns true if the operation was a success, or false if it failed
   *
   * @return <b>true</b> if the operation was a success, or <b>false</b> if it failed
   */
  public boolean isSuccess();

  /**
   * Returns an array of result messages to display to the user.  If there are no messages for the
   * user, this method returns false.
   *
   * @return An array of ResultMessage objects representing messages for the user as a result of
   *         the operation, or null if there are no messages
   */
  public ResultMessage[] getMessages();

  /**
   * <p>If the result warrants a dialog box to pop up and prompt the user to make a decision,
   * an optional set of tags can be returned.  This will direct the designer to create a dialog
   * box displaying any result messages, and prompt the user to select one of the option tags -
   * displayed as buttons.  The selected option tag will then be invoked by calling
   * Tag.tagInvoked().</p>
   *
   * <p>For this use of the Tag interface, methods will be used as follows:</p>
   * <table border=1>
   * <tr><th> Method                     <th> Purpose
   * <tr><td> Object getKey()            <td> (not used - unless 'displayName' is null)
   * <tr><td> String getDisplayName()    <td> Text on the dialog button (uses 'key.toString()' if null)
   * <tr><td> String getDescription()    <td> Tooltip on the dialog button (optional)
   * <tr><td> ImageData getDisplayIcon() <td> Icon on the dialog button (optional)
   * <tr><td> TagGroup getParentTag()    <td> Hierarchy ignored - only flat list shown as buttons
   * <tr><td> void tagInvoked()          <td> Called if the button is clicked
   * </table>
   *
   * @return an array of Tag objects representing the different dialog buttons
   */
  public Tag[] getOptionTags();
}