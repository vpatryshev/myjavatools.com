package com.borland.acm;

/**
 * <p>ACM is a acronym for "Abstract Component Model", thus this interface called 'ComponentModel'
 * is the root interface of ACM.  An implementation of ComponentModel describes the design-time
 * interaction and meta-data about a real component model that may be implemented in any language
 * on any platform.</p>
 *
 * <p><b>Palette, designer, and component meta-information:</b>
 * <pre>
 * [-] ComponentModel         (only one for whole IDE)
 *  |-[-] PalettePage         (one per palette page)
 *  |  |-[-] ComponentInfo    (one per component type)
 *  |  |  |---- PropertyInfo  (one per property)
 *  |  |  |---- PropertyInfo
 *  |  |  |---- ...
 *  |  |  |---- MethodInfo    (one per method)
 *  |  |  |---- MethodInfo
 *  |  |  |---- ...
 *  |  |  |---- EventInfo     (one per event)
 *  |  |  |---- EventInfo
 *  |  |  |---- ...
 *  |  |-[+] ComponentInfo
 *  |  \---- ...
 *  |-[-] PalettePage
 *  |  |-[+] ComponentInfo
 *  |  \---- ...
 *  |-[+] DesignerInfo        (one per designer type)
 *  |  \---- ...
 *  |-[+] DesignerInfo
 *  |  \---- ...
 *  \---- ...
 * </pre>
 * A set of PalettePage classes are retrieved from the singleton ComponentModel.  Each PalettePage
 * contains several ComponentInfo classes.  A ComponentInfo class describes the meta-data for a
 * single component type.
 *
 * <p><b>Live components at design-time:</b>
 * <pre>
 * [-] ComponentModel                 (only one for whole IDE)
 *  |-[-] LiveDesignerManager         (one per open buffer - manages design-time persistence)
 *  |  |-[-] LiveUIDesigner           (one per LiveDesignerManager - designs UI components)
 *  |  |  |-[-] LiveUIContainer       (one per live root ui component)
 *  |  |  |  |-[-] LiveUIComponent    (one per live ui component)
 *  |  |  |  |  |---- LiveProperty    (one per component property)
 *  |  |  |  |  |---- LiveProperty
 *  |  |  |  |  |---- ...
 *  |  |  |  |  |---- LiveEvent       (one per component event)
 *  |  |  |  |  |---- LiveEvent
 *  |  |  |  |  |---- ...
 *  |  |  |  |-[+] LiveUIComponent
 *  |  |  |  \---- ...
 *  |  |  |-[+] LiveUIContainer
 *  |  |  \---- ...
 *  |  |-[-] LiveMenuDesigner         (one per LiveDesignerManager - designs menu components)
 *  |  |  |-[-] LiveMenuContainer     (one per live root menu component)
 *  |  |  |  |-[+] LiveMenuComponent  (one per live menu component)
 *  |  |  |  \---- ...
 *  |  |  |-[+] LiveMenuContainer
 *  |  |  \---- ...
 *  |  \-[-] LiveDBDesigner           (one per LiveDesignerManager - designs db components)
 *  |     \---- ...                   (same pattern as above for DB components)
 *  |-[-] LiveDesignerManager         // Each LiveDesignerManager represents a single IDE buffer in
 *  |  |-[-] LiveUIDesigner           // 'design' mode.  Each LiveDesignerManager will expose the
 *  |  |  |-[-] LiveUIContainer       // same set of LiveDesigner classes.  Any combination of
 *  |  |  |  |-[+] LiveUIComponent    // LiveDesigner classes my be exposed - but always the same
 *  |  |  |  \---- ...                // set for a given ComponentModel
 * </pre>
 * Each LiveDesignerManager represents a single IDE buffer in 'design' mode.  Each LiveDesignerManager
 * will expose the same set of LiveDesigner classes.  Any combination of LiveDesigner classes my
 * be exposed - but always the same set for a given ComponentModel.  The IDE's designer will
 * interact with the LiveDesigner classes to create and manage the different types of LiveComponent
 * classes.  Each LiveComponent class surfaces a set of LiveProperty and LiveEvent objects.  These
 * represent the live interactions with the live component at design-time.
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public interface ComponentModel extends IDesignerFlags {

  /**
   * Returns the unique key for this component model.  This key will be used to uniquely identify
   * this model type, and to associate files in the IDE with this specific component model.  This
   * key must be something that a different component model would not be likely to use.
   *
   * @return The unique key for this component model
   */
  public Object getModelKey();

  /**
   * Returns the display name for this component model.
   *
   * @return The display name for the component model
   */
  public String getDisplayName();

  /**
   * Returns a description of this component model.
   *
   * @return A description of the component model
   */
  public String getDescription();

  /**
   * Returns a display icon for this component model.  This should be a 16x16 or 32x32 image.
   *
   * @return The image data representing a display icon for this component model
   */
  public ImageData getDisplayIcon();

  /**
   * Returns an array of PalettePage objects that represent the pages to show on the palette for
   * this component model.
   *
   * @return An array of PalettePage objects to build the palette
   */
  public ComponentPalettePage[] getPalettePages();

  /**
   * An overloaded version which returns a filtered array of PalettePage objects. Only objects
   * which can be designed by the designer key specified will be returned.
   *
   * @param designerKey Object
   * @return ComponentPalettePage[]
   */
  public ComponentPalettePage[] getPalettePages(Object designerKey);

  /**
   * Returns the ComponentInfo identified by the specified unique type key.
   *
   * @param compTypeKey The unique type key that uniquely identifies the desired ComponentInfo
   * @return The specified ComponentInfo class
   * @see ComponentInfo#getTypeKey()
   */
  public ComponentInfo getComponentInfo(Object compTypeKey);

  /**
   * Returns an array of DesignerInfo classes describing the different designers supported by this
   * component model.
   *
   * @return An array of DesignerInfo classes
   */
  public DesignerInfo[] getDesignerInfos();

  /**
   * Returns the DesignerInfo identified by the specified unique designer key.
   *
   * @param designerKey The unique key that uniquely identifies the desired DesignerInfo
   * @return The specified DesignerInfo class
   * @see DesignerInfo#getDesignerKey()
   */
  public DesignerInfo getDesignerInfo(Object designerKey);

  /**
   * Returns the DesignerInfo that is capable of designing the specified component type.
   *
   * @param compTypeKey The component type key that is about to be created or designed
   * @return The DesignerInfo representing the type of designer that can design the specified
   *         ComponentInfo
   * @see ComponentInfo#getTypeKey()
   */
  public DesignerInfo getDesignerInfoForComponent(Object compTypeKey);

  /**
   * Returns true if the component model implementation is 'remote' - meaning it is implemented as
   * a remote HTTP or web service host.  This causes subtle changes in the way these interfaces are
   * used.  For example, a LiveUIDesigner on a remote component model (RCM), will only get one
   * message when a component has been moved or resized - at the end of the drag operation.  A
   * LiveUIDesigner for a non-remote (or in-process) component model will get a moved or resized
   * message for each mouse event as it occurs in the designer.
   *
   * @return <b>true</b> if the component model is remote, <b>false</b> if it is in-process
   */
  public boolean isRemote();

  /**
   * Returns a newly created LiveDesignerManager.  This method is called when a node (buffer) is
   * activated in the visual designer.  Only one LiveDesignerManager will be created to represent a
   * given node in the IDE.
   *
   * @return A new LiveDesignerManager instance
   */
  public LiveDesignerManager createDesignerManager();

  /**
   * Returns the LiveDesignerManager with the specified unique manager key.
   *
   * @param managerInstanceKey The unique manager instance key
   * @return The LiveDesignerManager with the specified manager key
   * @see LiveDesignerManager#getManagerKey()
   */
  public LiveDesignerManager getDesignerManager(Object managerInstanceKey);

  /**
   * Returns all LiveDesignerManager instances currently 'alive' in the ComponentModel
   * @return An array of LiveDesignerManager instances
   */
  public LiveDesignerManager[] getDesignerManagers();

  /**
   * Disposes (releases) a LiveDesignerManager from the ComponentModel.  This method is called when
   * a node (buffer) is closed in the IDE.  Once disposed, a LiveDesignerManager will not be referenced
   * again.
   *
   * @param managerInstanceKey The unique manager instance key of the LiveDesignerManager to dispose
   * @return A standard Result object, which can represent success or failure, and my contain any
   *         number of messages for the user
   */
  public Result disposeDesignerManager(Object managerInstanceKey);

  /**
   * Mark this model as invalid and contents inaccessible.
   * Subsequent accesses on it should fail.
   */
  public void invalidateModel();

  /**
   * Hack to allow us to restart a component model that has died.
   * @param cmr
   */
  public void setRestarter(CMRestarter cmr);

  /**
   * Returns bitmask flags of properties the componentmodel wishes to
   * expose for the designer to modify it's appearance.
   * @see {@link com.borland.acm.IDesignerFlags }
   */
  public int getDesignerFlags();
}
