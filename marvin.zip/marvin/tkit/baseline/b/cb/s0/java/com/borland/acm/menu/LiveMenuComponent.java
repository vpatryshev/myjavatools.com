package com.borland.acm.menu;

import com.borland.acm.*;
import java.awt.*;

/**
 *
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public interface LiveMenuComponent extends LiveComponent {

  /**
   *
   * @return
   */
  public String getDisplayText();

  /**
   *
   * @return
   */
  public ImageData getDisplayIcon();

  /**
   *
   * @return
   */
  public boolean isCustomPainted();

  /**
   *
   * @return
   */
  public Dimension getCustomSize();

  /**
   *
   * @return
   */
  public ImageData getCustomImage();

  /**
   *
   * @return
   */
  public LiveMenuDesigner getMenuDesigner();

  /**
   *
   * @return
   */
  public LiveMenuContainer getParentMenuContainer();
}
