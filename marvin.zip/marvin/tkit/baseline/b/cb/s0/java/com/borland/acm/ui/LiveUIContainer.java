package com.borland.acm.ui;

import java.awt.*;
import com.borland.acm.*;

/**
 *
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public interface LiveUIContainer extends LiveUIComponent, LiveContainer {

  /**
   *
   * @param index
   * @return
   */
  public LiveUIComponent getUIComponent(int index);

  /**
   *
   * @return
   */
  public LiveUIComponent[] getUIComponents();

  /**
   *
   * @param compInstanceKey
   * @return
   */
  public LiveUIComponent getUIComponent(Object compInstanceKey);

  /**
   * Provide rectangle describing bounding box available for placement of
   * children.
   * @return Rectangle for bounding box of client/child space
   */
  public Rectangle getClientRect();

  /**
   *
   * @return
   */
  public boolean isConstrainedChildren();

   /**
   *
   * @return
   */
  public boolean canPaintChildren();
}
