package com.borland.acm.menu;

import com.borland.acm.*;

/**
 *
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public interface LiveMenuDesigner extends LiveDesigner {

  /**
   *
   * @param parent
   * @param compInfo
   * @return
   */
  public MenuCreateResult createComponent(LiveMenuContainer parent, ComponentInfo compInfo);

  /**
   * Creates a component or set of components using the specified persistence data.  This method is
   * used when component(s) have been 'cut' or 'copied' to the clipboard and 'pasted' onto the design
   * surface at a different location.  A new live component(s) should be created using any attributes
   * that apply from the persistence data, as well as new versions of any contained components in
   * the persistence data.  The new live component(s) (and contained components) should have new
   * unique instance keys.
   *
   * @param parent The menu container parent
   * @param persistData The persistence data
   * @return A MenuPasteResult
   */
  public MenuPasteResult pasteComponent(LiveMenuContainer parent, byte[] persistData);

  /**
   * Returns the live Menu component with the specified instance key
   *
   * @param compInstanceKey The desired live Menu component's instance key
   * @return The live Menu component with the specified instance key
   */
  public LiveMenuComponent getMenuComponent(Object compInstanceKey);

  /**
   * Returns the root Menu components (top-level) of this live Menu designer.
   *
   * @return An array of LiveMenuComponent instances representing the top-level components in this
   *         Menu designer.
   */
  public LiveMenuComponent[] getRootMenuComponents();
}
