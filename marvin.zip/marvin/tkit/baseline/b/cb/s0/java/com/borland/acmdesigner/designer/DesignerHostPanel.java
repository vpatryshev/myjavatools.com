package com.borland.acmdesigner.designer;

import java.util.*;
import java.util.List;
import java.awt.*;
import javax.swing.*;

import com.borland.primetime.actions.*;
import com.borland.primetime.ide.*;
import com.borland.primetime.node.*;
import com.borland.primetime.properties.*;
import com.borland.primetime.ui.*;
import com.borland.primetime.util.*;
import com.borland.primetime.vfs.*;

import com.borland.acm.*;
import com.borland.acm.util.*;
import com.borland.acmdesigner.*;
import com.borland.acmdesigner.inspector.*;
import com.borland.acmdesigner.palette.*;
import com.borland.acmdesigner.tree.*;
import com.borland.acmdesigner.util.*;
import com.borland.acm.stringtable.LiveStringTableDesigner;

/**
 * Central Control point of Designer. <br>
 * Target of ComponentModel (as DesignerListener) and
 * Designer internal notifications
 * Source of notifications to Designer subcomponents/panels.<br>
 * Root Panel of Designer (?) holding palette and Inspector
 * Interfaces to BE (Visual Designer) for Designer interactions and
 * client (builder) for LiveDesigner Events.
 */
public class DesignerHostPanel
  extends JPanel
  implements DesignerHost, DesignerListener, Observer, IDesignerEvents {

  protected Palette myPalette;
  protected JSplitPane splitter;
  private JSplitPane myLeftSplitter;
  private JComponent myPaletteComponent;
  private static final double SPLITTER_PROPORTION = 0.75;
  private static final int SPLITTER_DIVIDER_SIZE = 6;
  protected JPanel hostPanel = new JPanel(new BorderLayout(0, 0));
  protected AbstractInspector inspector;
  protected LiveDesignerManager manager;
  protected Context context;
  protected DesignerNodeViewer viewer;
  protected DesignerStructurePanel structurePane;

  protected Map designerPanelHash = new HashMap();
  protected ICodeManager codeManager;
  protected List dhListenerList = null;
  protected Tag[] hostTags = null;
  protected boolean modified = false;
  private boolean loading = false;
  private boolean madeBtns; // record deferred Designer button creation done.

  protected LiveComponent selectedComp;
  protected ComponentInfo selectedCompInfo;

  //stores splitter position. not exposed to user
  private static final GlobalIntegerProperty SPLITTER_POSITION = new GlobalIntegerProperty(
    DesignerPropertyPage.DESIGNER_CATEGORY, "spitter.pos", -1); //NORES
  protected static MessageCategory CATEGORY_DESIGNER = new MessageCategory(
    "Designer", // RES MessageCategoryTitleDesigner
    "Visual designer messages"); // RES MessageCategoryDescDesigner

  public DesignerHostPanel(Context context, LiveDesignerManager manager, DesignerNodeViewer viewer) {
    //System.out.println("new DesignerHostPanel!");
    this.context = context;
    this.manager = manager;
    this.viewer = viewer;
    try {
      jbInit();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  public Browser getBrowser() {
    return context.getBrowser();
  }

  public Node getNode() {
    return context.getNode();
  }

  public DesignerStructurePanel getStructurePane() {
    return structurePane;
  }

  public void handleResult(String operation, Result result) {
    if (result == null) {
      return;
    }
    Message topMessage = null;
    if (!result.isSuccess()) {
      topMessage = getBrowser().getMessageView().addMessage(
        CATEGORY_DESIGNER, " Failure: " + operation); // RES DesignerMessageFailure
    }
    boolean showDialog = false;
    ResultMessage[] rms = result.getMessages();
    if (rms != null && rms.length > 0) {
      for (int i = 0; rms != null && i < rms.length; i++) {
        if (result.isSuccess()) {
          topMessage = getBrowser().getMessageView().addMessage(
            CATEGORY_DESIGNER, " Success: " + operation); // RES DesignerMessageSuccess
        }
        ResultMessage rm = rms[i];
        if (rm.getMessageType() == rm.TYPE_CRITICAL) {
          showDialog = true;
        }
        Message rmMessage = new Message(" \"" + rm.getMessageTitle() + "\": "
          + rm.getMessageText());
        getBrowser().getMessageView().addMessage(CATEGORY_DESIGNER, topMessage,
          rmMessage);
      }
    }
    Tag[] ots = result.getOptionTags();
    if (ots != null && ots.length > 0) {
      showDialog = true;
      for (int j = 0; j < ots.length; j++) {
        Tag ot = ots[j];
        Message optMessage = new Message(" User Option [" + ot.getTagKey() + "]: \"" +  // RES DesignerMessageUserOption, NORES
          ot.getDisplayName() + "\": " + ot.getDescription());
        getBrowser().getMessageView().addMessage(CATEGORY_DESIGNER, topMessage,
          optMessage);
      }
    }
    if (showDialog) {
      ResultMessageDialog.showModalDialog(this, rms, ots);
    }
    else {

    }
  }

  public void activated() {
    manager.activated();
    addDesignerButtons();
    hostPanel.repaint();
  }

  public void deactivated() {
    storeDividerPosition();
    manager.deactivated();
  }

  public ComponentModel getComponentModel() {
    return manager.getComponentModel();
  }

  public LiveDesignerManager getLiveDesignerManager() {
    /* If the manager is dead, don't let it come back. */
    if (manager.isLost()) {
      return null;
    }
    return manager;
  }

//  public Inspector getInspector() {
//    return inspector;
//  }

  public Tag[] getHostContextTags() {
    if (hostTags == null) {
      BasicTagGroup tags = new BasicTagGroup();

      BasicTagGroup dsGroup = new BasicTagGroup("Activate designer", true); // RES DesignerTagActivateDesigner
      LiveDesigner[] ds = manager.getAllDesigners();
      // Show tags only if we have more than one designer
      if (ds.length > 1) {
        for (int i = 0; i < ds.length; i++) {
          final LiveDesigner d = ds[i];
          DesignerInfo di = d.getDesignerInfo();
          dsGroup.addTag(new BasicTag(di.getDisplayName(), di.getDisplayIcon()) {
            public Result tagInvoked() {
              setActiveDesigner(d);
              return null;
            }
          });
        }
      }
      tags.addTag(dsGroup);
      hostTags = tags.getTags();
    }
    return hostTags;
  }

  public void refresh() {
    fireDesignerActivated(getActiveDesigner());
    validate();
    repaint(100);
  }

  public Palette getPalette() {
    return myPalette;
  }

  public LiveDesigner getActiveDesigner() {
    return activeDesignerPanel != null ? activeDesignerPanel.getDesigner() : null;
  }

  protected DesignerPanel activeDesignerPanel;
  public DesignerPanel getActiveDesignerPanel() {
    return activeDesignerPanel;
  }

  public void setActiveDesigner(LiveDesigner designer) {
    setActiveDesigner(designer, true);
  }

  private void setActiveDesigner(LiveDesigner designer,
    boolean clearSelectedCompInfo) {
    if (getActiveDesigner() == designer) {
      return;
    }
    DesignerPanel dp = getDesignerPanel(designer);
    this.activeDesignerPanel = dp;
    hostPanel.removeAll();

    hostPanel.add(dp, BorderLayout.CENTER);
    dp.syncRootComponents();
    hostPanel.validate();
    hostPanel.repaint(100);
    structurePane.validate();
    structurePane.repaint(100);

    fireDesignerActivated(designer);

    // Clear selection to none
    if (clearSelectedCompInfo) {
      setSelectedComponentInfo(null);
    }
    //setSelectedComponent(null);

    /* Select first component under this designer */
    /** @todo: hops - Modify to store lastSelection per
     * designerFile(designerManager) when switch away from it.
     * Restore that selection if return to it.
     */
    //structurePane.scheduleDesignerDefaultSelect(designer);
  }

  public DesignerPanel getDesignerPanel(LiveDesigner designer) {
    if (designer == null) {
      return null;
    }
    DesignerPanel dp = (DesignerPanel) designerPanelHash.get(designer);
    if (dp == null) {
      dp = ACMDesignerManager.createDesignerPanel(this, designer);
      designerPanelHash.put(designer, dp);
    }
    return dp;
  }

  /**
   * Cleanup any old references to designerHostPanels including removal
   * from Listeners.
   */
  private void clearDesignerPanels() {
    Iterator iterator=designerPanelHash.values().iterator();
    while (iterator.hasNext()) {
      DesignerPanel designerPanel=(DesignerPanel)iterator.next();
//      System.out.println("removing listener ="+designerHostListener.getClass().getName()); //NORES
        removeDesignerHostListener(designerPanel);
        //designerPanel.cleanUp(); //should be used if this panel could be reused
        designerPanel.destroy();
    }
    designerPanelHash.clear();
    this.activeDesignerPanel = null;
  }

  public void setSelectedComponent(LiveComponent comp) {
    if (getSelectedComponent() == comp) {
      return;
    }
    mySelectedPath = null;
    setSelectedComponentHelper(comp);
  }

  public LiveComponent getSelectedComponent() {
    return selectedComp;
  }

  private void setSelectedComponentHelper(LiveComponent comp) {
    this.selectedComp = comp;
    fireComponentSelected(comp);
    splitter.doLayout();

  }

  //path - Sequence of LiveComponent's instance keys
  public void setSelectedComponent(LiveComponent comp, LiveComponent[] selectionPath) {
    if (getSelectedComponent() == comp && getSelectedPath() /**@todo*/ == selectionPath) {
      return;
    }
    mySelectedPath = selectionPath;
    setSelectedComponentHelper(comp);
    /** @todo: Why cant this be calculated as needed from selected component
     * mapped to treenode and path lookup in Structure pane ?
     */
  }

  public LiveComponent[] getSelectedPath() {
    return mySelectedPath;
  }

  private LiveComponent[] mySelectedPath;
  //

  public void setSelectedComponentInfo(ComponentInfo compInfo) {
    /** @todo: setSelectedComponentInfo is called mostly with a null value
     * - find out why that is and if its necessary
     */
    if (getSelectedComponentInfo() == compInfo) {
      return;
    }
    this.selectedCompInfo = compInfo;
    fireComponentInfoSelected(compInfo);
    if (compInfo != null) {
      // switch active Designer to that for selected componentInfo
      DesignerInfo di = manager.getComponentModel().getDesignerInfoForComponent(
        compInfo.getTypeKey());
      if (di != null) {
        LiveDesigner d = manager.getDesigner(di.getDesignerKey());
        if (d != null) {
          setActiveDesigner(d, false);
        }
      }
    }
  }

  public ComponentInfo getSelectedComponentInfo() {
    return selectedCompInfo;
  }

  public void addDesignerHostListener(DesignerHostListener dhl) {
    if (dhListenerList == null) {
      dhListenerList = new ArrayList();
    }
    dhListenerList.add(dhl);

    // Here we want to ensure that the codemanager is always the last
    // one in the list since it's necessary that everybody do their
    // thingie before a CodeManager proceeds
    if ( (codeManager != null) && (dhl != codeManager)) {
      setCodeManager(codeManager);
    }
  }

  public void removeDesignerHostListener(DesignerHostListener dhl) {
    if (dhListenerList != null) {
      dhListenerList.remove(dhl);
      if (dhListenerList.size() == 0) {
        dhListenerList = null;
      }
    }
  }

  private void fireComponentSelected(LiveComponent comp) {
    if (dhListenerList != null) {
      Iterator i = new ArrayList(dhListenerList).iterator();
      while (i.hasNext()) {
        ( (DesignerHostListener) i.next()).componentSelected(comp);
      }
    }
  }

  private void fireComponentInfoSelected(ComponentInfo compInfo) {
    if (dhListenerList != null) {
      Iterator i = new ArrayList(dhListenerList).iterator();
      while (i.hasNext()) {
        ( (DesignerHostListener) i.next()).componentInfoSelected(compInfo);
      }
    }
  }

  private void fireDesignerActivated(LiveDesigner designer) {
    if (dhListenerList != null) {
      Iterator i = new ArrayList(dhListenerList).iterator();
      while (i.hasNext()) {
        DesignerHostListener listener = (DesignerHostListener) i.next();
        //System.out.println("DesignerActivated listener="+listener); //NORES
        listener.designerActivated(designer);
      }

      if (myLeftSplitter.getDividerLocation() > 0) {
        storeDividerPosition();
      }
      /**
       * Notify palette directly since its not a DesignerHostListener
       * and this is all it needs know about
       */
      myPalette.designerActivated(this, designer);
//      if (myPalette.isEmpty()) {
      if (! designer.showPalette() || myPalette.isEmpty()) {
        myLeftSplitter.setLeftComponent(null);
        myLeftSplitter.setDividerSize(0);
      }
      else {
        if (myLeftSplitter.getLeftComponent() == null) {
          myLeftSplitter.setLeftComponent(myPaletteComponent);
          myLeftSplitter.setDividerSize(SPLITTER_DIVIDER_SIZE);
        }
        myLeftSplitter.setDividerLocation(SPLITTER_POSITION.getInteger());
      }
    }
  }

  private void storeDividerPosition() {
    try {
      int currentLocation = myLeftSplitter.getDividerLocation();
      if (myPalette.isEmpty()) {
        return;
      }

      if (SPLITTER_POSITION.getInteger() != currentLocation) {
        SPLITTER_POSITION.setInteger(currentLocation);
      }
    }
    catch (Exception e) {
      Debug.printStackTrace(e);
    }
  }

  private void fireManagerChanged(LiveDesignerManager manager) {
    if (dhListenerList != null) {
      Iterator i = new ArrayList(dhListenerList).iterator();
      while (i.hasNext()) {
        ( (DesignerHostListener) i.next()).managerChanged(manager);
      }
    }
  }

  private void fireDesignerChanged(LiveDesigner designer) {
    if (dhListenerList != null) {
      Iterator i = new ArrayList(dhListenerList).iterator();
      while (i.hasNext()) {
        ( (DesignerHostListener) i.next()).designerChanged(designer);
      }
    }
  }

  private void fireDesignerCleared(LiveDesigner designer) {
    if (dhListenerList != null) {
      Iterator i = new ArrayList(dhListenerList).iterator();
      while (i.hasNext()) {
        ( (DesignerHostListener) i.next()).designerCleared(designer);
      }
    }
  }


  private void fireComponentCreated(LiveComponent comp) {
    if (dhListenerList != null) {
      Iterator i = new ArrayList(dhListenerList).iterator();
      while (i.hasNext()) {
        ( (DesignerHostListener) i.next()).componentCreated(comp);
      }
    }
  }

  private void fireComponentChanged(LiveComponent comp) {
    if (dhListenerList != null) {
      Iterator i = new ArrayList(dhListenerList).iterator();
      while (i.hasNext()) {
        ( (DesignerHostListener) i.next()).componentChanged(comp);
      }
    }
  }

  private void fireComponentDisposed(LiveDesigner designer, Object compInstanceKey) {
    if (dhListenerList != null) {
      Iterator i = new ArrayList(dhListenerList).iterator();
      while (i.hasNext()) {
        ( (DesignerHostListener) i.next()).componentDisposed(designer,
          compInstanceKey);
      }
    }
  }

  private void fireComponentDisposing(LiveDesigner designer, LiveComponent comp) {
    if (dhListenerList != null) {
      Iterator i = new ArrayList(dhListenerList).iterator();
      while (i.hasNext()) {
        ( (DesignerHostListener) i.next()).componentDisposing(designer, comp);
      }
    }
  }

  private void firePropertyChanged(LiveProperty prop) {
    if (dhListenerList != null) {
      Iterator i = new ArrayList(dhListenerList).iterator();
      while (i.hasNext()) {
        ( (DesignerHostListener) i.next()).propertyChanged(prop);
      }
    }
  }

  private void fireEventChanged(LiveEvent event, String oldHook) {
    if (dhListenerList != null) {
      Iterator i = new ArrayList(dhListenerList).iterator();
      while (i.hasNext()) {
        ( (DesignerHostListener) i.next()).eventChanged(event, oldHook);
      }
    }
  }


  //update L&F for all non-active designer panels
  public void updateUI() {
    super.updateUI();
    if (designerPanelHash != null) {
      Iterator iterator = designerPanelHash.values().iterator();
      while (iterator.hasNext()) {
        DesignerPanel designerPanel = (DesignerPanel) iterator.next();
        if (designerPanel != activeDesignerPanel ) {
          SwingUtilities.updateComponentTreeUI(designerPanel);
        }
      }
    }
  }

  private void jbInit() throws Exception {
    this.setLayout(new BorderLayout(0, 0));

    myPalette = new Palette();
    inspector = Inspector.getInstance(this);
    addDesignerHostListener(inspector);
    structurePane = new DesignerStructurePanel(this);
    addDesignerHostListener(structurePane);

    myPaletteComponent = myPalette.getUIComponent(this);
    myLeftSplitter = createSplitter(myPaletteComponent, hostPanel);
    myLeftSplitter.setResizeWeight(0); //A value of 0, indicates the right/bottom component gets all the extra space (the left/top component acts fixed)
    splitter = createSplitter(myLeftSplitter, inspector.getUIComponent());
    splitter.setResizeWeight(1.0); //If you want the right component to stay the same size and left component to be flexible when the split pane gets bigger, set the resize weight to 1.0.

    myLeftSplitter.setFocusable(false);
    splitter.setFocusable(false);
    //addDesignerButtons(); //defer till after manager activates

    this.add(splitter, BorderLayout.CENTER);
    manager.addDesignerListener(this);

    SwingUtilities.invokeLater(new Runnable() {
      public void run() {
        int storedLocation = SPLITTER_POSITION.getInteger();
        if (storedLocation >= 0) {
          myLeftSplitter.setDividerLocation(storedLocation);
        }
        else {
          myLeftSplitter.setDividerLocation(SPLITTER_PROPORTION);
        }
        splitter.setDividerLocation(SPLITTER_PROPORTION);
        LiveDesigner dd = getDefaultDesigner();
        if (dd != null) {
          setActiveDesigner(dd);
        }
      }
    });
  }

  private static JSplitPane createSplitter(JComponent left, JComponent right) {
    JSplitPane splitPane = new ProportionalSplitPane(false, ProportionalSplitPane.HORIZONTAL_SPLIT, true) {
      public void paintBorder(Graphics g) {
        // suppress border painting.
      }
    };
    splitPane.setLeftComponent(left);
    splitPane.setRightComponent(right);
    final Dimension zero = new Dimension(1, 0);
    left.setMinimumSize(zero);
    right.setMinimumSize(zero);
    splitPane.setDividerSize(SPLITTER_DIVIDER_SIZE);
    return splitPane;
  }

  // If more than a single designer provide Designer buttons on bottom of panel.
  // designer button holds designer refenrece - @todo cleanUp
  private void addDesignerButtons() {
    if (madeBtns) {
      return;
    }
    madeBtns = true;
    LiveDesigner[] ds = manager.getAllDesigners();
    if (ds.length <= 1) {
      return;
    }
    JPanel bottomPanel = new JPanel(new GridBagLayout());
    final JLabel label=new JLabel("Active designer:"); // RES ActiveDesignerLabel
    bottomPanel.add(label,
      new GridBagConstraints(0, 0, 1, 1, 0.0, 1.0,
      GridBagConstraints.WEST,
      GridBagConstraints.NONE,
      new Insets(2, 6, 2, 2), 0, 0));
    label.setOpaque(true);
    /*final FocusManager focusManager=FocusManager.getCurrentManager();
    focusManager.addPropertyChangeListener(new PropertyChangeListener () {
      public void propertyChange(PropertyChangeEvent evt) {
        Component focusOwner = focusManager.getPermanentFocusOwner();
//        System.out.println(" focusOwner="+focusOwner); //NORES
        Container container = SwingUtilities.getAncestorOfClass(DesignerHostPanel.class, focusOwner);
        if (container == DesignerHostPanel.this) {
          label.setBackground(UIManager.getColor("activeCaption"));
        }
        else {
          label.setBackground(UIManager.getColor("inactiveCaption"));
        }
      }
    }
    );*/

    for (int d = 0; d < ds.length; d++) {
      DesignerStateAction dsa = new DesignerStateAction(ds[d]);
      DesignerInfo di = ds[d].getDesignerInfo();
      dsa.setShortText(di.getDisplayName());
      dsa.setLongText(di.getDescription());
      dsa.setSmallIcon(Utils.createIcon(di.getDisplayIcon()));
      ActionButton ab = new ActionButton(bottomPanel, dsa);
      ab.setShowText(true);
      ab.setShowIcon(true);
      ab.setFixedWidth((int)ab.getPreferredSize().getWidth() + ab.getGapSize() + dsa.getSmallIcon().getIconWidth());
      bottomPanel.add(ab,
        new GridBagConstraints(d + 1, 0, 1, 1, 0.0, 1.0,
        GridBagConstraints.WEST,
        GridBagConstraints.NONE,
        new Insets(2, 2, 2, 2), 4, 0));
    }
    bottomPanel.add(new JPanel(),
      new GridBagConstraints(ds.length + 1, 0, 1, 1, 1.0, 1.0,
      GridBagConstraints.WEST,
      GridBagConstraints.HORIZONTAL,
      new Insets(0, 0, 0, 0), 0, 0));
    this.add(bottomPanel, BorderLayout.SOUTH);
  }

  private LiveDesigner getDefaultDesigner() {
    LiveDesigner defaultDesigner = manager.getDesigner(manager.getDefaultDesignerKey());
    if (defaultDesigner == null) {
      LiveDesigner[] allDesigners = manager.getAllDesigners();
      if (allDesigners != null && allDesigners.length > 0) {
        defaultDesigner = allDesigners[0];
      }
    }
    return defaultDesigner;
  }

  /**
   * Action for Designer Buttons
   */
  public class DesignerStateAction
    extends StateAction {
    protected Object myDesignerKey;
    public DesignerStateAction(LiveDesigner designer) {
      myDesignerKey=designer.getDesignerInfo().getDesignerKey();
    }

    public void setState(Object source, boolean state) {
      if (state) {
        if (manager != null) {
            setActiveDesigner(manager.getDesigner(myDesignerKey));
            ((JPanel) source).repaint(100);
        }
      }
    }

    public boolean getState(Object source) {
      LiveDesigner designer=getActiveDesigner();
      if (designer == null) {
        return false;
      }
      return designer.getDesignerInfo().getDesignerKey() == myDesignerKey;
    }
  }

  /**
   * Flag that signals that we're loading a new buffer in the
   * Designer
   * @param loading new loading setting
   */
  public void setLoading(boolean loading) {
    this.loading = loading;
    getStructurePane().setLoading(loading);
  }

  public void setModified(boolean modified) {
    // Ignore calls to setModified while we're
    // loading a new Persistence data
    if (loading) {
      return;
    }
    this.modified = modified;
    if (modified) {
      setBufferModified();
    }
  }


  private void setBufferModified() {
//    try {
//      ( (FileNode) context.getNode()).getBuffer().setModified(true);
//    }
//    catch (Exception x) {
//      Debug.printStackTrace(x);
//    }
    viewer.informBufferOfUpdate();
  }

  public boolean isModified() {
    return modified || manager.isPersistenceDataModified();
  }

  public void managerChanged(LiveDesignerManager manager) {
    // manager changes under us - reload everything we 'know' about it

    /** @todo: reload DesignerInfo/ComponentInfo if cached anywhere  */
    myPalette.reloadPalette(this);
    if (manager.isLost()) {
      managerLost(manager);
    }
  }

  public void managerLost(LiveDesignerManager mgr) {
    getComponentModel().invalidateModel();

    setModified(false); // Lose any changes since we cant persist them

    loseDesigner();

    try {
      context.getBrowser().closeNode(context.getNode());
    }
    catch (java.lang.Exception e) {
    }

    /** @todo The dialog below will never show up, because loseDesigner will kill the
          parent window to which it would be displayed.
     */
//    showLostDialog();
  }

//  private void showLostDialog() {
//    // Show lost Live DesignerManager dialog and initiate display of source
//    ResultMessage[] rms = new ResultMessage[4];
//    rms[0] = new tResultMessage(ResultMessage.TYPE_CRITICAL,
//      "Designer Server Lost",
//      "Lost Connection to the Designer Server");
//    rms[1] = new tResultMessage(ResultMessage.TYPE_INFORMATION,
//      null,
//      "Removing access to Designers for this Component Model");
//    rms[2] = new tResultMessage(ResultMessage.TYPE_INFORMATION,
//      null,
//      "Any unsaved changes to this point have been lost");
//    rms[3] = new tResultMessage(ResultMessage.TYPE_INFORMATION,
//      null,
//      "You should probably restart the Builder...");
//    /** @todo Change this when/if implement server restart after Builder startup,
//     *  like if access ACM and server not running
//     */
//
//    ResultMessageDialog.showModalDialog(this, rms, null);
//  }

  // trigger swapping to non DesignerNode
  private void loseDesigner() {
    viewer.disableViewer();
    viewer.closeDesigner();
  }

  public void designerCleared(LiveDesigner designer) {
    fireDesignerCleared(designer);
  }

  public void designerChanged(LiveDesigner designer) {
    if (getActiveDesigner() == designer) {
      hostPanel.invalidate();
      validate();
      doLayout();
      repaint(100);
    }
    fireDesignerChanged(designer);
  }

  private void notifyHysteresisManager(LiveComponent comp) {
    if (manager instanceof ComponentChangeHysteresis) {
      ((ComponentChangeHysteresis)manager).handleComponentChanged(comp);
    }
  }

  public void componentCreated(LiveComponent comp) {
    setModified(true);
    if (comp.getParentContainer() != null) {
      fireComponentChanged(comp.getParentContainer());
    }
    fireComponentCreated(comp);
    notifyHysteresisManager(comp);
  }

  public void componentDisposing(LiveDesigner designer, LiveComponent lc) {
    fireComponentDisposing(designer, lc);
    /** @todo fix timing issues with primetime and buffer updates */
    // There is a problem with the buffer updating mechanism whereby
    // if we set a buffer updater on a buffer when that file is open
    // in the IDE, we will immediately be called back for the buffer
    // contents.  This is very bad, as at the point of disposing the component
    // we haven't actually removed it from the model yet, and the bits that
    // will be dumped into the buffer aren't what we really want there.  So
    // we've moved this for the RTM build to componentDisposed, and we'll
    // sort out the proper fix later.  See the implementation of the
    // hystersis interface in JBDesignerManager for how we use buffer
    // updaters.  Ref RAID 197139.
  //    notifyHysteresisManager(lc);
  }

  public void componentDisposed(LiveDesigner designer, Object compInstanceKey) {
    setModified(true);
    fireComponentDisposed(designer, compInstanceKey);

    /** @todo Hack for RTM.  See comment in componentDisposing */
    notifyHysteresisManager(null);
  }

  public void propertyChanged(LiveProperty prop) {
    setModified(true);
    firePropertyChanged(prop);
    notifyHysteresisManager(prop.getComponent());
  }

  public void eventChanged(LiveEvent event, String oldHook) {
    setModified(true);
    fireEventChanged(event, oldHook);
    notifyHysteresisManager(event.getComponent());
  }

  public void componentChanged(LiveComponent comp) {
    setModified(true);
    fireComponentChanged(comp);
    this.notifyHysteresisManager(comp);
  }

  public void setCodeManager(ICodeManager codeManager) {
    if (this.codeManager != null) {
      removeDesignerHostListener(this.codeManager);
      this.codeManager.deleteObserver(this);
    }
    // Here make sure we set the codeManager member before we add
    // since there's logic in addDesignerHostListener to ensure
    // that the CodeManager is last. This logic relies on
    // the codeManager data member being set before addDesignerHostListener is called
    this.codeManager = codeManager;
    if (codeManager != null) {
      addDesignerHostListener(codeManager);
      codeManager.addObserver(this);
    }
  }

  /**
   * Tell anything thats specifically interested that a Component has had
   * its name changed.
   * @param lc Live Component just renamed
   * @param oldName Original Live component name
   */
  public void componentRenamed(LiveComponent lc, String oldName) {
    // notify the CM explicitly
    CodeManagerEvent ehev = new CodeManagerEvent(CodeManagerEvent.COMPONENT_RENAMED, this, lc, oldName);
    fireCodeManagerNotification(ehev);
  }

  /**
   * Ask CodeManager for list of Tags for this event.
   *
   * @param le LiveEvent to query
   * @return Array of Tags
   */
  public Tag[] getEventTags(LiveEvent le) {
    CodeManagerEvent ehev = new CodeManagerEvent(CodeManagerEvent.GET_COMPATIBLE_EVENT_HANDLERS, this, le);
    Result result = fireCodeManagerNotification(ehev);
    if (result == null || result.isSuccess()) {
      return ehev.getEventTags();
    } else {
      return null;
    }
  }

  /**
   * Get CM to generate a HookEventName
   * @param le LiveEvent being hooked
   * @return  generated hook Name
   */
  public String createEventHandler(LiveEvent le) {
    CodeManagerEvent ehev = new CodeManagerEvent(CodeManagerEvent.GENERATE_DEFAULT_EVENT_NAME, this, le);
    Result result = fireCodeManagerNotification(ehev);
    if (result == null || result.isSuccess()) {
      return ehev.getEventHandlerName();
    } else {
      return ""; //NORES
    }
  }

  /**
   * Notify CM that a LiveEvents' event hook is being cleared.
   * LiveEvent hook value is empty or null.
   * Previous hookName value is provided
   *
   * @param le Live event whose hook is being cleared
   * @param oldHook - hookname prior to clearing
   */
  public void clearEventHandler(LiveEvent le, String oldHook) {
    CodeManagerEvent ehev = new CodeManagerEvent(CodeManagerEvent.EVENT_CLEARED, this, le);
    ehev.setEventHandlerName(oldHook);
    fireCodeManagerNotification(ehev);
  }

  /**
   * Notify CM that desire to be shown Code for given liveEvent
   * and hook value.
   * @param le LiveEvent to displayhook for
   * @param hook current hook value, normally same as le.getHookAsText()
   */
  public void navigateToEventHandler(LiveEvent le, String hook) {
    CodeManagerEvent ehev = new CodeManagerEvent(CodeManagerEvent.EVENT_NAVIGATE_TO_HANDLER, this, le);
    ehev.setEventHandlerName(hook);
    fireCodeManagerNotification(ehev);
  }

  /**
   * Tell CodeManager that an event has been renamed
   * @param liveEvent
   * @param oldName
   * @param newName
   */
  public void eventHandlerRenamed(LiveEvent liveEvent, String oldName) {
    CodeManagerEvent cmEvent = new CodeManagerEvent(CodeManagerEvent.EVENT_RENAMED, this, liveEvent, oldName);
    fireCodeManagerNotification(cmEvent);
  }

  /**
   * Notify CodeManger EventHooks should be revalidated
   * @param ld Live Designer for this design hierarchy.
   * @param lc root LiveComponent to revalidate from (null)
   */
  protected void codeManagerValidate() {
    CodeManagerEvent ehev = new CodeManagerEvent(CodeManagerEvent.VALIDATE_ALL, this);
    fireCodeManagerNotification(ehev);
  }

  /**
   * Send CodeManager an notification
   * @param ehev
   */
  private Result fireCodeManagerNotification(CodeManagerEvent ehev) {
    if (codeManager != null) {
      Result result = codeManager.codeManagerEvent(ehev);
      this.handleResult("Designer Code Manager", result); // NORES
      return result;
    }
    return null;
  }

  public ICodeManager getCodeManager() {
    return codeManager;
  }

  // get BufferContent for storage - store to vfs
  public byte[] getBufferContent(Buffer buf) {
    modified = false;
    byte[] data = manager.getPersistenceData();
    if (manager.getComponentModel()instanceof PersistenceConverter) {
      PersistenceResult presult = ( (PersistenceConverter) manager.getComponentModel()).
        convertPersistenceDataToBuffer(data);
      handleResult("Converting persistence data to buffer using the ComponentModel", // NORES
        presult);
      if (presult != null && presult.isSuccess()) {
        data = presult.getBytes();
      }
    }
    Node node = context.getNode();
    if (node instanceof PersistenceConverter) {
      PersistenceResult presult = ( (PersistenceConverter) node).
        convertPersistenceDataToBuffer(
        data);
      handleResult("Converting persistence data to buffer using the Node", presult); // NORES
      if (presult != null && presult.isSuccess()) {
        data = presult.getBytes();
      }
    }
    if (codeManager instanceof PersistenceConverter) {
      PersistenceResult presult = ( (PersistenceConverter) codeManager).
        convertPersistenceDataToBuffer(data);
      handleResult("Converting persistence data to buffer using the CodeManager", // NORES
        presult);
      if (presult != null && presult.isSuccess()) {
        data = presult.getBytes();
      }
    }

    String k = ( (FileNode) node).getUrl().getFullName();
    ClientPersistData.store(k);

    LiveDesigner ld = getActiveDesigner();
    if (ld == null) {
      ld = getDefaultDesigner();
    }
    return data;
  }

  // load Buffer with Content - loaded from vfs
  public void setBufferContent(byte[] buffer) {
    LiveDesigner ld = getDefaultDesigner();

    if (codeManager instanceof PersistenceConverter) {
      PersistenceResult presult = ( (PersistenceConverter) codeManager).
        convertBufferToPersistenceData(buffer);
      handleResult("Converting buffer to persistence data using the CodeManager", // NORES
        presult);
      if (presult != null && presult.isSuccess()) {
        buffer = presult.getBytes();
      }
    }
    Node node = context.getNode();
    if (node instanceof PersistenceConverter) {
      PersistenceResult presult = ( (PersistenceConverter) node).
        convertBufferToPersistenceData(
        buffer);
      handleResult("Converting buffer to persistence data using the Node", presult); // NORES
      if (presult != null && presult.isSuccess()) {
        buffer = presult.getBytes();
      }
    }
    if (manager.getComponentModel()instanceof PersistenceConverter) {
      PersistenceResult presult = ( (PersistenceConverter) manager.getComponentModel()).
        convertBufferToPersistenceData(buffer);
      handleResult("Converting buffer to persistence data using the ComponentModel", // NORES
        presult);
      if (presult != null && presult.isSuccess()) {
        buffer = presult.getBytes();
      }
    }

    // If a manager implements ContextSetter it means that it needs the current
    // context
    if (manager instanceof ContextSetter) {
      ( (ContextSetter) manager).setContext(context);
    }

    Object activeDesignerKey = getActiveDesigner() != null ?
      getActiveDesigner().getDesignerInfo().getDesignerKey() : null;
    handleResult("Setting persistence data on manager", // NORES
      manager.setPersistenceData(buffer));

    // tell CM to validate its events.
    codeManagerValidate(); // shld pass root LiveComponent

    clearDesignerPanels(); //?
    mySelectedPath=null;
    selectedComp=null;
    selectedCompInfo=null;

    modified = false;
    //syncRootComponents(); //lazy creation of DesignerPanels @see setActiveDesigner
    LiveDesigner d = manager.getDesigner(activeDesignerKey);
    if (d != null) {
      setActiveDesigner(d);
    }
  }

  public void syncRootComponents() {
    //commented out - lazy creation of DesignerPanels @see setActiveDesigner
//    LiveDesigner[] lds = manager.getAllDesigners();
//    for (int i = 0; lds != null && i < lds.length; i++) {
//      DesignerPanel dp = getDesignerPanel(lds[i]);
//      if (dp != null) {
//        dp.syncRootComponents();
//      }
//    }
  }

  /**
   * should be used to prepare this for GC and ensure that it does not hold any references
   */
  public void destroy() {
    handleResult("Disposing designer", // NORES
      manager.getComponentModel().disposeDesignerManager(manager.
      getManagerInstanceKey()));
    this.removeAll();
    Iterator iterator=designerPanelHash.values().iterator();
    while (iterator.hasNext()) {
      DesignerPanel designerPanel=(DesignerPanel)iterator.next();
      designerPanel.destroy();
    }
    dhListenerList=null;
    designerPanelHash=null;
    activeDesignerPanel=null;
    mySelectedPath = null;
    selectedComp = null;
    selectedCompInfo = null;
    hostTags = null;
    codeManager = null;

    myPalette=null;
    splitter=null;
    myLeftSplitter=null;
    myPaletteComponent=null;
    manager=null;
    context=null;
    viewer=null;
    if (inspector != null) {
      inspector.destroy();
      inspector=null;
    }
    if (structurePane != null) {
      structurePane.destroy();
      structurePane=null;
    }
    if (hostPanel != null) {
      hostPanel.removeAll();
      hostPanel=null;
    }
  }

 /**
 * should be used if this panel could be reused
 * @todo
 */
//  private void cleanUp() {
//    clearDesignerPanels();
//    mySelectedPath=null;
//    selectedComp=null;
//    selectedCompInfo=null;
//    dhListenerList=null;
//    //designerPanelHash=null;
//    activeDesignerPanel=null;
//    hostTags=null;
//    codeManager=null;
//    if (inspector != null) {
//      inspector.cleanUp();
//    }
//    if (structurePane != null) {
//      structurePane.cleanUp();
//    }
//    if (hostPanel != null) {
//      hostPanel.removeAll();
//    }
//  }

  // find LiveEvent corresponding to given LiveComponent key and Event path
  private LiveEvent getLiveEvent(Object compInstanceKey, Object eventKey) {
    LiveComponent lc = getActiveDesigner().getComponent(compInstanceKey);
    if (lc == null) {
      return null; //oops!
    }

    return lc.getEvent(new Object[] {
      eventKey});
  }

  // Observer interface implementation
  // For notification from CodeManager
  public void update(Observable o, Object d) {
    if (! (d instanceof EHookEventCM)) {
      return;
    }
    EHookEventCM eh = (EHookEventCM) d;

    LiveEvent le = getLiveEvent(eh.getCompInstanceKey(), eh.getEventKey());
    if (le == null) {
      com.borland.primetime.util.Debug.trace(
        DesignerHostPanel.class, "update(Live event lookup failed " // NORES
        + "comp=" + eh.getCompInstanceKey() // NORES
        + ", event=" + eh.getEventKey() // NORES
        + ")"); // NORES
      return;

    }
    String hookText = eh.getHookText();
    String oldHook = le.getHookAsText();
    le.setHookAsText(hookText);
    fireEventChanged(le, oldHook); // update displays
  }

  // internal/transient ResultMessage
  private class tResultMessage
    implements ResultMessage {
    private String msg;
    private String title;
    private int type;

    public tResultMessage(int type, String title, String msg) {
      this.type = type;
      this.msg = msg;
      this.title = title;
    }

    public int getMessageType() {
      return type;
    }

    public String getMessageTitle() {
      return title;
    }

    public String getMessageText() {
      return msg;
    }

    public ImageData getMessageIcon() {
      return null;
    }
  }
}
