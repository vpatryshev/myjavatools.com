package com.borland.acm.db;

import com.borland.acm.*;

/**
 *
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public interface LiveDBContainer extends LiveDBComponent, LiveContainer {

  /**
   *
   * @param index
   * @return
   */
  public LiveDBComponent getDBComponent(int index);

  /**
   *
   * @return
   */
  public LiveDBComponent[] getDBComponents();

  /**
   *
   * @param compInstanceKey
   * @return
   */
  public LiveDBComponent getDBComponent(Object compInstanceKey);
}
