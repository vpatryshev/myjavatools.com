package com.borland.acm;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * @todo Doc what this does and is used for
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Borland Software Corporation</p>
 * @author not attributable
 * @version 1.0
 */
public class LiveReference implements LiveComponent {
  private LiveReferenceCollection mySource;
  private LiveComponent myDestination;

  public LiveReference(LiveReferenceCollection source, LiveComponent destination) {
    mySource=source;
    myDestination=destination;
  }

  public LiveReferenceCollection getSource() {
    return mySource;
  }

  public LiveComponent getDestination() {
    return myDestination;
  }

  //implements LiveComponent by delegation most of methods to "destination"
  //
  public Object getInstanceKey() {
    return myDestination.getInstanceKey();
  }
  public String getInstanceName() {
    return myDestination.getInstanceName();
  }

  public boolean canCopy() {
    return true;
  }

  public boolean canDelete() {
    return true;
  }
  public boolean isUserRenamable() {
    return false;
  }

  public Result setInstanceName(String name) {
    return myDestination.setInstanceName(name);
  }

  public LiveDesigner getDesigner() {
    return myDestination.getDesigner();
  }
  public boolean testSetParentContainer(LiveContainer parent) {
    return false;
  }

  public Result setParentContainer(LiveContainer parent) {
    //throw new RuntimeException("method setParentContainer() should not be called on LiveReference instance!");
    return null;
  }

  public LiveContainer getParentContainer() {
    //throw new RuntimeException("method getParentContainer() should not be called on LiveReference instance!");
    //System.out.println("method getParentContainer() should not be called on LiveReference instance!!!");
    return myDestination.getParentContainer();
  }

  public LiveProperty[] getProperties() {
    return myDestination.getProperties();
  }
  public LiveProperty getProperty(Object[] propertyKeyPath) {
    return myDestination.getProperty(propertyKeyPath);
  }
  public LiveEvent[] getEvents() {
    return myDestination.getEvents();
  }
  public LiveEvent getEvent(Object[] eventKeyPath) {
    return myDestination.getEvent(eventKeyPath);
  }
  public ComponentInfo getComponentInfo() {
    return myDestination.getComponentInfo();
  }
  public Tag[] getContextTags(int x, int y) {
    return myDestination.getContextTags(x,y);
  }

  public void needsRefresh() {
    myDestination.needsRefresh();
  }
}
