package com.borland.acm.util;

import java.util.*;
import com.borland.acm.*;

/**
 *
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public class BasicTagGroup
  extends BasicTag
  implements TagGroup {

  protected boolean invokable = false;
  protected boolean popup = false;
  protected List tagList = new ArrayList();

  public BasicTagGroup() {
    super("");
  }

  public BasicTagGroup(Object key) {
    super(key);
  }

  public BasicTagGroup(Object key, boolean popup) {
    super(key);
    this.popup = popup;
  }

  public BasicTagGroup(Object key, String value) {
    super(key, value);
  }

  public BasicTagGroup(Object key, String value, boolean popup) {
    super(key, value);
    this.popup = popup;
  }

  public BasicTagGroup(Object key, ImageData imageData) {
    super(key, imageData);
  }

  public BasicTagGroup(Object key, ImageData imageData, boolean popup) {
    super(key, imageData);
    this.popup = popup;
  }

  public BasicTagGroup(Object key, String value, ImageData imageData) {
    super(key, value, imageData);
  }

  public BasicTagGroup(Object key, String value, ImageData imageData, boolean popup) {
    super(key, value, imageData);
    this.popup = popup;
  }

  public int getTagCount() {
    return tagList.size();
  }

  public Tag getTag(int index) {
    return (Tag) tagList.get(index);
  }

  public Tag[] getTags() {
    return (Tag[]) tagList.toArray(new Tag[tagList.size()]);
  }

  public void addTag(Tag tag) {
    tagList.add(tag);
  }

  public void addTag(int index, Tag tag) {
    tagList.add(index, tag);
  }

  public void removeTag(Tag tag) {
    tagList.remove(tag);
  }

  public void removeTag(int index) {
    tagList.remove(index);
  }

  public void setInvokable(boolean invokable) {
    this.invokable = invokable;
  }

  public boolean isInvokable() {
    return invokable;
  }

  public void setPopup(boolean popup) {
    this.popup = popup;
  }

  public boolean isPopup() {
    return popup;
  }
}