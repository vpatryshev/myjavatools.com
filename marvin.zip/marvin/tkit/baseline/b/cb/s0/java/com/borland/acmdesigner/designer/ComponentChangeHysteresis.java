package com.borland.acmdesigner.designer;

import com.borland.acm.LiveComponent;

/**
 * <p>Title: </p>
 * <p>Description: </p>
* This is really a hack interface.  It's here to allow designer panels to
* notify designer managers of changes to components.  It's a hysteresis in that
* some of the notifications that come to the designer panels are from the
* designer manager itself, so you have to be careful what you do with this in
* the designer managers.  The reason the interface is here, and this wasn't
* just tracked in the designer managers is that there are other sources of
* component change notifications that sometimes need to get back to the
* designer managers, and those don't come from the designer managers.
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Borland Software Corporation</p>
 * @author Eli Boling
 * @version 1.0
 */

public interface ComponentChangeHysteresis {
  /**
   * Fired when a component is changing in any way.  Could be a delete operation,
   * could be a property change.  Basically, this interface guarantees you that some
   * data in the component, and therefore the component model has changed.
   * @param comp LiveComponent
   */
  void handleComponentChanged(LiveComponent comp);
}
