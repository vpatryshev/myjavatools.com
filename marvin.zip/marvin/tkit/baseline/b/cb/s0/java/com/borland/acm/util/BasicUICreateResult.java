package com.borland.acm.util;

import com.borland.acm.*;
import com.borland.acm.ui.*;

/**
 *
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public class BasicUICreateResult extends BasicResult implements UICreateResult {

  public static BasicUICreateResult create(boolean success, LiveUIComponent uiComp) {
    return new BasicUICreateResult(success, uiComp);
  }

  public static BasicUICreateResult create(boolean success, LiveUIComponent uiComp, ResultMessage[] messages) {
    return new BasicUICreateResult(success, uiComp, messages);
  }

  public static BasicUICreateResult create(boolean success, LiveUIComponent uiComp, ResultMessage[] messages, Tag[] options) {
    return new BasicUICreateResult(success, uiComp, messages, options);
  }

  protected LiveUIComponent uiComp;

  public BasicUICreateResult(LiveUIComponent uiComp) {
    this.uiComp = uiComp;
  }

  public BasicUICreateResult(boolean success, LiveUIComponent uiComp) {
    super(success);
    this.uiComp = uiComp;
  }

  public BasicUICreateResult(boolean success, LiveUIComponent uiComp, ResultMessage[] messages) {
    super(success, messages);
    this.uiComp = uiComp;
  }

  public BasicUICreateResult(boolean success, LiveUIComponent uiComp, ResultMessage[] messages, Tag[] options) {
    super(success, messages, options);
    this.uiComp = uiComp;
  }

  public void setUIComponent(LiveUIComponent uiComp) {
    this.uiComp = uiComp;
  }

  public LiveComponent getComponent() {
    return uiComp;
  }

  public LiveUIComponent getUIComponent() {
    return uiComp;
  }
}