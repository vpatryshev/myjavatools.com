package com.borland.acmdesigner;

import java.util.Observer;
import com.borland.acm.*;
import com.borland.acmdesigner.designer.*;
/**
 *
 * <p>CodeManager Interface </p>
 * <p>Interface for interacting with a CodeManager.
 * Over and above DesignerHotsListener it needs to support sending an
 * EHookEvent and being setup to notify something else of changes
 * (Observer maintenance).
 *  </p>
 * <p>Copyright: Copyright (c) Borland Inc 2002</p>
 * <p>Company: Borland </p>
 * @author Joe Nuxoll Modified hops
 * @version 1.0
 */
public interface CodeManager extends DesignerHostListener {
  /**
   * Notify CodeManager of an action on EventHooks that CodeManager needs
   * to be aware of.
   * Action and target info is encapsulated in EHookEvent.
   *
   * @param ehev Parameter packet describing action update to Code Manager.
   */
  public void  eventAction(CodeManagerEvent ehev);

  /**
   * Add an Observer as a Listener/Watcher to notifications from the CodeManager
   * CodeManager is expected to provide to update() an instance of EHookEventCM.
   *
   * @param o Observer to add
   */
  public void addObserver(Observer o);

  /**
   * Remove an Observer from receiving notifications from a CodeManager
   * @param o Observer to add
   */
  public void deleteObserver(Observer o);
}