package com.borland.acm.db;

import com.borland.acm.*;

/**
 *
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public interface LiveDBComponent extends LiveComponent {

  /**
   *
   * @return
   */
  public LiveDBDesigner getDBDesigner();

  /**
   *
   * @return
   */
  public LiveDBContainer getParentDBContainer();
}
