package com.borland.acmdesigner;

import com.borland.acm.*;

public interface DesignableNode {
  public Object getComponentModelKey();
}
