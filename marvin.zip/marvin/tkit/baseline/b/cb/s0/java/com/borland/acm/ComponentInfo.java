package com.borland.acm;

import com.borland.primetime.ide.palette.PaletteItemInfo;

/**
 * The ComponentInfo interface describes the meta-data for a component type.
 * This includes all properties, methods, and events (PME).
 * This also provides information for displaying the component on the palette,
 * such as a display name, description, and image data for an icon.
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public interface ComponentInfo extends PaletteItemInfo {

  /**
   * Returns the unique type key for this component type.
   * This key must be unique across all of the component types provided in
   * the component model.  It is up to the implementor to determine the
   * appropriate key scheme.  An example that might be used if implementing
   * a JavaBeans component  model would be to use the full Java class name
   * to identify the type: e.g. "javax.swing.JButton".
   *
   * @return A unique type key that identifies this component type
   */
  public Object getTypeKey();

  /**
   * Returns the display name to identify the unique component type.
   * This would be the human-readable name for the component type.
   * This text also appears as a tooltip on the palette.
   *
   * @return The human-readable display name for this component type
   */
//  public String getDisplayName();

  /**
   * Returns a description of this component type.
   * This may be a bit more wordy, as it will appear along the status line
   * as the user 'hovers' the mouse over the component in the palette.
   *
   * @return A description of this component type
   */
//  public String getDescription();

  /**
   * Returns image data for the component's display icon on the component
   * palette.  This should be a 32x32 color image.
   * If null is returned a default image will be used.
   *
   * @return The 32x32 display icon for this component or null
   */
  public ImageData getPaletteIcon();

  /**
   * Returns image data for the component's display icon in the component tree.
   * This should be a 16x16 color image.
   * If null is returned, a default image will be used.
   *
   * @return The 16x16 display icon for this component or null.
   */
  public ImageData getTreeIcon();

  /**
   * Provide the header or Interface file name for this component.
   * Used by the CodeManager for placing #include inclusions in
   * source manipulating an instance of this component.
   *
   * @return Component Header filename for this Component
   */
  public String getHdrFileName();

  /**
   * Returns an array of PropertyInfo objects representing the property
   * meta-data for this component type.
   * This *may* be a dynamic list, so the actual list of properties shown in
   * the inspector is driven by the LiveComponent.getProperties() method.
   * This list is used for a meta-data listing before a live component is
   * actually created.
   *
   * @return An array of PropertyInfo objects representing this component
   * type's property meta-data.
   * @see LiveProperty#getProperties()
   */
  public PropertyInfo[] getPropertyInfos();

  /**
   * Returns a PropertyInfo object with the specified unique property key
   * hierarchy.
   *
   * @param propertyKeyPath The key hierarchy for the desired property
   *     (index 0 being the top-level property).
   * @return The specified PropertyInfo
   * @see PropertyInfo#getPropertyKey()
   */
  public PropertyInfo getPropertyInfo(Object[] propertyKeyPath);

  /**
   * Returns the 'default' property key.
   * This is used for when the user has a component selected on the design
   * surface, has the property inspector showing, but does not have a specific
   * property selected on the inspector, and starts to type.
   * The keystrokes will become edits to the 'default' property of the
   * component.  This is not the case, however, if the user has a specific
   * property or event already selected in the inspector.
   * The keystrokes on the component will be treated as edits to the
   * 'current' property or event in the inspector.
   *
   * @return The property key for the 'default' property of this component type
   * @see PropertyInfo#getPropertyKey()
   */
  public Object getDefaultPropertyKey();

  /**
   * Returns an array of MethodInfo objects representing the method meta-data
   *  for this component type.
   *
   * @return An array of MethodInfo objects representing this component
   *         type's method meta-data
   */
  public MethodInfo[] getMethodInfos();

  /**
   * Returns a MethodInfo object with the specified unique method key.
   *
   * @param methodKeyPath The desired method key (uniquely identifies a MethodInfo)
   * @return The specified MethodInfo
   * @see MethodInfo#getMethodKey()
   */
  public MethodInfo getMethodInfo(Object[] methodKeyPath);

  /**
   * Returns the 'default' method key.
   * At this point, the default method is not used in the designer.
   * This will be used in the future, however, for visually connecting
   * event handlers to methods.  Maybe.  ;-)
   *
   * @return The method key for the 'default' method of this component type
   * @see MethodInfo#getMethodKey()
   */
  public Object getDefaultMethodKey();

  /**
   * Returns an array of EventInfo objects representing the event meta-data
   * for this component type.
   *
   * @return An array of EventInfo objects representing this component type's
   * event meta-data
   */
  public EventInfo[] getEventInfos();

  /**
   * Returns a EventInfo object with the specified unique event key hierarchy.
   *
   * @param eventKeyPath The key hierarchy of the desired event
   *    (index 0 being top-level event)
   * @return The specified EventInfo
   * @see EventInfo#getEventKey()
   */
  public EventInfo getEventInfo(Object[] eventKeyPath);

  /**
   * <p>Returns the 'default' event key.
   * This is used when a user double-clicks on a component on the design
   * surface.  The 'default' event is hooked.
   *
   * <p>This is also used for when the user has a component selected on the
   * design surface, has the event inspector showing, but does not have a
   * specific event selected on the inspector, and starts to type.
   * The keystrokes will become edits to the 'default' event of the component.
   * This is not the case, however, if the user has a specific property or
   * event already selected in the inspector.
   * The keystrokes on the component will be treated as edits to the 'current'
   * property or event in the inspector.
   *
   * @return The event key for the 'default' event of this component type
   * @see EventInfo#getEventKey()
   */
  public Object getDefaultEventKey();
}
