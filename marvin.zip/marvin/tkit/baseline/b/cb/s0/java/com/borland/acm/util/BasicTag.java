package com.borland.acm.util;

import com.borland.acm.*;

/**
 * Represents a generic unit of information in a list.
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public class BasicTag
  implements Tag {

  protected TagGroup parent;
  protected Object key;
  protected String displayName;
  protected String description;
  protected ImageData icon;
  protected boolean enabled = true;
  protected boolean checked = false;

  public BasicTag() {}

  public BasicTag(Object key) {
    this.key = key;
  }

  public BasicTag(Object key, TagGroup parent) {
    this.key = key;
    this.parent = parent;
  }

  public BasicTag(Object key, String displayName) {
    this(key);
    this.displayName = displayName;
  }

  public BasicTag(Object key, String displayName, TagGroup parent) {
    this(key);
    this.displayName = displayName;
    this.parent = parent;
  }

  public BasicTag(Object key, String displayName, String description) {
    this(key, displayName);
    this.description = description;
  }

  public BasicTag(Object key, String displayName, String description, TagGroup parent) {
    this(key, displayName);
    this.description = description;
    this.parent = parent;
  }

  public BasicTag(Object key, ImageData icon) {
    this(key);
    this.icon = icon;
  }

  public BasicTag(Object key, ImageData icon, TagGroup parent) {
    this(key);
    this.icon = icon;
    this.parent = parent;
  }

  public BasicTag(Object key, String displayName, ImageData icon) {
    this(key, displayName);
    this.icon = icon;
  }

  public BasicTag(Object key, String displayName, ImageData icon, TagGroup parent) {
    this(key, displayName);
    this.icon = icon;
    this.parent = parent;
  }

  public void setTagKey(Object key) {
    this.key = key;
  }

  public Object getTagKey() {
    return key;
  }

  public void setDisplayName(String displayName) {
    this.displayName = displayName;
  }

  public String getDisplayName() {
    return displayName != null ? displayName : key != null ? key.toString() : null;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getDescription() {
    return description;
  }

  public void setDisplayIcon(ImageData icon) {
    this.icon = icon;
  }

  public ImageData getDisplayIcon() {
    return icon;
  }

  public void setEnabled(boolean enabled) {
    this.enabled = enabled;
  }

  public boolean isEnabled() {
    return enabled;
  }

  public void setChecked(boolean checked) {
    this.checked = checked;
  }

  public boolean isChecked() {
    return checked;
  }

  public void setParentTag(TagGroup parent) {
    this.parent = parent;
  }

  public TagGroup getParentTag() {
    return parent;
  }

  public Result tagInvoked() {
    return null;
  }
}