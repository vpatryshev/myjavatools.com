package com.borland.acm;

/**
 * <p>Title: LiveReference</p>
 * <p>Description: Interface that describes an object that holds references to another. This
 * interface is implemented by a LiveComponent object which wants to exposes its references to
 * other objects in the Sturcture Pane </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Borland Software Corporation</p>
 * @author not attributable
 * @version 1.0
 */
public interface LiveReferenceCollection {

  /**
   * The LiveComponent that implements this interface can returns an array of references
   * via this method
   * @return Array of LiveReferences
   */
  public LiveReference[] getReferences();

  public int getReferenceCount();

  public LiveReference getReference(int index);

  public void addReferenceTo(LiveComponent component);

  public void removeReferenceTo(LiveComponent component);
}