package com.borland.acm;

/**
 * @author Joe Nuxoll
 * @version 1.0
 */
public interface PersistenceResult extends Result {

  /**
   *
   * @return
   */
  public byte[] getBytes();
}