package com.borland.acm.util;

import com.borland.acm.*;
import com.borland.acm.db.*;

/**
 *
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public class BasicDBCreateResult extends BasicResult implements DBCreateResult {

  public static BasicDBCreateResult create(boolean success, LiveDBComponent dbComp) {
    return new BasicDBCreateResult(success, dbComp);
  }

  public static BasicDBCreateResult create(boolean success, LiveDBComponent dbComp, ResultMessage[] messages) {
    return new BasicDBCreateResult(success, dbComp, messages);
  }

  public static BasicDBCreateResult create(boolean success, LiveDBComponent dbComp, ResultMessage[] messages, Tag[] options) {
    return new BasicDBCreateResult(success, dbComp, messages, options);
  }

  protected LiveDBComponent dbComp;

  public BasicDBCreateResult(LiveDBComponent dbComp) {
    this.dbComp = dbComp;
  }

  public BasicDBCreateResult(boolean success, LiveDBComponent dbComp) {
    super(success);
    this.dbComp = dbComp;
  }

  public BasicDBCreateResult(boolean success, LiveDBComponent dbComp, ResultMessage[] messages) {
    super(success, messages);
    this.dbComp = dbComp;
  }

  public BasicDBCreateResult(boolean success, LiveDBComponent dbComp, ResultMessage[] messages, Tag[] options) {
    super(success, messages, options);
    this.dbComp = dbComp;
  }

  public LiveComponent getComponent() {
    return dbComp;
  }

  public void setDBComponent(LiveDBComponent dbComp) {
    this.dbComp = dbComp;
  }

  public LiveDBComponent getDBComponent() {
    return dbComp;
  }
}