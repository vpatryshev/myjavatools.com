package com.borland.acm;

/**
 * @author Joe Nuxoll
 * @version 1.0
 */
public interface PersistenceConverter {

  /**
   *
   * @param buffer
   * @return
   */
  public PersistenceResult convertBufferToPersistenceData(byte[] buffer);

  /**
   *
   * @param data
   * @return
   */
  public PersistenceResult convertPersistenceDataToBuffer(byte[] data);
}