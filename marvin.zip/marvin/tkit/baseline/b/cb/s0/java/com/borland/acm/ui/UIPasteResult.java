package com.borland.acm.ui;

import com.borland.acm.*;

/**
 * The UIPasteResult interface is used as a return value from the method:
 * LiveUIDesigner.pasteComponent(LiveComponent parent, Point point, byte[] persistData).
 *
 * @see LiveUIDesigner#pasteComponent(LiveComponent, Point, byte[])
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public interface UIPasteResult extends PasteResult {

  /**
   * Returns the set of live UI component(s) that were created as the result of the
   * LiveUIDesigner.pasteComponent(...) method call.  This may be null if the paste operation
   * resulted in failure, or created zero UI components.
   *
   * @return An array of LiveUIComponent(s) resulting from the paste operation
   */
  public LiveUIComponent[] getUIComponents();
}