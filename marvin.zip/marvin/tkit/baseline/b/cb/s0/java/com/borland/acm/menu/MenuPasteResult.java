package com.borland.acm.menu;

import com.borland.acm.*;

/**
 * The MenuPasteResult interface is used as a return value from the method:
 * LiveMenuDesigner.pasteComponent(LiveComponent parent, byte[] persistData).
 *
 * @see LiveMenuDesigner#pasteComponent(LiveComponent, byte[])
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public interface MenuPasteResult extends PasteResult {

  /**
   * Returns the set of live menu component(s) that were created as the result of the
   * LiveMenuDesigner.pasteComponent(...) method call.  This may be null if the paste operation
   * resulted in failure, or created zero menu components.
   *
   * @return An array of LiveMenuComponent(s) resulting from the paste operation
   */
  public LiveMenuComponent[] getMenuComponents();
}