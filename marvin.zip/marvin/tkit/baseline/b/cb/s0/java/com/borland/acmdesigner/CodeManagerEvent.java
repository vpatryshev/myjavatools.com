package com.borland.acmdesigner;

import java.util.*;

import com.borland.acm.*;
import com.borland.acmdesigner.*;

/**
 *
 * <p>Title: CodeManagerEvent</p>
 * <p>Description: Encapsulates data sent by a Designer for
 *    notifying a CodeManager of some change or desired action<br>
 * Currently there are 4 of these re EventHooking: <br>
 * <UL>
 *    <LI>Provide a new Event Hook String (hook an event)<br>
 *    <LI>Clear an existing event hook<br>
 *    <LI>Tell CodeManager to update EventInfo tags Tags for component and
 *        event (tags matching eventInfo signature)<br>
 *    <LI>Tell CodeManager to validate all its event hooks from a
 *         component root.
 *    <LI>Tell CodeManager to show code for an existing event hook
 * </UL>
 * Others are:
 * <UL>
 *     <LI>Tell CodeManager that a Components name has changed
 *     <LI>Tell CodeManager that a component has/is being disposed providing
 *          the disposee LiveComponent
 * </UL>
 * <br>
 * The Code Manager uses a corresponding (EHookEventCM) class to
 * notify of changes in its state to any Observers.
 *
 * </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Borland </p>
 * @author hops
 * @version 1.0
 */
public class CodeManagerEvent
  extends EventObject
  implements IDesignerEvents {

  private LiveComponent liveComponent = null;
  private LiveEvent liveEvent = null;
  private LiveDesigner liveDesigner = null;
  private String oldName = null;
  private String eventHandlerName = null;
  private Tag[] tags = null;
  private int op;

  /**
   * Construct object to notify CodeManager of event
   * @param operation
   * @param host
   * @param lc
   */
  public CodeManagerEvent(int operation, Object source, LiveComponent lc) {
    super(source);
    this.op = operation;
    this.liveComponent = lc;
  }

  /**
   * Construct object to notify CodeManager of event
   * @param operation
   * @param host
   * @param lc
   */
  public CodeManagerEvent(int operation, Object source) {
    super(source);
    this.op = operation;
  }

  /**
   * Construct object to notify code manager of special event pertaining to a live event
   * @param operation
   * @param host
   * @param le
   */
  public CodeManagerEvent(int operation, Object source, LiveEvent le) {
    this(operation, source, le.getComponent());
    this.liveEvent = le;
    this.eventHandlerName = le.getHookAsText();
  }

  /**
   * Construct object to notify code manager of an event pertaining to a live component
   * @param operation
   * @param host
   * @param ld
   * @param lc
   */
  public CodeManagerEvent(int operation, Object source,
    LiveDesigner ld, LiveComponent lc) {
    this(operation, source, lc);
    this.liveDesigner = ld;
  }

  /**
   * Construct object to notify code manager of a change to a live component
   * @param operation
   * @param host
   * @param lc
   * @param oldName
   */
  public CodeManagerEvent(int operation, Object source, LiveComponent lc, String oldName) {
    this(operation, source, lc);
    this.oldName = oldName;
  }

  /**
   * Construct object to notify code manager of a change to a live component
   * @param operation
   * @param host
   * @param lc
   * @param oldName
   */
  public CodeManagerEvent(int operation, Object source, LiveEvent le, String oldName) {
    this(operation, source, le);
    this.oldName = oldName;
  }

  public int getOp() {
    return op;
  }

  public LiveComponent getComponent() {
    return liveComponent;
  }

  public LiveEvent getEvent() {
    return liveEvent;
  }

  public LiveDesigner getDesigner() {
    return liveDesigner;
  }

  /**
   * Provide previous name of Component, new name is in LiveComponent
   * @return old component name prior to rename
   */
  public String getOldName() {
    return oldName;
  }

  /**
   * Get previously set hookName
   * @return hookname string
   */
  public String getEventHandlerName() {
    return eventHandlerName;
  }

  /**
   * Set desired value of hookName into this event.
   * Done by CM for create and IDE for clear.
   * @param nm  hookname to set
   */
  public void setEventHandlerName(String nm) {
    this.eventHandlerName = nm;
  }

  public void setEventTags(Tag[] tags) {
    this.tags = tags;
  }

  public Tag[] getEventTags() {
    return this.tags;
  }

  /**
   * Get Instance name of held LiveComponent
   * @return liveComponent instance name.
   */
  public String getComponentName() {
    return liveComponent.getInstanceName();
  }

  public String toString() {
    return
      ( (liveComponent == null) ? "" : (liveComponent.getInstanceName() + ":")) +
      ( (liveEvent == null) ? "" : liveEvent.getEventInfo().getDisplayName() + ":") +
      ( (eventHandlerName == null) ? "" : eventHandlerName + ":") +
      ( (oldName == null) ? "" : oldName);
  }
}
