package com.borland.acm;

/**
 * The MethodInfo interface describes a method on a component.  This interface is only used for
 * display purposes at this point, but will be used to visually connect event handlers to matching
 * method signatures in the future.  Maybe. ;-)
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public interface MethodInfo {

  /**
   * Returns a unique key identifying this method
   *
   * @return A unique key identifying this method
   */
  public Object getMethodKey();   // "void:doSomething(String,int)" (unique signature in component)

  /**
   *
   * @return
   */
  public String getDisplayName(); // "doSomething"

  /**
   *
   * @return
   */
  public String getDescription(); // "Does something"

  /**
   *
   * @return
   */
  public ImageData getDisplayIcon();

  /**
   *
   * @return
   */
  public Object[] getParameterTypeKeys(); // "String", "int"

  /**
   *
   * @return
   */
  public String[] getParameterNames();    // "message", "repeat"

  /**
   *
   * @return
   */
  public Object getReturnTypeKey();       // "void"

  /**
   *
   * @return
   */
  public String[] getModifiers(); // "public", "static"

  /**
   *
   * @return
   */
  public String getSyntax(); // "public static void doSomething(String message, int repeat)"

  /**
   * Returns the parent method info, if this method info is a sub-method of a group.  This method is
   * used to enabled a method hierarchy with nesting of methods.  In some component models, methods
   * are grouped in this way - in others, they are not.
   *
   * @return The parent MethodInfo object, or null if this is a top-level method
   */
  public MethodInfo getParentMethodInfo();

  /**
   * Returns <b>true</b> if this method info has child method infos, <b>false</b> if not
   *
   * @returns <b>true</b> if this method info has child method infos, <b>false</b> if not
   */
  public boolean hasMethodInfoChildren();

  /**
   * Returns the contained MethodInfo classes
   *
   * @return An array of MethodInfo classes
   */
  public MethodInfo[] getMethodInfos();

  /**
   * Returns the method info with the specified key if it is contained by this group.
   *
   * @param methodKey The desired method info's unique key
   * @return The MethodInfo with the specified key, or null if it is not contained by this group
   */
  public MethodInfo getMethodInfo(Object methodKey);
}
