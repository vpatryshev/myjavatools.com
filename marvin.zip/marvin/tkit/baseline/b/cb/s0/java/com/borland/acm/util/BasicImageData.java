package com.borland.acm.util;

import com.borland.acm.*;

/**
 *
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public class BasicImageData implements ImageData {
  protected int scan;
  protected int[] pixels;
  protected boolean alpha;

  public BasicImageData() {}

  public BasicImageData(int scan, int[] pixels) {
    this(scan, pixels, false);
  }

  public BasicImageData(int scan, int[] pixels, boolean alpha) {
    this.scan = scan;
    this.pixels = pixels;
    this.alpha = alpha;
  }

  public int getScanWidth() {
    return scan;
  }

  public void setScanWidth(int scan) {
    this.scan = scan;
  }

  public int[] getPixels() {
    return pixels;
  }

  public void setPixels(int[] pixels) {
    this.pixels = pixels;
  }

  public boolean isAlphaIncluded() {
    return alpha;
  }

  public void setAlphaIncluded(boolean alpha) {
    this.alpha = alpha;
  }

  public boolean isValid() {
    return pixels != null && pixels.length > 0 && scan > 0;
  }
}