package com.borland.acm;

/**
 * A Tag is a single item for use in a context menu, pull-down list, or as a dialog button
 * descriptor.  The Tag interface is used in many places throughout the ACM interfaces.  Refer to
 * the specific use of the Tag interface for more information on how it is used.
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public interface Tag {

  /**
   * A special Tag Key that indicates the concept of a separator.
   * NOTE: This notion is only applicable when tags are used to
   * construct menus. The designer will convert any tags using
   * this key into a menu separator. All other attributes of this
   * tag will be ignored!!
   */
  public static final String SEPARATOR_TAG_KEY = "----";

  /**
   * Returns a key that identifies this tag
   * @return Object that identifies this tag
   */
  public Object getTagKey();

  /**
   * Human-readable string that describes this tag
   * @return Readable string that describes this tag
   */
  public String getDisplayName();

  /**
   * Description of this tag
   * @return String that describes this tag
   */
  public String getDescription();

  /**
   * Image that can be used to illustrate this tag
   * @return Image of this tag
   */
  public ImageData getDisplayIcon();

  /**
   * Returns whether this tag is enabled
   * @return True if this tag is enabled, or false otherwise
   */
  public boolean isEnabled();

  /**
   * Returns whether this tagged should be marked as checked
   * @return True if this tag is checked or false otherwise
   */
  public boolean isChecked();

  /**
   * The Group to which this tag belongs
   * @return Parent Group of this tag
   */
  public TagGroup getParentTag();

  /**
   * Called when this tag is invoked: selected from a right-click context menu, dialog option button
   * clicked, etc.
   */
  public Result tagInvoked();
}
