package com.borland.acm;

/**
 * The PasteResult interface is used as a return value from the method:
 * LiveDesigner.pasteComponent(LiveComponent parent, byte[] persistData).
 *
 * @see LiveDesigner#pasteComponent(LiveComponent, byte[])
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public interface PasteResult extends Result {

  /**
   * Returns the set of live component(s) that were created as the result of the
   * LiveDesigner.pasteComponent(...) method call.  This may be null if the paste operation
   * resulted in failure, or created zero components.
   *
   * @return An array of LiveComponent(s) resulting from the paste operation
   */
  public LiveComponent[] getComponents();
}