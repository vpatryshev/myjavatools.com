package com.borland.acm;

/**
 * The LiveEvent interface represents an instance of a live event in a live component.  The live
 * event contains information about any 'hook', or association of the event with some body of code.
 * Note that the LiveEvent really only stores a piece of text representing an event hook - and that
 * the typical snap to the source code editor in the appropriate place to write event code is
 * actually handled by another open tool class more directly tied to the IDE.  When an event is
 * hooked or changed, an 'eventChanged' event is fired via the DesignerListener interface.  This
 * event firing is hooked by an IDE open tool to switch to the source viewer and generate the
 * appropriate code.
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public interface LiveEvent {

  /**
   * Returns the event info for this live event
   *
   * @return The EventInfo for this live evenet
   */
  public EventInfo getEventInfo();

  /**
   * Returns the live component that 'owns' this live event
   *
   * @return The LiveComponent that 'owns' this live event
   */
  public LiveComponent getComponent();

  /**
   * Sets this live event's hook text.  This is a text representation of the event hook - that will
   * be displayed in the inspector next to the event.  When this value is changed, an 'eventChanged'
   * event should be fired by the LiveDesignerManager via the DesignerListener interface.
   *
   * @param hookText The new event hook text
   * @return A standard Result object, indicating success or failure, and containing any number of
   *         messages for the user
   * @see DesignerListener#eventChanged(LiveEvent)
   */
  public Result setHookAsText(String hookText);

  /**
   * Returns the current hook text for this live event
   *
   * @return A String representing the current hook text
   */
  public String getHookAsText();

  /**
   * Gives the live event an opportunity to generate default hook text, and fire an 'eventChanged'
   * event via the DesignerListener interface.  This method will be called when a user double-
   * clicks on a component with a default event, or double clicks on an event in the event
   * inspector in the visual designer.
   *
   * @return A standard Result object, indicating success or failure, and containing any number of
   *         messages for the user
   * @see DesignerListener#eventChanged(LiveEvent)
   */
  public Result setDefaultHook();

  /**
   * Unhooks an event, effectively deleting the hook text and firing an 'eventChanged' event via
   * the DesignerListener interface
   *
   * @return A standard Result object, indicating success or failure, and containing any number of
   *         messages for the user
   * @see DesignerListener#eventChanged(LiveEvent)
   */
  public Result unhook();

  /**
   * Returns true if this live event is hooked, or false if it is not
   *
   * @return <b>true</b> if this live event is hooked, or <b>false</b> if not
   */
  public boolean isHooked();

  /**
   * <p>Returns a list of tag items to display in a drop-down for the event hook.  This might be a
   * list of valid existing hooks that the user can select from.  This list will be merged with the
   * tag items supplied by this live event's EventInfo class.  If no hook tags are supplied, a
   * drop-down list will not appear next to this event in the event inspector.</p>
   *
   * <p>For this use of the Tag interface, methods will be used as follows:</p>
   * <table border=1>
   * <tr><th> Method                     <th> Purpose
   * <tr><td> Object getKey()            <td> Passed as text to the 'setHookText(String)' method
   * <tr><td> String getDisplayName()    <td> Text of the drop-down item (uses 'key.toString()' if null)
   * <tr><td> String getDescription()    <td> Status text of the drop-down item (optional)
   * <tr><td> ImageData getDisplayIcon() <td> Icon of the drop-down item (optional)
   * <tr><td> TagGroup getParentTag()    <td> Tag hierarchy shown as expanded list in drop-down
   * <tr><td> void tagInvoked()          <td> (not used)
   * </table>
   *
   * @return An array of Tag objects, representing items for the drop-down list in the event
   *         inspector, or null for no drop-down to appear
   * @see setHookText(String)
   */
  public Tag[] getHookTags();

  /**
   * Returns the parent live event group that this live event is contained by, if any.
   *
   * @return The LiveEvent that this live event is contained by, or null if it is a top-level
   *         event
   */
  public LiveEvent getParentEvent();

  /**
   * Returns <b>true</b> if this event has child events, <b>false</b> if not
   *
   * @returns <b>true</b> if this event has child events, <b>false</b> if not
   */
  public boolean hasEventChildren();

  /**
   * Returns the array of live events contained by this live event group
   *
   * @return The array of LiveEvent objects contained by this live event group
   */
  public LiveEvent[] getEvents();

  /**
   *
   * @param eventKey
   * @return
   */
  public LiveEvent getEvent(Object eventKey);
}