package com.borland.acm;

/**
 * The LiveComponent interface encapsulates an instance of a live component.  From here, one can
 * gain access to the properties and events of a live component.  More often then not, a
 * sub-interface of LiveComponent actually represents the live component.
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public interface LiveComponent {

  /**
   * Returns the instance key for this live component.  This is effectively the hash key for this
   * live component.  It is up to the implementor of this interface to determine what to use for
   * instance keys.  This key will be used for future calls to uniquely identify this live
   * component.
   *
   * @return The instance key for this live component
   */
  public Object getInstanceKey();

  /**
   * Returns the live component's instance name.  This is typically the name of the instance
   * variable in code, like "jButton3" - but it is up to the implementor to determine the component
   * naming scheme.  This value will be displayed in the designer - both at the top of the inspector
   * and in the component tree.
   *
   * @return The current instance name for the live component
   */
  public String getInstanceName();

  /**
   * Returns true if this component can be copied.
   * Can be used i.e. with context tags: "Copy" tag will be disabled if false returned
   */
  public boolean canCopy();


  /**
   * Returns true if this component can be deleted.
   * Can be used i.e. with context tags: "Delete" tag will be disabled if false returned
   */
  public boolean canDelete();


  /**
   * Returns true if the live component may be renamed by the user.  The designer will allow a user
   * to rename any component that returns true from this method.  An example where this might return
   * false would be for the "this" component in a design hierarchy.
   *
   * @return <b>true</b> if the user should be allowed to rename the live component, <b>false</b>
   *         if not
   */
   public boolean isUserRenamable();

  /**
   * Sets the instance name for this live component.  This method will only be called if the
   * 'isUserRenamable()' method returns true.  Typically, this represents the instance variable
   * name in code, but it is up to the implementor to determine the component naming scheme and
   * rules.
   *
   * @see isUserRenamable()
   *
   * @param name The new instance name for this live component
   * @return A standard Result object - which may represent a success or failure, and may include
   *         any number of messages to the user
   */
  public Result setInstanceName(String name);

  /**
   * Returns the designer that created and 'owns' this live component.
   *
   * @return The designer that owns this live component
   */
  public LiveDesigner getDesigner();

  /**
   * Tests if a specific parent is a "valid" parent for this live component.  This is to enable
   * feedback during the drag-n-drop operations in the designer.  This method will be called while
   * the user is dragging a component around - testing each of the potential targets it is dragged
   * over.
   *
   * @param parent The live container parent to test if this component can be parented by, may be null
   * @return <b>true</b> if this component may be parented by the specified container, <b>false</b>
   *         if not
   */
  public boolean testSetParentContainer(LiveContainer parent);

  /**
   * Sets the parent live container for this live component.  This value may be null if the live
   * component is a top-level component.
   *
   * @param parent The live container parent
   * @return A standard Result object - which may represent a success or failure, and may include
   *         any number of messages to the user
   */
  public Result setParentContainer(LiveContainer parent);

  /**
   * Returns the live container of this live component (if it is contained).
   * @return The LiveContainer instance containing this live component, or null if this live
   *         component is a top-level component in the designer
   */
  public LiveContainer getParentContainer();

  /**
   * Returns an array of live property objects for this live component.
   *
   * @return An array of live property objects
   */
  public LiveProperty[] getProperties();

  /**
   * Returns the live property object with the specified property key hierarchy.
   *
   * @param propertyKeyPath The hierarchy of property keys (index 0 being top-level property)
   * @return the specified live property
   * @see LiveProperty#getPropertyInfo()
   * @see PropertyInfo#getPropertyKey()
   */
  public LiveProperty getProperty(Object[] propertyKeyPath);

  /**
   * Returns an array of live events objects for this live component.
   *
   * @return An array of live event objects
   */
  public LiveEvent[] getEvents();

  /**
   * Returns the live event object with the specified event key hierarchy.
   *
   * @param eventKeyPath The hierarchy of event keys (index 0 being top-level event)
   * @return the specified live event
   * @see LiveEvent#getEventInfo()
   * @see EventInfo#getEventKey()
   */
  public LiveEvent getEvent(Object[] eventKeyPath);

  /**
   * Returns this live component's component info class
   * @return this live component's component info class
   */
  public ComponentInfo getComponentInfo();


  /**
   * <p>Returns an array of tags to display in a right-click menu for this live component.</p>
   *
   * <p>For this use of the Tag interface, methods will be used as follows:</p>
   * <table border=1>
   * <tr><th> Method                     <th> Purpose
   * <tr><td> Object getKey()            <td> (not used - unless 'displayName' is null)
   * <tr><td> String getDisplayName()    <td> Text of the menu item (uses 'key.toString()' if null)
   * <tr><td> String getDescription()    <td> Status text of the menu item (optional)
   * <tr><td> ImageData getDisplayIcon() <td> Icon of the menu item (optional)
   * <tr><td> TagGroup getParentTag()    <td> Full hierarchy will be displayed in menu
   * <tr><td> void tagInvoked()          <td> Called if the menu item is selected
   * </table>
   *
   * @return An array of Tag objects to display in a right-click menu for this live component
   */
  public Tag[] getContextTags(int x, int y);

  /**
   * Mark component as dirty and needing reload.
   */
  public void needsRefresh();
}
