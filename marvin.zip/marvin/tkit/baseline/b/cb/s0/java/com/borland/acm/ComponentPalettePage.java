package com.borland.acm;

import com.borland.primetime.ide.palette.PalettePageInfo;

/**
 * The PalettePage interface extends Primetime's PalettePageInfo to include addition
 * information regarding components which are displayed on this palette page.
 *
 * @author Joe Nuxoll
 * @author Darren Kosinski
 * @version 2.0
 * @copyright (c) 2003-2004 Borland Software Corporation.  All rights reserved.
 */
public interface ComponentPalettePage extends PalettePageInfo {

  /**
   * Returns the title of the palette page.  This will be displayed as the text on the tab of the
   * component palette.
   *
   * @return The title of this palette page
   */
//  public String getPageTitle();

  public void setPageTitle(String title);

  /**
   * Returns a description (tooltip / status text) for this palette page.
   *
   * @return The description of this palette page
   */
//  public String getPageDescription();

  /**
   * Returns a display icon for this palette page.  This icon should be a 16x16 color image, and
   * will be displayed on this palette page's tab.
   *
   * @return ImageData for this palette page's icon, or null for no icon
   */
  public ImageData getPageIcon();

  /**
   * Returns an array of component infos representing the components to display on this palette
   * page.
   *
   * @return An array of ComponentInfo classes to display on this palette page
   */
  public ComponentInfo[] getComponentInfos();

  /** @todo: Add getComponentCount() and support in CModels */
  /* *
   * Returns the number of Components in this category/PalettePage
   *
   * @return Count of Components on this page
   */
  //  public int getComponentCount();

  /**
   *
   * @param compTypeKey Key for the ComponentInfo type desired
   * @return
   */
  public ComponentInfo getComponentInfo(Object compTypeKey);

  public void setComponentInfos(ComponentInfo[] infos);
}
