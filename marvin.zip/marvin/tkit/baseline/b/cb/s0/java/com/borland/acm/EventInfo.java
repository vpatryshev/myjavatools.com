package com.borland.acm;

/**
 * The EventInfo interface describes the meta-data for a specific event type.
 * Live events are represented by instances of the LiveEvent interface,
 * which each make reference  to an EventInfo class.
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 * @see LiveEvent
 */
public interface EventInfo {

  /**
   * Returns a unique event key.  The implementor must ensure that this key
   * be unique across all event types for a given component info.
   *
   * @return A key to uniquely identify the event
   */
  public Object getEventKey();

  /**
   * Returns the human-readable name of this event type.  For example, "mouseClick".
   *
   * @return A human-readable name for this event type
   */
  public String getDisplayName();

  /**
   * Returns a description of this event type.
   * For example, "Fired when the user clicks the mouse".
   *
   * @return A description of this event type
   */
  public String getDescription();

  /**
   * Returns image data representing a display icon for this event type.
   * This should be a 16x16 color image.
   * If null is returned, a default image will be used.
   *
   * @return ImageData representing a display icon for this event type, or null for a default image
   */
  public ImageData getDisplayIcon();

  /**
   * Returns true if this event type is hookable by the user - meaning should
   * a user be allowed to assign an event handler to it.
   * Nearly all EventInfos are hookable.  A group event may be
   * just a container for other event infos, and thus should not be hookable.
   *
   * @return <b>true</b> if this event is hookable, or <b>false</b> if not
   */
  public boolean isHookable();

  /**
   * <p>Returns an array of tags representing a static list of
   * pre-defined hook names.  This list will appear in the drop-down list for
   * this event type in the inspector.  Any tags supplied by the LiveEvent
   * object will also appear in the list.</p>
   *
   * <p>For this use of the Tag interface, methods will be used as follows:</p>
   * <table border=1>
   * <tr><th> Method                     <th> Purpose
   * <tr><td> Object getKey()            <td> Passed as text to the 'LiveEvent.setHookText(String)' method
   * <tr><td> String getDisplayName()    <td> Text of the drop-down item (uses 'key.toString()' if null)
   * <tr><td> String getDescription()    <td> Status text of the drop-down item (optional)
   * <tr><td> ImageData getDisplayIcon() <td> Icon of the drop-down item (optional)
   * <tr><td> TagGroup getParentTag()    <td> Tag hierarchy shown as expanded list in drop-down
   * <tr><td> void tagInvoked()          <td> (not used)
   * </table>
   *
   * @return An array of Tag objects representing the static items to place
   *    in every event of this  type's drop-down list.
   * @see LiveEvent#getHookTags()
   * @see LiveEvent#setHookAsText(String)
   */
  public Tag[] getHookTags();

  /**
   * Returns true if the user is not allowed to type in the event hook,
   * and should be constrained to selecting an item from the hook tags
   * in the drop-down list.  These tags may be supplied by
   * both the LiveEvent and the EventInfo for the event.
   *
   * @return <b>true</b> if the user should be forced to select an item
   * from the drop-down for the event, <b>false</b> if they should be
   * allowed to type in any text.
   * @see getHookTags()
   * @see LiveEvent#getHookTags()
   */
  public boolean isConstrainedToTags();

  /**
   * Returns the parent event info group if this event info is a
   * sub-event of a group.
   * This method is used to enabled an event hierarchy with nesting of events.
   * In some component models, events are grouped in this way -
   * in others, they are not.
   *
   * @return The parent EventInfo object, or null if this is a top-level event
   */
  public EventInfo getParentEventInfo();

  /**
   * Returns <b>true</b> if this event info has child event infos,
   *    <b>false</b> if not
   *
   * @returns <b>true</b> if this event info has child event infos,
   *     <b>false</b> if not
   */
  public boolean hasEventInfoChildren();

  /**
   * Returns the contained EventInfo classes
   *
   * @return An array of EventInfo classes
   */
  public EventInfo[] getEventInfos();

  /**
   * Returns the event info with the specified key if it is contained by this group.
   *
   * @param eventKey The desired event info's unique key
   * @return The EventInfo with the specified key, or null if it is not contained by this group
   */
  public EventInfo getEventInfo(Object eventKey);

  /**
   *  Provides Signature string for event.
   *
   * @return Signature String for this Event
   */
  public String getSignature();
}
