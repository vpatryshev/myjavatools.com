package com.borland.acm;

/**
 * The DesignerInfo interface describes a designer of a component model.  A component model may
 * surface as many designers as it likes.
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public interface DesignerInfo {

  /**
   * Returns the unique key that identifies this designer type.  This string must be different from
   * any other DesignerInfo keys from this component model.
   *
   * @return The unique designer key
   */
  public Object getDesignerKey();

  /**
   * Returns the human-readable name of this designer type.  This string will be shown in the
   * component tree in the visual designer.  Examples might be "UI", "Menu", "Database", or "Other"
   *
   * @return The human-readable name of this designer type, or null to recycle the designer key
   */
  public String getDisplayName();

  /**
   * Returns the human-readable description of this designer type.
   *
   * @return A description of this designer type, or null to recycle the display name
   */
  public String getDescription();

  /**
   * Returns image data representing a display icon for this designer.  This should be a 16x16
   * color image, and will be displayed in the component tree next to the designer name.  If null
   * is returned, a default image will be used.
   *
   * @return ImageData representing a display icon for this designer, or null to use a default
   *         image
   */
  public ImageData getDisplayIcon();

  /**
   * <p>Returns a list of context tags to display when the user right-clicks on the designer.
   * These tags will be merged with the context tags supplied by the LiveDesigner.</p>
   *
   * <p>For this use of the Tag interface, methods will be used as follows:</p>
   * <table border=1>
   * <tr><th> Method                     <th> Purpose
   * <tr><td> Object getKey()            <td> (not used - unless 'displayName' is null)
   * <tr><td> String getDisplayName()    <td> Text of the menu item (uses 'key.toString()' if null)
   * <tr><td> String getDescription()    <td> Status text of the menu item (optional)
   * <tr><td> ImageData getDisplayIcon() <td> Icon of the menu item (optional)
   * <tr><td> TagGroup getParentTag()    <td> Full hierarchy will be displayed in menu
   * <tr><td> void tagInvoked()          <td> Called if the menu item is selected
   * </table>
   *
   * @return An array of Tag objects to display on the right-click menu for this designer
   */
  public Tag[] getContextTags();
}
