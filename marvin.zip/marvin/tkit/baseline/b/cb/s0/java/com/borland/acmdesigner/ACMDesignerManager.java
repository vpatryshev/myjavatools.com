package com.borland.acmdesigner;

import java.lang.reflect.*;
import java.util.*;
import com.borland.acm.*;
import com.borland.acm.db.*;
import com.borland.acm.menu.*;
import com.borland.acm.ui.*;
import com.borland.primetime.*;
import com.borland.acmdesigner.designer.*;
import com.borland.acmdesigner.designer.db.*;
import com.borland.acmdesigner.designer.dflt.*;
import com.borland.acmdesigner.designer.menu.*;
import com.borland.acmdesigner.designer.ui.*;
import com.borland.primetime.ide.*;
import com.borland.primetime.node.*;
import com.borland.acm.stringtable.LiveStringTableDesigner;
import com.borland.acmdesigner.designer.stringtable.StringTableDesignerPanel;

public class ACMDesignerManager {

  protected static List cmodels = new ArrayList();
  protected static List cmListeners = new ArrayList();
  protected static List cmHeartBeats = new ArrayList();
  protected static HashMap cmodelsHash = new HashMap();
  protected static List codeManagerFactoryList = new ArrayList();

  protected static Map designerPanelReg = new HashMap();
  protected static final Class[] DesignerPanelCtorArgs = new Class[] { DesignerHost.class, LiveDesigner.class };

  public static void initOpenTool(byte majorVersion, byte minorVersion) {
    Browser.registerNodeViewerFactory(new DesignerViewerFactory());
    registerDesignerPanel(LiveUIDesigner.class, UIDesignerPanel.class);
    registerDesignerPanel(LiveMenuDesigner.class, MenuDesignerPanel.class);
    //registerDesignerPanel(LiveDBDesigner.class, DBDesignerPanel.class);
    registerDesignerPanel(LiveDesigner.class, DefaultDesignerPanel.class);
    registerDesignerPanel(LiveStringTableDesigner.class, StringTableDesignerPanel.class);
    PrimeTime.initializeOpenTools("ComponentModels"); // NORES
    PrimeTime.initializeOpenTools("CodeManagers"); // NORES
  }

  public static class DesignerViewerFactory
      implements NodeViewerFactory {
    public boolean canDisplayNode(Node node) {
      return canDesignNode(node);
    }

    public NodeViewer createNodeViewer(Context context) {
      ComponentModel cm = getComponentModel(context.getNode());
      if (cm != null) {
        DesignerNodeViewer dnv = new DesignerNodeViewer(context, cm);
        return dnv;
      }
      return null;
    }
  }

  public static void registerComponentModel(ComponentModel cm) {
    if (!cmodels.contains(cm)) {
      if (PrimeTime.isVerbose()) {
        System.out.println("Registered component model: " + cm.getDisplayName()); // RES VerboseRegCompModel
      }
      cmodels.add(cm);
      cmodelsHash.put(cm.getModelKey(), cm);
    }
  }

  public static void unregisterComponentModel(ComponentModel cm) {
    if (cmodels.contains(cm)) {
      if (PrimeTime.isVerbose()) {
        System.out.println("Unregistered component model: " + cm.getDisplayName()); // RES VerboseUnregCompModel
      }
      cmodels.remove(cm);
      cmodelsHash.remove(cm.getModelKey());
    }
    cmHeartBeats.remove(cm);
    cmodels.remove(cm);
    codeManagerFactoryList.remove(cm);
  }

  /**
   * Used when we want to throw a component model into the ring, but defer
   * the actual registration as long as possible, or to provide other
   * custom tweeking for the lifetime of the component model in the designer.
   * @param cml
   */
  public static void registerComponentModel(ComponentModelListener cml) {
    if (PrimeTime.isVerbose()) {
      System.out.println("Deferred registration of component model: " + cml.GetName()); // RES VerboseDeferredReg
    }
    cmListeners.add(cml);
    cmHeartBeats.add(cml);
  }

  public static void registerCodeManagerFactory(CodeManagerFactory factory) {
    if (!codeManagerFactoryList.contains(factory)) {
      codeManagerFactoryList.add(factory);
    }
  }

  /**
   * We've delayed registering a component model as long as possible.  Time to
   * give it a prod.
   */
  private static void ProcessDeferredRegistrations() {
    if (cmListeners.size() != 0) {
      for (int i = 0; i < cmListeners.size(); i++) {
        ComponentModelListener cml = (ComponentModelListener) cmListeners.get(i);
        if (PrimeTime.isVerbose()) {
          System.out.println("Deferred component model registration: " + cml.GetName()); // RES VerboseDeferredCompReg
        }
        cml.Register();
      }
      cmListeners.clear();
    }
    if (cmHeartBeats.size() != 0) {
      for (int i = 0; i < cmHeartBeats.size(); i++) {
        ComponentModelListener cml = (ComponentModelListener) cmHeartBeats.get(i);
        cml.HeartBeat();
      }
    }
  }

  public static ComponentModel[] getComponentModels() {
    ProcessDeferredRegistrations();
    return (ComponentModel[])cmodels.toArray(new ComponentModel[cmodels.size()]);
  }

  public static ComponentModel getComponentModel(String typeKey) {
    ProcessDeferredRegistrations();
    return (ComponentModel)cmodelsHash.get(typeKey);
  }

  public static ComponentModel getComponentModel(Node node) {
    if (node instanceof DesignableNode) {
      ComponentModel cm = (ComponentModel)cmodelsHash.get(((DesignableNode)node).getComponentModelKey());
      if (cm != null) {
        return cm;
      }
      ProcessDeferredRegistrations();
      cm = (ComponentModel)cmodelsHash.get(((DesignableNode)node).getComponentModelKey());
      if (cm != null) {
        return cm;
      }
    }
    else {
      /** @todo can we defer here?  If we don't, do we init too early? */
//      ProcessDeferredRegistrations();
      for (int i = 0; i < cmodels.size(); i++) {
        ComponentModel cm = (ComponentModel)cmodels.get(i);
        if (cm instanceof DesignableNodeSelector) {
          if (((DesignableNodeSelector)cm).isDesignableNode(node)) {
            return cm;
          }
        }
      }
    }
    return null;
  }

  public static ICodeManager getCodeManager(Context context, LiveDesignerManager manager, DesignerHost host) {
    for (int i = 0; i < codeManagerFactoryList.size(); i++) {
      CodeManagerFactory cmf = (CodeManagerFactory)codeManagerFactoryList.get(i);
      if (cmf.canManageCode(context.getNode(), manager.getComponentModel())) {
        return cmf.createCodeManager(context, manager, host);
      }
    }
    return null;
  }

  public static boolean canDesignNode(Node node) {
    return getComponentModel(node) != null;
  }


  public static boolean registerDesignerPanel(Class liveDesignerClass, Class designerPanelClass) {
    if (DesignerPanel.class.isAssignableFrom(designerPanelClass)) {
      try {
        Constructor con = designerPanelClass.getConstructor(DesignerPanelCtorArgs);
        if (con != null) {
          designerPanelReg.put(liveDesignerClass, designerPanelClass);
          return true;
        }
      }
      catch (NoSuchMethodException nsmx) {
        nsmx.printStackTrace();
      }
    }
    return false;
  }

  // whats with this null op ?
  protected static Class[] orderClasses(Class[] classes) {
    return classes;
  }

  /**
   * Create DesignerPanel for given LiveDesigner.
   * Use preregistered map of LiveDesignerInterface Classes to DesignerPanel
   * classes and match against the list of interfaces (explicitly declared)
   * implemented by the LiveDesigner.
   * If theres no match or match fails return the DefaultDesignerPanel
   *
   * @param host DesignerHost to construct wrt
   * @param designer LiveDesigner to create DesignerPanel for
   * @return Designer DesignerPanel for LiveDesigner given. (never null).
   */
  public static DesignerPanel createDesignerPanel(DesignerHost host, LiveDesigner designer) {
    // find which interfaces this designer implements
    //   (LiveDesigner, LiveUIDesigner, LiveDBDesigner, LiveMenuDesigner, etc...)
    Class[] ifs = orderClasses(designer.getClass().getInterfaces());
    // This interface lookup should probably walk class hierarchy and get
    // all interfaces for all classes in inheritance hierarchy.
    // As is mandates that designer class definition MUST include the
    // implements clause for the Designer Interface it supports otherwise
    // registration of the Panel fails reverting to the DefaultDesignerPanel...
    DesignerPanel dp = null;
    for (int i = 0; i < ifs.length; i++) {
      Class designerPanelClass = (Class) designerPanelReg.get(ifs[i]);
      if (designerPanelClass != null) {
        try {
          Constructor con = designerPanelClass.getConstructor(DesignerPanelCtorArgs);
          if (con != null) {
            dp = (DesignerPanel)con.newInstance(new Object[] {host, designer});
          }
        }
        catch (Exception x) {
          x.printStackTrace();
        }
      }
    }
    if (dp == null) {
      dp = new DefaultDesignerPanel(host, designer);
    }
    host.addDesignerHostListener(dp);
    return dp;
  }
}
