package com.borland.acm;

/**
 * The LiveContainer interface encapsulates an instance of a live container.  This extension of
 * the LiveComponent interface is a generic containership definition, which allows different types
 * of live components to surface containership in a generic manner.  This allows the designer to
 * display a component tree and a hierarchy involving many different types of live components.
 * More often then not, a sub-interface of LiveContainer actually represents the live container.
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public interface LiveContainer extends LiveComponent {

  /**
   * Returns the number of live components that this container contains
   *
   * @return An int representing the number of live components that this container contains
   */
  public int getComponentCount();

  /**
   * Returns the live component at the specified index.  The passed index is zero-based, and must
   * greater than -1 and not greater than or equal to the component count.
   *
   * @param index the zero-based index of the desired live component in this container
   * @return the live component at the specified index
   */
  public LiveComponent getComponent(int index);

  /**
   * Returns an array of all the live components contained in this live container
   *
   * @return An array of LiveComponent, representing all the contained live components
   */
  public LiveComponent[] getComponents();

  /**
   * Returns the live component with the specified instance key.  This method may return null if
   * this container does not contain a live component with the specified instance key.
   *
   * @param compInstanceKey the desired live component's instance key
   * @return A LiveComponent with the desired instance key, or null if it is not contained
   * @see LiveComponent#getInstanceKey()
   */
  public LiveComponent getComponent(Object compInstanceKey);

  /**
   * Sets the specified live components index within this live container.  This may refer to Z order
   * or index order depending on the type of compoent.
   *
   * @param comp The child live component to set the index of
   * @param index The desired index
   * @return A standard Result object - which may represent a success or failure, and may include
   *         any number of messages to the user
   */
  public Result setComponentIndex(LiveComponent comp, int index);

  /**
  * Returns true if given persistData can be pasted to this container.
  * Can be used i.e. with context tags: "Paste" tag will be disabled if false is returned
  */
  public boolean canPaste(byte[] persistData);
}