package com.borland.acm.db;

import com.borland.acm.*;

/**
 *
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public interface LiveDBDesigner extends LiveDesigner {

  /**
   *
   * @param parent
   * @param compInfo
   * @return
   */
  public DBCreateResult createComponent(LiveDBContainer parent, ComponentInfo compInfo);

  /**
   *
   * @param parent
   * @param persistData
   * @return
   */
  public DBPasteResult pasteComponent(LiveDBContainer parent, byte[] persistData);

  /**
   * Returns the live DB component with the specified instance key
   *
   * @param compInstanceKey The desired live DB component's instance key
   * @return The live DB component with the specified instance key
   */
  public LiveDBComponent getDBComponent(Object compInstanceKey);

  /**
   * Returns the root DB components (top-level) of this live DB designer.
   *
   * @return An array of LiveDBComponent instances representing the top-level components in this
   *         DB designer.
   */
  public LiveDBComponent[] getRootDBComponents();
}
