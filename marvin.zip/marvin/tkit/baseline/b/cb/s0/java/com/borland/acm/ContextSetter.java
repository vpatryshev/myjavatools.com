package com.borland.acm;

import com.borland.primetime.ide.Context;

/**
 * <p>Title: ContextSetter</p>
 * <p>Description: This interface is used to indicate that an object may have
 * a com.borland.primetime.ide.Context assigned to it. This was created so
 * that the DesignerNodeViewer could safely assign a Context to a Manager w/o
 * affecting all Managers. The context info is needed by the sharable component
 * implementation for Series60.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Borland Software Corporation</p>
 * @author Nathan York
 * @version 1.0
 */

public interface ContextSetter {
  /**
   * Assigns a context to an object.
   * @param c The context
   */
  public void setContext(Context c);
}