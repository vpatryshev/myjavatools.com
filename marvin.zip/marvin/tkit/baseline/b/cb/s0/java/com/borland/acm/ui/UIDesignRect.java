package com.borland.acm.ui;

import java.awt.*;
import com.borland.acm.*;

/**
 * <p>The UIDesignRect interface is used to describe a portion of a design surface that the user
 * can interact with using the mouse.  This may be part of the design surface itself, or a
 * portion of any component being designed on the design surface.  All coordinates are in
 * the respective coordinate space of the designer or component that provided the UIDesignRect.</p>
 *
 * <p>There are several 'types' of design rect.  Any single design rect may implement any
 * combination of these to produce the desired effect on the design surface.</p>
 *
 * <p>The 'types' of design rect are:</p>
 *
 * <p><b>Clickable</b> - A UIDesignRect that returns true from the isClickable() method should
 * pass-through a mouse click.  An example of this might be the check portion of a checkbox, or
 * the tab "heads" of a tabset.  If a user clicks within the rectangle described by a
 * clickable design rect, the click will be passed along to the design-time code for that component
 * via the 'designMouseClick(Point p)' method.</p>
 *
 * <p><b>Context Provider</b> - A UIDesignRect that returns true from the isContextProvider()
 * method has a set of context tags that the user should see when they right-click within the
 * UIDesignRect's rectangle.  Any designer or component can surface these context items, and these
 * proved by the 'getContextTags()' method will be inserted at the beginning of the list.</p>
 *
 * <p><b>Movable</b> - A UIDesignRect that returns true from the isMovable() method should appear
 * to be movable on the design surface.  This means that the appropriate mouse signals will
 * occur - such as the move mouse cursor when the user hovers over the rectangle.  Constraints for
 * the move operation may also be specified by returning any combination of the MOVE_xxx attribute
 * bits from the 'getMoveConstraintFlags()' method, and by returning a Rectangle from the
 * 'getMoveConstraintRect()' method to restrict the movement within.</p>
 *
 * <p><b>Resizable</b> - A UIDesignRect that returns true from the isResizable() method should
 * appear to be resizable on the design surface.  This means that the appropriate mouse signals will
 * occur - such as the resize cursor when the user hovers over the edges of the rectangle.
 * Constraints for the sizing operation may also be specified by returning any combination of the
 * RESIZE_xxx attribute bits from the 'getResizeConstraints()' method, and by returning a Rectangle
 * from the 'getResizeConstraintRect()' method to restrict the resizing within.</p>
 *
 * <p><b>Live</b> - A UIDesignRect that returns true from the isLive() method will be treated as a
 * live portion of the design surface.  All mouse messages will be passed along via the methods:
 * 'liveDesignMouseDown(Point p)', 'liveDesignMouseDrag(Point p)', and 'liveDesignMouseUp(Point p)'.
 * Each of these methods returns a boolean to indicate if the event has been 'consumed'.  Note that
 * this is a band-width intensive design rect, and should only be implemented for in-process
 * designers.</p>
 *
 * @see UIDesignRect#isClickable()
 * @see UIDesignRect#isContextProvider()
 * @see UIDesignRect#isMovable()
 * @see UIDesignRect#isResizable()
 * @see UIDesignRect#isLive()
 *
 * @author Joe Nuxoll
 * @version 1.0
 * @copyright (c) 2003 Borland Software Corporation.  All rights reserved.
 */
public interface UIDesignRect {

  /**
   * Returns the bounding rectangle for this UIDesignRect.  This is in the coordinate space of the
   * designer or component that provided the UIDesignRect.
   *
   * @return a java.awt.Rectangle for the bounding region of this UIDesignRect in the designer or
   *         component's coordinate space.
   */
  public Rectangle getRectangle();

  /**
   * Returns text to display in a tooltip when the mouse is 'hovered' over this design rect.
   *
   * @return The text to display in the tooltip
   */
  public String getToolTipText();

  /**
   * A UIDesignRect that returns true from the isClickable() method should pass-through a mouse
   * click.  An example of this might be the check portion of a checkbox, or the tab "heads" of a
   * tabset.  If a user clicks within the rectangle described by a clickable design rect, the click
   * will be passed along to the design-time code for that component via the
   * 'designMouseClick(Point p)' method.
   *
   * @return <b>true</b> if this design rect is clickable, or <b>false</b> if not
   */
  public boolean isClickable();

  /**
   * Called when a user has clicked (mouse-down followed by mouse-up) within the rectangle
   * described by this UIDesignRect. This method is never called if isClickable() returns false.
   *
   * @param p The click point (mouse-up) in the designer or component's coordinate space - NOT in
   *        the coordinate space of the design rect itself.
   * @param clickCount The number of clicks - this resets to zero after the user has paused
   * @return A standard Result object incidating success or failure, and including any number of
   *         messages for the user
   * @see isClickable()
   */
  public Result designMouseClick(Point p, int clickCount);

  /**
   * A UIDesignRect that returns true from the hasContextTags() method has a set of context tags
   * that the user should see when they right-click within the UIDesignRect's rectangle.  Any
   * designer or component can surface these context items, and these proved by the
   * 'getContextTags()' method will be inserted at the beginning of the list.
   *
   * @return <b>true</b> if this design rect has context tags, or <b>false</b> if not
   */
  public boolean hasContextTags();

  /**
   * <p>Returns an array of Tag objects to display in the right-click menu.  When the user
   * selects an item from the context menu, the corresponding Tag.tagInvoked() method is
   * called. This method is never called is isContextProvider() returns false.</p>
   *
   * <p>For this use of the Tag interface, methods will be used as follows:</p>
   * <table border=1>
   * <tr><th> Method                     <th> Purpose
   * <tr><td> Object getKey()            <td> (not used - unless 'displayName' is null)
   * <tr><td> String getDisplayName()    <td> Text of the menu item (uses 'key.toString()' if null)
   * <tr><td> String getDescription()    <td> Status text of the menu item (optional)
   * <tr><td> ImageData getDisplayIcon() <td> Icon of the menu item (optional)
   * <tr><td> TagGroup getParentTag()    <td> Full hierarchy will be displayed in menu
   * <tr><td> void tagInvoked()          <td> Called if the menu item is selected
   * </table>
   *
   * @return An array of Tag objects to disply in the right-click menu.
   * @see isContextProvider()
   */
  public Tag[] getContextTags(int x, int y);

  /**
   * A UIDesignRect that returns true from the isMovable() method should appear to be movable on
   * the design surface.  This means that the appropriate mouse signals will occur - such as the
   * move mouse cursor when the user hovers over the rectangle.  Constraints for the move operation
   * may also be specified by returning any combination of the MOVE_xxx attribute bits from the
   * 'getMoveConstraintFlags()' method, and by returning a bounding Rectangle from the
   * 'getMoveConstraintRect()' method to restrict the movement within.
   *
   * @return <b>true</b> if this design rect is movable, or <b>false</b> if not
   */
  public boolean isMovable();

  public static final int MOVE_VERTICAL   = 0xF;
  public static final int MOVE_HORIZONTAL = 0xF0;
  public static final int MOVE_ANY        = MOVE_VERTICAL | MOVE_HORIZONTAL;

  /**
   * Returns any constraints that should be enforced for the move operation.  These can be
   * MOVE_VERTICAL, MOVE_HORIZONTAL, or MOVE_ANY. This method is never called if isMovable()
   * returns false.
   *
   * @return any combination of MOVE_xxx constaint bits.
   * @see isMovable()
   */
  public int getMoveConstraintFlags();

  /**
   * If the movable design rect should only be allowed to move within a certain area, a bounding
   * Rectangle may be specified here. This method is never called if isMovable() returns false.
   *
   * @return A Rectangle to constrain the movement within.  This rectangle must be in the designer
   *         or component's coordinate space - NOT in the coordinate space of the design rect itself.
   * @see isMovable()
   */
  public Rectangle getMoveConstraintRect();

  /**
   * Called when the move operation has completed. This method is never called if isMovable()
   * returns false.
   *
   * @param newRect The new rectangle as a result of the move operation in the designer or
   *        component's coordinate space - NOT in the coordinate space of the design rect itself.
   * @return A rectangle indicating the 'actual' move.  This is typically the same as the passed
   *         rectangle, but a different return rectangle indicates that the rect has 'snapped'
   *         to a new location.  An animation will be shown to the user to indicate this.
   * @see isMovable()
   */
  public Rectangle moveCompleted(Rectangle newRect);

  /**
   * A UIDesignRect that returns true from the isResizable() method should appear to be resizable
   * on the design surface.  This means that the appropriate mouse signals will occur - such as the
   * resize cursor when the user hovers over the edges of the rectangle. Constraints for the sizing
   * operation may also be specified by returning any combination of the RESIZE_xxx attribute bits
   * from the 'getResizeConstraints()' method, and by returning a bounding Rectangle from the
   * 'getResizeConstraintRect()' method to restrict the resizing within.
   *
   * @return <b>true</b> if this design rect is resizable, or <b>false</b> if not
   */
  public boolean isResizable();

  public static final int RESIZE_TOP        = 0xF;
  public static final int RESIZE_LEFT       = 0xF0;
  public static final int RESIZE_BOTTOM     = 0xF00;
  public static final int RESIZE_RIGHT      = 0xF000;
  public static final int RESIZE_HORIZONTAL = RESIZE_LEFT | RESIZE_RIGHT;
  public static final int RESIZE_VERTICAL   = RESIZE_TOP | RESIZE_BOTTOM;
  public static final int RESIZE_ANY        = RESIZE_HORIZONTAL | RESIZE_VERTICAL;

  /**
   * Returns any constraints that should be enforced for the resize operation.  These can be
   * RESIZE_TOP, RESIZE_LEFT, RESIZE_BOTTOM, RESIZE_RIGHT, RESIZE_HORIZONTAL, RESIZE_VERTICAL,
   * and RESIZE_ANY. This method is never called if isResizable() returns false.
   *
   * @return any combination of RESIZE_xxx constaint bits.
   * @see isResizable()
   */
  public int getResizeConstraintFlags();

  /**
   * If the resizable design rect should only be allowed to size within a certain limits, a
   * bounding Rectangle may be specified here. This method is never called if isResizable() returns
   * false.
   *
   * @return A Rectangle to constrain the resizing within.  This rectangle must be in the designer
   *         or component's coordinate space - NOT in the coordinate space of the design rect itself.
   * @see isResizable()
   */
  public Rectangle getResizeConstraintRect();

  /**
   * Called when the resize operation has completed. This method is never called if isResizable()
   * returns false.
   *
   * @param newRect The new rectangle as a result of the resize operation in the designer or
   *        component's coordinate space - NOT in the coordinate space of the design rect itself.
   * @return A rectangle indicating the 'actual' resize.  This is typically the same as the passed
   *         rectangle, but a different return rectangle indicates that the rect has 'snapped'
   *         to a new location or size.  An animation will be shown to the user to indicate this.
   * @see isResizable()
   */
  public Rectangle resizeCompleted(Rectangle newRect);

  /**
   * A UIDesignRect that returns true from the isLive() method will be treated as a live portion of
   * the design surface.  All mouse messages will be passed along via the methods:
   * 'liveDesignMouseDown(Point p)', 'liveDesignMouseDrag(Point p)', and
   * 'liveDesignMouseUp(Point p)'.  Each of these methods returns a boolean to indicate if the
   * event has been 'consumed'.<br><br>
   *
   * <b>Note:</b> This is a band-width intensive use of design rect, and should only be implemented
   * for in-process designers.
   *
   * @return <b>true</b> if this design rect is live, or <b>false</b> if not
   */
  public boolean isLive();

  /**
   * The user has pressed the mouse button at the specified point. This method is never called if
   * isLive() returns false.
   *
   * @param down The mouse-down point in the designer or component's coordinate space - NOT in the
   *        coordinate space of the design rect itself.
   * @return <b>true</b> if the mouse event should be considered 'consumed' by the UIDesignRect.
   * @see isLive()
   */
  public boolean liveDesignMouseDown(Point down);

  /**
   * The user has dragged the mouse through the specified point. This method is never called if
   * isLive() returns false.
   *
   * @param down The mouse-down point in the designer or component's coordinate space - NOT in the
   *        coordinate space of the design rect itself.
   * @param drag The mouse-drag point in the designer or component's coordinate space - NOT in the
   *        coordinate space of the design rect itself.
   * @return <b>true</b> if the mouse event should be considered 'consumed' by the UIDesignRect.
   * @see isLive()
   */
  public boolean liveDesignMouseDrag(Point down, Point drag);

  /**
   * The user has released the mouse button at the specified point.  This method is never called if
   * isLive() returns false.
   *
   * @param down The mouse-down point in the designer or component's coordinate space - NOT in the
   *        coordinate space of the design rect itself.
   * @param up The mouse-up point in the designer or component's coordinate space - NOT in the
   *        coordinate space of the design rect itself.
   * @return <b>true</b> if the mouse event should be considered 'consumed' by the UIDesignRect.
   * @see isLive()
   */
  public boolean liveDesignMouseUp(Point down, Point up);
}