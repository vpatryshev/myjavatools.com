package com.borland.cbuilder.doxygen;

import java.io.*;
import java.util.*;

import com.borland.cbuilder.build.toolset.*;
import com.borland.cbuilder.node.*;
import com.borland.primetime.ide.*;
import com.borland.primetime.node.*;
import com.borland.primetime.vfs.*;
import com.borland.primetime.properties.*;

/**
 *
 * <p>Title: DoxygenConfig</p>
 * <p>Description: This class will be a central location to set and retreive doxygen config options and their corresponding values.</p>
 * <P>This will make life a lot easier when we add a doc tab to the ide preferences.
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author Mathew Duafala
 * @version 1.0
 *
 */

public class DoxygenConfig
  extends GlobalProperty {

  /**
   * These are the key values for our configuration.
   */
  public static String DOXY_CATEGORY = "Doxygen"; //NORES
  public static String DOXY_LOCATION = "Location"; //NORES

  //Need to create a map that will keep track of our options and write them
  //to the doxyfile . MTD
//  Map doxyProperyMap = new Map();



  /**
   * @todo Need to change this filename array to a list so we can easily recurse
   * into folders etc.
   */
//  public List nameList = new List();
  public String[] fileNamesToGen = null, dirNamesToGen = null;
  public String quote = "\""; //NORES

  public DoxygenConfig(String catagory, String name) {
    super(catagory, name);
  }

  Project thisProject = Browser.getActiveBrowser().getActiveProject();

  public Url[] dirsToSearch;
  public String[] extensionsToInclude, extensionsToExclude;
  public Url outputDirectory;

  /**
   * @todo Need to make this truncate the path into a relative path to the dir
   * we are running this from.
   * @param dirToAdd Url
   */
  public void addDir(Node[] dirsToAdd) {
    dirNamesToGen = new String[dirsToAdd.length];
    for (int i = 0; i < dirsToAdd.length; i++) {
      dirNamesToGen[i] = quote + ".\\" + dirsToAdd[i].getDisplayName() + quote;
    }
  }

  /**
   *
   * @param fileList Node[]
   * Need to remove any files that aren't proper source files (dll's, lib's etc).
   */
  public void addFiles(Node[] fileList) {
    if ( (fileList.length > 0)) {
      if (fileNamesToGen != null) {
      }
      else {
        fileNamesToGen = new String[fileList.length];
      }
      for (int i = 0; i < fileList.length; i++) {
        if (fileList[i] instanceof NavigationDirectoryNode) {
          addDir(fileList[i].getChildren());
        }
        if (fileList[i] instanceof CPPFileNode) {
          AddFileInstance(fileList, i);
        }
        else
        if (fileList[i] instanceof HFileNode) {
          AddFileInstance(fileList, i);
        }
        else
        if (fileList[i] instanceof IDLFileNode) {
          AddFileInstance(fileList, i);
        }
        else
        /**
         * recursively looking into folder views.
         */
        if (fileList[i] instanceof FolderNode) {
          addFiles(fileList[i].getChildren());
        }
      }
    }
  }

  private void AddFileInstance(Node[] fileList, int i) {

    if (fileNamesToGen.length <= i) { //we need to make the filelist bigger.
      String[] fileNamesToGen2 = new String[fileNamesToGen.length * 2];
      for (int j = 0; j < fileNamesToGen.length; j++) {
        fileNamesToGen2[j] = fileNamesToGen[j];
      }
      fileNamesToGen = fileNamesToGen2;
    }
    fileNamesToGen[i] = fileList[i].getLongDisplayName().trim();
    if (fileNamesToGen != null) {
      fileNamesToGen[i] = quote +
        getRelativePath(fileList[i].getLongDisplayName(),
        thisProject.getProjectPath().getFile().toString()) +
        quote;
    }
  }

  /**
   * <P>This function takes two file objects (a file object and a dir object) and
   * returns the relative path of the file object to that dir.
   * <P> It just calls the same function that takes two strings.
   * @param inputFile File
   * @param baseDir File
   * @return String
   */
  public String getRelativePath(File inputFile, File baseDir) {
    return getRelativePath(inputFile.getAbsolutePath(), baseDir.getAbsolutePath());
  }

  /**
   * This will remove the base dir from the full path name of the passed in file.
   * It's essentially a path truncation, it can't make paths relative to each
   * other if they are on different directory trees.
   *
   * @param inputPath String This is a full path and filename
   * @param basePath String  This should be a dir that we are ralative too.
   * @return String
   */
  public String getRelativePath(String inputPath, String basePath) {

    if (inputPath.startsWith(basePath)) {
//    return inputPath.replaceFirst(basePath,".\\");
      return "./" +
        inputPath.subSequence(basePath.length() + 1, inputPath.length());
    }
    else {
      return inputPath;
    }
  }

  /**
   * This will generate a 'doxyfile' based off of our settings.
   */
  public void generateDoxyConfigFile() throws IOException {
    String skeletonFile = "PROJECT_NAME = " + //NORES
      thisProject.getDisplayName().substring(0, thisProject.getDisplayName().indexOf(".")) + "\r\n" +
      "OUTPUT_DIRECTORY = ./doc \r\n" + //NORES
      "INPUT = "; //NORES
    /**
     * @todo Should make each input file appear on it's own line with a '\' continuation char.
     */
    if (fileNamesToGen != null) {
      if (fileNamesToGen.length > 0) {
        for (int i = 0; i < fileNamesToGen.length; ++i) {
          //This is becuase we will have a null value for each item in the project that isn't a valid file.
          if (fileNamesToGen[i] != null) {
            skeletonFile += fileNamesToGen[i] + " ";
          }
        }
      }
    }
    if (dirNamesToGen != null) {
      if (dirNamesToGen.length > 0) {
        for (int i = 0; i < dirNamesToGen.length; ++i) {
          if (dirNamesToGen[i] != null) {
            skeletonFile += dirNamesToGen[i] + " ";
          }
        }
      }
    }

//We need to grab the include paths for the current toolset.
    File[] includePaths = NodeUtil.getIncludePaths(thisProject,
      BuildToolCategoryManager.getBuildToolCategory(BuildToolCategory.
      TOOL_TYPE_COMPILER));

    skeletonFile +=
      "\r\n" +
      "FILE_PATTERNS    = *.hpp *.hh *.h *.cc *.cpp *.c \r\n" + //NORES
      "INCLUDE_PATH     = "; //NORES
    for (int i = 0; i < includePaths.length; i++) {
      skeletonFile += "\"" + includePaths[i] + "\" ";
    }
    skeletonFile += " \r\n" +
      /**
       * @todo Need to make these read the values from the project (since
       * these will appear on the property page).
       */
      "SEARCHENGINE    = NO \r\n" + //NORES
      "GENERATE_LATEX  = NO \r\n" + //NORES
      "EXTRACT_ALL     = YES \r\n" + //NORES
      "EXTRACT_PRIVATE = YES \r\n" + //NORES
      "EXTRACT_STATIC = YES \r\n" + //NORES
//      "CASE_SENSE_NAMES = NO \r\n" + //NORES  //might need this to fix the leading underscore problem MTD
      "RECURSIVE = NO \r\n" + //NORES
      "WARNINGS = YES \r\n"; //NORES

    //Now we need to add some info for the intl users.
    skeletonFile += "#note, if you are using a foreign language version, you should \r\n#uncomment the following lines, and change the \r\n#output language to the appropriate one.\r\n" + //NORES
      "#OUTPUT_LANGUAGE = Japanese \r\n" + //NORES
      "#USE_WINDOWS_ENCODING = YES    # Windows \r\n" + //NORES
      "#USE_WINDOWS_ENCODING = NO     # Linux, Solaris \r\n"; //NORES

    String configFileLocation = Browser.getActiveBrowser().getActiveUserProject().
      getProjectPath().toString() + "/doc/doxyfile"; //NORES
    Url location = new Url(configFileLocation);

    if (!location.getFileObject().exists()) {
      location.getFileObject().createNewFile();
      FileWriter doxyFile = new FileWriter(location.getFileObject());
      doxyFile.write(skeletonFile);
      doxyFile.flush();
      doxyFile.close();
      doxyFile = null;
    }
  }

  /**
   *
   * @param doxyfile Url This is a URL to an existing config file we can get our values from.
   * @throws FileNotFoundException
   */
  public void readDoxyConfigFile(Url doxyfile) throws FileNotFoundException {

  }

  /**
   * @param fileList Node[]  This just called addFiles
   */
  public DoxygenConfig(Node[] fileList) {
    super(DOXY_CATEGORY, DOXY_LOCATION);
    addFiles(fileList);
  }
}
