package com.borland.cbuilder.doxygen;

//import java.io.File;

import com.borland.cbuilder.node.*;
import com.borland.primetime.ide.*;
import com.borland.cbuilder.CBuilderMenu;
import com.borland.primetime.node.*;
import com.borland.primetime.actions.*;
import com.borland.primetime.properties.*;

/**
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author Mathew Duafala
 * @version 1.0
 *
 * <P>Everytime a file is opened in the browser, all factories are checked to see
 * if they can create a view of the file.
 *
 * @todo Need to hook the file add and delete events, then add or remove the file
 * from the list of files to generate doxygen for.
 */

public class DoxyNodeViewerFactory
  implements NodeViewerFactory {

  private boolean visible;
  private Context currentContext;

  public DoxyNodeViewerFactory() {}

  public static ActionGroup GROUP_DOXY_GENERATOR =
    new ActionGroup("Doxygen Generator"); //Doxygen_Generator_Group

  public static void initOpenTool(byte majorVersion, byte minorVersion) {
    try {
      Browser.registerNodeViewerFactory(new DoxyNodeViewerFactory());

      DoxyNodeListener eventListener = new DoxyNodeListener();
      Browser.addStaticBrowserListener(eventListener);
//      Browser.getActiveBrowser().getActiveProject().addStaticProjectListener(eventListener);

      GROUP_DOXY_GENERATOR.add(DoxyMenu.ACTION_DOC_GENERATOR);
      CBuilderMenu.GROUP_Project.add(GROUP_DOXY_GENERATOR);
//      Project.getDefaultProjectExtension(); //why is this here?
      PropertyManager.registerPropertyGroup(new DoxyPropertiesGroup("Doxygen")); //NORES

    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * One of the functions needed to implement ModeViewerFactory.
   * Use this function to tell the Browser if this factory can
   * view a certain node.
   *
   * @param node  the node the Browser will open
   *
   * @return  true if this factory can create a viewer for this node,
   *          false otherwise.
   *
   *
   */
  public boolean canDisplayNode(Node node) {
    if ( (node instanceof CPPFileNode) || (node instanceof HFileNode) ||
      (node instanceof IDLFileNode)) {
      return true;
    } else {
      return false;
    }
  }

  /**
   * One of the functions needed to implement NodeViewerFactory.
   * Used to create the viewer for the node that is described
   * by a context.  The viewer created is of type DoxyNodeViewer.
   *
   * This function basically checks to see if this is a supported file type
   * (cpp, header, idl), and then creates the viewer.  Then it checks to see if
   * the doc exists, if it doesn't, it sets the viewer to 'hide'.  Otherwise,
   * it sets the viewer to 'show'.    So in effect, there will always be a doc
   * viewer for supported files types, but it will only be visible if the doc exists.
   *
   * @param context  the context that describes the node.
   *
   * @return  a NodeViewer capable of viewing this node, or
   *          null if the viewer creation fails.
   */
  public NodeViewer createNodeViewer(Context context) {
    Node node = context.getNode();
    currentContext = context;

    if (canDisplayNode(node)) {
      DoxyViewerComponent viewer = new DoxyViewerComponent(currentContext);
      DoxyNodeViewer nodeViewer = new DoxyNodeViewer(context,
        ( (FileNode) node).getUrl().getFileObject());

      if (viewer.checkForDoc(currentContext)) {
        nodeViewer.canShow = true;
      } else {
        nodeViewer.canShow = false;
      }
      return nodeViewer;
    }
    return null;
  }

  public static final String DOXYGEN = "Doxygen"; //NORES

  public static final GlobalProperty ENABLED = new GlobalProperty(
    DoxygenConfig.DOXY_CATEGORY, DoxygenConfig.DOXY_LOCATION);

  public boolean canShowViewer() {
    return true;
  }

}
