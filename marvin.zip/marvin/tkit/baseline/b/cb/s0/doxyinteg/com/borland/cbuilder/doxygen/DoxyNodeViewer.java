package com.borland.cbuilder.doxygen;

import javax.swing.event.*;
import java.io.*;
import javax.swing.*;

import com.borland.primetime.vfs.*;
import com.borland.primetime.ide.*;
import com.borland.primetime.viewer.*;
import com.borland.cbuilder.node.*;
import com.borland.primetime.node.*;
import com.borland.primetime.*;
import com.borland.cbuilder.viewer.HTMLNodeViewer;
import com.borland.primetime.node.FileNode;

/**
 *
 * <p>Title: Doxygen OpenTool</p>
 * <p>Description: This component is in charge of the HTML viewer for this node.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Borland Software corp</p>
 * @author Mathew Duafala
 * @version 1.0
 *
 * */

public class DoxyNodeViewer
  extends HTMLNodeViewer implements WebViewable, Hideable {

  public DoxyNodeViewer(Context context) {
    super(context);
    currentContext = context;
    super.viewerComponent.setToolTipText("Doxygen Viewer"); //RES Doxygen_Viewer
    JTable table = new JTable(1 ,1);
//    super.
  }

  public DoxyNodeViewer(Context context, File editorFile) {
    super(context);
    currentContext = context;
    currentUrl = new Url(editorFile);
    Browser.getActiveBrowser().updateViewers(context.getNode());

  }

  //We don't need to add an entry to the stuct pane.
  /**
   * @todo look into adding a structure view of the generated html.  Don't know
   * if this is worth doing or not.
   * @return JComponent
   */
  public JComponent createStructureComponent() {
    return null;
  }

  /**
   * This is the function that needs to return our viewer type.
   *
   * This is actually created when the user clicks on the tab.
   *
   * @return JComponent
   */

  public JComponent createViewerComponent() {

    return new DoxyViewerComponent(currentContext);
  }

  public String getViewerTitle() {
    return "Doc"; //RES DOXY_DOC
  }

  public String getViewerDescription() {
    return "Doxygen Viewer"; //RES Doxygen_Viewer
  }

  /**
   * isWebViewable
   *
   * @return boolean
   */
  public boolean isWebViewable() {
    return true;
  }

//   File currentFile;
  /**
   * setWebViewable
   *
   * @param boolean0 boolean
   */
  public void setWebViewable(boolean boolean0) {
  }

  public Context currentContext;
  public Url currentUrl;

  /**
   *  This should just return true, so that we can dynamically show the doc tab
   * when we generate the docs for the first time.
   *
   * @return boolean
   */
  public boolean canShowViewer() {

    if (generatingDocs) {
      return true;
    }
    else {
      return canShow;
    }
  }

  public boolean canShow = false;
  public static boolean generatingDocs = false;

}
