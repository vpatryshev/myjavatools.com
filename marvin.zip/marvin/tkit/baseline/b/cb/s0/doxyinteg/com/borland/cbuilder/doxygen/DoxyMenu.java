package com.borland.cbuilder.doxygen;

import javax.swing.*;
import java.awt.event.*;

import com.borland.primetime.ide.*;
import com.borland.primetime.node.Node;
import com.borland.cbuilder.node.*;
import com.borland.primetime.vfs.*;
import com.borland.primetime.node.*;
import com.borland.cbuilder.node.*;
import com.borland.cbuilder.doxygen.*;
import com.borland.primetime.properties.*;

import java.io.*;
import com.borland.cbuilder.node.symbian.*;

/**
 *
 * <p>Title: Doxygen Menu</p>
 * <p>Description: This is the menu implimentation (ie the action item) </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author Mathew Duafala
 * @version 1.0
 *
 * @todo instead of adding messages tabs telling the user that we can't generate
 * the documentation, I think we should just put some diagnostic info on the
 * status bar (since the failure isn't a fatal problem for the user).
 */

public class DoxyMenu
  extends java.lang.Object implements ContextActionProvider {
  public DoxyMenu() {
  }

  public Action getContextAction(Browser currentBrowser, Node[] nodes) {
    if (nodes.length == 1 && nodes[0] instanceof CBProject) { //Change this to project.
//      if(nodes[0].getDisplayName() != "")
      return ACTION_DOC_GENERATOR;
    }
    return null;
  }

  public static BrowserAction ACTION_DOC_GENERATOR = new BrowserAction(
    "Doxygen Generator",  //RES DOXYGEN_GENERATOR
    'g', //NORES
    "Generate documentation for the current project") { //RES DOXYGEN_GENERATOR_DESCRIPTION
    public void update(Browser browser) {
      if (browser.getActiveUserProject() instanceof CBProject) {
        if (System.getProperty("os.name").startsWith("Win")) { //NORES
          if (new File(DoxyConfigPage.DoxyProperties.getValue() + File.separator + "doxygen.exe").exists()) { //NORES
            setEnabled(true);
          }
          else {
            setEnabled(false);
          }
        }
        else {
          if (new File(DoxyConfigPage.DoxyProperties.getValue() + File.separator + "doxygen").exists()) { //NORES
            setEnabled(true);
          }
          else {
            setEnabled(false);
          }

        }
      }
      else {
//        if (Browser.getActiveBrowser().getActiveProject() == null) {
//          System.out.println("The active project was null");
//        }
        setEnabled(false);
      }
    }

    public void actionPerformed(Browser source) {

      if (source.getActiveUserProject() instanceof CBProject) {
      }
      else {
        setEnabled(false);
        /**
         * Need to get the current editor files name, then find the corresponding
         * html file.  If there is no doxyfile, then we assume that we need to gen
         * the documentation.
         */
      }

      Url projectDir;
      if (Browser.getActiveBrowser().getActiveUserProject() != null) {
        projectDir = Browser.getActiveBrowser().getActiveUserProject().
          getProjectPath();
        Browser.getActiveBrowser().getActiveProject().addStaticProjectListener(new DoxyNodeListener());
      }
      else {
        return;
      }
      try {
        Url docDir = new Url(projectDir.toString() + "/doc"); //NORES
//        //If the directory doesn't already exist, then we create it.
        if (!docDir.getFileObject().exists()) {
          docDir.getFileObject().mkdir();
        }
      }
      catch (Exception Ex) {
//        System.out.println("There was an error creating the documentation.  Please check the file system permissions and free space.");
        Ex.printStackTrace();
      }

      try {
        DoxygenConfig config = new DoxygenConfig(DoxygenConfig.DOXY_CATEGORY, DoxygenConfig.DOXY_LOCATION);
        /**
         * Add the project files, and the dirs that the project is using.
         * Need to add a check to see if this is a mobile app, and add the
         * src dir accordingly.
         */

        CBProject proj = (CBProject) Browser.getActiveBrowser().
          getActiveUserProject();
        Node[] sourceFiles = proj.getChildren(); // getNode(proj.getUrl()).getChildren();

//This is for symbian projects.
        // symbian projects have their own compatibility magic
        if (proj.getProjectType() instanceof SymbianProjectType) {
          //add the symbian sourcedir (using getSourceDir)
          Url[] sourceDirs = proj.getSourceDirectories();
          Node[] sourceDirNodes = new Node[sourceDirs.length];
          for (int j = 0; j < sourceDirs.length; j++) {
//            System.out.println(sourceDirs.toString());
            sourceDirNodes[j] = proj.getNode(sourceDirs[j]);
          }
          //I am skipping the first item, since that is our root directory.
          for (int i = 1; i < sourceDirs.length; i++) {
            config.addDir(sourceDirNodes);
          }
          if (sourceFiles.length > 0) {
            config.addFiles(sourceFiles);
          }
        }
//end of section for Symbian project compatibility.
        config.addFiles(sourceFiles);

        if (!new File(projectDir.toString() + "/doc/doxyfile"). //NORES
          exists()) {
          config.generateDoxyConfigFile();
          //Now that we have created it, we need to add it to the project.
          CBProject project = (CBProject) Browser.getActiveBrowser().
            getActiveUserProject();
          if (project != null) {
            Url doxyFile = new Url(projectDir.toString() + "/doc/doxyfile"); //NORES
            Node node = project.getNode(doxyFile);
            node.setParent(project);
          }
        }

        /**
         * Read our executable location value and use that in our generated command line.
         */
        runDoxygen(projectDir);
        /**
         * @todo Add an output stream for the doxygen process and print the console messages to the message view.
         */

        /**
         * Need to iterate through all the open nodes and add our
         * doc tab to them (if applicable).
         */
        DoxyNodeViewer.generatingDocs = true;
        Node currentNode = Browser.getActiveBrowser().getActiveNode();
        NodeViewer viewer = Browser.getActiveBrowser().getActiveViewer(currentNode);
        Node[] openNodes = Browser.getActiveBrowser().getAllOpenNodes(
          Browser.getActiveBrowser().getActiveProject());
        for (int i = 0; i < openNodes.length; i++) {
          Browser.getActiveBrowser().updateViewers(openNodes[i]);
        }
        //Try to reset the display to how it started.
        Browser.getActiveBrowser().setActiveViewer(currentNode, viewer, true);
      }
      catch (Exception Ex) {
        Ex.printStackTrace();
        DoxyNodeViewer.generatingDocs = false;
      }
      DoxyNodeViewer.generatingDocs = false;
    }

    private void runDoxygen(Url projectDir) throws IOException {
      String doxyLocation = DoxyConfigPage.DoxyProperties.getValue() + File.separator;

      MessageCategory[] currentMessageTabs = Browser.getActiveBrowser().getMessageView().getTabs();
      for (int i = 0; i < currentMessageTabs.length; i++) {
        if (currentMessageTabs[i].getTitle() == "doc") { //RES Doc
          ;
        }
      }

      MessageCategory DoxyMessages = new MessageCategory(DOXYMESSAGECATEGORY);

      if (System.getProperty("os.name").startsWith("Win")) { //NORES
        if (! (new File(doxyLocation + "doxygen.exe").exists())) { //NORES
          if (!Browser.getActiveBrowser().getMessageView().hasMessages(DoxyMessages)) {
            Browser.getActiveBrowser().getMessageView().setActiveTab(DoxyMessages);
            Browser.getActiveBrowser().getMessageView().addMessage(DoxyMessages,
              "Cannot find the Doxygen executable at the specified location:" + doxyLocation); //RES Doxy_Cannot_Find_File
            Browser.getActiveBrowser().getMessageView().addMessage(DoxyMessages,
              "Please set the doxygen location in the global properties."); //RES DOXY_LOCATION_ERROR_MESSAGE
          }
          return;
        }
      }
      else {
        if (! (new File(doxyLocation + "doxygen").exists())) { //NORES
          if (!Browser.getActiveBrowser().getMessageView().hasMessages(DoxyMessages)) {
            Browser.getActiveBrowser().getMessageView().setActiveTab(DoxyMessages);
            Browser.getActiveBrowser().getMessageView().addMessage(DoxyMessages,
              "Cannot find the Doxygen executable at the specified location:" + doxyLocation); //RES Doxy_Cannot_Find_File
            Browser.getActiveBrowser().getMessageView().addMessage(DoxyMessages,
              "Please set the doxygen location in the global properties."); //RES DOXY_LOCATION_ERROR_MESSAGE
          }
          return;
        }
      }
      //Do I need to add a check to make sure we have permission to execute
      //the doxygen command (using SecurityManager.checkExec )?
      if (System.getProperty("os.name").startsWith("Win")) { //NORES
        String generatedCommandLine = doxyLocation + "doxygen.exe \"" + //NORES
          projectDir.getFile().toString() + "/doc/doxyfile\""; //NORES
        Runtime.getRuntime().exec(generatedCommandLine, null,
          projectDir.getFileObject());
      }
      else { //This is a *nix machine
        /**
         * @todo Might need to change this command to something like :
         * Runtime.getRuntime().exec (new String[]{"/bin/sh", "-c", "doxygen"}
         * to get it to work.  Under linux, this is having problems.
         */
        String generatedCommandLine = doxyLocation + "doxygen " + //NORES
          projectDir.getFile().toString() + "/doc/doxyfile"; //NORES
        Runtime.getRuntime().exec(new String[] {
          "/bin/sh", "-c", generatedCommandLine}, null, //NORES
          projectDir.getFileObject());
      }
    }
  };

  static String DOXYMESSAGECATEGORY = "Doxygen Generation"; //RES Doxy_Message_Category

}
