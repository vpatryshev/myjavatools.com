package com.borland.cbuilder.doxygen;

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import com.borland.primetime.ide.*;
import com.borland.primetime.vfs.*;
import com.borland.primetime.vfs.ui.*;
import com.borland.primetime.ui.*;
import javax.swing.event.*;

/**
 *
 * <p>Title: The doxygen config panel</p>
 * <p>Description: This is the actual configuration panel that shows up in
 * the global properties dialog.</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Borland Software Corporation</p>
 * @author Mathew Duafala
 * @version 1.0
 *
 */
public class DoxyConfigPanel
  extends JPanel {
  BorderLayout borderLayout1 = new BorderLayout();
  JLabel doxygenPathLabel = new JLabel();
  JTextField tfDirectory = new JTextField();
  JButton dirBrowseButton = new JButton();
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  JPanel topPanel = new JPanel();
  GridBagLayout gridBagLayout2 = new GridBagLayout();
  public DoxyConfigPanel() {
    try {
      jbInit();
//      String doxygenLocation = Browser.getActiveBrowser().getActiveUserProject().
//        getAutoProperty(DoxygenConfig.DOXY_CATEGORY,
//        DoxygenConfig.DOXY_LOCATION) + File.separator;

//      if (! (new File(doxygenLocation + "doxygen.exe").exists())) {  //NORES
      //      }
//      else {
//      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  void jbInit() throws Exception {
    doxygenPathLabel.setText("Doxygen location:"); //RES Doxygen_Location
    dirBrowseButton.setOpaque(true);
    dirBrowseButton.setText("..."); //NORES
    dirBrowseButton.addActionListener(new java.awt.event.ActionListener() {

      public void actionPerformed(ActionEvent e) {
        dirBrowseButton_actionPerformed(e);
      }
    }); //RES Doxygen_Install_Location_Label
    this.setLayout(gridBagLayout1);
    this.setBorder(null);
    this.setDebugGraphicsOptions(0);
    this.setMaximumSize(new Dimension(2147483647, 2147483647));
    this.setPreferredSize(new Dimension(410, 198));
    this.setRequestFocusEnabled(true);

    tfDirectory.setToolTipText("Enter the directory that the Doxygen executable resides in."); //NORES
    tfDirectory.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusLost(FocusEvent e) {
        tfDirectory_focusLost(e);
      }
    }); //RES DOXY_CONFIG_LABEL
    tfDirectory.addInputMethodListener(new java.awt.event.InputMethodListener() {
      public void caretPositionChanged(InputMethodEvent e) {
      }

      public void inputMethodTextChanged(InputMethodEvent e) {
        tfDirectory_inputMethodTextChanged(e);
      }
    }); //RES Doxygen_Install_Location_EditBox
    topPanel.setLayout(gridBagLayout2);
    this.add(tfDirectory, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
      , GridBagConstraints.EAST, GridBagConstraints.HORIZONTAL, new Insets(0, 100, 0, 0), 161, 5));
    this.add(dirBrowseButton, new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0
      , GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 20), 0, 0));
    this.add(topPanel, new GridBagConstraints(0, 0, 2, 1, 0.0, 0.0
      , GridBagConstraints.NORTH, GridBagConstraints.HORIZONTAL, new Insets(0, 0, 2, 0), 69, 73));
    this.add(doxygenPathLabel, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
      , GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
  }

  void dirBrowseButton_actionPerformed(ActionEvent e) {
    Url url;
    if (tfDirectory.getText() != null) {
      url = UrlChooser.promptForDir(Browser.getActiveBrowser(), new Url(new File(tfDirectory.getText())));
    } else {
      url = UrlChooser.promptForDir(Browser.getActiveBrowser(), null);
    }
    if (url != null) {
      checkDoxyLocation(url);
    }

  }

  public void checkDoxyLocation(Url url) {
    if (System.getProperty("os.name").startsWith("Win")) {  //NORES
      if ( (new File(url.getFileObject().toString() + File.separator + "doxygen.exe").exists())) { //NORES
        tfDirectory.setText(url.getFileObject().getAbsolutePath());
      } else {
        JOptionPane.showMessageDialog(null,
          "Cannot Find Doxygen", //RES cant_find_doxygen
          "Error", //RES Error
          JOptionPane.WARNING_MESSAGE);
      }

    } else
    if ( (new File(url.getFileObject().toString() + File.separator + "doxygen").exists())) { //NORES
      tfDirectory.setText(url.getFileObject().getAbsolutePath());

    } else {
      tfDirectory.setText(url.getFileObject().getAbsolutePath());
      JOptionPane.showMessageDialog(null,
        "Cannot Find Doxygen", //RES cant_find_doxygen
        "The entered path does not contain the doxygen executable", //RES cant_find_doxygen_in_path
        JOptionPane.WARNING_MESSAGE);

    }
  }

  public String getPath() {
    return (tfDirectory.getText());
  }

  public void setPath(String path) {
    tfDirectory.setText(path);
  }

  void recursiveCheckBox_stateChanged(ChangeEvent e) {
    //Set the property here.
  }

  void warningsCheckBox_stateChanged(ChangeEvent e) {
//    Browser.getActiveBrowser().getActiveUserProject().
    //Set the property here.
  }

  void extractallCheckBox_stateChanged(ChangeEvent e) {
    //Set the property here.
  }

  void tfDirectory_inputMethodTextChanged(InputMethodEvent e) {

  }

  /**
   * @todo Need to get rid of this event and use the property page events
   * for pageCancelled, pageDeactivating, etc.  That will make the error
   * handling much more seemless.
   * @param e FocusEvent
   */

  void tfDirectory_focusLost(FocusEvent e) {
//    //check to see if we can find the typed-in path.
//    File file = new File(tfDirectory.getText());
//    checkDoxyLocation(new Url(file));
  }

}
