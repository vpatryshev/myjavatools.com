package com.borland.cbuilder.doxygen;

import java.io.*;
import com.borland.cbuilder.node.*;
import com.borland.primetime.ide.*;
import com.borland.primetime.node.*;
import com.borland.primetime.util.*;
import com.borland.primetime.vfs.*;
import com.borland.cbuilder.viewer.*;
import com.borland.cbuilder.viewer.HTMLViewerComponent;

/**
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author Mathew Duafala
 * @version 1.0
 *
 *
 */

public class DoxyNodeListener
  extends BrowserAdapter implements BufferListener, ProjectListener {
  private Url url;
  private boolean isPartofProject = false;

  public DoxyNodeListener() {}

  /**
   * @param browser Browser
   * @param node Node
   * @param viewer NodeViewer
   */
  public void browserViewerActivated(
    Browser browser, Node node, NodeViewer viewer) {
    super.browserViewerActivated(browser, node, viewer);
//
    node.check();

    if (url != null) {
      Buffer buffer = null;

    }
    if (viewer instanceof DoxyNodeViewer) {
      try {
        url = Browser.getActiveBrowser().getActiveProject().getProjectPath();

        HTMLViewerComponent currentView = (HTMLViewerComponent) browser.
          getActiveBrowser().getActiveViewer(node).getViewerComponent();
        if (currentView != null) {
          currentView.goHome();

        }
        try {
          VFS.getBuffer(url).addBufferListener(this);
          VFS.fileModified(url);
        }
        catch (Exception ex) {
          ex.printStackTrace();
        }
        Buffer buffer = VFS.getBuffer(url);
        if (buffer != null) {
          buffer.updateContent();
        }
        else {
//          System.out.println("buffer was null");
        }
      }
      catch (Exception ex) {
        ex.printStackTrace();
      }

      node.check();
    }

    if (node instanceof CPPFileNode) {
      url = ( (CPPFileNode) node).getUrl();
      try {
        VFS.getBuffer(url).addBufferListener(this);
      }
      catch (IOException ex) {
        ex.printStackTrace();
      }
    }
  }

//
  public void browserViewerDeactivating(
    Browser browser, Node node, NodeViewer viewer) throws VetoException {

    if (viewer instanceof DoxyNodeViewer) {
      if (url != null) {
        Buffer buffer = null;
        try {
          buffer = VFS.getBuffer(url);
        }
        catch (IOException ex) {
          ex.printStackTrace();
        }
        if (buffer != null) {
          buffer.removeBufferListener(this);
        }
        url = null;
      }
    }
    if (node instanceof CPPFileNode) {
      url = ( (CPPFileNode) node).getUrl();
      try {
        VFS.getBuffer(url).removeBufferListener(this);
      }
      catch (IOException ex) {
        ex.printStackTrace();
      }
    }

  }

//
  public void bufferChanged(Buffer buffer, BufferUpdater updater) {

  }

  public void bufferLoaded(Buffer buffer) {

  }

  public void bufferStateChanged(Buffer buffer, int oldState, int newState) {

  }

  public void bufferSaving(Buffer buffer) {
    try {
      /**
       * \bug If the use clicks on the doc tab too soon after saving (ie before
       * doxygen is done generatng the file) then it will show a dialog
       */
      regenCurrentNode();

    }
    catch (Exception ex) {
      Browser.getActiveBrowser().getMessageView().addMessage(new
        MessageCategory("Doxygen Generation"), ex.getMessage()); //RES Doxygen_Generation
      ex.printStackTrace();
    }

  }

  /**
   *  This will regen the documentation for a single file.
   * @throws FileNotFoundException
   * @throws IOException
   * @todo Need to check the config file to see if the user wants to regen
   * files after every save.
   *
   */
  public void regenCurrentNode() throws FileNotFoundException, IOException {

    //We don't want to gen docs for files that aren't part of the current project.
    //Need to make sure we actually have a project associated with our file.
    if (Browser.getActiveBrowser().getActiveUserProject() == null) {
      return;
    }
    Node currentNode = Browser.getActiveBrowser().getActiveNode();
    Node[] projectNodes = Browser.getActiveBrowser().getActiveUserProject().
      getChildren();

    isChild(currentNode,projectNodes);

    if (!isPartofProject) {
      return;
    }
    // read in the current doxyfile
    File configFileLocation = new File(Browser.getActiveBrowser().
      getActiveProject().
      getProjectPath().getFullName() +
      "/doc/doxyfile"); //NORES
    if (configFileLocation.exists() &&
      (Browser.getActiveBrowser().getActiveNode()) != null) {
      FileReader reader = new FileReader(configFileLocation);
      FileWriter outFile = new FileWriter(configFileLocation + ".temp"); //NORES
      //read it in using a stream.
      BufferedReader bufReader = new BufferedReader(reader);
      //replace the input files with just the current filename
      String currentLine = ""; //NORES
      while ( (currentLine = bufReader.readLine()) != null) {
        if (currentLine.startsWith("INPUT")) { //NORES
          outFile.write("INPUT = \"" + //NORES
            Browser.getActiveBrowser().getActiveNode().
            getLongDisplayName() + "\""); //NORES
          outFile.write("\r\n"); //NORES
        }
        else {
          outFile.write(currentLine); //just write our the config file.
          outFile.write("\r\n"); //NORES
        } //end of else
      } //end of loop
      outFile.flush();
      outFile.close();
      outFile = null;
      reader.close();
      reader = null;
      bufReader.close();
      bufReader = null;

      //call doxygen with that config file name.
      Url projectDir = Browser.getActiveBrowser().getActiveProject().
        getProjectPath();

      /**
       *<P> This is a hack because the process stays active and clutters the
       *task manager otherwise (I think it might also prevent the ide
       *from shutting down)
       * <P> This might also cause a problem when we are trying to regen the docs
       *  for a lot of files (ie the previous instance isn't done, but we kill it
       *   and create a new one)
       */

      if (p != null) {
        p.destroy();
      }
      p = null;

      String doxyLocation = DoxyConfigPage.DoxyProperties.getValue() + File.separator;

      MessageCategory DoxyMessages = new MessageCategory(DoxyMenu.DOXYMESSAGECATEGORY);

      if (! (new File(doxyLocation + "doxygen.exe").exists())) { //NORES

//        if(!Browser.getActiveBrowser().getMessageView().hasMessages(DoxyMessages))
//        Browser.getActiveBrowser().getMessageView().addMessage(DoxyMessages,
//            "Please set the doxygen location in the global properties.");
//        return;
      }
      else {
        if (System.getProperty("os.name").startsWith("Win")) { //NORES
          String generatedCommandLine = doxyLocation + "doxygen.exe \"" + //NORES
            projectDir.getFile().toString() + "/doc/doxyfile.temp\""; //NORES

          p = Runtime.getRuntime().exec(generatedCommandLine, null,
            projectDir.getFileObject());
        }
        else {

          String generatedCommandLine = doxyLocation + "doxygen " + //NORES
            projectDir.getFile().toString() + "/doc/doxyfile.temp"; //NORES

          p = Runtime.getRuntime().exec(new String[] {
            "/bin/sh", "-c", generatedCommandLine}, null, //NORES
            projectDir.getFileObject());

        }
      }
//
//      p = Runtime.getRuntime().exec("doxygen.exe \"" + projectDir.getFullName() +
//                                    "/doc/doxyfile.temp\"", null,
//                                    projectDir.getFileObject());

      //delete the temp file that we created.
      File temp = new File(configFileLocation + ".temp"); //NORES
      temp.deleteOnExit();
      temp = null;
      configFileLocation = null;

    }
  isPartofProject = false;  //just need to reset this
  }

  private void isChild(Node currentNode, Node[] projectNodes) {

    for (int j = 0; j < projectNodes.length; j++) {
      if (projectNodes[j].equals(currentNode)) {
        isPartofProject = true;
      }
      if (projectNodes[j] instanceof FolderNode) { //Need to look in Virtual Folders
        isChild(currentNode, projectNodes[j].getChildren());
      }
    }
  }

//  /**
//   *
//   * @param browser Browser
//   * @throws VetoException
//   * <P>I am hooking this to kill off the last doxygen process so we don't
//   * have any problems getting the IDE to close because doxygen is hanging around.
//   */
  public void browserClosing(Browser browser) throws VetoException {
    if (p != null) {
      p.destroy();
    }
    p = null;
  }

//
//  /**
//   * @todo  add checks for when a file is added or removed from a project.
//   */
//  /**
//   *
//   * @param project Project
//   * @param node Node
//   */
  public void nodeChildrenChanged(Project project, Node node) {

    if (node instanceof CPPFileNode) {
      Node[] projectNodes = Browser.getActiveBrowser().getActiveProject().getChildren();
      for (int i = 0; i < projectNodes.length; ++i) {
        if (node.equals(projectNodes[i])) {
          insertNodeToDoxyGen(project, node);
        }
      }
    }
//    System.out.println(node.getDisplayName());

  }

//
//  /**
//   *
//   * @param project Project
//   * @param node Node
//   */
  public void nodeChanged(Project project, Node node) {
//    System.out.println(node.getDisplayName());
  }

  /**
   *
   * @param project Project
   * @param string String
   * @param string2 String
   * @param string3 String
   * @param string4 String
   * @todo Need to use this to pick up changes to the include paths etc.
   */
  public void projectPropertyChanged(Project project, String string,
    String string2, String string3,
    String string4) {}

//
  public static Process p;

  public void insertNodeToDoxyGen(Project project, Node node) {
//    System.out.println("Adding a node to the project");

  }

}
