package com.borland.cbuilder.doxygen;

import com.borland.primetime.properties.PropertyGroup;
import com.borland.primetime.properties.PropertyPageFactory;
import com.borland.primetime.ide.*;
import com.borland.primetime.properties.*;

/**
 * <p>Title: </p>
 * <p>Description: This page defines the properties that we will use.
 * Once we register it with the property manager, it will create keys in the
 * user properties for the IDE to use.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author Mathew Duafala
 * @version 1.0
 */
public class DoxyPropertiesGroup
  extends PropertyPageFactory
  implements PropertyGroup {

  public DoxyPropertiesGroup(String Category) {
    super(Category);
  }

  public PropertyPage createPropertyPage() {
    return new DoxyConfigPage(Browser.getActiveBrowser().getActiveProject());
  }

  public PropertyPageFactory getPageFactory(Object topic) {
    if (topic == null) {
      return new DoxyPropertiesGroup("Doxygen");  //NORES
    }
    else {
      return null;
    }
  }

  public void initializeProperties() {}

}
