package com.borland.cbuilder.doxygen;

//import com.borland.primetime.teamdev.vcs.*;
//import com.borland.jbcl.layout.*;
import com.borland.primetime.help.*;
import com.borland.primetime.ide.*;
import com.borland.primetime.node.*;
import com.borland.primetime.vfs.*;
import com.borland.primetime.properties.*;
import javax.swing.JLabel;
import com.borland.primetime.ui.DefaultDialog;
import java.io.File;
import javax.swing.JOptionPane;
import com.borland.cbuilder.CBuilderHelp;

/**
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: Borland Software Corporation</p>
 * @author Mathew Duafala
 * @version 1.0
 *
 * <P> This isn't going to use the regular primetime properties (except for the
 * location of doxygen.exe itself), since that would require me to merge options
 * between the doxyfile, the GUI, and the stored properties in the project file.
 * I will just use the doxyfile for the actual doxygen properties.
 */

public class DoxyConfigPage
  extends PropertyPage {
  DoxyConfigPanel pnlConfig = new DoxyConfigPanel();
  Project project;

  public DoxyConfigPage(Project project) {
    this.project = project;
    try {
      jbInit();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  public static GlobalProperty DoxyProperties = new GlobalProperty(DoxygenConfig.DOXY_CATEGORY, DoxygenConfig.DOXY_LOCATION, " ");

  private void jbInit() throws Exception {
    this.add(pnlConfig);
  }

  public void writeProperties() {

    Url url = new Url(new File(pnlConfig.getPath()));
    if (pnlConfig.getPath().trim().length() != 0) {
      if (System.getProperty("os.name").startsWith("Win")) { //NORES
        if (! (new File(url.getFileObject().toString() + "/" + "doxygen.exe").exists())) { //NORES
          JOptionPane.showMessageDialog(null,
            "Cannot Find Doxygen", //RES cant_find_doxygen
            "Error", //RES cant_find_doxygen_in_path
            JOptionPane.WARNING_MESSAGE);
        }
      }
      else
      if (!new File(url.getFileObject().toString() + File.separator + "doxygen").exists()) { //NORES
        JOptionPane.showMessageDialog(null,
          "Cannot Find Doxygen", //RES cant_find_doxygen
          "Error", //RES cant_find_doxygen_in_path
          JOptionPane.WARNING_MESSAGE);

      }
    }else{
      return;
    }
    Browser.setProperty(DoxyProperties);
    DoxyProperties.setValue(pnlConfig.getPath());
  }

  /**
   * @todo Need to make sure this points to the correct topic.
   * @return HelpTopic
   */
  public HelpTopic getHelpTopic() {
    return CBuilderHelp.TOPIC_DoxygenIntegration;
  }

  public PropertyPage getProjectConfigPageNew(Project project) {
    return (new DoxyConfigPage(project));
  }

//   public void prepareForReset() {
//     super.prepareForReset();
//     //Need to add a check here to make sure we actually have a value to reset
//     //to (ie, the key has to exist).
//     if(this.DoxyProperties.getValue().length()==0){
//       this.DoxyProperties.setValue(" ");
//     }
//   }

  public void readProperties() {
    String path = DoxyProperties.getValue();
    if (path != null) {
      pnlConfig.setPath(path);
    }
  }

}
