package com.borland.cbuilder.doxygen;

import com.borland.cbuilder.viewer.*;
import com.borland.primetime.viewer.*;
import com.borland.primetime.ide.*;
import com.borland.primetime.vfs.*;
import com.borland.cbuilder.node.*;
import com.borland.primetime.properties.*;
import java.lang.Character;

import java.io.*;

/**
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author Mathew Duafala
 * @version 1.0
 *
 * <P>This is the component that actually has to render the html documentation
 * <P>It will be created and displayed on the doc tab in the IDE
 */
public class DoxyViewerComponent
  extends HTMLViewerComponent {

  /**
   * @param currentContext Context
   */
  public DoxyViewerComponent(Context currentContext) {

    super(currentContext);
    checkForDoc(currentContext);
  }

  public boolean checkForDoc(Context currentContext) {
    //Make sure the html is there before trying to display it.
    //If there is no active project associated with a file, then we don't
    //show the docs.
    if (Browser.getActiveBrowser().getActiveUserProject() == null) {
      return false;
    }
    Url projectDir = Browser.getActiveBrowser().getActiveUserProject().
      getProjectPath();
    urlToDoc = projectDir;

    if (currentContext.getNode() instanceof CPPFileNode) {
      FileCheck(currentContext, projectDir);
    }
    if (currentContext.getNode() instanceof HFileNode) {
      FileCheck(currentContext, projectDir);
    }
    if (currentContext.getNode() instanceof IDLFileNode) {
      //idlFileCheck(currentContext, projectDir); //Need to add an IDL file check fcn.
    }

    projectDir = null;
    urlToDoc = null;
    return validDocumentFound;
  }

  /**
   *
   * @param currentContext Context  This is the currently open file
   * @param projectDir Url  This is the url to the project dir
   *
   * @return String  Use the same hash algorithm as doxygen to get the
   * correct file name to lookup.
   *
   * <P>There are some instances in the new doxygen that will append a leading
   * underscore to a file with a leading capital letter.  I can't find a way
   * in the config file to fix this.  Might need to add a fallback check
   * to see if that version of the docs exist if we can't find this version.
   *
   *
   */
  String getfileNameForDoc(Context currentContext, Url projectDir) {

    String fileName = currentContext.getNode().getDisplayName();
    String result = "";
    for (int i = 0; i < fileName.length(); i++) {
      switch (fileName.charAt(i)) {
        case '_':
          result += "__";
          break;
        case '-':
          result += "-";
          break;
        case ':':
          result += "_1";
          break;
        case '/':
          result += "_2";
          break;
        case '<':
          result += "_3";
          break;
        case '>':
          result += "_4";
          break;
        case '*':
          result += "_5";
          break;
        case '&':
          result += "_6";
          break;
        case '|':
          result += "_7";
          break;
        case '.':
          result += "_8";
          break;
        case '!':
          result += "_9";
          break;
        case ',':
          result += "_00";
          break;
        case ' ':
          result += "_01";
          break;
        default:
          result += fileName.charAt(i);
          break;
      }
    }
    result += ".html";  //NORES
    //We need to verify that the file exists before returning the filename
    File docFile = new File(projectDir.getFullName() + "/doc/html/" + result); //NORES
    if (docFile.exists()) {
      return result;
    }
    else {
      /**
       * Newer versions of doxygen append an underscore to uppercase characters.
       */
      String underbarResult = "";
      for(int i=0;i<result.length();i++){
        if(Character.isUpperCase(result.charAt(i))){
          underbarResult += '_';
        }
        underbarResult += result.charAt(i);
      }
      underbarResult = underbarResult.toLowerCase();
//      System.out.println(underbarResult);
      File underbarDocFile = new File(projectDir.getFullName() + "/doc/html/" + underbarResult);//NORES
      if (underbarDocFile.exists()) {
        return underbarResult;
      }
    }
    //if we get here, there isn't a valid doc file.
    return "annotated.html"; //NORES
  }
  /**
   * @param currentContext Context This is the current file
   * @param projectDir Url This is the base directory
   */
  private void FileCheck(Context currentContext, Url projectDir) {

    String fileName = getfileNameForDoc(currentContext, projectDir);
    try {
      urlToDoc = new Url(projectDir.toString() + "/doc/html/" + fileName); //NORES
      super.setInternalURL("vfs:///" + urlToDoc.toString()); //NORES
      if (urlToDoc.getFileObject().exists()) {
        validDocumentFound = true;
      }else{
        validDocumentFound = false;
      }
    }
    catch (InvalidUrlException ex) {
      ex.printStackTrace();
    }
  } // end of the file check.

  boolean validDocumentFound = false;
  static Url urlToDoc = null;
  private File docFile;
}
