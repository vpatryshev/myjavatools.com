package com.borland.dspspb.primetime.crmplugin.view.rvtreetable;

import java.awt.Color;
import javax.swing.*;

import com.borland.dspspb.primetime.crmplugin.gui.treetable.TableNodeAdapter;
import com.borland.dspspb.primetime.crmplugin.resources.ResourceManager;
import com.starbase.caliber.*;
import com.starbase.caliber.server.RemoteServerException;

public class RequirementTypeNode extends TableNodeAdapter
{
  private static Color reqBackground					= Color.white;
  private static Color reqForeground					= Color.black;

  private static ImageIcon iconOpened = null;
  private static ImageIcon iconClosed	= null;

  private RequirementType m_requirementType = null;

  // Load icons
  static
  {
    iconOpened = ResourceManager.getIcon (ResourceManager.RequirementTypeNode_Opened_icon);
    iconClosed = ResourceManager.getIcon (ResourceManager.RequirementTypeNode_Closed_icon);
  }

  public RequirementTypeNode (Object data)
  {
    super (data);
  }

  public Color getBackground ()
  {
    return reqBackground;
  }

  public Color getForeground ()
  {
    return reqForeground;
  }

  public Icon getIcon (boolean bExpanded)
  {
    m_isExpanded = bExpanded;
    return (bExpanded ? iconOpened : iconClosed);
  }

  public String getText ()
  {
    if (m_requirementType == null) return "";

    StringBuffer buffer = new StringBuffer ();

    buffer.append (m_requirementType.getName());
    buffer.append (" (");
    buffer.append (m_requirementType.getTag());
    buffer.append (')');

    return buffer.toString();
  }

  public String getToolTipText ()
  {
    if (m_requirementType != null)
      return m_requirementType.getName ();
    return "";
  }

  public RequirementType getRequirementType()
  {
    return m_requirementType;
  }

  public void setRequirementType(RequirementType requirementType)
  {
    m_requirementType = requirementType;
  }

  public void initAssociatedObject(Session session)
  {
    if (m_requirementType != null)
      return;
    RequirementTreeNode rtnRequirementType = (RequirementTreeNode)getUserObject();
    try
    {
      m_requirementType = (RequirementType)session.get(rtnRequirementType.getAssociatedObjectID());
    }
    catch (RemoteServerException ex)
    {
    }
  }

//------------------------------------------------------------------------------

  private boolean m_isExpanded = false;

  public boolean isExpanded()
  {
    return m_isExpanded;
  }
}
