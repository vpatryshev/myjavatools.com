package com.borland.dspspb.primetime.crmplugin.actions;
import java.awt.event.*;

import com.borland.dspspb.primetime.crmplugin.gui.treetable.*;
import com.borland.dspspb.primetime.crmplugin.resources.*;
import com.borland.dspspb.primetime.crmplugin.view.*;
import com.borland.dspspb.primetime.crmplugin.view.rvtreetable.*;
import com.borland.dspspb.primetime.crmplugin.opentool.CommentStatus;
import com.borland.dspspb.primetime.crmplugin.management.FramingManager;

public class ActionUpdateComments extends PluginUpdateAction
{
  public ActionUpdateComments()
  {
    super
      ("Update Comments", //RES ActionUpdateComment_shorttext
       "Update comments associated with selected traces", //RES ActionUpdateComment_longtext
       ResourceManager.ActionUpdateComment_icon);
  }

  public void actionPerformed (ActionEvent e)
  {
    TraceTable traceTable = (TraceTable) e.getSource();
    RequirementNode requirementNode = null;
    int nUnknown = 0;

    int [] selectedRows = traceTable.getSelectedRows ();

    for (int i = 0; i < selectedRows.length; i++)
    {
      TraceInfo traceInfo = traceTable.getData () [selectedRows [i]];
      int status = traceInfo.getStatus ();

      if (status != CommentStatus.STATUS_UNKNOWN)
      {
        requirementNode = traceInfo.getRequirementNode();
        requirementNode.updateTrace (traceInfo);
      }
      else
      {
        nUnknown++;
      }
    }

    traceTable.updateTable ();

    // Restore current selection
    for (int i = 0; i < selectedRows.length; i++)
    {
      traceTable.addRowSelectionInterval (selectedRows [i], selectedRows [i]);
    }

    updateRequirementTable (requirementNode);

    if (nUnknown != 0)
    {
      String message = "" + nUnknown + " "; //NORES
      message += (nUnknown == 1
        ? "of associated comments has not been updated because of Unknown status." //RES ActionUpdateComment_message1
        : "of associated comments have not been updated because of Unknown status."); //RES ActionUpdateComment_message2
      FramingManager.getInstance().showWarning(message);
    }
  }

  public void update (Object source)
  {
    TraceTable traceTable = (TraceTable) source;
    setEnabled (traceTable.getSelectedRowCount () > 0);
  }

// -----------------------------------------------------------------------------

  /**
   * @todo: Relocate this method. But where to?
   */
  public static void updateRequirementTable (RequirementNode requirementNode)
  {
    if (requirementNode == null) return;

    // All requirement nodes for traceTable have the same context (reference to owner view)
    // so we do the following once
    PluginView pluginView = (PluginView)requirementNode.getContext ();
    RVTreeTable reqTable = pluginView.getTable ();
    int selectedRow = reqTable.getSelectedRow ();
    TreeTableModelAdapter model = (TreeTableModelAdapter)reqTable.getModel ();
    model.fireTableRowsUpdated (selectedRow, selectedRow);
  }
}
