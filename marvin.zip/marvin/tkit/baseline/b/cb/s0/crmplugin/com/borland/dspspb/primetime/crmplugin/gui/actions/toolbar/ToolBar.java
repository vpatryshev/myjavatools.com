package com.borland.dspspb.primetime.crmplugin.gui.actions.toolbar;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.Border;
import com.borland.dspspb.primetime.crmplugin.gui.actions.SwingAction;
import javax.swing.AbstractButton;
import java.util.Vector;
import com.borland.dspspb.primetime.crmplugin.gui.actions.SwingCheckBoxAction;

public class ToolBar extends JPanel {
    public ToolBar() { this(HORIZONTAL); }

    public ToolBar(int align) {
        super();
        alignment = align;
        if (alignment == HORIZONTAL) {
            setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
            setBorder(new javax.swing.plaf.basic.BasicBorders.MenuBarBorder(Color.gray, Color.white));
        } else {
            setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        }
    }

    public void addAction(SwingAction action) {
        ToolBarButton button = new ToolBarButton(action);
        add(button);
        if(convexUI)button.setForceRollover(true);
    }

    public void addSeparator() {
        final Dimension d = getSeparatorAlignment() == HORIZONTAL ? new Dimension(22,4) :
                                                                    new Dimension(4,22) ;
        add(new JSeparator(getSeparatorAlignment()){
            public Dimension getMaximumSize() {return d;}
            public Dimension getMinimumSize() {return d;}
            public Dimension getPreferredSize() {return d;}
        });
    }

    private int getAlignment() {
        return alignment;
    }
    private int getSeparatorAlignment() {
        return alignment == HORIZONTAL ? VERTICAL : HORIZONTAL;
    }

    public void setBorder(Border border) {
    super.setBorder(BorderFactory.createCompoundBorder(
                    border,
              BorderFactory.createEmptyBorder(1, 1, 1, 1)));
    }

    public void setBorder(int t, int l, int b, int r) {
        setBorder(BorderFactory.createMatteBorder(t, l, b, r, UIManager.getColor("controlShadow")));
    }

    public void updateToolbar() {
        Component[] comps = getComponents();
        for(int i=0; i<comps.length; i++) {
            if(comps[i] instanceof ToolBarButton) {
                ((ToolBarButton)comps[i]).updateButton();
            }
        }
    }

    public void setConvexUI() {
        Component[] comps = getComponents();
        for(int i=0; i<comps.length; i++) {
            if(comps[i] instanceof ToolBarButton) {
                ((ToolBarButton)comps[i]).setForceRollover(true);
            }
        }
        convexUI = true;
    }

    private boolean convexUI = false;
    private int alignment;
    public static int HORIZONTAL = SwingUtilities.HORIZONTAL;
    public static int VERTICAL = SwingUtilities.VERTICAL;
}
