package com.borland.dspspb.primetime.crmplugin.gui.swingcomponents;

import javax.swing.*;


public class SwingLabel extends SwingComponent
{
        private JLabel label = new JLabel();

        public SwingLabel(String name, String displayName, Object value)
        {
                super(name, displayName, value);
        }

        public void setText(String text)
        {
                if (label != null)
                        label.setText(text);
        }

        public JComponent getMainComponent()
        {
                return label;
        }
}
