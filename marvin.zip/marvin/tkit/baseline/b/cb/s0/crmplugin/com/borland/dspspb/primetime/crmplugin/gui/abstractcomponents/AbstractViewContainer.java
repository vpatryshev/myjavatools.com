package com.borland.dspspb.primetime.crmplugin.gui.abstractcomponents;

import java.lang.reflect.*;
import java.util.*;
import java.io.*;
import java.util.*;
import com.borland.dspspb.primetime.crmplugin.gui.abstractcomponents.listeners.UpdateFormListener;


public abstract class AbstractViewContainer extends AbstractViewComponent
{
   protected HashMap components = new HashMap();
   private int order=-1;
   protected Vector updateFormListeners;

   public Collection getComponents()
   {
       return getComponents(false);
   }

  public Collection getComponents(boolean deep)
  {
     if ( !deep ) return components.values();
     return getComponents( this );
  }


  private Collection getComponents(AbstractViewContainer parent )
  {
     Iterator i = parent.getComponents().iterator();
     Vector result = new Vector();
     while ( i.hasNext() )
     {
        AbstractViewComponent nextComp =(AbstractViewComponent)i.next();
        if ( nextComp instanceof AbstractViewContainer)
        result.addAll( getComponents((AbstractViewContainer)nextComp) );
        else
        result.add(nextComp);
     }
     return result;
  }


  public void addUpdateFormListener( UpdateFormListener listener )
  {
    if ( updateFormListeners == null )
    updateFormListeners = new Vector();
    updateFormListeners.add( listener );
  }

  public HashMap getComponentsMap()
  {
     return components;
  }

  public AbstractViewContainer()
  {
  }

 protected void addComp ( String cName,AbstractViewComponent  component )
 {
   components.put (cName,component );
   component.setContainer(this);
   component.setOrder(order);
   order++;
 }

 public void add ( AbstractViewComponent  component,int extOrder )
 {
    components.put (component.getName(),component );
    component.setContainer(this);
    component.setOrder(extOrder);
 }

 public void add ( AbstractViewComponent  component )
 {
    if (component instanceof AbstractViewContainer )
    {
      addComp ( "container_"+order,component );
    }
    else
    addComp ( component.getName(),component );
 }

 private AbstractViewComponent getComponentByName(String compName,AbstractViewContainer parent )
 {

    Iterator i = parent.getComponents().iterator();
    while ( i.hasNext() )
    {
        AbstractViewComponent comp = (AbstractViewComponent)i.next();
        if ( compName.equals(comp.getName())) return comp;
                // OT+
        //      if ( (compName+"_right").equals(comp.getName()) && (comp instanceof WorkflowSuperChoice)) return comp;
                //OT-
                if ( comp instanceof AbstractViewContainer )
        {
              AbstractViewContainer cont =(AbstractViewContainer)comp;
              AbstractViewComponent result =  cont.getComponentByName(compName);
              if ( result!=null ) return result;
        }

    }
    return null;
 }

 public AbstractViewComponent getComponentByName(String searchName )
 {
    return getComponentByName ( searchName,this );
 }

 public void remove ( AbstractViewComponent component )
 {
   components.remove(component.getName() );
 }

 public void removeAllComponents ( )
 {
   components = new HashMap();
   order=0;
 }

}
