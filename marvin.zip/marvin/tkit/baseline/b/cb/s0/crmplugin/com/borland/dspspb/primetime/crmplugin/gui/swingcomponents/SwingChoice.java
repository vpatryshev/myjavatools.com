package com.borland.dspspb.primetime.crmplugin.gui.swingcomponents;

import javax.swing.JComboBox;
import javax.swing.JComponent;
import java.util.Vector;
import java.util.Collection;
import java.util.Iterator;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.BorderFactory;
import com.borland.dspspb.primetime.crmplugin.gui.abstractcomponents.AbstractChoiceComponent;
import java.awt.Dimension;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;

public class SwingChoice extends AbstractChoiceComponent
{
  JComboBox mainComponent = new JComboBox();
  JLabel label = new JLabel();
  private String displayName;
  private Object val;

  public SwingChoice(String name,String displayName )
  {
     setName ( name );
     this.displayName = displayName;
  }

  public Object getValue()
  {
     return mainComponent.getSelectedItem();
  }


  public void setValue(Object value)
  {
     super.setValue ( value );
     mainComponent.setSelectedItem( value );
     this.val = value;
  }

  public Object getUI()
  {
      JPanel mainPanel = new JPanel();
      mainComponent.addItemListener( new ItemListener()
      {
         public void itemStateChanged(ItemEvent e)
         {

           JComboBox mc=(JComboBox)e.getSource();
           Object val = getValue();
           if ( val!=null && !val.equals (  mc.getSelectedItem() ) )
           setValue ( mc.getSelectedItem() );
         }
      });
      mainPanel.setLayout( new BorderLayout() );
      label.setName( displayName );
      mainPanel.add( label,BorderLayout.NORTH );
      if ( isMandatory() ) label.setText("(*) "+displayName );
      else
      label.setText ( displayName );
      Iterator i = getChoiceValues().iterator();
      mainComponent.removeAllItems();
      while ( i.hasNext() )
      {
         mainComponent.addItem( i.next() );
      }
      if ( val!=null)
      mainComponent.setSelectedItem(val);
      mainComponent.setPreferredSize( new Dimension(0,22) );
      mainPanel.add ( mainComponent,BorderLayout.CENTER );
      return mainPanel;
  }



}
