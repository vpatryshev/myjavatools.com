package com.borland.dspspb.primetime.crmplugin.gui.dialogs;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public abstract class AdrenalinDialog extends JDialog implements ActionListener {
    public AdrenalinDialog(JFrame main) {
        super(main);
        setModal(true);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent evt) {
                doCancel();
            }
        });
    }
    public abstract JPanel createContentPane();
    public JPanel createButtonPane() {
        JPanel bp = new JPanel();
        bp.setLayout(new FlowLayout(FlowLayout.RIGHT));
        String[] buts = getButtons();
        for (int i=0; i<buts.length; i++) {
            AdrenalinDialogButton but = new AdrenalinDialogButton(buts[i]);
            but.addActionListener(this);
            bp.add(but);
        }
        return bp;
    }

    public void actionPerformed(ActionEvent evt) {
        AdrenalinDialogButton but = (AdrenalinDialogButton)evt.getSource();
        if (but.getButtonType().equals(AdrenalinDialogButton.OK)) {
            try {
                doOk();
                isOK = true;
                dispose();
            }
            catch (Exception ex) {
                JOptionPane.showMessageDialog(getOwner(), "Exception occured: "+ex.getMessage(), "Exception", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        }
        else if (but.getButtonType().equals(AdrenalinDialogButton.CANCEL)) {
            doCancel();
            dispose();
        }
        else {
            doButton(but.getButtonType());
        }
    }

    public boolean isOK() {
        return isOK;
    }

    public void doOk() {
    }

    public void doCancel() {
    }
    public void doButton(String but) {
    }
    public String[] getButtons() {
        return new String[] {AdrenalinDialogButton.OK, AdrenalinDialogButton.CANCEL};
    }

    private boolean isOK = false;
    private JFrame parent = null;
    private boolean bNoPack = false;

    public void setNoPack(boolean noPack) {
        bNoPack = noPack;
    }

    public void show() {
        JPanel cpane = (JPanel) getContentPane();
        cpane.setLayout(new BorderLayout());
        cpane.add(createContentPane(), BorderLayout.CENTER);
        cpane.add(createButtonPane(), BorderLayout.SOUTH);
        if(!bNoPack) {
            super.pack();
        }
        if (getOwner() != null)
          setLocationRelativeTo(getOwner());
        else
        {
          Dimension ss = getToolkit().getScreenSize();
          Dimension ds = getSize();
          int x = (ss.width - ds.width) / 2;
          int y = (ss.height - ds.height) / 2;
          setLocation(x, y);
        }
        super.show();
    }
}
