package com.borland.dspspb.cbuilder.crmplugin.stewards;

import java.awt.*;
import java.awt.event.*;

import com.borland.dspspb.primetime.crmplugin.opentool.*;
import com.borland.primetime.actions.*;
import com.borland.primetime.editor.*;
import com.borland.primetime.ide.*;
import com.borland.primetime.node.*;
import javax.swing.ImageIcon;
import javax.swing.Action;


public class ActionGoToRequirement extends UpdateAction
{
  private static final String iconUrl = "com/borland/dspspb/resources/images/reqview/goto_requirement.gif"; //NORES
  private static ImageIcon icon =
    new ImageIcon (ActionGoToRequirement.class.getClassLoader().getResource (iconUrl));

  private EditorPane editor = null;
  private String requirementLocator = null;

  public ActionGoToRequirement (EditorPane editor)
	{
    super ("Open Requirement"); //RES ActionGotoRequirement_shortname
    putValue (Action.SMALL_ICON, icon);

    this.editor = editor;
	}

  public void actionPerformed (ActionEvent e)
	{
    if (requirementLocator == null) return;

    NodeStewardsManager.openRequirement (requirementLocator);
	}

  public boolean findRequirementLocator ()
  {
    Node activeNode = Browser.getActiveBrowser ().getActiveNode();

    if (!(activeNode instanceof FileNode)) return false;

    INodeSteward nodeSteward = NodeStewardsManager.findSteward (activeNode);

    if (nodeSteward == null) return false;

    int caretPosition = editor.getCaretPosition();
    int lineNo = editor.getLineNumber(caretPosition);
    int columnNo = editor.getColumnNumber (caretPosition);
    Point point = new Point (columnNo, lineNo);

    requirementLocator = nodeSteward.getRequirementLocator (activeNode, point);

    return (requirementLocator != null && requirementLocator.length() > 0);
  }
}
