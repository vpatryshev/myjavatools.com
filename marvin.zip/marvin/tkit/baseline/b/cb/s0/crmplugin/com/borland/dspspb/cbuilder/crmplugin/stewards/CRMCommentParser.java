package com.borland.dspspb.cbuilder.crmplugin.stewards;

import java.io.*;
import java.awt.*;

import com.borland.cbuilder.ide.*;
import com.borland.cbuilder.parser.*;
import com.borland.cbuilder.util.*;
import java.util.StringTokenizer;

/**
 * Parser to locate CRM Plugin comments
 */
public class CRMCommentParser
  extends CPPCommentParser {

  private String requirementLocator = null;
  private String commentLocator = null;
  private Point point = null;

  private boolean foundComment = false;
  private boolean foundPoint = false;
  private Token commentToken = null;
  private Token pointToken = null;
  private int startPos = -1;
  private int endPos = -1;

  /**
   * Constructs parser to track CRM Plugin comments
   * @param file File
   * @param reader Reader
   */
  public CRMCommentParser(File file, Reader reader) {
    super(file, reader);
    setParserFlags(DONT_RECORD_PREPROC_SCOPES | DONT_RECORD_MACROS | IGNORE_CONDITIONAL);
  }

  /**
   * Invoke this method if you want to find a comment that contains the specified locator
   * @param locator String
   */
  void setCommentLocator(String locator) {
    this.commentLocator = locator;
  }

  /**
   * Return the locator
   * @return String
   */
  public String getCommentLocator() {
    return commentLocator;
  }

  /**
   * Invoke this method if you want to find a comment that contains the specified locator
   * @param locator String
   */
  void setRequirementLocator(String locator) {
    this.requirementLocator = locator;
  }

  /**
   * Return the locator
   * @return String
   */
  public String getRequirementLocator() {
    return requirementLocator;
  }

  /**
   * Invoke this method if you want to find out whether the point contains
   * @param point Point
   */
  void setPoint(Point point) {
    this.point = point;
  }

  /**
   * Updates the parser to keep track of the token we're looking for
   * @param tok Token
   */
  private void setCommentToken(Token tok) {
    foundComment = true;
    commentToken = tok;
  }

  /**
   * Return the token
   * @return Token
   */
  public Token getCommentToken() {
    return commentToken;
  }

  /**
   * Sets the token that matched the specified point
   * @param tok Token
   */
  private void setPointToken(Token tok) {
    pointToken = tok;
    foundPoint = true;
  }

  /**
   * Returns the token that matched the specified point
   * @return Token
   */
  public Token getPointToken() {
    return pointToken;
  }

  public int getStartPos() {
    return startPos;
  }

  public int getEndPos() {
    return endPos;
  }

  /**
   * We override getNextToken and just run through the end of the document.
   * This approach works because comments are dispatched in the background
   * by the underlying parser's preprocessor.
   * @return The next non-comment token in the stream.
   */
  public Token getNextToken() {
    Token tok;
    for (; ; ) {
      tok = getNextToken(true);
      if (tok.kind == EOF) {
        break;
      }
      // If we've found what we're looking for, stop
      if ( ( ( (commentLocator == null) && (requirementLocator == null)) || foundComment) &&
        ( (point == null) || foundPoint)) {
        break;
      }
    }
    return tok;
  }

  /**
   * Returns if a point falls within a token
   * @param tok Token
   * @param point Point
   * @return boolean
   */
  private static boolean pointInToken(Token tok, Point point) {
    return (((point.y > tok.beginLine) || ((point.y == tok.beginLine) && (point.x >= tok.beginColumn))) &&
      ((point.y < tok.endLine) || ((point.y == tok.endLine) && (point.x <= tok.endColumn))));
  }

  /**
   * Routine that handles a comment.
   * We override this routine to eliminate the overhead of keeping track of comment declarations
   * That logic is only necessary for a "parse" that will be used by the Scoper/Folder subsystem
   * @param str Content of comment
   * @param tok Token that contains the comment
   * @param commentType Type of comment, basically BLOCK_COMMENT, START_LINE_COMMENT or LINE_COMMENT
   */
  protected void handleComment(String str, Token tok, int commentType, boolean firstTokenOnLine) {
    /**
     * @todo Come up with a better way to validate the comment up front. Using length of 10
     * is bogus!!! :)
     */
    if ( (commentType == BLOCK_COMMENT) && ( str.length() > 10) && (str.charAt(0) == '*')) {
      if (commentLocator != null) {
        if (getLineContainingTag(str, commentLocator) != null) {
          setCommentToken(tok);
        }
      }
      if (requirementLocator != null) {
        if (getLineContainingTag(str, requirementLocator) != null) {
          setCommentToken(tok);
        }
      }
      if (point != null) {
        if (pointInToken(tok, point)) {
          setPointToken(tok);
          String line = getLineContainingTag(str, null);
          if (line != null) {
            StringTokenizer tokenizer = new StringTokenizer(line, " "); //NORES
            while (tokenizer.hasMoreTokens()) {
              String token = tokenizer.nextToken();
              if (CPPNodeSteward.COMMENT_TAG.equals(token)) {
                if (tokenizer.hasMoreTokens()) {
                  setCommentLocator(tokenizer.nextToken());
                }
              }
              if (CPPNodeSteward.REQUIREMENT_TAG.equals(token)) {
                if (tokenizer.hasMoreTokens()) {
                  setRequirementLocator(tokenizer.nextToken());
                }
              }
            }
          }
        }
      }
    }
  }

  /**
   * Returns a line with the many lines represented by 'str'
   * that contains tags we're looking for
   * @param str String
   * @param locator String
   * @return String
   */
  private String getLineContainingTag(String str, String locator) {
    String[] lines = Util.stringToStringArray(str);
    JavaDocFormatter formatter = new JavaDocFormatter(lines);
    lines = formatter.getUnformattedLines();
    for (int i = 0; i < lines.length; i++) {
      String line = lines[i];
      if (line.indexOf(CPPNodeSteward.COMMENT_TAG) != -1) {
        if ( (locator == null) || line.indexOf(locator) != -1) {
          return line;
        }
      }
      if (line.indexOf(CPPNodeSteward.REQUIREMENT_TAG) != -1) {
        if ( (locator == null) || line.indexOf(locator) != -1) {
          return line;
        }
      }
    }
    return null;
  }

  /**
   * Override from the base class. In raw mode we just want to make sure
   * the location we're interested in does not fall within a preprocessor block
   * @param kind int The preprocessor token kind
   * @param tokenizer IPreprocessorTokens The preprocessor tokenizer
   */
  protected void handlePreprocessor(int kind, IPreprocessorTokens tokenizer) {
    if (point != null) {
      Token start = tokenizer.getStart();
      Token token = start;
      // NOTE: IPreprocessorTokens return NULL at the end, not EOF, but
      //       it does not hurt to be safe here
      while (token.kind != EOF) {
        Token next = tokenizer.getNextToken();
        if (next == null) {
          break;
        }
        token = next;
      }
      token = createToken("PREPROC", start, token); //NORES
      if (pointInToken(token, point)) {
        setPointToken(token);
      }
    }
  }

  /**
   * Converts this object to its string representation
   * @return String
   */
  public String toString() {
    StringBuffer sbuf = new StringBuffer();
    // Are we looking for a particular point
    if (point != null) {

    }
    return sbuf.toString();
  }

  /**
   * Test driver
   * @param args String[]
   */
  public static void main(String[] args) {
    try {
      File file = new File(args[0]);
      Reader reader = new FileReader(file);
      CRMCommentParser parser = new CRMCommentParser(file, reader);
      parser.parse();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }
}
