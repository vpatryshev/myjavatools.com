package com.borland.dspspb.cbuilder.crmplugin;

import java.io.File;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import com.borland.primetime.actions.*;
import com.borland.primetime.ide.*;
import com.borland.primetime.ide.view.ViewManager;
import com.borland.primetime.node.*;
import com.borland.primetime.properties.InfoBooleanProperty;

import com.borland.cbuilder.CBuilderMenu;
import com.borland.cbuilder.node.CParseableFileNode;

import com.borland.dspspb.cbuilder.crmplugin.stewards.CPPNodeSteward;
import com.borland.dspspb.primetime.crmplugin.PluginManager;
import com.borland.dspspb.primetime.crmplugin.actions.*;
import com.borland.dspspb.primetime.crmplugin.management.*;
import com.borland.dspspb.primetime.crmplugin.opentool.*;
import com.borland.dspspb.primetime.crmplugin.resources.ResourceManager;
import com.borland.dspspb.primetime.crmplugin.view.PluginViewFactory;
import com.borland.cbuilder.node.HTMLFileNode;
import com.borland.dspspb.cbuilder.crmplugin.stewards.HtmlNodeSteward;
import com.borland.cbuilder.node.CPPFileNode;

public class Main
{
  private static final InfoBooleanProperty CALIBERRM_ENABLED =
      new InfoBooleanProperty("Tool", "caliberm-enabled");  //NORES

  public static void initOpenTool(byte majorVersion, byte minorVersion)
  {
    String homedirname = new File(System.getProperty("user.dir")).getParent() + File.separator + "lib" + File.separator; //NORES
    FramingManager.getInstance().setHomeDirName(homedirname);

    LightweightNode.registerLightweightNodeClass("Plugin", PluginLWNode.class); //NORES
    LightweightNode.registerLightweightNodeClass("Source", SourceLWNode.class); //NORES

    ViewManager.registerViewFactory (new PluginViewFactory ());

    // Create actions...
    ActionGroup actionGroupCRMPlugin = new ActionGroup
        ("CaliberRM", //RES Main_ActionGroupCRMPlugin_shorttext
        '\0', //NORES
        "Configure CaliberRM plugin", //RES Main_ActionGroupCRMPlugin_longtext
        ResourceManager.getIcon(ResourceManager.Main_ActionGroupCRMPlugin_icon))
    {
      public void update(Browser browser) {
        super.update(browser);
        setEnabled(this.isEnabled() && true /*CALIBERRM_ENABLED.getBoolean()*/ );
      }
    };
    actionGroupCRMPlugin.setPopup (true);
    final UpdateAction actionEditSources = new ActionEditSources ();
    BrowserAction browseractionEditSources = new BrowserAction (
      actionEditSources.getShortText(),
      actionEditSources.getMnemonic(),
      actionEditSources.getLongText(),
      actionEditSources.getSmallIcon())
    {
      public void actionPerformed(Browser browser)
      {
        actionEditSources.actionPerformed(null);
      }
    };
    final UpdateAction actionEditFilters = new ActionEditFilters();
    BrowserAction browseractionEditFilters = new BrowserAction(
      actionEditFilters.getShortText(),
      actionEditFilters.getMnemonic(),
      actionEditFilters.getLongText(),
      actionEditFilters.getSmallIcon())
    {
      public void actionPerformed(Browser browser)
      {
        actionEditSources.actionPerformed(null);
      }
    };
    actionGroupCRMPlugin.add(actionEditSources);
    actionGroupCRMPlugin.add(actionEditFilters);
    CBuilderMenu.GROUP_Tools.add(actionGroupCRMPlugin);


    final BrowserAction ACTION_ACTIVATE_VIEW = new BrowserAction
     ("Open", //RES SourceLWNodeMenu_ActionRun_shorttext
      'O',    //RES SourceLWNodeMenu_ActionRun_mnemonic
      "Open Caliber connection", //RES SourceLWNodeMenu_ActionRun_longtext
      ResourceManager.getIcon(ResourceManager.SourceLWNodeMenu_ActionRun_icon))
    {
      public void actionPerformed(Browser browser)
      {
        SwingUtilities.invokeLater(new Runnable()
        {
          public void run()
          {
            Node selectedNode = Browser.getActiveBrowser().getProjectView().getSelectedNode();
            if (selectedNode == null || !(selectedNode instanceof SourceLWNode))
              return;
            SourceLWNode sourceLWNode = (SourceLWNode)selectedNode;
            Source source = sourceLWNode.getSource();
            PluginManager.getInstance().openView(source);
          }
        });
      }
    };
    ProjectView.registerContextActionProvider(new ContextActionProvider()
    {
      public Action getContextAction(Browser browser, Node[] nodeArray)
      {
        if (nodeArray.length == 1 && nodeArray[0] instanceof SourceLWNode)
        {
          SourceLWNode sourceLWNode = (SourceLWNode)nodeArray[0];
          if (sourceLWNode.getSource() != null)
            return ACTION_ACTIVATE_VIEW;
        }
        return null;
      }
    });

    final BrowserAction ACTION_REMOVE_SOURCE = new BrowserAction
     ("Remove", //RES ActionRemoveSource_shorttext
      '0', //RES ActionRemoveSource_mnemonic
      "Remove", //RES ActionRemoveSource_longtext
      ResourceManager.getIcon(ResourceManager.SourceLWNodeMenu_ActionRemove_icon))
    {
      public void actionPerformed(Browser browser)
      {
        SwingUtilities.invokeLater(new Runnable()
        {
          public void run()
          {
            Node selectedNode = Browser.getActiveBrowser().getProjectView().getSelectedNode();
            if (selectedNode == null || !(selectedNode instanceof SourceLWNode))
              return;
            SourceLWNode sourceLWNode = (SourceLWNode)selectedNode;
            PluginLWNode pluginLWNode = (PluginLWNode)sourceLWNode.getParent();
            sourceLWNode.setParent(null);
            if (!pluginLWNode.hasChildren())
            {
              pluginLWNode.setParent(null);
            }
          }
        });
      }
    };
    ProjectView.registerContextActionProvider(new ContextActionProvider()
    {
      public Action getContextAction(Browser browser, Node[] nodeArray)
      {
        if (nodeArray.length == 1 && nodeArray[0] instanceof SourceLWNode)
          return ACTION_REMOVE_SOURCE;
        else
          return null;
      }
    });

    final Browser browser = Browser.getActiveBrowser();
    browser.addStaticBrowserListener(new BrowserAdapter()
    {
      public void browserProjectActivated(Browser browser, Project project)
      {
        modifyProjectTreeMouseListeners(Browser.getActiveBrowser(), true);
        IDEProject ideProject = FramingManager.getInstance().getActiveIDEProject();
        if (ideProject == null)
          return;
        ideProject.checkSources();
      }

      public void browserProjectClosed(Browser browser, Project project)
      {
        modifyProjectTreeMouseListeners(Browser.getActiveBrowser(), false);
      }

      public void browserClosing(Browser browser)
      {
        // on exit from JBuilder, browserProjectClosed is not called...
        modifyProjectTreeMouseListeners(Browser.getActiveBrowser(), false);
        // close all connections
        Source[] sources = SourceManager.getInstance().getSources();
        for (int i = 0; i < sources.length; i++)
        {
          sources[i].setSession(null);
        }
      }

    });
    modifyProjectTreeMouseListeners(Browser.getActiveBrowser(), true);

    NodeStewardsManager.registerSteward(CPPFileNode.class, (INodeSteward)new CPPNodeSteward());
    NodeStewardsManager.registerSteward(CParseableFileNode.class, (INodeSteward)new CPPNodeSteward());
    NodeStewardsManager.registerSteward(HTMLFileNode.class, (INodeSteward)new HtmlNodeSteward());
  }

  private static MouseListener m_mlProjectTreeClick = new MouseListener()
  {
    public void mouseClicked(MouseEvent e)
    {
      if (e.getClickCount() != 2)
        return;
      ProjectTree projectTree = (ProjectTree)e.getComponent();
      Node selectedNode = projectTree.getSelectedNode();
      if (selectedNode == null || !(selectedNode instanceof SourceLWNode))
        return;
      Node clickedNode = projectTree.locationToNode(e.getPoint());
      if (clickedNode == null)
        return;
      if (!selectedNode.equals(clickedNode))
        return;
//      int row = projectTree.getRowForLocation(e.getX(), e.getY());
//      if (row != -1)
//      {
//        TreePath selPath = projectTree.getPathForLocation(e.getX(), e.getY());
//        Node node = ((ProjectTree.ProjectTreeNode)selPath.getLastPathComponent()).getNode();
//        if (e.getClickCount() == 2)
//          activateNode(node);
//      }
      SourceLWNode sourceLWNode = (SourceLWNode)selectedNode;
      PluginManager.getInstance().openView(sourceLWNode.getSource());
    }

    public void mouseEntered(MouseEvent e)
    {
    }

    public void mouseExited(MouseEvent e)
    {
    }

    public void mousePressed(MouseEvent e)
    {
    }

    public void mouseReleased(MouseEvent e)
    {
    }
  };

  static private void modifyProjectTreeMouseListeners(Component component, boolean bAdd)
  {
    if (component instanceof Container)
    {
      Component[] components = ((Container)component).getComponents();
      for (int i = 0; i < components.length; i++)
      {
        if (components[i] instanceof ProjectTree)
        {
          ProjectTree projectTree = (ProjectTree)components[i];
          if (bAdd)
          {
            MouseListener[] mouseListeners = projectTree.getMouseListeners();
            if (mouseListeners != null)
            {
              for (int j = 0; j < mouseListeners.length; j++)
              {
                if (mouseListeners[j].equals(m_mlProjectTreeClick))
                {
                  return;
                }
              }
            }
            projectTree.addMouseListener(m_mlProjectTreeClick);
          }
          else
          {
            components[i].removeMouseListener(m_mlProjectTreeClick);
          }
        }
        modifyProjectTreeMouseListeners(components[i], bAdd);
      }
    }
  }
}
