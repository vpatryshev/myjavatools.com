package com.borland.dspspb.primetime.crmplugin.opentool;

import javax.swing.Icon;

import com.borland.dspspb.primetime.crmplugin.management.*;
import com.borland.dspspb.primetime.crmplugin.resources.ResourceManager;
import com.borland.dspspb.primetime.crmplugin.resources.ResourceManager;
import com.borland.primetime.node.*;

public class SourceLWNode extends LightweightNode
{
  public static final String PROPERTY_CATEGORY = "CaliberRM"; //NORES
  public static final String PROPERTY_NAME = "Source"; //NORES

  public SourceLWNode(Project project, Node node, String name)
  {
    super(project, node, null);
  }

  public Source getSource()
  {
    String nodeSourceId = getProperty(SourceLWNode.PROPERTY_CATEGORY, SourceLWNode.PROPERTY_NAME, null);
    if (nodeSourceId == null)
      return null;
    return SourceManager.getInstance().findSource(nodeSourceId);
  }

  public String getName()
  {
    Source source = getSource();
    if (source == null)
      return null;
    return source.getName();
  }

  public String getDisplayName()
  {
    return getName();
  }

  public Icon getDisplayIcon()
  {
    return ResourceManager.getIcon(ResourceManager.SourceLWNode_icon);
  }
}
