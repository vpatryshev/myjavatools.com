package com.borland.dspspb.primetime.crmplugin.gui.swingcomponents;

import javax.swing.JTextField;
import javax.swing.JComponent;

public class SwingText extends SwingComponent
{
   private JTextField textField = new JTextField();

   public SwingText( String name,String displayName,Object value )
   {
    super ( name,displayName );
    setValue(value);
   }

   public Object getValue ()
   {
     return textField.getText();
   }

   public void setValue(Object value )
   {
      super.setValue(value);
    textField.setText( (String)value );
   }


   public void setEditable( boolean editable)
   {
     textField.setEditable( editable );
   }

   public JComponent getMainComponent()
   {
      textField.setText( (String)getValue() );
      return textField;
   }
}
