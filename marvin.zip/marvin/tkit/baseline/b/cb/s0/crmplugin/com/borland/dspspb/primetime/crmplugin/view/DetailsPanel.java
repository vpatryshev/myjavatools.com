package com.borland.dspspb.primetime.crmplugin.view;

import javax.swing.ImageIcon;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;

import com.borland.dspspb.primetime.crmplugin.view.DescriptionPanel;
import com.borland.dspspb.primetime.crmplugin.view.TracesPanel;
import com.borland.dspspb.primetime.crmplugin.resources.ResourceManager;
import com.borland.dspspb.primetime.crmplugin.resources.ResourceManager;

public class DetailsPanel extends JTabbedPane
{
  private JScrollPane descScrollPane = null;
  private DescriptionPanel descPanel = null;
  private TracesPanel tracesPanel = null;
  private AttributesPanel attributesPanel = null;

  private static String titleDescription = null;
  private static ImageIcon iconDescription = null;
  private static String titleTraceability = null;
  private static ImageIcon iconTraceability = null;
  private static String titleAttributes = null;
  private static ImageIcon iconAttributes = null;
  private static String titleCommentTrace = null;
  private static ImageIcon iconCommenttrace = null;

  static
  {
    titleDescription = "Description"; //RES DetailsPanel_Description_title
    iconDescription = ResourceManager.getIcon (ResourceManager.DetailsPanel_Description_icon);
    titleTraceability = "Comment Traces"; //RES DetailsPanel_Traces_title
    iconTraceability = ResourceManager.getIcon (ResourceManager.DetailsPanel_Traceability_icon);
    titleAttributes = "User Defined Attributes"; //RES DetailsPanel_UserAttributes_title
    iconAttributes = ResourceManager.getIcon (ResourceManager.DetailsPanel_UserAttributes_icon);
  }

  public DetailsPanel ()
  {
    super (JTabbedPane.TOP);

    descPanel = new DescriptionPanel ();
    descScrollPane = new JScrollPane (descPanel);
    tracesPanel = new TracesPanel ();
    attributesPanel = new AttributesPanel ();

    this.addTab (titleDescription, iconDescription, descScrollPane);
    this.addTab (titleAttributes, iconAttributes, attributesPanel);
    this.addTab (titleTraceability, iconTraceability, tracesPanel);
  }

  public DescriptionPanel getDescriptionPanel()
  {
    return descPanel;
  }

  public TracesPanel getTracesPanel()
  {
    return tracesPanel;
  }

  public AttributesPanel getAttributesPanel()
  {
    return attributesPanel;
  }
}

