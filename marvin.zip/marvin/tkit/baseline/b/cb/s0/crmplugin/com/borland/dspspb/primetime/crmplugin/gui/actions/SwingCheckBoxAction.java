package com.borland.dspspb.primetime.crmplugin.gui.actions;

import javax.swing.JMenuItem;
import javax.swing.JCheckBoxMenuItem;

public abstract class SwingCheckBoxAction extends SwingAction {
    public SwingCheckBoxAction(String name) {
        super(name);
    }

    public boolean isChecked() {
        return false;
    }

}
