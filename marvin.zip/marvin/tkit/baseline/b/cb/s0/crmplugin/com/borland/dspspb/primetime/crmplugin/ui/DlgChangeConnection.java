package com.borland.dspspb.primetime.crmplugin.ui;

import com.borland.dspspb.primetime.crmplugin.dialog.PluginDialog;
import com.borland.dspspb.primetime.crmplugin.management.Source;
import com.borland.dspspb.primetime.crmplugin.management.SourceManager;
import com.borland.primetime.help.PrimetimeHelp;

import javax.swing.*;
import java.awt.*;


public class DlgChangeConnection extends PluginDialog
{
  private JPanel contentPanel = null;
  private JLabel lblConnection = null;
  private JComboBox cbConnection = null;

  private Source selectedSource = null;

  public DlgChangeConnection (Component owner, Source selectedSource)
  {
    super (owner, "Change Connection"); //RES DlgChangeConnection_title
    setHelpTopic (PrimetimeHelp.createTopic (PrimetimeHelp.BOOK_UserGuide, "ui/dialogs/dlgcaliberchangeconnection.html")); //NORES

    this.selectedSource = selectedSource;
  }

  public JComponent getContentUI ()
  {
    contentPanel = new JPanel (new GridBagLayout ());

    lblConnection = new JLabel ("Connection:"); //RES DlgChangeConnection_Connection_text

    cbConnection = new JComboBox (SourceManager.getInstance ().getSources ());
    cbConnection.setSelectedItem (selectedSource);

    if (cbConnection.getSelectedIndex () == -1) cbConnection.setSelectedIndex (0);

    GridBagConstraints constraints = new GridBagConstraints ();

    constraints.anchor = GridBagConstraints.NORTHWEST;

		constraints.anchor = GridBagConstraints.NORTHWEST;
		constraints.gridx = 0;
		constraints.gridy = 0;
		constraints.weightx = 0.0;
		constraints.weighty = 1.0;
		constraints.fill = GridBagConstraints.NONE;
		constraints.insets = new Insets (3, 0, 0, 5);
		contentPanel.add (lblConnection, constraints);

		constraints.gridx = 1;
		constraints.gridy = 0;
		constraints.weightx = 1.0;
		constraints.weighty = 1.0;
		constraints.insets = new Insets (0, 0, 0, 0);;
		constraints.fill = GridBagConstraints.HORIZONTAL;
		contentPanel.add (cbConnection, constraints);

    return contentPanel;
  }

  public Source getResult ()
  {
    return (Source) cbConnection.getSelectedItem ();
  }
}
