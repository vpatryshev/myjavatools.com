package com.borland.dspspb.primetime.crmplugin.actions;

import java.awt.event.*;
import javax.swing.*;

import com.borland.dspspb.primetime.crmplugin.management.*;
import com.borland.dspspb.primetime.crmplugin.resources.*;
import com.borland.dspspb.primetime.crmplugin.view.*;
import com.borland.dspspb.primetime.crmplugin.ui.DlgChangeConnection;

public class ActionSelectSource extends PluginUpdateAction
{
  public ActionSelectSource ()
  {
    super
      ("Change Connection...", //RES ActionSelectSource_shorttext
       "Change current connection to Caliber server", //RES ActionSelectSource_longtext
       ResourceManager.ActionSelectSource_icon);
  }

  public void update (Object object)
  {
    setEnabled(SourceManager.getInstance().getSources().length > 0);
  }

  public void actionPerformed(ActionEvent e)
  {
    PluginView pluginView = (PluginView) e.getSource();

    Source currentSource = pluginView.getSource ();

    DlgChangeConnection dlgChangeConnection = new DlgChangeConnection (pluginView, currentSource);

    if (dlgChangeConnection.showDialog ())
    {
      Source source = dlgChangeConnection.getResult ();

      if (source != null)
      {
        pluginView.runSource (source);
      }
    }
  }
}
