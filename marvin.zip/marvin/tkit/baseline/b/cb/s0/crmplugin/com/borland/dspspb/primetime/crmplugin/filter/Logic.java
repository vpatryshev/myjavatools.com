package com.borland.dspspb.primetime.crmplugin.filter;

public class Logic
{
  public static final String NOP     = "";       //NORES
  public static final String NOT     = "NOT";    //NORES
  public static final String AND     = "AND";    //NORES
  public static final String OR      = "OR";     //NORES
  public static final String ANDNOT  = "ANDNOT"; //NORES
  public static final String ORNOT   = "ORNOT";  //NORES

  private static final Logic LOGICNOP     = new Logic(NOP);
  private static final Logic LOGICNOT     = new Logic(NOT);
  private static final Logic LOGICAND     = new Logic(AND);
  private static final Logic LOGICOR      = new Logic(OR);
  private static final Logic LOGICANDNOT  = new Logic(ANDNOT);
  private static final Logic LOGICORNOT   = new Logic(ORNOT);

  private String m_code = NOP;

  public Logic()
  {
  }

  public Logic(String code)
  {
    this.m_code = code;
  }

  public String getCode()
  {
    return m_code;
  }

  public void setCode(String code)
  {
    this.m_code = code;
  }

//------------------------------------------------------------------------------

  public String getName()
  {
    return m_code;
  }

  public static Logic getLogic(String code)
  {
    if (code != null)
    {
      if (code.equals(Logic.NOP))
        return LOGICNOP;
      if (code.equals(Logic.NOT))
        return LOGICNOT;
      if (code.equals(Logic.AND))
        return LOGICAND;
      if (code.equals(Logic.OR))
        return LOGICOR;
      if (code.equals(Logic.ANDNOT))
        return LOGICANDNOT;
      if (code.equals(Logic.ORNOT))
        return LOGICORNOT;
    }
    return LOGICNOP;
  }

  public static Logic[] getLogics1()
  {
    return new Logic[] {LOGICNOP, LOGICNOT};
  }

  public static Logic[] getLogics2()
  {
    return new Logic[] {LOGICAND, LOGICANDNOT, LOGICOR, LOGICORNOT};
  }

  public String toString()
  {
    return getName();
  }
}
