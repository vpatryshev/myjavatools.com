package com.borland.dspspb.primetime.crmplugin.view.rvtreetable;

import java.awt.*;
import javax.swing.*;

import com.borland.dspspb.primetime.crmplugin.gui.treetable.TableNodeAdapter;
import com.borland.dspspb.primetime.crmplugin.management.Source;
import com.borland.dspspb.primetime.crmplugin.resources.ResourceManager;
import com.starbase.caliber.Session;

public class SourceNode extends TableNodeAdapter
{
  private static Color reqBackground				= new Color (213, 230, 234);
  private static Color reqForeground = Color.black;

  private static ImageIcon iconConnected = null;
  private static ImageIcon iconDisconnected = null;

  private Source m_source = null;

  // Load icons
  static
  {
    iconConnected = ResourceManager.getIcon (ResourceManager.SourceNode_Connected_icon);
    iconDisconnected = ResourceManager.getIcon (ResourceManager.SourceNode_Disconnected_icon);
  }

  public SourceNode(Object data)
  {
    super(data);
    if (data != null && (data instanceof Source))
      m_source = (Source)data;
  }

  public Color getBackground()
  {
    return reqBackground;
  }

  public Color getForeground()
  {
    return reqForeground;
  }

  public int getFontStyle ()
  {
    return Font.BOLD;
  }

  public Icon getIcon(boolean bExpanded)
  {
    return (getSession() != null ? iconConnected : iconDisconnected);
  }

  public String getText()
  {
    Source source = (Source)getUserObject();
    String text = source.getName(); // + " [" + source.getServer().toUpperCase() + "]";
    if (getSession() == null)
      text += "(not connected)"; //RES SourceNode_Notconnected_text
    return text;
  }

  public Source getSource()
  {
    return m_source;
  }

  public Session getSession()
  {
    if (getSource() == null)
      return null;
    return getSource().getSession();
  }
}
