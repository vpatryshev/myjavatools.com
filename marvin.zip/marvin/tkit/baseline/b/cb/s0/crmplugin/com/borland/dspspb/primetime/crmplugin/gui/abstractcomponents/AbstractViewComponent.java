package com.borland.dspspb.primetime.crmplugin.gui.abstractcomponents;

import java.util.*;
import com.borland.dspspb.primetime.crmplugin.gui.abstractcomponents.listeners.*;

public abstract class AbstractViewComponent
{
   protected String name;
   private int order;
   private AbstractViewContainer container;
   protected  Vector values = new Vector();
   protected boolean editable=true;
   protected boolean mandatory=false;
   private Vector componentListeners = new Vector();

  public void setValue( Object value )
   {
      if ( values==null )
      values=new Vector();
      values.addElement (value);

   }

  public void removeValue( Object value )
  {
       if ( values!=null ) values.remove( value );
  }


 public void addUpdateComponentListener( UpdateComponentListener listener )
 {
    componentListeners.add ( listener );
 }

 public Vector getListeners()
 {
    return componentListeners;
 }

  public void clearValues()
  {
     values = new Vector();
  }

    public void setEditable(boolean editable )
    {
      this.editable=editable;
    }

    public boolean isEditable()
    {
       return editable;
    }

     public void setMandatory(boolean mandatory )
     {
        this.mandatory=mandatory;
     }

      public boolean isMandatory()
      {
         return mandatory;
      }


   public Object getValue ()
   {
       try
       {
          return values.lastElement();
       }
       catch (Exception e)
       {
         return null;
       }
   }

   public void setValues( Collection valuesList )
   {
      this.values= new Vector();
      addValues(valuesList);
   }

   public void addValues( Collection valuesList )
   {
     values.addAll(valuesList);
   }

   public Vector getValues()
   {
     return values;
   }

   public void setContainer(AbstractViewContainer cont)
   {
      this.container = cont;
   }

   public AbstractViewContainer getContainer()
   {
      return container;
   }

   public String getName()
   {
      return name;
   }
   public void setName(String name )
   {
     this.name=name;
   }

   public abstract Object getUI();

   public void setOrder(int order)
   {
     this.order=order;
   }

   public int getOrder()
   {
      return order;
   }

   public String toString()
   {
     return "Abstract Component--name:"+getName()+" values:"+values;
   }

}
