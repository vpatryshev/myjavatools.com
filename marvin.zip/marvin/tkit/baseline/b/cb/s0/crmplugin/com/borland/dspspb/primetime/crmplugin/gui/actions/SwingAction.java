package com.borland.dspspb.primetime.crmplugin.gui.actions;

import javax.swing.JMenuItem;
import javax.swing.JComponent;
import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import java.awt.event.ActionEvent;
import javax.swing.*;
import java.awt.event.*;

public abstract class SwingAction extends AbstractAction {
    private String name;
    private ImageIcon icon;
    private int mnemonic = 0;
    private String tooltip;

    private JMenuItem menuItem = null;

    public SwingAction(String name) {
        super(name);
        this.name = name;
    }

    public void actionPerformed(ActionEvent evt) {
    }

    public void setup(String iconURL, int mnemonic, int mask, String tooltip) {
        this.mnemonic = mnemonic;
        //((JComponent)WindowManager.getInstance().getMainFrame().getContentPane()).registerKeyboardAction(SwingAction.this, KeyStroke.getKeyStroke(mnemonic, mask),JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
        putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(mnemonic, mask));
        this.tooltip = tooltip;
        if(tooltip != null) {
            super.putValue(super.SHORT_DESCRIPTION, tooltip);
        }
        if(iconURL != null) {
            this.icon = new ImageIcon(getClass().getClassLoader().getResource(iconURL));
            super.putValue(super.SMALL_ICON, icon);
        }
    }

    public String getActionName() { return name; }
    public boolean isEnabled() { return true; }
}


