package com.borland.dspspb.primetime.crmplugin.util.smartxml;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;

import java.io.*;

import org.w3c.dom.Element;

public class DomManager {

  private static DomManager instance;
  private DomManager() {}
  public static DomManager getInstance() {
    if(instance == null) {
      instance = new DomManager();
      instance.init();
    }
    return instance;
  }
/////////////////

  private DocumentBuilder builder;

  public void init() {
    try {
      builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
/*
      Thread.currentThread().setContextClassLoader(getClass().getClassLoader());
      builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
*/
/*
      DocumentBuilderFactory builderFactory = new org.apache.crimson.jaxp.DocumentBuilderFactoryImpl();
      builder = builderFactory.newDocumentBuilder();
*/
    }catch(Exception exc) {
      exc.printStackTrace();
    }
  }

  public DocumentBuilder getDocumentBuilder() { return builder; }

  public Document readXML(InputStream is) {
    try {
      return builder.parse(is);
    }catch(Exception exc) {
      exc.printStackTrace();
      return builder.newDocument();
    }
  }

  public Document fromLiteralXML(String literalXML) {
    ByteArrayInputStream bais = new ByteArrayInputStream(literalXML.getBytes());
    return readXML(bais);
  }

    public void write(Document doc, OutputStream os) {
        XMLWriter.getInstance().write(doc, os);
    }
    public String toLiteralXml(Document doc) {
        return XMLWriter.getInstance().toLiteralXML(doc);
    }

  public Document newDocument() { return builder.newDocument(); }

    public Convertable readConvertable(InputStream is) {
        Document doc = readXML(is);
        return DomXML.toConvertable(doc.getDocumentElement());
    }

    public void writeConvertable(OutputStream os, Convertable c) {
        Document doc = getDocumentBuilder().newDocument();
        Element elem = DomXML.fromConvertable(doc, "root", c); //NORES
        doc.appendChild(elem);
        XMLWriter.getInstance().write(doc, os);
    }

    public Convertable readConvertableFromString(String literalXML) {
        ByteArrayInputStream bais = new ByteArrayInputStream(literalXML.getBytes());
        return readConvertable(bais);
    }

    public String writeConvertableToString(Convertable c) {
        Document doc = getDocumentBuilder().newDocument();
        Element elem = DomXML.fromConvertable(doc, "root", c); //NORES
        doc.appendChild(elem);
        return XMLWriter.getInstance().toLiteralXML(doc);
    }

    public void writeConvertable ( String fileName,Convertable c){
        File file = new File(fileName);
        try {
          FileOutputStream fop = new FileOutputStream(file);
           writeConvertable (fop, c);
           fop.close();
        } catch ( Exception e ){
            e.printStackTrace();
        }
    }
    public Convertable readConvertable ( String fileName ){
        File file = new File(fileName);
        try {
          FileInputStream fip = new FileInputStream(file);
           Convertable c =  readConvertable (fip);
           fip.close();
           return c;
        } catch ( Exception e ){
            e.printStackTrace();
            return null;
        }
    }


}
