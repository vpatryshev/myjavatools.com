package com.borland.dspspb.primetime.crmplugin.actions;

import java.awt.event.*;

import com.borland.dspspb.primetime.crmplugin.resources.*;
import com.borland.dspspb.primetime.crmplugin.view.*;
import com.borland.dspspb.primetime.crmplugin.view.rvtreetable.*;
import com.borland.dspspb.primetime.crmplugin.gui.treetable.*;

// Update single (selected) comment
public class ActionCheckForUpdate extends PluginUpdateAction
{
  public ActionCheckForUpdate ()
  {
    super
      ("Update All Comments", //RES ActionCheckForUpdate_shorttext
       "Updates all requirement comments associated with Caliber project", //RES ActionCheckForUpdate_longtext
       ResourceManager.ActionCheckForUpdate_icon);
  }

  public void actionPerformed (ActionEvent e)
  {
    PluginView pluginView = (PluginView) e.getSource();
    RVTreeTable table = pluginView.getTable();

    table.initAllRequirements();

    new TreeIterator ().traverse (table.getRootNode(), new CommentUpdater ());
    table.updateUI ();

    if (table.getSelectedNode() != null)
    {
      table.updateTracePanel (table.getSelectedNode());
    }
  }

// -----------------------------------------------------------------------------

  private class CommentUpdater implements INodeProcessor
  {
    public boolean accept (TableNodeAdapter node)
    {
      return (node instanceof RequirementNode);
    }

    public boolean process (TableNodeAdapter node)
    {
      RequirementNode requirementNode = (RequirementNode) node;
      requirementNode.updateTraces ();

      return true;
    }
  }
}
