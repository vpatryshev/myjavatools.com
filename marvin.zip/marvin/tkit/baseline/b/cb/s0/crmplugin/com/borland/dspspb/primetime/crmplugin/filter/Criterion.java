package com.borland.dspspb.primetime.crmplugin.filter;

import java.util.*;

import com.borland.dspspb.primetime.crmplugin.management.*;
import com.borland.dspspb.primetime.crmplugin.util.smartxml.*;
import com.starbase.caliber.*;

public class Criterion implements Convertable
{
  private static FilterManager filterManager = FilterManager.getInstance();

  private String m_logicCode;
  private String m_fieldId;
  private String m_checkCode;
  private Vector m_values = new Vector();

  public Criterion()
  {
  }

  public Criterion(String logicCode, String fieldId, String checkCode, Vector values)
  {
    m_logicCode = logicCode;
    m_fieldId = fieldId;
    m_checkCode = checkCode;
    m_values.addAll(values);
  }

  public String getLogicCode()
  {
    return m_logicCode;
  }

  public void setLogicCode(String logicCode)
  {
    m_logicCode = logicCode;
  }

  public String getFieldId()
  {
    return m_fieldId;
  }

  public void setFieldId(String fieldId)
  {
    m_fieldId = fieldId;
  }

  public String getCheckCode()
  {
    return m_checkCode;
  }

  public void setCheckCode(String checkCode)
  {
    m_checkCode = checkCode;
  }

  public String[] getValues()
  {
    return (String[])m_values.toArray(new String[m_values.size()]);
  }

  public void setValues(String[] values)
  {
    m_values.clear();
    for (int i = 0; i < values.length; i++)
    {
      m_values.add(values[i]);
    }
  }

//------------------------------------------------------------------------------

  public Logic getLogic()
  {
    return Logic.getLogic(m_logicCode);
  }

  public Field getField()
  {
    return FilterManager.getInstance().getField(m_fieldId);
  }

  public Check getCheck()
  {
    return Check.getCheck(m_checkCode);
  }

//------------------------------------------------------------------------------

  private Vector getCurrentValues()
  {
    Vector currentValues = new Vector();
    for (int i = 0; i < m_values.size(); i++)
    {
      if (m_values.get(i) instanceof String)
      {
        if (m_values.get(i).equals(Filter.CURRENT_USER))
        {
          currentValues.add(System.getProperty("user.name")); //NORES
          continue;
        }
        else if (m_values.get(i).equals(Filter.CURRENT_DATE))
        {
          Date currentDate = FilterManager.adjustDate(Calendar.getInstance().getTime());
          currentValues.add("" + currentDate.getTime()); //NORES
          continue;
        }
      }
      currentValues.add(m_values.get(i));
    }
    return currentValues;
  }

  public boolean check(Requirement requirement)
  {
    boolean bResult = false;
    try
    {
      String id = getField().getId();
      String value = CaliberManager.getRequirementField(requirement, id);
      if (getCheck().getCode().equals(Check.EXISTS))
      {
        bResult = (value != null);
        return bResult;
      }
      if (value == null)
        return bResult;
      if (m_values.size() == 0)
        return bResult;
      String values0 = (String)(String)m_values.get(0);
      if (getCheck().getCode().equals(Check.EQ))
      {
         bResult = value.equals(values0);
      }
      else if (getCheck().getCode().equals(Check.ONEOF))
      {
        bResult = m_values.contains(value);
        return bResult;
      }
      else if (getCheck().getCode().equals(Check.CONTAINS))
      {
        bResult = (value.indexOf(values0) != -1);
        return bResult;
      }
      else if (getCheck().getCode().equals(Check.LT))
      {
        bResult = (value.compareTo(values0) < 0);
        return bResult;
      }
      else if (getCheck().getCode().equals(Check.LE))
      {
        bResult = (value.compareTo(values0) <= 0);
        return bResult;
      }
      else if (getCheck().getCode().equals(Check.GT))
      {
        bResult = (value.compareTo(values0) > 0);
        return bResult;
      }
      else if (getCheck().getCode().equals(Check.GE))
      {
        bResult = (value.compareTo(values0) >= 0);
        return bResult;
      }
      if (m_values.size() < 2)
        return bResult;
      String values1 = (String)m_values.get(1);
      if (getCheck().getCode().equals(Check.BETWEEN))
      {
        bResult = (((value.compareTo(values0) > 0) && (value.compareTo(values1) < 0)) ||
                   ((value.compareTo(values0) < 0) && (value.compareTo(values1) > 0)));
      }
    }
    catch (Exception e)
    {
    }
    return bResult;
  }

  private String toString(boolean bFormat)
  {
    String result = ""; //NORES
    if (!getLogicCode().equals(Logic.NOP))
      result = getLogic().toString() + " "; //NORES
    result += getField().toString()+ " " + getCheck().toString(); //NORES
    String type = getField().getType();
    for (int i = 0; i < m_values.size(); i++)
    {
      if (bFormat)
        result += " " + filterManager.formatValue(m_values.get(i).toString(), type); //NORES
      else
        result += " " + m_values.get(i).toString(); //NORES
      if (i != m_values.size() - 1)
        result += ","; //NORES
    }
    return result;
  }

  public String toString()
  {
    return toString(true);
  }
}
