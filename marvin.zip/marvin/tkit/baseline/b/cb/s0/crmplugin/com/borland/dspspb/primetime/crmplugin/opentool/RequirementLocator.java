package com.borland.dspspb.primetime.crmplugin.opentool;
import java.io.Serializable;

public class RequirementLocator implements Serializable
{
  private String [] locatorFields = null;
  private static final int FIELDS_SIZE = 4;
  public static final String FIELD_DELIMITER = ":"; //NORES


  public RequirementLocator (String server, String projectId, String requirementId, String version)
  {
    locatorFields = new String [FIELDS_SIZE];

    locatorFields [0] = server;
    locatorFields [1] = projectId;
    locatorFields [2] = requirementId;
    locatorFields [3] = version;
  }

  public RequirementLocator (String requirementLocator)
  {
    locatorFields = requirementLocator.split (FIELD_DELIMITER, FIELDS_SIZE);
  }

  public String getServer ()
  {
    return locatorFields [0];
  }

  public String getProjectId ()
  {
    return locatorFields [1];
  }

  public String getRequirementId ()
  {
    return locatorFields [2];
  }

  public String getVersion ()
  {
    return locatorFields [3];
  }

  public String toString ()
  {
    if (locatorFields == null) return null;

    StringBuffer buffer = new StringBuffer ();

    for (int i = 0; i < locatorFields.length; i++)
    {
      buffer.append(locatorFields [i]);
      buffer.append (FIELD_DELIMITER);
    }

    buffer.deleteCharAt (buffer.length() - 1);

    return buffer.toString();
  }
}
