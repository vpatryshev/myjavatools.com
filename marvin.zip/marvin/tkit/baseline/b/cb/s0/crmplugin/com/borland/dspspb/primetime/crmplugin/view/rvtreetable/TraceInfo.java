package com.borland.dspspb.primetime.crmplugin.view.rvtreetable;

import javax.swing.*;

import com.borland.dspspb.primetime.crmplugin.opentool.*;
import com.starbase.caliber.*;
import com.starbase.caliber.external.xgeneric.*;

public class TraceInfo
{
  private File m_file = null;
  private int m_status = CommentStatus.STATUS_UNKNOWN;
  private RequirementNode requirementNode = null;
  private Trace caliberTrace = null;

  public TraceInfo (RequirementNode requirementNode, Trace caliberTrace)
  {
    this.requirementNode = requirementNode;
    this.caliberTrace = caliberTrace;
  }

  public RequirementNode getRequirementNode ()
  {
    return requirementNode;
  }

  public Trace getCaliberTrace ()
  {
    return caliberTrace;
  }

  public File getTraceObject()
  {
    return m_file;
  }

  public void setTraceObject(File file)
  {
    m_file = file;
  }

  public int getStatus()
  {
    return m_status;
  }

  public Icon getIcon ()
  {
    INodeSteward steward = NodeStewardsManager.findSteward (m_file.getName());
    return (steward == null ? null : steward.getIcon ());
  }


  public void setStatus(int status)
  {
    m_status = status;
  }
}
