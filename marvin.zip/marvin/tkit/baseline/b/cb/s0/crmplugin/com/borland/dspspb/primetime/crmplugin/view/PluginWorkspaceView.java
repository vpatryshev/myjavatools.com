package com.borland.dspspb.primetime.crmplugin.view;

import java.beans.*;

import javax.swing.*;

import com.borland.dspspb.primetime.crmplugin.resources.*;
import com.borland.primetime.ide.view.*;

public class PluginWorkspaceView implements View
{
  private PluginView pluginView = null;
  private String title = "CaliberRM View"; //RES PLuginWorkspaceView_title

  private static ImageIcon icon =
    ResourceManager.getIcon (ResourceManager.PluginLWNode_icon);

  public PluginWorkspaceView ()
  {
    pluginView = new PluginView ();
    pluginView.init ();
  }

  public void removePropertyChangeListener (PropertyChangeListener propertyChangeListener)
  {
  }

  public void addPropertyChangeListener (PropertyChangeListener propertyChangeListener)
  {
  }

  public void release ()
  {
  }

  public JComponent getContent ()
  {
    return pluginView;
  }

  public String getOrientation ()
  {
    return View.HORIZONTAL_ORIENTATION;
  }

  public Icon getIcon ()
  {
    return icon;
  }

  public String getDescription ()
  {
    return "CaliberRM Plugin"; //RES PLuginWorkspaceView_description
  }

  public String getTitle ()
  {
    return title;
  }

  public ViewType getViewType ()
  {
    return new PluginViewType ();
  }

// -----------------------------------------------------------------------------

  public void setTitle (String title)
  {
    this.title = title;
  }
}
