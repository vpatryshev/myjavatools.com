package com.borland.dspspb.primetime.crmplugin.view;

import java.util.*;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.*;

import com.borland.dspspb.primetime.crmplugin.gui.treetable.*;
import com.borland.dspspb.primetime.crmplugin.view.rvtreetable.*;
import com.borland.dspspb.primetime.crmplugin.opentool.CommentStatus;

public class TraceTable extends JTable
{
  private Vector data = null;

	private static String [] columnNames = new String []
	{
		"Type", //RES TraceTable_Type_field
    "Location", //RES TraceTable_Location_field
    "Status" //RES TraceTable_Status_field
	};

  public TraceTable (Vector data)
  {
    this.data = data;

    setModel (new TraceTableModel ());
		getTableHeader().setDefaultRenderer (new HeaderRenderer ());
    setGridColor (Color.lightGray);
    getSelectionModel().setSelectionMode (ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
    getTableHeader().setReorderingAllowed(false);
    setDefaultRenderer(String.class, new TraceTableCellRenderer ());
  }

  public void updateModel (Vector newData)
  {
    data = newData;
    updateTable ();
  }

  public void updateTable ()
  {
    ((TraceTableModel) getModel ()).fireTableDataChanged ();
  }

  public TraceInfo [] getData ()
  {
    return (TraceInfo []) data.toArray (new TraceInfo [data.size()]);
  }

// -----------------------------------------------------------------------------

  public class TraceTableModel extends AbstractTableModel
  {
    public int getColumnCount()
    {
      return columnNames.length;
    }

    public String getColumnName (int columnIndex)
    {
      return columnNames [columnIndex];
    }

    public int getRowCount()
    {
      return data.size();
    }

    public Object getValueAt (int rowIndex, int columnIndex)
    {
      TraceInfo traceInfo = (TraceInfo) data.get (rowIndex);

      switch (columnIndex)
      {
        case 0: // Type (Steward Id)
          return traceInfo.getTraceObject().getName();
        case 1: // Location (Path to comment)
          return traceInfo.getTraceObject().getPath();
        case 2: // Status
          return CommentStatus.getStatusDisplayName(traceInfo.getStatus());
      }

      return ""; //NORES
    }

    public Class getColumnClass(int columnIndex)
    {
      return String.class;
    }
  }

// -----------------------------------------------------------------------------

  private class TraceTableCellRenderer extends DefaultTableCellRenderer
  {
    public Component getTableCellRendererComponent
      (JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
    {
      super.getTableCellRendererComponent(table, value, isSelected, false, row, column);

      TraceInfo traceInfo = (TraceInfo) data.get (row);

      setIcon (column == 0 ? traceInfo.getIcon() : null);

      return this;
    }
  }
}
