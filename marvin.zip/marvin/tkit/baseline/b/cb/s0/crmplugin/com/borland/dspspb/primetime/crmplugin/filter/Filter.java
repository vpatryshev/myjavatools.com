package com.borland.dspspb.primetime.crmplugin.filter;

import java.util.*;

import com.borland.dspspb.primetime.crmplugin.util.smartxml.*;
import com.borland.dspspb.primetime.crmplugin.management.Utils;
import com.starbase.caliber.*;

public class Filter implements Convertable
{
  // Constants
  public static final String TRUE = "TRUE"; //NORES
  public static final String FALSE = "FALSE"; //NORES

  // Parameters
  public static final String CURRENT_USER = "%CURRENT_USER%"; //NORES
  public static final String CURRENT_DATE = "%CURRENT_DATE%"; //NORES

  private String m_id = ""; //NORES
  private String m_name = ""; //NORES
  private String description = ""; //NORES
  private Vector criteria = new Vector();
  private boolean predefined = false;

  public Filter()
  {
    m_id = FilterManager.generateId();
  }

  public Filter(String name)
  {
    this();
    m_name = name;
  }

  public Filter(String name, Vector criteria)
  {
    m_name = name;
    if (criteria != null)
      this.criteria = criteria;
  }

  public String getId ()
  {
    return m_id;
  }

  public void setId (String id)
  {
    this.m_id = id;
  }

  public String getName()
  {
    return m_name;
  }

  public void setName(String name)
  {
    m_name = name;
  }

  public String getDescription()
  {
    return description;
  }

  public void setDescription(String description)
  {
    this.description = description;
  }

  public Criterion[] getCriteria()
  {
    return (Criterion[])criteria.toArray(new Criterion[criteria.size()]);
  }

  public void setCriteria(Criterion[] criteria)
  {
    this.criteria.clear();
    for (int i = 0; i < criteria.length; i++)
    {
      this.criteria.add(criteria[i]);
    }
    verifyLogic();
  }

  private void verifyLogic()
  {
    if (this.criteria.size() == 0)
      return;
    String code0 = ((Criterion)this.criteria.get(0)).getLogicCode();
    if (code0.equals(Logic.AND) || code0.equals(Logic.OR))
      ((Criterion)this.criteria.get(0)).setLogicCode(Logic.NOP);
    else if (code0.equals(Logic.ANDNOT) || code0.equals(Logic.ORNOT))
      ((Criterion)this.criteria.get(0)).setLogicCode(Logic.NOT);
    for (int i = 1; i < criteria.size(); i++)
    {
      String codeN = ((Criterion)this.criteria.get(i)).getLogicCode();
      if (codeN.equals(Logic.NOP))
        ((Criterion)this.criteria.get(i)).setLogicCode(Logic.AND);
      else if (codeN.equals(Logic.NOT))
        ((Criterion)this.criteria.get(i)).setLogicCode(Logic.ANDNOT);
    }
  }

  public boolean getPredefined()
  {
    return predefined;
  }

  public void setPredefined(boolean predefined)
  {
    this.predefined = predefined;
  }

  public Object clone()
  {
    Vector criteria = (Vector)this.criteria.clone();
    Filter other = new Filter(getName(), criteria);
    other.setId(getId());
    return other;
  }

//------------------------------------------------------------------------------

  public void addCriterion(Criterion criterion)
  {
    criteria.add(criterion);
    verifyLogic();
  }

  public void insertCriterion(Criterion criterion, int index)
  {
    criteria.insertElementAt(criterion, index);
    verifyLogic();
  }

  public void removeCriterion(Criterion criterion)
  {
    criteria.remove(criterion);
    verifyLogic();
  }

//  public Criterion findCriterion(String name)
//  {
//    for (int i = 0; i < criteria.size(); i++)
//    {
//      Criterion criterion = (Criterion)criteria.get(i);
//
//      if (criterion.getName().equals(name))
//        return criterion;
//    }
//
//    return null;
//  }
//
  public void replaceCriterion(Criterion criterionOld, Criterion criterionNew)
  {
    if (criterionOld == null)
      addCriterion(criterionNew);
    else
    {
      int index = criteria.indexOf(criterionOld);
      if (index >= 0)
      {
        criteria.set(index, criterionNew);
        verifyLogic();
      }
      else
        addCriterion(criterionNew);
    }

  }

//------------------------------------------------------------------------------

  public boolean accept(Requirement requirement)
  {
    boolean bAccept = true; // ??? false ??? accept/don't accept if no criteria/requirement defined
    if (requirement == null)
      return bAccept;
    for (int i = 0; i < criteria.size(); i++)
    {
      Criterion criterion = ((Criterion)criteria.get(i));
      boolean bCheck = criterion.check(requirement);
      if (criterion.getLogicCode().equals(Logic.NOP))
      {
        bAccept = bCheck;
      }
      else if (criterion.getLogicCode().equals(Logic.NOT))
      {
        bAccept = !bCheck;
      }
      else if (criterion.getLogicCode().equals(Logic.AND))
      {
        bAccept = bAccept && bCheck;
      }
      else if (criterion.getLogicCode().equals(Logic.OR))
      {
        bAccept = bAccept || bCheck;
      }
      else if (criterion.getLogicCode().equals(Logic.ANDNOT))
      {
        bAccept = bAccept && !bCheck;
      }
      else if (criterion.getLogicCode().equals(Logic.ORNOT))
      {
        bAccept = bAccept || !bCheck;
      }
    }
    return bAccept;
  }

//------------------------------------------------------------------------------

  public String getFilename()
  {
    String fileName = Utils.convertToFilename (m_name);
    return fileName + ".xml"; //NORES

//    return m_name + ".xml"; //NORES
  }

  public String toString()
  {
    if (predefined)
      return "<html><b>" + m_name + "</b></html>"; //NORES
    else
      return m_name;
  }
}
