package com.borland.dspspb.primetime.crmplugin.actions;

import java.awt.event.*;

import com.borland.dspspb.primetime.crmplugin.management.*;
import com.borland.dspspb.primetime.crmplugin.resources.*;
import com.borland.dspspb.primetime.crmplugin.ui.*;

public class ActionEditFilters extends PluginUpdateAction
{
  public ActionEditFilters ()
  {
    super
      ("Configure Filters...", //RES ActionEditFilters_shorttext
       "Configure requirement filters", //RES ActionEditFilters_longtext
       ResourceManager.ActionEditFilters_icon);

    setMnemonic('F'); //RES ActionEditFilters_mnemonic
  }

  public void actionPerformed (ActionEvent e)
  {
    DlgConfigureFilters dlg = new DlgConfigureFilters (FramingManager.getInstance().getMainFrame());
    dlg.showDialog();
  }
}
