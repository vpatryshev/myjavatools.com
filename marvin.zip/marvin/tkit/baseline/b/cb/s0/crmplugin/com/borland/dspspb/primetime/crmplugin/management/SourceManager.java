package com.borland.dspspb.primetime.crmplugin.management;

import java.io.File;
import java.net.UnknownHostException;
import java.rmi.dgc.VMID;
import java.text.MessageFormat;
import java.util.Vector;

import com.borland.dspspb.primetime.crmplugin.util.smartxml.DomManager;
import com.borland.dspspb.primetime.crmplugin.resources.ResourceManager;


public class SourceManager
{
  private static String NEW_SOURCE = "New Connection"; //RES SourceManager_New_Source_0
  private static String NEW_SOURCE_N_PATTERN = "New Connection {0}"; //RES SourceManager_New_Source_N_pattern
  private static String SOURCESDIRNAME = ".connections"; //NORES
  private static String SOURCESDIRFULLNAME = System.getProperty("user.home") + File.separator + SOURCESDIRNAME + File.separator; //NORES

  private static SourceManager manager = null;
  private static Vector sources = null;

  protected SourceManager ()
  {
  }

  public static final synchronized SourceManager getInstance ()
  {
    if (manager == null)
    {
      manager = new SourceManager ();
      manager.init ();
    }

    return manager;
  }

  private void init ()
  {
    sources = new Vector();
    File fileSourceDir = new File(SOURCESDIRFULLNAME);
    if (!fileSourceDir.exists())
    {
      fileSourceDir.mkdirs();
    }
    String[] filenameSources = fileSourceDir.list();
    for (int i = 0; i < filenameSources.length; i++)
    {
       Source source = (Source)DomManager.getInstance ().readConvertable (SOURCESDIRFULLNAME + filenameSources[i]);
       if (source != null)
         sources.add(source);
    }
  }

// -----------------------------------------------------------------------------

  private void addSourceFile (Source source)
  {
    if (source == null)
      return;
    String filenameSource = SOURCESDIRFULLNAME + source.getFilename();
    DomManager.getInstance ().writeConvertable (filenameSource, source);
  }

  private void removeSourceFile (Source source)
  {
    if (source == null)
      return;
    File fileSource = new File(SOURCESDIRFULLNAME + source.getFilename());
    fileSource.delete();
  }

  public Source[] getSources ()
  {
    return (Source[])sources.toArray(new Source[sources.size()]);
  }

  public void addSource (Source source)
  {
    sources.add (source);
    addSourceFile (source);
  }

  public void removeSource (Source source)
  {
    sources.remove (source);
    removeSourceFile(source);
  }

  public Source findSource (String id)
  {
    for (int i = 0; i < sources.size(); i++)
    {
      Source source = (Source) sources.get (i);

      if (source.getId().equals(id))
        return source;
    }

    return null;
  }

  public Source findSourceByName (String name)
  {
    if (name == null)
      return null;
    for (int i = 0; i < sources.size(); i++)
    {
      Source source = (Source) sources.get (i);

      if (name.equals(source.getName()))
        return source;
    }

    return null;
  }

  public void replaceSource(Source sourceOld, Source sourceNew)
  {
    if (sourceOld == null)
      addSource(sourceNew);
    else
    {
      int idx = sources.indexOf(sourceOld);
      if (idx >= 0)
      {
        removeSourceFile(sourceOld);
        sources.set(idx, sourceNew);
        addSourceFile(sourceNew);
      }
      else
        addSource(sourceNew);
    }
  }

  public int getSourcesCount()
  {
    return sources.size();
  }

// -----------------------------------------------------------------------------

  public String generateNewName()
  {
    Vector names = new Vector();
    for (int i = 0; i < getSourcesCount(); i++)
    {
      names.add(((Source)sources.get(i)).getName());
    }
    return generateNewName(names);
  }

  public String generateNewName(Vector names)
  {
    return Utils.generateNewName(NEW_SOURCE, NEW_SOURCE_N_PATTERN, names);
  }

  public static String generateId()
  {
    try
    {
      return MessageFormat.format("{0}-{1}-{2}", //NORES
                                  new Object[]
                                  {java.net.InetAddress.getLocalHost().getCanonicalHostName(),
                                   java.net.InetAddress.getLocalHost().getHostAddress(),
                                   new VMID ()});
    }
    catch (UnknownHostException ex)
    {
      return ""; //NORES
    }
  }
}
