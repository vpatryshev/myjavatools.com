package com.borland.dspspb.primetime.crmplugin.gui.swingcomponents.tableproperties.external;

import javax.swing.JComponent;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import java.awt.Dimension;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import com.borland.dspspb.primetime.crmplugin.gui.dialogs.AdrenalinDialog;
import com.borland.dspspb.primetime.crmplugin.gui.swingcomponents.tableproperties.internal.TextInternalComponent;

public class MultilineDialog extends AdrenalinDialog {
  private TextInternalComponent comp;
  private JTextArea ta = new JTextArea();

  public MultilineDialog(TextInternalComponent comp) {
        super(null);
    this.comp = comp;
    ta.setLineWrap(true);
    ta.setWrapStyleWord(true);
    super.setTitle( comp.getDisplayName() );
  }

  public JPanel createContentPane() {
    JPanel mainPanel = new JPanel(new BorderLayout()) {
      public void requestFocus() { ta.requestFocus();	}
    };
    mainPanel.setPreferredSize(new Dimension(300, 240));
    ta.setText( (String)comp.getValue() );
    JScrollPane taSP = new JScrollPane(ta);
    mainPanel.add(taSP, BorderLayout.CENTER);
    return mainPanel;
  }

    public void doOk() {
      comp.setValue( ta.getText() );
      comp.updateUI();
      comp.getEditor().fireEditingStopped();
    }

    public void doCancel() {
      comp.getEditor().fireEditingCanceled();
  }

}
