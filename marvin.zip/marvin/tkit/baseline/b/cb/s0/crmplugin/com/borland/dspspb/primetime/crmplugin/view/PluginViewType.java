package com.borland.dspspb.primetime.crmplugin.view;

import com.borland.primetime.ide.view.ViewType;

public class PluginViewType extends ViewType
{
  public static final String PLUGIN_VIEWTYPE = "CaliberPlugin"; //NORES

  public PluginViewType()
  {
    super (PLUGIN_VIEWTYPE);
  }

  public boolean isTransient()
  {
    return true;
  }
}
