package com.borland.dspspb.primetime.crmplugin.gui.abstractcomponents;

import java.util.Vector;
import java.util.Collection;

public abstract class AbstractChoiceComponent extends AbstractViewComponent
{
      private Vector choiceValues= new Vector();

      public void addChoiceValue(Object value)
      {
            choiceValues.add (value);
      }

      public void setChoiceValues(Collection values)
      {
         choiceValues = new Vector();
         choiceValues.addAll( values );
      }

      public Collection getChoiceValues()
      {
         return choiceValues;
      }

      public void clearChoiceValues()
      {
          choiceValues.clear();
      }

}
