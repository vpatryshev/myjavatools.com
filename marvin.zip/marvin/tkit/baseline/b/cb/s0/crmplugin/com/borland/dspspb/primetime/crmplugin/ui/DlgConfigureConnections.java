package com.borland.dspspb.primetime.crmplugin.ui;

import com.borland.dspspb.primetime.crmplugin.PluginManager;
import com.borland.dspspb.primetime.crmplugin.view.PluginWorkspaceView;
import com.borland.dspspb.primetime.crmplugin.dialog.ButtonsGroup;
import com.borland.dspspb.primetime.crmplugin.dialog.IUpdatableDialog;
import com.borland.dspspb.primetime.crmplugin.dialog.PluginDialog;
import com.borland.dspspb.primetime.crmplugin.filter.Filter;
import com.borland.dspspb.primetime.crmplugin.filter.FilterManager;
import com.borland.dspspb.primetime.crmplugin.management.*;
import com.borland.dspspb.primetime.crmplugin.resources.ResourceManager;
import com.borland.primetime.help.PrimetimeHelp;
import com.starbase.caliber.Baseline;
import com.starbase.caliber.Project;
import com.starbase.caliber.Session;
import com.starbase.caliber.server.*;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Vector;
import java.util.HashMap;

public class DlgConfigureConnections extends PluginDialog
  implements ActionListener, ListSelectionListener, ItemListener, IUpdatableDialog
{
  private static ImageIcon iconConnection =
    ResourceManager.getIcon (ResourceManager.DlgConfigureConnections_Connection_icon);

  // Connections list
  private JPanel connectionsPanel = null;
  private JList connectionsList = null;
  private JButton btnNew = null;
  private JButton btnDelete = null;

  // Connection settings
  private JPanel serverPanel = null;
  private JLabel lblName = null;
  private JTextField txtName = null;
  private JLabel lblHost = null;
  private JTextField txtHost = null;
  private JLabel lblUser = null;
  private JTextField txtUser = null;
  private JLabel lblPassword = null;
  private JPasswordField txtPassword = null;
  private JButton btnConnect = null;

  // Project settings
  private JPanel projectPanel = null;
  private JLabel lblProject = null;
  private JComboBox cbProject = null;
  private JLabel lblBaseline = null;
  private JComboBox cbBaseline = null;
  private JLabel lblFilter = null;
  private JComboBox cbFilter = null;

  private JButton btnAddToProject = null;
  private JButton btnOpenView = null;

  private static Insets insetsLbl = new Insets (3, 5, 2, 5);
  private static Insets insetsTxt = new Insets (0, 5, 5, 5);
  private static Insets insetsBtn = new Insets (5, 5, 5, 5);

  private IDEProject ideProject = null;
  private Vector vSources = null;
  private Vector vAddedSources = new Vector();

  private Object syncUpdate = new Object ();

  public DlgConfigureConnections(Component owner)
  {
    super (owner, "Configure Connections"); //RES DlgConfigureConnections_title
    setHelpTopic (PrimetimeHelp.createTopic (PrimetimeHelp.BOOK_UserGuide, "ui/dialogs/dlgcaliberconfigureconnections.html")); //NORES
  }

  public JComponent getContentUI()
  {
    createConnectionsPanel ();
    createServerPanel ();
    createProjectPanel ();

    JPanel contentPanel = new JPanel (new GridBagLayout ());

    GridBagConstraints c = new GridBagConstraints();

    c.anchor = GridBagConstraints.NORTHWEST;
    c.gridx = 0;
    c.gridy = 0;
    c.gridwidth = 1;
    c.gridheight = GridBagConstraints.REMAINDER;
    c.weightx = 0.0;
    c.weighty = 1.0;
    c.fill = GridBagConstraints.VERTICAL;
    contentPanel.add (connectionsPanel, c);

    c.gridx = 1;
    c.gridy = 0;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.gridheight = 1;
    c.weightx = 1.0;
    c.weighty = 0.0;
    c.fill = GridBagConstraints.HORIZONTAL;
    contentPanel.add (serverPanel, c);

    c.gridx = 1;
    c.gridy = 1;
    c.gridwidth = 1;
    c.weightx = 1.0;
    c.weighty = 0.0;
    c.fill = GridBagConstraints.HORIZONTAL;
    contentPanel.add (projectPanel, c);

    c.gridx = 1;
    c.gridy = 2;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.weightx = 1.0;
    c.weighty = 1.0;
    c.fill = GridBagConstraints.HORIZONTAL;
//    contentPanel.add (buttonsGroup, c);

    initControls ();

    return contentPanel;
  }

  private void createConnectionsPanel()
  {
    connectionsPanel = new JPanel (new GridBagLayout ());
    connectionsPanel.setBorder
      (BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(),
       " Connections ")); //RES DlgConfigureConnections_Border1_text

    connectionsList = new JList ();
    connectionsList.setSelectionMode (ListSelectionModel.SINGLE_SELECTION);

    btnNew = new JButton ("New"); //RES DlgConfigureConnections_BtnNew_text
    btnNew.setMnemonic('N'); //RES DlgConfigureConnections_BtnNew_mnemonic
    btnDelete = new JButton ("Delete"); //RES DlgConfigureConnections_BtnDelete_text
    btnDelete.setMnemonic('D'); //RES DlgConfigureConnections_BtnDelete_mnemonic
    btnAddToProject = new JButton ("Add to Project"); //RES DlgConfigureConnections_BtnAddToProject_text
		btnAddToProject.setMnemonic('A'); //RES DlgConfigureConnections_BtnAddToProject_mnemonic

    ButtonsGroup buttonsGroup = new ButtonsGroup (ButtonsGroup.CENTER);

    buttonsGroup.addButton (btnNew, this);
    buttonsGroup.addButton (btnDelete, this);
    buttonsGroup.addButton (btnAddToProject, this);

    GridBagConstraints c = new GridBagConstraints();

    c.anchor = GridBagConstraints.NORTHWEST;
    c.gridx = 0;
    c.gridy = 0;
    c.gridwidth = 1;
    c.weightx = 1.0;
    c.weighty = 1.0;
    c.fill = GridBagConstraints.BOTH;

    JScrollPane scrollPane = new JScrollPane (connectionsList);
    scrollPane.setHorizontalScrollBarPolicy (JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

    connectionsPanel.add (scrollPane, c);

    c.gridx = 0;
    c.gridy = 1;
    c.gridwidth = 1;
    c.gridheight = 1;
    c.weightx = 1.0;
    c.weighty = 0.0;
    c.fill = GridBagConstraints.HORIZONTAL;
    connectionsPanel.add (buttonsGroup, c);
  }

  private void createServerPanel()
  {
    serverPanel = new JPanel (new GridBagLayout ());
    serverPanel.setBorder
      (BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(),
       " Connection Settings ")); //RES DlgConfigureConnections_Border2_text

    lblName = new JLabel ("Name:"); //RES DlgConfigureConnections_Name_text
		lblName.setDisplayedMnemonic ('M'); //RES DlgConfigureConnections_Name_mnemonic
    txtName = new JTextField (20);
		lblName.setLabelFor (txtName);

    lblHost = new JLabel ("Host:"); //RES DlgConfigureConnections_Host_text
		lblHost.setDisplayedMnemonic ('H'); //RES DlgConfigureConnections_Host_mnemonic
    txtHost = new JTextField ();
		lblHost.setLabelFor (txtHost);

    lblUser = new JLabel ("User:"); //RES DlgConfigureConnections_User_text
		lblUser.setDisplayedMnemonic ('U'); //RES DlgConfigureConnections_User_mnemonic
    txtUser = new JTextField (11);
		lblUser.setLabelFor (txtUser);

    lblPassword = new JLabel ("Password:"); //RES DlgConfigureConnections_Password_text
		lblPassword.setDisplayedMnemonic ('W'); //RES DlgConfigureConnections_mnemonic
    txtPassword = new JPasswordField (13);
		lblPassword.setLabelFor (txtPassword);

    // Button text is set dinamically (see updateDialog)
    btnConnect = new JButton ("Connect");  //RES DlgConfigureConnections_BtnConnect_text
		btnConnect.setMnemonic ('C'); //RES DlgConfigureConnections_BtnConnect_mnemonic

    GridBagConstraints c = new GridBagConstraints();

    // Name
    c.anchor = GridBagConstraints.NORTHWEST;
    c.gridx = 0;
    c.gridy = 0;
    c.gridwidth = 1;
    c.weightx = 0.0;
    c.weighty = 0.0;
    c.insets = insetsLbl;
    c.fill = GridBagConstraints.NONE;
    serverPanel.add (lblName, c);

    c.gridx = 1;
    c.gridy = 0;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.weightx = 1.0;
    c.weighty = 1.0;
    c.insets = insetsTxt;
    c.fill = GridBagConstraints.HORIZONTAL;
    serverPanel.add (txtName, c);

    // Host
    c.gridx = 0;
    c.gridy = 1;
    c.gridwidth = 1;
    c.weightx = 0.0;
    c.weighty = 0.0;
    c.insets = insetsLbl;
    c.fill = GridBagConstraints.NONE;
    serverPanel.add (lblHost, c);

    c.gridx = 1;
    c.gridy = 1;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.weightx = 1.0;
    c.weighty = 0.0;
    c.insets = insetsTxt;
    c.fill = GridBagConstraints.HORIZONTAL;
    serverPanel.add (txtHost, c);

    // User
    c.gridx = 0;
    c.gridy = 2;
    c.gridwidth = 1;
    c.weightx = 0.0;
    c.weighty = 0.0;
    c.insets = insetsLbl;
    c.fill = GridBagConstraints.NONE;
    serverPanel.add (lblUser, c);

    c.gridx = 1;
    c.gridy = 2;
    c.weightx = 0.5;
    c.weighty = 0.0;
    c.insets = insetsTxt;
    c.fill = GridBagConstraints.HORIZONTAL;
    serverPanel.add (txtUser, c);

    // Password
    c.gridx = 2;
    c.gridy = 2;
    c.gridwidth = 1;
    c.weightx = 0.0;
    c.weighty = 0.0;
    c.insets = insetsLbl;
    c.insets = new Insets (insetsLbl.top, insetsLbl.left + 5, insetsLbl.bottom, insetsLbl.right);
    c.fill = GridBagConstraints.NONE;
    serverPanel.add (lblPassword, c);

    c.gridx = 3;
    c.gridy = 2;
    c.weightx = 0.5;
    c.weighty = 0.0;
    c.insets = insetsTxt;
    c.fill = GridBagConstraints.HORIZONTAL;
    serverPanel.add (txtPassword, c);

    // Test
    c.anchor = GridBagConstraints.EAST;
    c.gridx = 3;
    c.gridy = 3;
    c.weightx = 1.0;
    c.weighty = 1.0;
    c.insets = new Insets (2, 0, 5, 4);
    c.fill = GridBagConstraints.NONE;
    serverPanel.add (btnConnect, c);
  }

  private void createProjectPanel()
  {
    projectPanel = new JPanel (new GridBagLayout ());
    projectPanel.setBorder
      (BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(),
       " Project Settings ")); //RES DlgConfigureConnections_Border3_text

    lblProject = new JLabel ("Project:"); //RES DlgConfigureConnections_Project_text
    lblProject.setDisplayedMnemonic('P'); //RES DlgConfigureConnections_Project_mnemonic
    cbProject = new JComboBox ();
    lblProject.setLabelFor (cbProject);

    lblBaseline = new JLabel ("Baseline:"); //RES DlgConfigureConnections_Baseline_text
    lblBaseline.setDisplayedMnemonic('B'); //RES DlgConfigureConnections_Baseline_mnemonic
    cbBaseline = new JComboBox ();
    lblBaseline.setLabelFor (cbBaseline);

    lblFilter = new JLabel ("Filter:"); //RES DlgConfigureConnections_Filter_text
		lblFilter.setDisplayedMnemonic ('F'); //RES DlgConfigureConnections_Filter_mnemonic
    cbFilter = new JComboBox ();
    lblFilter.setLabelFor (cbFilter);

    GridBagConstraints c = new GridBagConstraints();

    // Project
    c.anchor = GridBagConstraints.NORTHWEST;
    c.gridx = 0;
    c.gridy = 0;
    c.insets = insetsLbl;
    c.fill = GridBagConstraints.NONE;
    projectPanel.add (lblProject, c);

    c.gridx = 1;
    c.gridy = 0;
    c.insets = insetsTxt;
    c.fill = GridBagConstraints.HORIZONTAL;
    projectPanel.add (cbProject, c);

    // Baseline
    c.gridx = 0;
    c.gridy = 1;
    c.insets = insetsLbl;
    c.fill = GridBagConstraints.NONE;
    projectPanel.add (lblBaseline, c);

    c.gridx = 1;
    c.gridy = 1;
    c.insets = insetsTxt;
    c.fill = GridBagConstraints.HORIZONTAL;
    projectPanel.add (cbBaseline, c);

    // Filter
    c.gridx = 0;
    c.gridy = 2;
    c.insets = insetsLbl;
    c.fill = GridBagConstraints.NONE;
    projectPanel.add (lblFilter, c);

    c.gridx = 1;
    c.gridy = 2;
    c.weightx = 1.0;
    c.weighty = 1.0;
    c.insets = insetsTxt;
    c.fill = GridBagConstraints.HORIZONTAL;
    projectPanel.add (cbFilter, c);
  }

// -----------------------------------------------------------------------------

  private void initControls ()
  {
    loadFilters ();

    Source [] sources = SourceManager.getInstance ().getSources ();

    vSources = new Vector (sources.length);

    for (int i = 0; i < sources.length; i++)
    {
      Source newSource = (Source) sources [i].clone();
      vSources.add (newSource);
    }

    ideProject = FramingManager.getInstance().getActiveIDEProject();
    if (ideProject != null)
      vAddedSources = ideProject.getProjectSourceIds ();

    connectionsList.setListData (vSources);
    connectionsList.setValueIsAdjusting (true);
    connectionsList.setCellRenderer (new ConnectionCellRenderer ());
    connectionsList.addListSelectionListener (this);

    if (vSources.size () == 0)
    {
      doNew ();
    }

    connectionsList.setSelectedIndex (0);

    btnConnect.addActionListener (this);

    cbProject.setRenderer (new ProjectCellRenderer ());
    cbProject.addItemListener( this);

    cbBaseline.setRenderer (new BaselineCellRenderer ());
    cbBaseline.addItemListener(this);

    cbFilter.setRenderer (new FilterCellRenderer ());
    cbFilter.addItemListener (this);

    updateProjects ();
    updateBaselines ();
    updateFilters ();
  }

// -----------------------------------------------------------------------------
// Connections List handling

  private class ConnectionCellRenderer extends DefaultListCellRenderer
  {
    private Font fontBold = null;
    private Font fontPlain = null;

    public ConnectionCellRenderer ()
    {
      fontPlain = getFont ();
      fontBold = fontPlain.deriveFont (Font.BOLD);
    }

    public Component getListCellRendererComponent
      (JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
    {
      String connectionName = ""; //NORES

      Source source = (Source) value;
      if (source != null) connectionName = source.getName ();

      super.getListCellRendererComponent (list, connectionName, index, isSelected, cellHasFocus);

      setIcon (iconConnection);
      setFont (vAddedSources.contains(source.getId()) ? fontBold : fontPlain);

      return this;
    }
  }

  private static class ProjectCellRenderer extends DefaultListCellRenderer
  {
    public Component getListCellRendererComponent
      (JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
    {
      String projectName = ""; //NORES

      if (value instanceof Project)
      {
        Project rmProject = (Project) value;
        if (rmProject != null) projectName = rmProject.getName ();
      }
      if (value instanceof String)
      {
        projectName = value.toString();
      }

      if (projectName.length() == 0) projectName = " "; //NORES

      super.getListCellRendererComponent (list, projectName, index, isSelected, cellHasFocus);
      return this;
    }
  }

  private static class BaselineCellRenderer extends DefaultListCellRenderer
  {
    public Component getListCellRendererComponent
      (JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
    {
      if (value == null) return this;

      String baselineName = value.toString ();;

      if (value instanceof Baseline)
      {
        Baseline baseline = (Baseline) value;
        if (baseline != null) baselineName = baseline.getName ();
      }
      if (value instanceof String)
      {
        baselineName = value.toString();
      }

      if (baselineName.length() == 0) baselineName = " "; //NORES

      super.getListCellRendererComponent (list, baselineName, index, isSelected, cellHasFocus);
      return this;
    }
  }

  private static class FilterCellRenderer extends DefaultListCellRenderer
  {
    public Component getListCellRendererComponent
      (JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
    {
      if (value == null) return this;

      String filterName = value.toString ();;

      if (value instanceof Filter)
      {
        Filter filter = (Filter) value;
        if (filter != null) filterName = filter.getName ();
      }
      if (value instanceof String)
      {
        filterName = value.toString();
      }

      if (filterName.length() == 0) filterName = " "; //NORES

      super.getListCellRendererComponent (list, filterName, index, isSelected, cellHasFocus);
      return this;
    }
  }

// -----------------------------------------------------------------------------
// ListSelectionListener implementation

  public void valueChanged (ListSelectionEvent e)
  {
    Source selectedConnection = (Source) connectionsList.getSelectedValue ();

    if (selectedConnection == null)
    {
      txtName.setText (""); //NORES
      txtHost.setText (""); //NORES
      txtUser.setText (""); //NORES
      txtPassword.setText (""); //NORES
    }
    else
    {
      txtName.setText (selectedConnection.getName ());
      txtHost.setText (selectedConnection.getServer ());
      txtUser.setText (selectedConnection.getLogin ());
      txtPassword.setText (selectedConnection.loadPassword ());
    }

    updateProjects ();
    updateFilters ();
  }

// -----------------------------------------------------------------------------
// ItemListener implementation

  public void itemStateChanged (ItemEvent e)
  {
    Object eventSource = e.getSource();

    if (eventSource == cbProject)
    {
      Object selectedItem = cbProject.getSelectedItem();

      if (selectedItem instanceof Project)
      {
        Source selectedConnection = (Source) connectionsList.getSelectedValue();

        if (selectedConnection != null)
        {
          Project selectedProject = (Project) selectedItem;
          selectedConnection.setProjectId ("" + selectedProject.getID().getIDNumber()); //NORES
          selectedConnection.setProjectName (selectedProject.getName());
        }
      }

      updateBaselines();
    }
    else if (eventSource == cbBaseline)
    {
      Object selectedItem = cbBaseline.getSelectedItem();

      if (selectedItem instanceof Baseline)
      {
        Source selectedConnection = (Source) connectionsList.getSelectedValue();

        if (selectedConnection != null)
        {
          Baseline selectedBaseline = (Baseline) selectedItem;
          selectedConnection.setBaselineId ("" + selectedBaseline.getID().getIDNumber()); //NORES
          selectedConnection.setBaselineName (selectedBaseline.getName());
        }
      }
    }
    else if (eventSource == cbFilter)
    {
      Object selectedItem = cbFilter.getSelectedItem();

      if (selectedItem instanceof Filter)
      {
        Source selectedConnection = (Source) connectionsList.getSelectedValue();

        if (selectedConnection != null)
        {
          Filter selectedFilter = (Filter) selectedItem;
          selectedConnection.setFilterId (selectedFilter.getId());
        }
      }
    }
  }

// -----------------------------------------------------------------------------
// ActionListener implementation

  public void actionPerformed(ActionEvent e)
  {
    Object eventSource = e.getSource();

    if (eventSource == btnNew)
    {
      doNew ();
    }
    else if (eventSource == btnDelete)
    {
      doDelete ();
    }
    else if (eventSource == btnConnect)
    {
      Source selectedSource = (Source) connectionsList.getSelectedValue();

      if (selectedSource == null) return;

      if (selectedSource.getSession () == null)
        doConnect ();
      else
        doDisconnect ();
    }
    else if (eventSource == btnAddToProject)
    {
      doAddToProject ();
    }
    else if (eventSource == btnOpenView)
    {
      doOpenView ();
    }
  }

  private void doNew ()
  {
    Vector names = new Vector (vSources.size());

    for (int i = 0; i < vSources.size(); i++)
    {
      names.add (((Source) vSources.get (i)).getName ());
    }

    Source newSource = new Source (SourceManager.getInstance().generateNewName(names), "localhost"); //NORES
    vSources.add (newSource);

    connectionsList.setListData (vSources);
    connectionsList.setSelectedValue (newSource, true);

    txtName.selectAll ();
    txtName.requestFocus ();
  }

  private void doDelete ()
  {
    Source selectedSource = (Source)connectionsList.getSelectedValue ();

    if (selectedSource == null) return;

    vSources.remove (selectedSource);
    connectionsList.setListData (vSources);
  }

  private void doConnect ()
  {
    Source selectedConnection = (Source) connectionsList.getSelectedValue();

    if (selectedConnection == null) return;

    String strHost = txtHost.getText().trim();
    String strUser = txtUser.getText().trim();
    String strPassword = new String (txtPassword.getPassword());

    Cursor currentCursor = getCursor ();
    setCursor (Cursor.getPredefinedCursor (Cursor.WAIT_CURSOR));

    CaliberServer server = new CaliberServer (strHost);
    String failReason = ""; //NORES
    Session session = null;

    try
    {
      session = server.login (strUser, strPassword);
    }
    catch (InvalidLoginException ex)
    {
      failReason = "Invalid user id or password has been entered."; //RES DlgLogin_InvalidLoginException
    }
    catch (AccountDisabledException ex)
    {
      failReason = "User's account has been disabled by the administrator."; //RES DlgLogin_AccountDisabledException
    }
    catch (LicenseExpirationException ex)
    {
      failReason = "The license on the remote Caliber server has expired."; //RES DlgLogin_LicenseExpirationException
    }
    catch (NoAvailableLicenseException ex)
    {
      failReason = "All available floating licenses on the CaliberRM server are in use."; //RES DlgLogin_NoAvailableLicenseException
    }
    catch (PasswordExpiredException ex)
    {
      failReason = "The current user's password has expired."; //RES DlgLogin_PasswordExpiredException
    }
    catch (UserMustChangePasswordException ex)
    {
      failReason = "User must change password in order to login to the system."; //RES DlgLogin_UserMustChangePasswordException
    }
    catch (RemoteServerException ex)
    {
      failReason = "Server exception occurred. Please verify that the server is running and accessible."; //RES DlgLogin_RemoteServerException
    }
    catch (Exception ex)
    {
      failReason = "Exception occurred. Please verify that the server is running and accessible."; //RES DlgLogin_AnyOtherException
    }
    finally
    {
      setCursor (currentCursor);
    }

    if (session == null)
    {
      String failMessage =
        "Failed to connect to server " + //RES DlgLogin_ConnectionFailed
        strHost + "\n" + failReason; //NORES
      showValidationMessage (failMessage, txtUser);
    }

    selectedConnection.setSession (session);

    updateProjects ();
  }

  private void doDisconnect ()
  {
    Source selectedSource = (Source) connectionsList.getSelectedValue();

    if (selectedSource == null) return;

    Session session = selectedSource.getSession ();

    if (session == null) return;

    PluginWorkspaceView [] pluginWorkspaceViews = PluginManager.getSessionViews (session);

    if (pluginWorkspaceViews.length != 0)
    {
      int result = JOptionPane.showConfirmDialog
        (this,
         "CaliberRM plugin views associated with current session will be closed.\nDo you wish to proceed?", //RES DlgConfigureConnections_CloseViews_message
         "Closing plugin views", //RES DlgConfigureConnections_CloseViews_title
         JOptionPane.OK_CANCEL_OPTION, JOptionPane.WARNING_MESSAGE);

      if (result != JOptionPane.OK_OPTION) return;
    }

    for (int iView = 0; iView < pluginWorkspaceViews.length; iView++)
    {
      PluginManager.closeView (pluginWorkspaceViews [iView]);
    }

    try
    {
      session.logout();
    }
    catch (Exception ex)
    {
    }

    SessionManager.getInstance().setSession (selectedSource, null);
  }

  private void doAddToProject ()
  {
    Source source = (Source) connectionsList.getSelectedValue();

    if (source == null || vAddedSources.contains (source.getId ())) return;

    vAddedSources.add(source.getId());
    connectionsList.repaint ();
  }

  private void doOpenView ()
  {
    Source source = (Source) connectionsList.getSelectedValue();

    if (source == null) return;

    if (source.getSession() == null)
    {
      DlgCaliberLogin dlgLogin = new DlgCaliberLogin(FramingManager.getInstance().getMainFrame(), source);

      if (!dlgLogin.showDialog() || source.getSession() == null)
        return;
    }

    PluginManager.getInstance().getView().runSource(source);
  }

// -----------------------------------------------------------------------------

  private void updateProjects ()
  {
    synchronized (syncUpdate)
    {
      cbProject.removeAllItems();

      Source selectedConnection = (Source) connectionsList.getSelectedValue ();

      if (selectedConnection == null) return;

      // Load Caliber projects
      Session session = selectedConnection.getSession();

      if (session == null)
      {
        cbProject.removeAllItems();
        cbProject.addItem(selectedConnection.getProjectName());
        cbProject.setSelectedIndex(0);
        return;
      }

      Project [] projects = getProjects (selectedConnection);

      if (projects == null) return; // ???

      String currentProjectId = selectedConnection.getProjectId ();

      for (int i = 0; i < projects.length; i++)
      {
        Project project = projects [i];
        cbProject.addItem (project);
        String projectId = "" + project.getID().getIDNumber(); //NORES

        if (projectId.equals (currentProjectId))
        {
          cbProject.setSelectedItem (project);
        }
      }
    }
  }

  private void updateBaselines ()
  {
    cbBaseline.removeAllItems ();

    Source selectedSource = (Source) connectionsList.getSelectedValue ();

    if (selectedSource == null) return;

    if (selectedSource.getSession () == null)
    {
      cbBaseline.addItem (selectedSource.getBaselineName ());
      cbBaseline.setSelectedIndex (0);
      return;
    }

    // Load baselines for current project
    Object selectedObject = cbProject.getSelectedItem ();

    if (!(selectedObject instanceof Project)) return;

    Project selectedProject = (Project) selectedObject;

    if (selectedProject == null) return;

    String currentBaselineId = selectedSource.getBaselineId ();

    try
    {
      Baseline[] baselines = selectedProject.getBaselines ();

      for (int i = 0; i < baselines.length; i++)
      {
        Baseline baseline = baselines[i];
        cbBaseline.addItem (baseline);
        String baselineId = "" + baseline.getID ().getIDNumber (); //NORES

        if (baselineId.equals (currentBaselineId))
        {
          cbBaseline.setSelectedItem (baseline);
        }
      }
    }
    catch (RemoteServerException ex)
    {
      System.err.println ("DlgConfigureConnections: RemoteServerException");  //NORES
    }
  }

  private void updateFilters ()
  {
    Source selectedSource = (Source) connectionsList.getSelectedValue ();

    if (selectedSource == null) return;

    for (int i = 0; i < cbFilter.getItemCount(); i++)
    {
      Filter filter = (Filter) cbFilter.getItemAt (i);

      if (filter.getId ().equals (selectedSource.getFilterId()))
      {
        cbFilter.setSelectedIndex (i);
        break;
      }
    }
  }

  private void loadFilters ()
  {
    cbFilter.removeAllItems();

    Filter [] filters = FilterManager.getInstance ().getFilters();

    for (int i = 0; i < filters.length; i++)
    {
      Filter filter = filters [i];
      cbFilter.addItem (filter);
    }
  }

// -----------------------------------------------------------------------------

  public void onOk ()
  {
    SourceManager sourceManager = SourceManager.getInstance();

    // Remove old sources
    Source [] oldSources = sourceManager.getSources();

    for (int i = 0; i < oldSources.length; i++)
    {
      sourceManager.removeSource(oldSources [i]);
    }

    // Create new sources
    for (int i = 0; i < vSources.size(); i++)
    {
      sourceManager.addSource((Source) vSources.get(i));
    }


    if (ideProject != null)
    {
      for (int i = 0; i < vAddedSources.size(); i++)
      {
        Source source = sourceManager.findSource((String)vAddedSources.get(i));
        if (source != null)
          ideProject.addSource(source);
      }

      ideProject.checkSources();
    }
  }

// -----------------------------------------------------------------------------
// IUpdatableDialog implementation

  public synchronized void updateDialog()
  {
    synchronized (syncUpdate)
    {
      Source selectedSource = (Source)connectionsList.getSelectedValue();
      boolean isSelection = (selectedSource != null);

      Session session = null;

      if (isSelection)
      {
        if (!selectedSource.getName().equals(txtName.getText()))
        {
          selectedSource.setName(txtName.getText());
          connectionsList.repaint();
        }
        selectedSource.setServer(txtHost.getText());
        selectedSource.setLogin(txtUser.getText());
        selectedSource.savePassword(new String(txtPassword.getPassword()));

        session = selectedSource.getSession();
      }

      boolean hasSession = (session != null);

      btnDelete.setEnabled(isSelection);
      btnAddToProject.setEnabled(isSelection && (ideProject != null) && !vAddedSources.contains(selectedSource.getId()));

      txtName.setEnabled(isSelection);
      txtName.setEditable(isSelection);
      txtHost.setEnabled(isSelection);
      txtHost.setEditable(isSelection);
      txtUser.setEnabled(isSelection);
      txtUser.setEditable(isSelection);
      txtPassword.setEnabled(isSelection);
      txtPassword.setEditable(isSelection);

      btnConnect.setText(hasSession
                         ? "Disconnect" //RES DlgConfigureConnections_BtnDisconnect_text
                         : "Connect"); //RES DlgConfigureConnections_BtnConnect_text

      boolean bEnabled = cbProject.isEnabled();
      if (!bEnabled && (isSelection && hasSession))
      {
        Object item0 = null;
        if (cbProject.getItemCount() > 0)
        {
          item0 = cbProject.getItemAt(0);
        }
        if ((item0 == null) || !(item0 instanceof Project))
        {
          Project[] projects = getProjects(selectedSource);
          cbProject.removeAllItems();
          if (projects == null)return; // ???
          for (int i = 0; i < projects.length; i++)
          {
            Project project = projects[i];
            cbProject.addItem(project);
          }
        }
      }
      cbProject.setEnabled(isSelection && hasSession);
      cbBaseline.setEnabled(isSelection && hasSession);
      cbFilter.setEnabled(isSelection);
    }
  }

// -----------------------------------------------------------------------------

  // Projects cache
  private HashMap projectMap = new HashMap ();

  private Project [] getProjects (Source source)
  {
    String key = SessionManager.getSourceKey (source);

    Project [] projects = (Project []) projectMap.get (key);

    if (projects == null)
    {
      Session session = source.getSession ();

      if (session == null) return null;

      projects = CaliberManager.getProjects (session);
      projectMap.put (key, projects);
    }

    return projects;
  }
}
