package com.borland.dspspb.primetime.crmplugin.gui.actions.menu;

import com.borland.dspspb.primetime.crmplugin.gui.actions.SwingAction;

public interface IMenuItem {
    SwingAction getAdrenalinAction();
    void udpateMenuItem();
}
