package com.borland.dspspb.primetime.crmplugin.view;

import javax.swing.JEditorPane;
import javax.swing.event.HyperlinkListener;
import javax.swing.event.HyperlinkEvent;
import javax.swing.text.html.HTMLFrameHyperlinkEvent;
import javax.swing.text.html.HTMLDocument;
import java.net.URL;
import javax.swing.JLabel;


public class DescriptionPanel extends JEditorPane
	implements HyperlinkListener
{
	public DescriptionPanel ()
	{
		setEditable (false);
    setBackground(new JLabel ().getBackground ());
		setContentType ("text/html"); //NORES
//		addHyperlinkListener (this);
setFocusable (false);
  }

  public URL getPage ()
  {
    // Disable internal JEditorPane page "caching"
    return null;
  }

  public void hyperlinkUpdate (HyperlinkEvent e)
  {
    if (e.getEventType () == HyperlinkEvent.EventType.ACTIVATED)
    {
      JEditorPane pane = (JEditorPane) e.getSource ();
      if (e instanceof HTMLFrameHyperlinkEvent)
      {
        HTMLFrameHyperlinkEvent evt = (HTMLFrameHyperlinkEvent) e;
        HTMLDocument doc = (HTMLDocument) pane.getDocument ();
        doc.processHTMLFrameHyperlinkEvent (evt);
      }
      else
      {
        try
        {
          setText(""); //NORES
          pane.setPage (e.getURL ());
        }
        catch (Throwable t)
        {
//          t.printStackTrace ();
        }
      }
    }
  }

  public void updateUI ()
  {
    super.updateUI();
    setBackground(new JLabel ().getBackground ());
  }

//  /**
//   * Sets the text of this <code>DescriptionPanel</code> to the specified text.
//   *
//   * Note: this was added to hook in the fixup for Raid #205388, it can be removed in the future
//   * @see fixupHTML()
//   *
//   * @param t the new text to be set
//   *
//   */
//  public void setText(String t) {
//    //System.out.println("BEFORE: " + t);
//    t = fixupHTML(t, "<br />", "<br>"); //NORES
//    t = fixupHTML(t, "<body />", "<body>"); //NORES
//    super.setText(t);
//    //System.out.println("AFTER: " + t);
//    setContentType("text/html"); //NORES
//  }
//
//  // Fix for Raid #205388
//  /** @todo  This should be removed at some point in the future when Caliber
//   *          fixes their SDK to properly handle "<BR />"
//   */
//  private String fixupHTML(String source, String search, String replace) {
//    StringBuffer result = new StringBuffer();
//    int pos = 0;
//    int lastpos = 0;
//    while ( (pos = source.indexOf(search)) >= 0) { // NORES
//      if (pos > 0) {
//        result.append(source.substring(0, pos));
//      }
//      result.append(replace);
//      lastpos = pos + search.length();
//      source = source.substring(lastpos);
//    }
//    result.append(source);
//    return result.toString();
//  }
//
}
