package com.borland.dspspb.primetime.crmplugin.ui;

import java.util.Vector;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;

import com.borland.dspspb.primetime.crmplugin.dialog.ButtonsGroup;
import com.borland.dspspb.primetime.crmplugin.dialog.IUpdatableDialog;
import com.borland.dspspb.primetime.crmplugin.dialog.PluginDialog;
import com.borland.dspspb.primetime.crmplugin.resources.ResourceManager;
import com.borland.dspspb.primetime.crmplugin.view.rvtreetable.RVTableColumn;
import com.borland.dspspb.primetime.crmplugin.resources.ResourceManager;
import com.borland.primetime.help.HelpTopic;
import com.borland.primetime.help.PrimetimeHelp;

public class DlgTableOptions
	extends PluginDialog
	implements ActionListener, IUpdatableDialog
{
	static final Color COLOR_NAMEROW				= new Color (210, 210, 210);

  private static ImageIcon iconArrowUp 		= ResourceManager.getIcon(ResourceManager.DlgConfigureComment_arrowup_icon);
  private static ImageIcon iconArrowDown	= ResourceManager.getIcon(ResourceManager.DlgConfigureComment_arrowdown_icon);

	private JTable myTable;
	private JButton btnHideAll;
	private JButton btnShowAll;
	private JButton btnMoveUp;
	private JButton btnMoveDown;
	private JButton btnSetDefault;
	private JCheckBox myVLines;
	private JCheckBox myHLines;
	private boolean vLines;
	private boolean hLines;

	private Vector all;
	private Vector defaults;
	private boolean[] checked;

  Object syncObject = new Object ();

	private static final String columnNames []	=
	{
    "Field Name" //RES DlgConfigureComment_FieldName_text
	};

	public DlgTableOptions
		(Component owner, Vector all, Vector defaults, Vector shown, boolean vLines, boolean hLines)
	{
		super (owner, "Table Options"); //RES DlgTableOptions_title
    setHelpTopic (PrimetimeHelp.createTopic (PrimetimeHelp.BOOK_UserGuide, "ui/dialogs/dlgcalibertableoptions.html")); //NORES
		setResizable (false);

		this.vLines = vLines;
		this.hLines = hLines;
		this.defaults = defaults;
		this.all = all;

		checked = new boolean [all.size ()];

		checked [0] = true;
		for (int i = 1; i < all.size (); i++)
		{
			checked[i] = shown.contains (all.get (i));
		}
	}

  private JPanel createButtonsPanel ()
  {
    ButtonsGroup panel = new ButtonsGroup (ButtonsGroup.CENTER);

    btnMoveUp = new JButton ("Move Up", iconArrowUp); //RES DlgConfigureComment_MoveUp_text
    btnMoveUp.setMnemonic('U'); //RES DlgConfigureComment_MoveUp_mnemonic
    btnMoveDown = new JButton ("Move Down", iconArrowDown); //RES DlgConfigureComment_MoveDown_text
    btnMoveDown.setMnemonic('D'); //RES DlgConfigureComment_MoveDown_mnemonic
    btnHideAll = new JButton ("Hide All"); //RES DlgConfigureComment_HideAll_text
    btnHideAll.setMnemonic('H'); //RES DlgConfigureComment_HideAll_mnemonic
    btnShowAll = new JButton ("Show All"); //RES DlgConfigureComment_ShowAll_text
    btnShowAll.setMnemonic('S'); //RES DlgConfigureComment_ShowAll_mnemonic
    btnSetDefault = new JButton ("Set Default"); //RES DlgConfigureComment_SetDefault_text
    btnSetDefault.setMnemonic('T'); //RES DlgConfigureComment_SetDefault_mnemonic

    panel.addButton (btnMoveUp, this);
    panel.addButton (btnMoveDown, this);
    panel.addButton (btnShowAll, this);
    panel.addButton (btnHideAll, this);
//    panel.addButton (btnSetDefault, this);

    return panel;
  }

	public JPanel createCheckBoxesPanel ()
	{
		JPanel panel = new JPanel (new FlowLayout (FlowLayout.LEFT));

		panel.add (myHLines);
		panel.add (myVLines);

		return panel;
	}

	public JComponent getContentUI ()
	{
		JPanel contentPanel = new JPanel (new BorderLayout ());
		myTable = new JTable ();

		JScrollPane tablePane = new JScrollPane(myTable);

		myTable.setModel (new MyTableModel ());
		myTable.setDefaultRenderer (JCheckBox.class, new FieldNameRenderer ());
		myTable.addMouseListener (new MyTableMouseListener ());
		myTable.addKeyListener (new MyTableKeyAdapter ());
		myTable.setRowSelectionAllowed (true);
		myTable.setColumnSelectionAllowed (false);
		myTable.getTableHeader ().setReorderingAllowed (false);
		myTable.setGridColor (Color.lightGray);
		myTable.getSelectionModel ().setSelectionMode (ListSelectionModel.SINGLE_SELECTION);
		myTable.setAutoResizeMode (JTable.AUTO_RESIZE_LAST_COLUMN);
		myTable.setPreferredScrollableViewportSize (new Dimension (300, 16 * Math.min(20, all.size())));
		myTable.getTableHeader ().setDefaultRenderer (new HeaderRenderer ());
  	myTable.setRowSelectionInterval (0, 0);

		myHLines = new JCheckBox ("Horizontal Lines", hLines); //RES DlgTableOptions_HorizontalLines_text
		myHLines.setMnemonic('O'); //RES DlgTableOptions_HorizontalLines_mnemonic
		myVLines = new JCheckBox ("Vertical Lines", vLines); //RES DlgTableOptions_VerticalLines_next
		myVLines.setMnemonic('V'); //RES DlgTableOptions_VerticalLines_mnemonic

		JPanel controls = new JPanel (new BorderLayout ());
		controls.add (createButtonsPanel (), BorderLayout.NORTH);
		controls.add (createCheckBoxesPanel (), BorderLayout.SOUTH);
    controls.setBorder (BorderFactory.createEtchedBorder ());

		contentPanel.add (tablePane, BorderLayout.NORTH);
		contentPanel.add (controls, BorderLayout.SOUTH);

// -----------------------------------------------------------------------------

    // Register Enter/Escape keyboard action
    myTable.registerKeyboardAction (new ActionListener ()
    {
      public void actionPerformed (ActionEvent ae)
      {
        doDefaultClick ();
      }
    }, KeyStroke.getKeyStroke (KeyEvent.VK_ENTER, 0),
       JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

    myTable.registerKeyboardAction (new ActionListener ()
    {
      public void actionPerformed (ActionEvent ae)
      {
        closeDialog (false);
      }
    }, KeyStroke.getKeyStroke (KeyEvent.VK_ESCAPE, 0),
       JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

		return contentPanel;
	}

	public boolean isVLines ()
	{
		return myVLines.isSelected ();
	}

	public boolean isHLines ()
	{
		return myHLines.isSelected ();
	}

	public Vector getValues ()
	{
		Vector values = new Vector ();

		for (int i = 0; i < checked.length; i++)
		{
			if (checked[i])
			{
				values.add (all.get (i));
			}
		}

		return values;
	}

	public void moveDown ()
	{
		int idx = myTable.getSelectedRow ();

		if (idx == all.size () - 1)
		{
			return;
		}

		Object down = all.get (idx + 1);
		all.setElementAt (all.get (idx), idx + 1);
		all.setElementAt (down, idx);

		boolean bdown = checked[idx + 1];
		checked[idx + 1] = checked[idx];
		checked[idx] = bdown;

		myTable.setRowSelectionInterval (idx + 1, idx + 1);
	}

	public void moveUp ()
	{
		int idx = myTable.getSelectedRow ();

		if (idx <= 1)
		{
			return;
		}

		Object up = all.get (idx - 1);
		all.setElementAt (all.get (idx), idx - 1);
		all.setElementAt (up, idx);

		boolean bup = checked[idx - 1];
		checked[idx - 1] = checked[idx];
		checked[idx] = bup;

		myTable.setRowSelectionInterval (idx - 1, idx - 1);
	}

//------------------------------------------------------------------------------

	class MyTableModel extends AbstractTableModel
	{
		public int getColumnCount ()
		{
			return columnNames.length;
		}

		public int getRowCount ()
		{
			return all.size ();
		}

		public String getColumnName (int col)
		{
			return columnNames [col];
		}

		public Object getValueAt (int row, int col)
		{
			RVTableColumn field = (RVTableColumn) all.get(row);

			if (col == 0)
			{
        return field.getDisplayName();
			}

			return null;
		}

		public Class getColumnClass (int c)
		{
			if (c == 0)
			{
				return (JCheckBox.class);
			}
			else
			{
				return (String.class);
			}
		}

		public boolean isCellEditable (int row, int col)
		{
			return false;
		}
	}

//------------------------------------------------------------------------------

	class FieldNameRenderer extends JCheckBox implements TableCellRenderer
	{
		public Component getTableCellRendererComponent (JTable table, Object value,
																										boolean isSelected, boolean hasFocus,
																										int row, int col)
		{
			if (row == 0)
      {
				setBackground (COLOR_NAMEROW);
				setForeground (Color.black);
        setEnabled (false);
			}
      else
      {
        setBackground(isSelected ? table.getSelectionBackground() : table.getBackground());
        setForeground(isSelected ? table.getSelectionForeground() : table.getForeground());
        setEnabled (true);
      }

			String fontName = getFont().getName();
			int size = getFont().getSize();

			if (row == 0)
				setFont(new Font (fontName, Font.BOLD, size));
			else
				setFont(new Font (fontName, Font.PLAIN, size));

			setSelected (checked[row]);
			setText (value.toString());

			return this;
		}
	}

	class FieldTypeRenderer extends DefaultTableCellRenderer
	{
		public Component getTableCellRendererComponent (JTable table, Object value,
																										boolean isSelected, boolean hasFocus,
																										int row, int col)
		{
			setBackground (row == 0 ? COLOR_NAMEROW : table.getBackground());

			String fontName = getFont().getName();
			int size = getFont().getSize();

			if (row == 0)
				setFont(new Font (fontName, Font.BOLD, size));
			else
				setFont(new Font (fontName, Font.PLAIN, size));

			setText (value.toString());

			return this;
		}
	}

//------------------------------------------------------------------------------

	class MyTableMouseListener extends MouseAdapter
	{
		public void mousePressed (MouseEvent e)
		{
			int row = myTable.rowAtPoint (e.getPoint ());

			if (row == 0) return;

			if (e.getPoint ().x <= myTable.getRowHeight ())
      {
				checked[row] = !checked[row];
			}

			myTable.setRowSelectionInterval (row, row);
			myTable.repaint ();
		}
	}

//------------------------------------------------------------------------------

	class MyTableKeyAdapter extends KeyAdapter
	{
		public void keyReleased (KeyEvent e)
		{
			int keyCode = e.getKeyCode ();
			if (keyCode == KeyEvent.VK_SPACE)
			{
				int row = myTable.getSelectedRow ();
				if (row > 0)
				{
					checked[row] = !checked[row];
					myTable.repaint ();
				}
			}
		}
	}

//------------------------------------------------------------------------------

	void allShowHide (JTable table, boolean bShow)
	{
		for (int i = 1; i < checked.length; i++)
		{
			checked[i] = bShow;
		}
		table.repaint ();
	}

	public void actionPerformed (ActionEvent event)
	{
		Object source = event.getSource ();

    synchronized (syncObject)
    {
      if (source == btnShowAll)
      {
        allShowHide (myTable, true);
      }
      else if (source == btnHideAll)
      {
        allShowHide (myTable, false);
      }
      else if (source == btnMoveUp)
      {
        moveUp ();
      }
      else if (source == btnMoveDown)
      {
        moveDown ();
      }
      else if (source == btnSetDefault)
      {
        selectDefault();
      }
    }
  }

//------------------------------------------------------------------------------

	private void selectDefault ()
	{
		for (int i = 0; i < all.size (); i++)
		{
			checked[i] = defaults.contains (all.get (i));
		}

    myTable.repaint();
	}

	public void updateDialog ()
	{
    synchronized (syncObject)
    {
      int selectedRow = myTable.getSelectedRow ();

      btnMoveUp.setEnabled (selectedRow > 1);
      btnMoveDown.setEnabled
        (selectedRow != 0 && selectedRow != myTable.getRowCount () - 1);

      int selCount = 0;

      for (int i = 0; i < checked.length; i++)
      {
        if (checked[i]) selCount++;
      }

      btnHideAll.setEnabled (selCount > 1);
      btnShowAll.setEnabled (selCount != checked.length);
    }
	}

// -----------------------------------------------------------------------------
// Table header renderer

	public class HeaderRenderer extends JLabel implements TableCellRenderer
	{
		public HeaderRenderer ()
		{
			setBorder (BorderFactory.createCompoundBorder
								 (UIManager.getBorder ("TableHeader.cellBorder"), BorderFactory.createEmptyBorder (0, 5, 0, 5))); //NORES
		}

		public Component getTableCellRendererComponent
			(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
		{
			JTableHeader header = table.getTableHeader ();

			setForeground (header.getForeground ());
			setBackground (header.getBackground ());
			setFont (header.getFont ());

			setText (value.toString ());

			return this;
		}
	}
}
