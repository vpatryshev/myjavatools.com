package com.borland.dspspb.primetime.crmplugin.ui;

import java.util.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

import com.borland.dspspb.primetime.crmplugin.filter.*;
import com.borland.dspspb.primetime.crmplugin.dialog.PluginDialog;
import com.borland.primetime.help.HelpTopic;
import com.borland.primetime.help.PrimetimeHelp;

public class EditCriterionDialog extends PluginDialog
{
  private boolean bFirstCriterion;
  private Criterion m_criterion = null;
  private HashMap valuesForType = new HashMap();
  private Vector untypedValues = new Vector();

  public EditCriterionDialog(Component owner, boolean bFirstCriterion)
  {
    super(owner, "Add Criterion"); //RES DlgEditCriterion_Add_title
    setHelpTopic (PrimetimeHelp.createTopic (PrimetimeHelp.BOOK_UserGuide, "ui/dialogs/dlgcaliberaddeditcriteria.html")); //NORES

    this.bFirstCriterion = bFirstCriterion;
  }

  public EditCriterionDialog(Component owner, final Criterion criterion, boolean bFirstCriterion)
  {
    super(owner, "Edit Criterion");  //RES DlgEditCriterion_Edit_title
    setHelpTopic (PrimetimeHelp.createTopic (PrimetimeHelp.BOOK_UserGuide, "ui/dialogs/dlgcaliberaddeditcriteria.html")); //NORES

    m_criterion = criterion;
    this.bFirstCriterion = bFirstCriterion;
    String type = criterion.getField().getType();
    if (type != null)
    {
      Vector v = new Vector();
      String[] values = criterion.getValues();
      for (int i = 0; i < values.length; i++)
      {
        v.add(values[i]);
      }
      valuesForType.put(type, v);
    }
  }

  public JComponent getContentUI()
  {
    JPanel contentPane = new JPanel(new GridBagLayout());

    GridBagConstraints c;

    c = setConstraints(0, 0, 1, 1, 1.0, 0.0, NOWE, BOTH, 5, 5, 0, 5);
    contentPane.add(createOptionsPanel(), c);

    c = setConstraints(0, 1, 1, REMD, 1.0, 1.0, NOWE, BOTH, 5, 5, 0, 5);
    contentPane.add(createValuesPanel(), c);

    return contentPane;
  }

//------------------------------------------------------------------------------
// Options panel

  private JComboBox cbLogic;
  private JComboBox cbFields = new JComboBox(FilterManager.getInstance().getFields());
  private JComboBox cbCheck = new JComboBox();

  private JPanel createOptionsPanel()
  {
    if (bFirstCriterion)
    {
      cbLogic = new JComboBox(Logic.getLogics1());
    }
    else
    {
      cbLogic = new JComboBox(Logic.getLogics2());
    }

    cbFields.addItemListener(new ItemListener()
    {
      public void itemStateChanged(ItemEvent e)
      {
        if (e.getStateChange() == ItemEvent.DESELECTED)
          return;
        String type = ((Field)cbFields.getSelectedItem()).getType();
        valuesList.setListData(formatValues(getValuesForType(type), type));
        setChecks(type);
      }
    });

    if (m_criterion != null)
    {
      cbLogic.setSelectedItem(m_criterion.getLogic());
      cbFields.setSelectedItem(m_criterion.getField());
      setChecks(m_criterion.getField().getType());
      cbCheck.setSelectedItem(m_criterion.getCheck());
    }
    else
    {
      cbLogic.setSelectedIndex(0);
      cbFields.setSelectedIndex(0);
      setChecks(((Field)cbFields.getSelectedItem()).getType());
      cbCheck.setSelectedIndex(0);
    }

    JPanel panel = new JPanel(new GridBagLayout());

    GridBagConstraints c;
    c = setConstraints(0, 0, 1, 1, 0.0, 0.0, NOWE, NONE);
    JLabel lblLogic = new JLabel("Logic:");  //RES DlgEditCriterion_Logic_text
    lblLogic.setDisplayedMnemonic('L');  //RES DlgEditCriterion_Logic_mnemonic
    lblLogic.setLabelFor(cbLogic);
    panel.add(lblLogic, c);
    c = setConstraints(0, 1, 1, 1, 0.0, 0.0, NOWE, HORZ);
    panel.add(cbLogic, c);

    c = setConstraints(1, 0, 1, 1, 0.0, 0.0, NOWE, NONE);
		JLabel lblFields = new JLabel("Fields:"); //RES DlgEditCriterion_Fields_text
		lblFields.setDisplayedMnemonic('F'); //RES DlgEditCriterion_Fields_mnemonic
		lblFields.setLabelFor(cbFields);
    panel.add(lblFields, c);
    c = setConstraints(1, 1, 1, 1, 0.0, 0.0, NOWE, HORZ);
    panel.add(cbFields, c);

    c = setConstraints(2, 0, 1, 1, 0.0, 0.0, NOWE, NONE);
    JLabel lblCheck = new JLabel("Check:"); //RES DlgEditCriterion_Check_text
    lblCheck.setDisplayedMnemonic('C'); //RES DlgEditCriterion_Check_mnemonic
    lblCheck.setLabelFor(cbCheck);
    panel.add(lblCheck, c);
    c = setConstraints(2, 1, 1, 1, 1.0, 0.0, NOWE, HORZ);
    panel.add(cbCheck, c);

    return panel;
  }

  private void setChecks(String type)
  {
    cbCheck.removeAllItems();
    Check[] checks = Check.getChecks(type);
    for (int i = 0; i < checks.length; i++)
    {
      cbCheck.addItem(checks[i]);
    }
  }
//------------------------------------------------------------------------------
// Values panel

  private JList valuesList = new JList();
  private JScrollPane valuesPane = new JScrollPane(valuesList);
  private JButton btnAdd = new JButton ("Add..."); //RES DlgEditCriterion_BtnAdd_text
  private JButton btnEdit = new JButton("Edit..."); //RES DlgEditCriterion_BtnEdit_text
  private JButton btnRemove = new JButton("Remove"); //RES DlgEditCriterion_BtnRemove_text

  private JPanel createValuesPanel()
  {
  	btnAdd.setMnemonic('A'); //RES DlgEditCriterion_BtnAdd_mnemonic
  	btnEdit.setMnemonic('E'); //RES DlgEditCriterion_BtnEdit_mnemonic
  	btnRemove.setMnemonic('R'); //RES DlgEditCriterion_BtnRemove_mnemonic

    valuesList.addListSelectionListener(new ListSelectionListener()
    {
      public void valueChanged(ListSelectionEvent e)
      {
        updateButtonsPanel();
      }
    });
    valuesList.getSelectionModel().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    Field field = (Field)cbFields.getSelectedItem();
    if (field != null)
    {
      String type = field.getType();
      Vector values = getValuesForType(type);
      valuesList.setListData(formatValues(values, type));
    }

    JPanel panel = new JPanel(new GridBagLayout());

    valuesPane.setPreferredSize(new Dimension(200, 100));
    GridBagConstraints c;
    c = setConstraints(0, 0, 1, 1, 1.0, 0.0, NOWE, HORZ);
    panel.add(new JLabel("Value(s):"), c); //RES DlgEditCriterion_Values_text
    c = setConstraints(0, 1, 2, 1,  1.0, 1.0, NOWE, BOTH);
    panel.add(valuesPane, c);
    c = setConstraints(0, 2, 2, 1, 1.0, 0.0, NOWE, HORZ, 10, 0, 0, 5);
    panel.add(createButtonsPanel(), c);
    updateButtonsPanel();

    return panel;
  }

  private JPanel createButtonsPanel()
  {
    JPanel panel = new JPanel();
    panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));

    btnAdd.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        String type = ((Field)cbFields.getSelectedItem()).getType();
        String newValue = getNewValue(null, type);
        if (newValue != null && newValue.length() != 0)
        {
//          Vector values = new Vector();
//          for (int i = 0; i < valuesList.getModel().getSize(); i++)
//          {
//            values.add(valuesList.getModel().getElementAt(i));
//          }
          Vector values = getValuesForType(type);
          int index = valuesList.getSelectedIndex();
          if (index != -1)
          {
            values.insertElementAt(newValue, index + 1);
          }
          else
          {
            values.addElement(newValue);
          }
          valuesList.setListData(formatValues(values, type));
          valuesList.setSelectedIndex(index + 1);
          updateButtonsPanel();
        }
      }
    });
    // TODO: btnEdit
    btnEdit.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        String type = ((Field)cbFields.getSelectedItem()).getType();
        Vector values = getValuesForType(type);
        int index = valuesList.getSelectedIndex();
        String newValue = getNewValue((String)values.get(index), type);
        if (newValue != null && newValue.length() != 0)
        {
          values.setElementAt(newValue, index);
          valuesList.setListData(formatValues(values, type));
          valuesList.setSelectedIndex(index);
          updateButtonsPanel();
        }
      }
    });
    btnRemove.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        String type = ((Field)cbFields.getSelectedItem()).getType();
        Vector values = getValuesForType(type);
        values.remove(valuesList.getSelectedIndex());
        valuesList.setListData(formatValues(values, type));
        updateButtonsPanel();
      }
    });

    panel.add(btnAdd);
    panel.add(Box.createHorizontalStrut(3));
    panel.add(btnEdit);
    panel.add(Box.createHorizontalStrut(6));
    panel.add(btnRemove);
//    panel.setBorder (BorderFactory.createEtchedBorder ());

    return panel;
  }

  private Vector getValuesForType(String type)
  {
    if (type == null)
      return untypedValues;
    Vector values = (Vector)valuesForType.get(type);
    if (values == null)
    {
      values = new Vector();
      valuesForType.put(type, values);
    }
    return values;
  }

  private Vector formatValues(Vector values, String type)
  {
    Vector formattedValues =  new Vector();
    for (int i = 0; i < values.size(); i++)
    {
      String formattedValue = FilterManager.getInstance().formatValue((String)values.elementAt(i), type);
      formattedValues.add(formattedValue);
    }
    return formattedValues;
  }

  private String getNewValue(String oldValue, String type)
  {
    String newValue = null;
    if (type == Field.TYPE_ENUM ||
        type == Field.TYPE_USER)

    {
      if (oldValue == null)
      {
        newValue = (String)JOptionPane.showInputDialog(EditCriterionDialog.this,
        "Value:", "Add Value", //RES DlgEditCriterion_Value_text,DlgEditCriterion_AddValue_text
        JOptionPane.QUESTION_MESSAGE, null, FilterManager.getFieldValues(type), null);
      }
      else
      {
        newValue = (String)JOptionPane.showInputDialog(EditCriterionDialog.this,
        "Value:", "Select Value",  //RES DlgEditCriterion_Value_text,DlgEditCriterion_SelectValue_text
        JOptionPane.QUESTION_MESSAGE, null, FilterManager.getFieldValues(type), valuesList.getSelectedValue());
      }
    }
    else /*if (type == Field.TYPE_STRING ||
             type == Field.TYPE_TEXT)*/
    {
      if (oldValue == null)
      {
        newValue = JOptionPane.showInputDialog(EditCriterionDialog.this,
        "Value:", "Add Value", //RES DlgEditCriterion_Value_text,DlgEditCriterion_AddValue_text
        JOptionPane.QUESTION_MESSAGE);
      }
      else
      {
        newValue = (String)JOptionPane.showInputDialog(EditCriterionDialog.this,
        "Value:", "Edit Value",  //RES DlgEditCriterion_Value_text,DlgEditCriterion_EditValue_text
        JOptionPane.QUESTION_MESSAGE, null, null, valuesList.getSelectedValue());
      }
    }
/*
    else
    {
      JOptionPane.showMessageDialog(this, "Value(s) for this type are not supported yet.",
        ((Field)cbFields.getSelectedItem()).getName(), JOptionPane.WARNING_MESSAGE);
      return null;
    }
*/
    return newValue;
  }

  private void updateButtonsPanel()
  {
    String selectedValue = (String)valuesList.getSelectedValue();
    if (selectedValue == null)
    {
      btnAdd.setEnabled(true);
      btnEdit.setEnabled(false);
      btnRemove.setEnabled(false);
    }
    else
    {
      btnAdd.setEnabled(true);
      btnEdit.setEnabled(true);
      btnRemove.setEnabled(true);
    }
  }

//------------------------------------------------------------------------------

  public Criterion getCriterion()
  {
    String type = ((Field)cbFields.getSelectedItem()).getType();
    Vector values = getValuesForType(type);
    return new Criterion(((Logic)cbLogic.getSelectedItem()).getCode(),
      ((Field)cbFields.getSelectedItem()).getId(), ((Check)cbCheck.getSelectedItem()).getCode(), values);
  }

//------------------------------------------------------------------------------

  private static int NONE = GridBagConstraints.NONE;
  private static int BOTH = GridBagConstraints.BOTH;
  private static int NORT = GridBagConstraints.NORTH;
  private static int WEST = GridBagConstraints.WEST;
  private static int NOWE = GridBagConstraints.NORTHWEST;
  private static int HORZ = GridBagConstraints.HORIZONTAL;
  private static int VERT = GridBagConstraints.VERTICAL;
  private static int REMD = GridBagConstraints.REMAINDER;

  private GridBagConstraints setConstraints(int gridx, int gridy,
    int gridwidth, int gridheight, double weightx, double weighty,
    int anchor, int fill,
    int ins_bottom, int ins_left, int ins_right, int ins_top)
  {
    return new GridBagConstraints(gridx, gridy, gridwidth, gridheight,
      weightx, weighty, anchor, fill,
      new Insets(ins_bottom, ins_left, ins_right, ins_top),
      0, 0);
  }

  private GridBagConstraints setConstraints(int gridx, int gridy,
    int gridwidth, int gridheight, double weightx, double weighty,
    int anchor, int fill)
  {
    return setConstraints(gridx, gridy,
      gridwidth, gridheight, weightx, weighty,
      anchor, fill,
      0, 0, 0, 0);
  }
}
