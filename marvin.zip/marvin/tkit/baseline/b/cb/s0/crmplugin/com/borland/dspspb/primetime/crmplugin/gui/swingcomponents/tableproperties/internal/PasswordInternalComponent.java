package com.borland.dspspb.primetime.crmplugin.gui.swingcomponents.tableproperties.internal;

import java.util.Vector;
import java.awt.Component;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JPasswordField;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.event.FocusListener;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class PasswordInternalComponent extends SwingInternalComponent {

    public PasswordInternalComponent(String name, String displayName, String value) {
        this(name, displayName);
        setValue(value);
    }

    public PasswordInternalComponent(String name, String displayName) {
        super(name, displayName);
        tf.addKeyListener(escapeListener);
        tf.addFocusListener(lostListener);
    }

    private JPasswordField tf = new JPasswordField();

    public Component getInternalRenderer() {
        return getInternalEditor();
    }

    public Component getInternalEditor() {
        tf.setEditable( isEditable() );
        return tf;
    }

    public void updateUI() {
        tf.setText( (String)getValue() );
    }
    public void updateData() {
        setValue( new String(tf.getPassword()) );
    }

    public String getStringValue() {
        return (String)getValue();
    }
}
