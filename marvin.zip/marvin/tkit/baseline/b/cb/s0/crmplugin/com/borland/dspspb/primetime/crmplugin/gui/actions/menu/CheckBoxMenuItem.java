package com.borland.dspspb.primetime.crmplugin.gui.actions.menu;

import com.borland.dspspb.primetime.crmplugin.gui.actions.SwingCheckBoxAction;
import com.borland.dspspb.primetime.crmplugin.gui.actions.SwingAction;
import javax.swing.JCheckBoxMenuItem;

public class CheckBoxMenuItem  extends JCheckBoxMenuItem implements IMenuItem {
    public CheckBoxMenuItem(SwingCheckBoxAction action) {
        super(action);
    }

    public SwingAction getAdrenalinAction() {
        return (SwingAction)getAction();
    }

    public void udpateMenuItem() {
        SwingCheckBoxAction action = (SwingCheckBoxAction)getAdrenalinAction();
        setEnabled(action.isEnabled());
        setSelected(action.isChecked());
    }
}
