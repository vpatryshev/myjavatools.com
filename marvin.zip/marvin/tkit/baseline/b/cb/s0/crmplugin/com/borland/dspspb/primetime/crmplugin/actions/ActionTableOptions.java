package com.borland.dspspb.primetime.crmplugin.actions;

import java.util.*;

import java.awt.event.*;

import com.borland.dspspb.primetime.crmplugin.*;
import com.borland.dspspb.primetime.crmplugin.gui.treetable.*;
import com.borland.dspspb.primetime.crmplugin.resources.*;
import com.borland.dspspb.primetime.crmplugin.ui.*;
import com.borland.dspspb.primetime.crmplugin.view.*;
import com.borland.dspspb.primetime.crmplugin.view.rvtreetable.*;


public class ActionTableOptions extends PluginUpdateAction
{
  public ActionTableOptions ()
  {
    super
      ("Table Options", //RES ActionTableOptions_shorttext
       "Configure requirements table options", //RES ActionTableOptions_longtext
       ResourceManager.ActionTableOptions_icon);
  }

	public void actionPerformed (ActionEvent e)
	{
    PluginView pluginView = (PluginView) e.getSource();

		Vector all = PluginManager.getAllColumns ();
		Vector defaults = PluginManager.getDefaultColumns ();

		RVTreeTable table = pluginView.getTable ();
		TreeTableModelAdapter tableAdapter = (TreeTableModelAdapter) table.getModel ();
		RVTreeTableModel tableModel = (RVTreeTableModel) tableAdapter.getTreeTableModel ();
		Vector shown = tableModel.getColumns ();

		boolean vLines = table.getShowVerticalLines ();
		boolean hLines = table.getShowHorizontalLines ();

		DlgTableOptions dlgTableOptions = new DlgTableOptions
			(null, all, defaults, shown, vLines, hLines);

		if (dlgTableOptions.showDialog ())
		{
			tableModel.setColumns (dlgTableOptions.getValues ());
			table.createDefaultColumnsFromModel();
			table.setShowHorizontalLines (dlgTableOptions.isHLines());
			table.setShowVerticalLines (dlgTableOptions.isVLines());
		}
	}
}
