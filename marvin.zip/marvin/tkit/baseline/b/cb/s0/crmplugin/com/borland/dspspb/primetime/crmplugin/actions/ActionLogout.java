package com.borland.dspspb.primetime.crmplugin.actions;

import java.awt.event.*;

import com.borland.dspspb.primetime.crmplugin.*;
import com.borland.dspspb.primetime.crmplugin.management.*;
import com.borland.dspspb.primetime.crmplugin.resources.*;
import com.borland.dspspb.primetime.crmplugin.view.*;
import com.starbase.caliber.*;
import javax.swing.JOptionPane;

public class ActionLogout extends PluginUpdateAction
{
  public ActionLogout ()
  {
    super
      ("Logout", //RES ActionLogout_shorttext
       "Logout the server associated with current connection", //RES ActionLogout_longtext
       ResourceManager.ActionLogout_icon);
  }

  public void actionPerformed (ActionEvent e)
  {
    PluginView pluginView = (PluginView)e.getSource();
    Source source = pluginView.getSource();
    Session session = SessionManager.getInstance().getSession(source);
    if (session != null)
    {
      PluginWorkspaceView [] pluginWorkspaceViews = PluginManager.getSessionViews (session);

      if (pluginWorkspaceViews.length != 0)
      {
        int result = FramingManager.getInstance().showConfirm(
          "CaliberRM plugin views associated with current session will be closed.\nDo you wish to proceed?"); //RES CloseViewsWarning_message

        if (result != JOptionPane.OK_OPTION) return;
      }

      for (int iView = 0; iView < pluginWorkspaceViews.length; iView++)
      {
        PluginManager.closeView (pluginWorkspaceViews [iView]);
      }

      try
      {
        session.logout();
      }
      catch (Exception ex)
      {
      }
      SessionManager.getInstance().setSession(source, null);
    }
  }
}
