package com.borland.dspspb.primetime.crmplugin.dialog;

import javax.swing.JPanel;
import java.awt.FlowLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;

public class ButtonsGroup extends JPanel
{
	public static final int LEFT = FlowLayout.LEFT;
	public static final int RIGHT = FlowLayout.RIGHT;
	public static final int CENTER = FlowLayout.CENTER;

	public ButtonsGroup (int align)
	{
		setLayout (new FlowLayout (align));
	}

	public void addButton (JButton button, ActionListener listener)
	{
		this.add (button);

    if (listener != null) button.addActionListener (listener);
	}
}
