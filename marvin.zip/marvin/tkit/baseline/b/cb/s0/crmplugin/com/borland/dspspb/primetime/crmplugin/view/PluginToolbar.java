package com.borland.dspspb.primetime.crmplugin.view;

import com.borland.dspspb.primetime.crmplugin.actions.*;
import com.borland.primetime.actions.*;
import java.awt.Component;
import java.awt.Container;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import com.borland.primetime.ide.Browser;
import com.borland.primetime.ide.StatusView;
import javax.swing.Action;

public class PluginToolbar extends ActionToolBarPane
{
  public PluginToolbar (Object source)
 {
    super (source);
    createActions ();
    setHorizontal(false);
  }

  private void createActions ()
 {
    ActionGroup group0 = new ActionGroup ("group0"); //NORES
    group0.add (new ActionEditSources ());
    group0.add (new ActionEditFilters ());

    ActionGroup group1 = new ActionGroup ("group1"); //NORES
    group1.add (new ActionLogout ());
    group1.add (new ActionSelectSource ());
    group1.add (new ActionSelectProject ());
    group1.add (new ActionSelectFilter ());

    ActionGroup group2 = new ActionGroup ("group2"); //NORES
    group2.add (new ActionToggleDetails ());
    group2.add (new ActionHierarchicalNumbers ());
    group2.add (new ActionSerialNumbers ());
    group2.add (new ActionTableOptions ());
    group2.add (new ActionCommentConfig ());

    ActionGroup group3 = new ActionGroup ("group3"); //NORES
    group3.add (new ActionRefresh ());
    group3.add (new ActionCheckForUpdate ());
    group3.add (new ActionRunCaliberRMClient());

    this.addGroup (group0);
    this.addGroup (group1);
    this.addGroup (group2);
    this.addGroup (group3);
  }

// -----------------------------------------------------------------------------

  public static void setHinter (ActionToolBarPane toolBarPane)
	{
    MouseAdapter hintMouseAdapter = new MouseAdapter ()
    {
      public void mouseEntered (MouseEvent e)
      {
        ActionButton button = (ActionButton)e.getSource ();

        StatusView statusView = Browser.getActiveBrowser ().getStatusView ();
        statusView.setHintText ((String) button.getAction ().getValue (Action.LONG_DESCRIPTION));
      }

      public void mouseExited (MouseEvent e)
      {
        StatusView statusView = Browser.getActiveBrowser ().getStatusView ();
        statusView.setHintText ("");
      }
    };

    Component [] actionToolBars = toolBarPane.getComponents();

    for (int i = 0; i < actionToolBars.length; i++)
    {
      Component actionToolBar = actionToolBars [i];
      Component [] buttonPanels = ((Container) actionToolBar).getComponents();

      for (int j = 0; j < buttonPanels.length; j++)
      {
        Component buttonPanel = buttonPanels [j];
        Component [] buttons = ((Container) buttonPanel).getComponents();

        for (int k = 0; k < buttons.length; k++)
        {
          Component button = buttons [k];

          if (button instanceof ActionButton)
          {
            button.addMouseListener (hintMouseAdapter);
          }
        }
      }
    }
	}
}
