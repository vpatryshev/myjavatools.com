package com.borland.dspspb.primetime.crmplugin.view;
import com.borland.primetime.actions.ActionToolBarPane;
import com.borland.primetime.actions.ActionGroup;
import com.borland.dspspb.primetime.crmplugin.actions.ActionUpdateComments;
import com.borland.dspspb.primetime.crmplugin.actions.ActionOpenComments;
import com.borland.dspspb.primetime.crmplugin.actions.ActionDeleteTraces;

public class TracePanelToolbar extends ActionToolBarPane
{
  public TracePanelToolbar(Object source)
  {
    super (source);
    createActions ();
    setHorizontal(true);
  }

  private void createActions ()
  {
    ActionGroup group0 = new ActionGroup ("group0"); //NORES
    group0.add (new ActionUpdateComments ());
    group0.add (new ActionOpenComments ());
    group0.add (new ActionDeleteTraces ());
    this.addGroup (group0);
  }
}
