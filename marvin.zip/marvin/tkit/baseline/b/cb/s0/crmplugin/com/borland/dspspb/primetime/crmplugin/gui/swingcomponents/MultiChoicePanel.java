package com.borland.dspspb.primetime.crmplugin.gui.swingcomponents;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class MultiChoicePanel extends JPanel {
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  JLabel leftTitle = new JLabel();
  JList leftList = new JList();
  JPanel centerPanel = new JPanel();
  JLabel rightLabel = new JLabel();
  JList rightList = new JList();
  GridLayout gridLayout1 = new GridLayout();
  JButton addButton = new JButton();
  JButton addAllButton = new JButton();
  JButton removeButton = new JButton();
  JButton removeAllButton = new JButton();
  JPanel downPodporka = new JPanel();
  JScrollPane rightPane = new JScrollPane(rightList,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED );
  JScrollPane leftPane = new JScrollPane(leftList,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED );
  DefaultListModel leftListModel = new DefaultListModel();
  DefaultListModel rightListModel = new DefaultListModel();

  public MultiChoicePanel(String leftLabelText,String rightLabelText) {

    leftTitle.setText(leftLabelText);
    leftList.setModel( leftListModel);
    rightList.setModel( rightListModel);
    leftListModel.addElement("Vasya");
    leftListModel.addElement("Pupkin");
    leftListModel.addElement("was");
    leftListModel.addElement("Here");
    this.setLayout(gridBagLayout1);
    rightLabel.setText(rightLabelText);
    centerPanel.setLayout(gridLayout1);
    addButton.setText("Add >");
    addButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        addButton_actionPerformed(e);
      }
    });
    addAllButton.setText("Add all >>");
    addAllButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        addAllButton_actionPerformed(e);
      }
    });
    removeButton.setText("< Remove");
    removeButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        removeButton_actionPerformed(e);
      }
    });
    removeAllButton.setToolTipText("");
    removeAllButton.setText("<< Remove All");
    removeAllButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        removeAllButton_actionPerformed(e);
      }
    });
    gridLayout1.setRows(4);
    gridLayout1.setColumns(1);
    gridLayout1.setHgap(3);
    gridLayout1.setVgap(6);
    this.add(leftTitle,       new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 12, 0, 0), 0, 0));
    this.add(leftPane,           new GridBagConstraints(0, 1, 1, 1, 1.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(3, 12, 6, 0), 150, 0));
    this.add(centerPanel,                 new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(50, 6, 50, 6), 0, 0));
    centerPanel.add(addButton, null);
    centerPanel.add(addAllButton, null);
    centerPanel.add(removeButton, null);
    centerPanel.add(removeAllButton, null);
    this.add(rightLabel,         new GridBagConstraints(2, 0, 2, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    this.add(rightPane,            new GridBagConstraints(2, 1, 1, 1, 1.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(3, 0, 6, 12), 150, 0));
    this.add(downPodporka,        new GridBagConstraints(0, 2, 5, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
  }

  public DefaultListModel getLeftListModel()
  {
     return leftListModel;
  }

  public DefaultListModel getRightListModel()
  {
     return rightListModel;
  }

  void addButton_actionPerformed(ActionEvent e)
  {
     int[] indexes = leftList.getSelectedIndices();
     for ( int i =0;i<indexes.length;i++ )
     {
        Object addObject=leftListModel.getElementAt(indexes[i]);
        if ( !rightListModel.contains(addObject) )
        {
            rightListModel.addElement( addObject );
        }
     }
  }

  void addAllButton_actionPerformed(ActionEvent e)
  {
     int sz = leftListModel.getSize();
     for ( int i =0;i<sz;i++ )
     {
        Object addObject=leftListModel.getElementAt(i);
        if ( !rightListModel.contains(addObject) )
        {
            rightListModel.addElement( addObject );
        }
     }
  }

  void removeAllButton_actionPerformed(ActionEvent e) {
     rightListModel.removeAllElements();
  }

  void removeButton_actionPerformed(ActionEvent e)
  {
     while ( rightList.getSelectedIndex()!=-1 )
     {
        rightListModel.removeElementAt( rightList.getSelectedIndex() );
     }
  }
}
