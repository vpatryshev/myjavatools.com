package com.borland.dspspb.primetime.crmplugin.gui.swingcomponents;

import javax.swing.JTextField;
import javax.swing.JComponent;
import javax.swing.JTextArea;
import java.awt.Dimension;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;

public class SwingTextArea extends SwingComponent
{
   private JTextArea textField;
   JScrollPane scrollPane;

   public SwingTextArea( String name,String displayName,Object value )
   {
      super ( name,displayName,value );
      textField = new JTextArea();
   }

   public void setEditable( boolean editable)
   {
     textField.setEditable( editable );
   }

   public void setValue(Object value )
   {
      super.setValue(value);
      if ( textField!=null )
      textField.setText( (String)value );
   }
   public Object getValue ()
   {
     return textField.getText();
   }


   public JComponent getMainComponent()
   {

         textField.setText( (String)getValue() );
          if ( scrollPane == null )
          {
            scrollPane = new JScrollPane(textField,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
            scrollPane.setMinimumSize( new Dimension(10,100) );
            scrollPane.setPreferredSize( new Dimension (0,100) );
          }
         return scrollPane;
   }
}
