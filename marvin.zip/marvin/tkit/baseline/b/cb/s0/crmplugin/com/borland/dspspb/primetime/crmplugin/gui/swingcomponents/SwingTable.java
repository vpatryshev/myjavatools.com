package com.borland.dspspb.primetime.crmplugin.gui.swingcomponents;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.table.AbstractTableModel;
import java.util.*;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.JTableHeader;
import java.awt.Component;
import com.borland.dspspb.primetime.crmplugin.gui.abstractcomponents.AbstractViewComponent;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.FlowLayout;
import java.awt.BorderLayout;
import java.text.SimpleDateFormat;

public class SwingTable extends AbstractViewComponent
 {
  public static final int DATA_TYPE_STRING=1;
  public static final int DATA_TYPE_NUMBER=2;
  public static final int DATA_TYPE_DATE=3;

  private static SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yy hh:mm");

    protected JTable internalTable = new JTable();
  JScrollPane scrollPane = new JScrollPane(internalTable,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED );
  JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
  JPanel myPanel = new JPanel(new BorderLayout());
    protected SwingTableModel model;
    private int sortOrder = SwingTableModel.ORDER_ASCENDING;
  private int currentColumn=0;
  private Vector tableButtons = new Vector();
    private static ImageIcon iconArrowUp;
  private static ImageIcon iconArrowDown;

  private HeaderListener headerListener;
  private HeaderRenderer headerRenderer;

//	private boolean buttonsDown = true;

    public static final String ADD_COLUMN_ACTION = "Add_Column";
    public static final String REMOVE_COLUMN_ACTION = "Remove_Column";

    public void SwingTable()
    {
    }

   public JTable getTable()
   {
      return internalTable;
   }

   public void addSelectionListener(ListSelectionListener lsl)
   {
      internalTable.getSelectionModel().addListSelectionListener( lsl );
   }

    public void updateRow( int rowNum,Object[] data )
    {
      model.setDataRow (rowNum,data);
      model.fireTableDataChanged();
  }

//	public void setButtonsPanelBelow(boolean below) {
//		buttonsDown = below;
//	}

    private void loadIcons ()
    {
        if ( iconArrowUp!=null );
        iconArrowUp = new ImageIcon(getClass().getClassLoader().getResource("com/borland/dspspb/resources/images/ui/arrowup.gif"));
        iconArrowDown = new ImageIcon(getClass().getClassLoader().getResource("com/borland/dspspb/resources/images/ui/arrowdown.gif"));
   }

    public void removeRow(String index)
    {
       model.removeRow(index);
       model.fireTableDataChanged();
    }
    public void removeRow(int index)
    {
       model.removeRow(index);
       model.fireTableDataChanged();
    }

    public void setColumnNames ( String[] columnNames )
    {
        model = new SwingTableModel(columnNames);
    internalTable.setModel ( model );
    if(headerListener == null) {
      headerListener = new HeaderListener();
      internalTable.getTableHeader().addMouseListener( headerListener );
    }
    internalTable.getTableHeader ().setReorderingAllowed( false );
    if(headerRenderer == null) {
      headerRenderer = new HeaderRenderer();
      internalTable.getTableHeader ().setDefaultRenderer (headerRenderer);
    }
  }
    public void addTableButton(JButton button) {
       addTableButton(button,null);
    }

  public void addTableButton(JButton button,String name) {
    tableButtons.add(button);
        button.setName(name);
  }

    public void addDataRow ( Object[] data )
    {
       model.addRow( data );
  }

  public void resort() {
    model.sort ( currentColumn, sortOrder );
  }

  public void setColumnType(int column, int sortType) {
    model.setColumnType(column, sortType);
  }
  public int getColumnType(int column) {
    return model.getColumnType(column);
  }

    public Object getUI()
  {
     model.sort ( currentColumn, sortOrder );
     internalTable.setModel( model );
     loadIcons();
     scrollPane.setPreferredSize( new Dimension(0,230) );
// OT+
    int maxWidth = 0;
    for(int i=0; i<tableButtons.size(); i++) {
      JButton btn = (JButton)tableButtons.get(i);
      maxWidth = Math.max(maxWidth, btn.getPreferredSize().width);
    }
    Dimension dim = new Dimension(maxWidth, 22);
    for(int i=0; i<tableButtons.size(); i++) {
      JButton btn = (JButton)tableButtons.get(i);
      btn.setPreferredSize(dim);
    }
    for(int i=0; i < tableButtons.size(); i++) {
      JButton btn = (JButton)tableButtons.get(i);
      buttonsPanel.add(btn);
    }
//		buttonsPanel.add(new JPanel(), FlowLayout.LEFT);

    if(tableButtons.size() != 0) {
      myPanel.add(buttonsPanel, BorderLayout.SOUTH);
    }
    myPanel.setBorder(BorderFactory.createEmptyBorder(3,6,0,0));
    myPanel.add(scrollPane, BorderLayout.CENTER);
//		System.out.println("Name: "+getName());
    myPanel.add(new JLabel(getName()), BorderLayout.NORTH);
//       return scrollPane;
    return myPanel;
// OT-
  }

    private class HeaderListener extends MouseAdapter
    {
       public void mouseClicked (MouseEvent event)
       {
         int col = internalTable.getColumnModel ().getColumnIndexAtX (event.getPoint ().x);
         String columnName = model.getColumnName (col);
         if (SwingUtilities.isLeftMouseButton (event))
         {
            if ( col==currentColumn )
            {
               if ( sortOrder == SwingTableModel.ORDER_ASCENDING ) sortOrder = SwingTableModel.ORDER_DESCENDING;
                 else sortOrder = SwingTableModel.ORDER_ASCENDING;

            }
            else sortOrder = SwingTableModel.ORDER_ASCENDING;
      model.sort ( col,sortOrder );

            currentColumn = col;
            internalTable.repaint();
            internalTable.getTableHeader().repaint();
         }
      }
    }

   public void removeInterval( int[] interval )
   {
      for ( int i=0;i<interval.length;i++ )
      {
        model.removeRow( interval[i] );
      }
      model.fireTableDataChanged();
   }

  private class HeaderRenderer extends JLabel implements TableCellRenderer
  {
      public HeaderRenderer ()
      {
          JTableHeader header = internalTable.getTableHeader ();
          setForeground (header.getForeground ());
          setBackground (header.getBackground ());
          setFont (header.getFont ());
          setBorder (BorderFactory.createCompoundBorder (UIManager.getBorder ("TableHeader.cellBorder"), BorderFactory.createEmptyBorder (0, 5, 0, 5)));
          setHorizontalTextPosition (JLabel.LEFT);
          setIconTextGap (10);
     }
     public Component getTableCellRendererComponent
                (JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
                {
                                if (column==currentColumn)
                                {
                                  setIcon (sortOrder == SwingTableModel.ORDER_ASCENDING ? iconArrowUp : iconArrowDown);
                                }
                                else
                                {
                                 setIcon (null);
                                }

                                setText (value.toString () );
                                return this;
                }

                public String getToolTipText ()
                {
                                String text = getText().trim();
                                return (text.length() == 0 ? null : text);
                }
    }
     public void clearData()
     {
        if(model != null)model.clearData();
     }

    public Collection getSelectedIndexes()
    {

       Vector result = new Vector();
       try
       {
                   int[] rows = internalTable.getSelectedRows();
                   for ( int i=0;i<rows.length;i++ )
                   {
                      result.add( internalTable.getValueAt(rows[i],0 ));
                   }
       }
       catch ( Exception e ){}
       return result;
    }


    public int getSelectedIndex() {
        return internalTable.getSelectedRow();
    }

    public SwingTableModel getModel() {
        return model;
    }

    public void fireTableDataChanged() {
        model.fireTableDataChanged();
    }


    private static class SwingTableModel extends AbstractTableModel
    {

       public static final int ORDER_ASCENDING=1;
       public static final int ORDER_DESCENDING=2;
     List columnNames;
     Vector rowData = new Vector();
     Hashtable colTypes = new Hashtable();
     public int getColumnType(int column) {
    Integer i = (Integer)colTypes.get(new Integer(column));
    if(i == null)return DATA_TYPE_STRING;
    else return i.intValue();
     }
     public void setColumnType(int column, int sortType) { colTypes.put(new Integer(column), new Integer(sortType)); }

       public SwingTableModel( String[] columnNamesArray )
       {
           columnNames = Arrays.asList(columnNamesArray);
       }

       public void clearData()
       {
           rowData.clear();
           this.fireTableDataChanged();
       }

       public void setDataRow( int rowId ,Object[] data )
       {
           rowData.setElementAt( data,rowId );
       }

       public void addRow ( Object[] data )
       {
         rowData.add (data);
         this.fireTableDataChanged();
       }

       public void removeRow(int index)
       {
          rowData.remove(index);
       }

       public void removeRow(String index)
       {
          Iterator i = rowData.iterator();
          while ( i.hasNext() )
          {
                Object[] row = (Object[])i.next();
                if ( row==null || row.length==0 ) continue;
                if ( index.equals(row[0]) )
                {
                     rowData.remove( row );
                     return;
                }
          }
       }

       public String getColumnName( int index)
       {
         return (String)columnNames.get(index);
       }

       public int getRowCount()
       {
          return rowData.size();
       }

       public int getColumnCount()
       {
          return columnNames.size();
       }

       public Object getValueAt(int row, int column)
       {
           Object[] rowArray = (Object[])rowData.elementAt(row);
           try
           {
              return rowArray[column];
           }
           catch ( Exception e )
           {
              return "-";
           }

       }

    public void sort ( int columnNum,int order) {
      sort(columnNum, order, getColumnType(columnNum));
    }

     public void sort ( int columnNum,int order,int dataType )
       {
            Comparator comparator = new SortComparator ( columnNum,order,dataType );

            Collections.sort ( rowData,comparator );
       }

       private static class SortComparator implements Comparator
       {
          int orderKoef = 1;
          private int cDataType = DATA_TYPE_STRING;
          int columnNum = 0;
          public SortComparator( int columnNum,int order,int dataType )
          {
             this.columnNum = columnNum;
             if ( order == ORDER_DESCENDING ) orderKoef =-1;
             this.cDataType=dataType;
          }

          public int compare ( Object o1Array,Object o2Array )
          {
               if ( o1Array==null || o2Array==null ) return 0;
               Object o1 = ((Object[])o1Array)[columnNum];
               Object o2 = ((Object[])o2Array)[columnNum];
               if ( o1==null || o2==null ) return 0;
               if ( cDataType == DATA_TYPE_NUMBER )
               {
                  try
                  {
                    float f1 = Float.parseFloat( (String)o1 );
                    float f2 = Float.parseFloat( (String)o2 );
                    if ( f1*orderKoef > f2*orderKoef ) return 1; else return -1;
                  }
                  catch ( Exception e) { return 0; }
         }
        else if ( cDataType == DATA_TYPE_NUMBER )
        {
          try
          {
            long lg1 = dateFormat.parse( (String)o1 ).getTime();
            long lg2 = dateFormat.parse( (String)o2 ).getTime();
            if ( lg1*orderKoef > lg2*orderKoef ) return 1; else return -1;
          }
          catch ( Exception e) { return 0; }
        }
               else
         {
// OT +
          try
          {
            float f1 = Float.parseFloat( (String)o1 );
            float f2 = Float.parseFloat( (String)o2 );
            if ( f1*orderKoef > f2*orderKoef ) return 1; else return -1;
          }
          catch ( Exception e) { }
// OT-
          try
          {
                      String s1 = (String)o1;
                      String s2 = (String)o2;
                      return orderKoef*s1.compareTo(s2);
          }
          catch ( Exception e) { }

          return 0;
               }
          }

       }


    }

}
