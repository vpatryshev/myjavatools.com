package com.borland.dspspb.primetime.crmplugin.view.rvtreetable;

import java.util.*;

import java.awt.*;
import java.awt.Image;
import java.awt.dnd.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;

import com.borland.dspspb.primetime.crmplugin.gui.treetable.*;
import com.borland.dspspb.primetime.crmplugin.management.*;
import com.borland.dspspb.primetime.crmplugin.opentool.*;
import com.borland.dspspb.primetime.crmplugin.resources.*;
import com.borland.dspspb.primetime.crmplugin.ui.*;
import com.borland.dspspb.primetime.crmplugin.view.*;
import com.borland.primetime.node.*;
import com.starbase.caliber.*;
import com.starbase.caliber.Project;
import com.starbase.caliber.server.*;
import com.borland.dspspb.primetime.crmplugin.actions.ActionRunCaliberRMClient;
import java.text.MessageFormat;
import java.lang.reflect.*;
import com.starbase.caliber.util.HTMLHelper;

public class RVTreeTable extends JTreeTable implements TableModelListener, DragSourceListener, DragGestureListener, TreeWillExpandListener
{
  private DragSource dragSource = null;

  private static ImageIcon iconDragCursor	= null;
  private static Cursor dragCursor = null;

  private Source m_source = null;
  private boolean m_bSourceFailed = false;
  private PluginView ownerView = null;

  // Load icon(s)
  static
  {
    iconDragCursor = ResourceManager.getIcon (ResourceManager.RVTreeTable_DragCursor_icon);
    dragCursor = createDragCursor ();
  }

  public RVTreeTable(PluginView ownerView, RVTreeTableModel treeTableModel)
  {
    super(treeTableModel);

    this.ownerView = ownerView;

    init();

		HeaderRenderer renderer = new HeaderRenderer ();
		getTableHeader ().setDefaultRenderer (renderer);

    // Set mouse listener
    addMouseListener(new MouseAdapter()
    {
      public void mousePressed(MouseEvent e)
      {
        if (SwingUtilities.isRightMouseButton(e))
        {
          int row = rowAtPoint(e.getPoint());
          setRowSelectionInterval(row, row);
        }
      }

      public void mouseReleased(final MouseEvent e)
      {
        if (SwingUtilities.isRightMouseButton(e))
        {
          if (e.isPopupTrigger())
          {
            TableNodeAdapter selectedNode = getSelectedNode();
            if (selectedNode == null || !(selectedNode instanceof RequirementNode))
              return;
            JPopupMenu popupMenu = new JPopupMenu();
            ActionRunCaliberRMClient actionRunCaliberRMClient = new ActionRunCaliberRMClient()
            {
              public void actionPerformed(ActionEvent e)
              {
                e.setSource(getView());
                super.actionPerformed(e);
              }
            };
            actionRunCaliberRMClient.putValue(Action.NAME, actionRunCaliberRMClient.getShortText());
            popupMenu.add(actionRunCaliberRMClient);
            Node node = FramingManager.getInstance().getActiveNode();
            INodeSteward nodeSteward = NodeStewardsManager.findSteward(node);
            if (nodeSteward != null)
            {
              Requirement requirement = ((RequirementNode)selectedNode).getRequirement();
              Action[] actions = nodeSteward.getActions(node, requirement);
              if (actions != null && actions.length != 0)
              {
                popupMenu.addSeparator();
                for (int i = 0; i < actions.length; i++)
                {
                  popupMenu.add(actions[i]);
                }
              }
            }
            popupMenu.show(RVTreeTable.this, e.getX(), e.getY());
          }
        }
      }
    });
  }

  private PluginView getView()
  {
    return ownerView;
  }

  public void setModel(TreeTableModel treeTableModel, boolean bFlat)
  {
    updateModel(treeTableModel);

    init();

    sortColumn = -1;
  }

// -----------------------------------------------------------------------------

  private void init()
  {
    setShowGrid(true);
    setGridColor(Color.lightGray);
    getSelectionModel().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    getTableHeader().setReorderingAllowed(false);

    getTree().setRootVisible(false);

    for (int i = 0; i < getRowCount(); i++)
    {
      getTree().expandRow(i);
    }

    if (getColumnCount() > 1)
    {
      getColumnModel().getColumn(0).setPreferredWidth(300);
    }

    if (getRowCount() > 0) setRowSelectionInterval (0, 0);

    dragSource = new DragSource();
    dragSource.createDefaultDragGestureRecognizer(this, DnDConstants.ACTION_COPY, this);

//    getTree ().addTreeWillExpandListener (this);
  }

  public void runSource(Source source)
  {
    TreeTableModelAdapter tableAdapter = (TreeTableModelAdapter)getModel();
    RVTreeTableModel tableModel = (RVTreeTableModel)tableAdapter.getTreeTableModel();
    TableNodeAdapter nodeRoot = (TableNodeAdapter)tableModel.getRoot();
    if (source == null)
    {
      m_source = source;
      nodeRoot.removeAllChildren();
      updateUI();
      return;
    }
    Session session = source.getSession();
    if (session == null)
    {
      if (source.loadPassword() != null)
      {
        try
        {
          CaliberServer server = new CaliberServer(source.getServer());
          session = server.login(source.getLogin(), source.loadPassword());
          source.setSession(session);
        }
        catch (Exception e)
        {
        }
      }
      if (session == null)
      {
        DlgCaliberLogin dlgLogin = new DlgCaliberLogin(FramingManager.getInstance().getMainFrame(), source);
        if (!dlgLogin.showDialog() || source.getSession() == null)
          return;
      }
    }
    rerunSource(source);
  }

  public void rerunSource(final Source source)
  {
    TreeTableModelAdapter tableAdapter = (TreeTableModelAdapter)getModel();
    RVTreeTableModel tableModel = (RVTreeTableModel)tableAdapter.getTreeTableModel();
    final TableNodeAdapter nodeRoot = (TableNodeAdapter)tableModel.getRoot();
    if (source == null)
    {
      m_source = source;
      nodeRoot.removeAllChildren();
      updateUI();
      return;
    }
    getTree().removeTreeWillExpandListener(this);
    Runnable run = new Runnable()
    {
      public void run()
      {
        m_source = source;
        nodeRoot.removeAllChildren();
        SourceNode sourceNode = new SourceNode(source);
        nodeRoot.add(sourceNode);
        createSourceTree(sourceNode);
        updateUI();
      }

    };
    if (SwingUtilities.isEventDispatchThread())
      run.run();
    else
    {
      try
      {
        SwingUtilities.invokeAndWait(run);
      }
      catch (InvocationTargetException ex)
      {
      }
      catch (InterruptedException ex)
      {
      }
    }
    getTree().addTreeWillExpandListener(this);
  }

  public Source getSource()
  {
    return m_source;
  }

  public boolean isSourceFailed()
  {
    return m_bSourceFailed;
  }

  public void setSourceFailed(boolean bFailed)
  {
    m_bSourceFailed = bFailed;
  }

  private void createRequirementSubtree(TableNodeAdapter treeTableNode, boolean bRecursive)
  {
    RequirementTreeNode rtnRequirement = (RequirementTreeNode) treeTableNode.getUserObject ();
    if (rtnRequirement.getChildCount () > 0)
    {
      RequirementTreeNode[] rtnRequirements = rtnRequirement.getChildren ();
      for (int j = 0; j < rtnRequirements.length; j++)
      {
        RequirementNode newRequirementNode = new RequirementNode (rtnRequirements[j]);
        newRequirementNode.setContext(ownerView);
        treeTableNode.add (newRequirementNode);
        if (bRecursive)
          createRequirementSubtree(newRequirementNode, bRecursive);
      }
    }
  }

  public Exception initRequirementSubtree(final TableNodeAdapter treeTableNode)
  {
    Vector children = treeTableNode.getChildren();
    if (children == null || children.size() == 0)
      return null;
    Session session = m_source.getSession();
    if (session == null)
      return null;
    if (!((children.get(0) instanceof RequirementNode)))
      return null;
     if (((RequirementNode)children.get(0)).getRequirement() != null)
      return null;

    Exception exceptionCatched = null;
    Vector ids = new Vector();
    for (int i = 0; i < children.size (); i++)
    {
      ids.add(new RequirementID(((RequirementTreeNode)((RequirementNode)children.get(i)).getUserObject()).getAssociatedObjectID().getIDNumber()));
//      ids.add(((RequirementTreeNode)((RequirementNode)children.get(i)).getUserObject()).getAssociatedObjectID());
    }
    try
    {
      Requirement[] associatedRequirements = (Requirement[])session.get((CaliberObjectID[])ids.toArray(new CaliberObjectID[0]), Requirement.class);
      for (int i = 0; i < children.size (); i++)
      {
        ((RequirementNode)children.get(i)).setRequirement(associatedRequirements[i]);
      }
    }
    catch (Exception e)
    {
      exceptionCatched = e;
    }

    if (exceptionCatched != null)
    {
      Runnable run = new Runnable()
      {
        public void run()
        {
          treeTableNode.removeAllChildren();
          treeTableNode.add(new TableNodeAdapter("Operation failed...") //RES TableNode_Operation_failed
          {
            public Icon getIcon(boolean bExpanded)
            {
              return ResourceManager.getIcon(ResourceManager.ErrorCross_icon);
            }
          });
        }
      };
      if (SwingUtilities.isEventDispatchThread())
        run.run();
      else
      {
        try
        {
          SwingUtilities.invokeAndWait(run);
        }
        catch (InvocationTargetException ex)
        {
        }
        catch (InterruptedException ex)
        {
        }
      }
      setSourceFailed(true);
    }
    return exceptionCatched;
  }

  public boolean createSourceTree(SourceNode sourceNode)
  {
    Source source = sourceNode.getSource();
    try
    {
      Session session = source.getSession();
      if (session == null)
        return false;
      Project project = CaliberManager.getInstance().getProject(source);
      if (project == null)
        return false;
      Baseline baseline = CaliberManager.getInstance().getBaseline(source);
      if (baseline == null)
//GMS+        return false;
          baseline = project.getCurrentBaseline();
      FramingManager.showWaitCursor(true);
      RequirementTree reqTree = baseline.getRequirementTree();
      RequirementTreeNode rtnRoot = reqTree.getRoot();
      ProjectNode projectNode = new ProjectNode(rtnRoot); // ???
      projectNode.setProject(project);
      projectNode.setBaseline(baseline);
      sourceNode.add(projectNode); // ???
      RequirementTreeNode[] rtnReqTypes = rtnRoot.getChildren();
      // Sort requirement types
      Vector rtnReqTypesList = new Vector();
      for (int i = 0; i < rtnReqTypes.length; i++)
      {
        rtnReqTypesList.add(rtnReqTypes[i]);
      }
      Collections.sort(rtnReqTypesList, new Comparator()
      {
        public int compare(Object o1, Object o2)
        {
          RequirementTreeNode n1 = (RequirementTreeNode)o1;
          RequirementTreeNode n2 = (RequirementTreeNode)o2;
          return n1.getName().compareTo(n2.getName());
        }
      });
      // Create tree nodes for requirement types
      for (int i = 0; i < rtnReqTypesList.size(); i++)
      {
        RequirementTypeNode reqTypeNode = new RequirementTypeNode(rtnReqTypesList.get(i));
        projectNode.add(reqTypeNode);
        createRequirementSubtree(reqTypeNode, true);
      }
      // init tree nodes for requirement types
      Vector children = projectNode.getChildren();
      Vector ids = new Vector();
      for (int i = 0; i < children.size (); i++)
      {
        ids.add(((RequirementTreeNode)((RequirementTypeNode)children.get(i)).getUserObject()).getAssociatedObjectID());
      }
      try
      {
        RequirementType[] associatedRequirementTypes = (RequirementType[])session.get((CaliberObjectID[])ids.toArray(new CaliberObjectID[0]), RequirementType.class);
        for (int i = 0; i < children.size (); i++)
        {
          ((RequirementTypeNode)children.get(i)).setRequirementType(associatedRequirementTypes[i]);
        }
      }
      catch (RemoteServerException ex)
      {
      }
      expandNode(projectNode);
    }
    catch (RemoteServerException e)
    {
      FramingManager.showWaitCursor(false);
      FramingManager.getInstance().showError("Failed to get list of requirements from source " + //RES RVTreeTable_Message1
                                             source.getName() + "."); //NORES
      return false;
    }

    expandNode(sourceNode);
    FramingManager.showWaitCursor(false);
    return true;
  }

  private TableNodeAdapter findRequirementNode(TableNodeAdapter node, int requirementIDNumber)
  {
    Vector children = node.getChildren();
    if (children == null || children.size() == 0)
      return null;
    for (int i = 0; i < children.size(); i++)
    {
      TableNodeAdapter child = (TableNodeAdapter)children.get(i);
      if ((child.getUserObject() instanceof RequirementTreeNode) &&
          (((RequirementTreeNode)(child.getUserObject())).getAssociatedObjectID().getIDNumber() == requirementIDNumber))
        return child;
      TableNodeAdapter found = findRequirementNode(child, requirementIDNumber);
      if (found != null)
      {
        return found;
      }
    }
    return null;
  }

  public void showRequirementNode(int requirementIDNumber)
  {
    FramingManager.showWaitCursor(true);
    TreeTableModelAdapter tableAdapter = (TreeTableModelAdapter) getModel ();
    RVTreeTableModel tableModel = (RVTreeTableModel)tableAdapter.getTreeTableModel();
    TableNodeAdapter nodeRoot = (TableNodeAdapter) tableModel.getRoot ();
    TableNodeAdapter found = findRequirementNode(nodeRoot, requirementIDNumber);
    if (found == null)
    {
      FramingManager.getInstance().showWaitCursor(false);
      FramingManager.getInstance().showMessage
        ("Requirement with the specified ID not found in the project."); //RES RVTreeTable_Message2
      return;
    }
    TreePath treePath = new TreePath(found.getPath());
    Vector parents = new Vector();
    TableNodeAdapter parent = found;
    while ((parent = (TableNodeAdapter)parent.getParent()) != null)
      parents.add(parent);
    for (int i = parents.size() - 1; i >= 0; i--)
      getTree().expandPath(new TreePath(((TableNodeAdapter)parents.get(i)).getPath()));
    int row = getTree().getRowForPath(treePath);
    if (row == -1)
    {
      while (row == -1)
      {
        treePath = treePath.getParentPath();
        row = getTree().getRowForPath(treePath);
      }
      row++;
    }
    setRowSelectionInterval(row, row);
    scrollRectToVisible(getCellRect(getSelectedRow(), 0, true));
    FramingManager.showWaitCursor(false);
  }

// -----------------------------------------------------------------------------

  public TableNodeAdapter getSelectedNode()
  {
    int selectedRow = getSelectedRow();

    if (selectedRow == -1)
      return null;

    TreeTableModelAdapter model = (TreeTableModelAdapter)getModel();
    return (TableNodeAdapter)model.nodeForRow(selectedRow);
  }

  public Object getSelectedObject()
  {
    TableNodeAdapter selectedNode = getSelectedNode();
    Object selectedObject = null;
    if (selectedNode != null)
    {
      if (selectedNode instanceof RequirementNode)
        selectedObject = ((RequirementNode)selectedNode).getRequirement();
      else if (selectedNode instanceof RequirementTypeNode)
        selectedObject = ((RequirementTypeNode)selectedNode).getRequirementType();
      else if (selectedNode instanceof ProjectNode)
        selectedObject = ((ProjectNode)selectedNode).getProject();
      else if (selectedNode instanceof SourceNode)
        selectedObject = ((SourceNode)selectedNode).getSource();
    }
    return selectedObject;
  }

  public TableNodeAdapter getNodeForRow(int row)
  {
    TreeTableModelAdapter model = (TreeTableModelAdapter)getModel();
    return (TableNodeAdapter)model.nodeForRow(row);
  }

  public int getRowForNode(TreeNode node)
  {
    if (node == null)
      return -1;
    TreeNode pathNode = node;
    Vector path = new Vector();
    while (pathNode != null)
    {
      path.add(0, pathNode);
      pathNode = pathNode.getParent();
    }
    TreePath treePath = new TreePath(path.toArray());
    return getTree().getRowForPath(treePath);
  }

//------------------------------------------------------------------------------

  public void dragEnter(DropTargetDragEvent event)
  {
    event.acceptDrag(DnDConstants.ACTION_MOVE);
  }

  public void dragExit(DropTargetEvent event)
  {
  }

  public void dragOver(DropTargetDragEvent event)
  {
  }

  public void dropActionChanged(DropTargetDragEvent event)
  {
  }

  public void dragGestureRecognized(DragGestureEvent event)
  {
    TableNodeAdapter selectedNode = getSelectedNode();

    if (selectedNode == null || !(selectedNode instanceof RequirementNode))
      return;

    try
    {
      dragSource.startDrag(event, DragSource.DefaultMoveNoDrop, (RequirementNode)selectedNode, this);
    }
    catch (InvalidDnDOperationException ex)
    {
      ex.printStackTrace();
      return;
    }
  }

  public void dragDropEnd(DragSourceDropEvent dsde)
  {
    if (dsde.getDropSuccess())
    {
      // Update views
      int selectedRow = getSelectedRow();
      TreeTableModelAdapter model = (TreeTableModelAdapter)getModel();
      model.fireTableRowsUpdated(selectedRow, selectedRow);
      updateTracePanel(getSelectedNode());
    }
  }

  public void dragEnter(DragSourceDragEvent event)
  {
    event.getDragSourceContext().setCursor(dragCursor);
  }

  public void dragExit(DragSourceEvent event)
  {
    event.getDragSourceContext().setCursor(DragSource.DefaultMoveNoDrop);
  }

  public void dragOver(DragSourceDragEvent event)
  {
    Cursor cursor = event.getDragSourceContext().getCursor();
    if (!dragCursor.equals(cursor))
      event.getDragSourceContext().setCursor(dragCursor);
  }

  public void dropActionChanged(DragSourceDragEvent event)
  {
  }

  public void expandNode(TableNodeAdapter node)
  {
    expandNode(node, false);
  }

  public void expandNode(TableNodeAdapter node, boolean recursive)
  {
    try
    {
      getTree().expandPath(new TreePath(node.getPath()));
      if (recursive)
      {
        Enumeration myEnum = node.children();
        while (myEnum.hasMoreElements())
        {
          expandNode((TableNodeAdapter)myEnum.nextElement());
        }
      }
    }
    catch (Exception ex)
    {
    }
  }

// -----------------------------------------------------------------------------

  public void valueChanged (ListSelectionEvent e)
  {
    super.valueChanged(e);

    Object selectedObject = getSelectedObject();
    updateDescriptionPanel(selectedObject);
    updateTracePanel(getSelectedNode());
    updateAttributesPanel(selectedObject);
  }

  // Background color for non-requirement descriptions
  private static Color bgColor = new JLabel ().getBackground();

  private void updateDescriptionPanel (Object selectedObject)
  {
    if (ownerView == null) return;

    String description = ""; //NORES
    final DescriptionPanel descPanel = ownerView.getDescriptionPanel();

    if (selectedObject == null)
    {
      descPanel.setText(description);
      descPanel.setBackground (bgColor);
      return;
    }

    if (selectedObject instanceof Source)
    {
      Source source = (Source) selectedObject;
      description = Utils.getSourceDescription (source);
      descPanel.setBackground (bgColor);
    }
    if (selectedObject instanceof Project)
    {
      Project project = (Project) selectedObject;
      description = project.getDescription();
      descPanel.setBackground (bgColor);
    }
    if (selectedObject instanceof RequirementType)
    {
      RequirementType reqType = (RequirementType) selectedObject;
      description = reqType.getDescription();
      descPanel.setBackground (bgColor);
    }
    else if (selectedObject instanceof Requirement)
    {
      Requirement req = (Requirement) selectedObject;
      description = req.getDescription().getText();
      // Check if embedded images are present
      int ids[] = null;
      try
      {
        ids = HTMLHelper.getImageIDs(description);
      }
      catch (Exception ex)
      {
      }
      descPanel.setBackground (Color.white);

      if ((ids != null) && (ids.length > 0))
      {
        final int[] finalIds = ids;
        final String finalDescription = description;
        // Ensure embedded images visibility
        ICaliberOperation operation = new ICaliberOperation()
        {
          boolean bResult = true;

          public void run()
          {
            FramingManager.showWaitCursor(true);
            try
            {
              Session session = getSource().getSession ();
              ImageManager imageManager = (ImageManager)session.getManager (com.starbase.caliber.Image.class);
              imageManager.populateCache (finalIds);
            }
            catch (Exception ex)
            {
              bResult = false;
            }
            descPanel.setText(finalDescription);
            descPanel.setCaretPosition(0);
            FramingManager.showWaitCursor(false);
          }

          public boolean getResult()
          {
            return bResult;
          }

          public void setCanceled()
          {
          }

          public void onSuccess()
          {
          }

          public void onError()
          {
            FramingManager.showWaitCursor(false);
            String failMessage =
              "Failed to get description images from server" + //RES RVTreeTable_Failed_to_get_images
              " " + getSource().getServer() + "."; //NORES
            FramingManager.getInstance().showError(failMessage);
          }

          public void onCancel()
          {
            descPanel.setText(finalDescription);
            descPanel.setCaretPosition(0);
            FramingManager.showWaitCursor(false);
          }
        };

        CaliberAccess caliberAccess = new CaliberAccess(operation);
        caliberAccess.setMessage("Retrieving description images from server..."); //RES RVTreeTable_Retrieving_images
        caliberAccess.perform();
        return;
      }
    }
    else
    {
      descPanel.setBackground (bgColor);
    }

    descPanel.setText(description);
    descPanel.setCaretPosition(0);
  }

// -----------------------------------------------------------------------------
// Disable change selection while dragging

  private boolean canSelect = true;

  protected void processMouseEvent (MouseEvent e)
  {
    canSelect = (e.getID() != MouseEvent.MOUSE_DRAGGED);
    super.processMouseEvent (e);
  }

  protected void processMouseMotionEvent (MouseEvent e)
  {
    canSelect = (e.getID() != MouseEvent.MOUSE_DRAGGED);
    super.processMouseMotionEvent (e);
  }

  public void setRowSelectionInterval (int index0, int index1)
  {
    if (canSelect) super.setRowSelectionInterval(index0, index1);
  }

  public void changeSelection (int rowIndex, int columnIndex, boolean toggle, boolean extend)
  {
    if (canSelect) super.changeSelection(rowIndex, columnIndex, toggle, extend);
  }

// -----------------------------------------------------------------------------

  private static Cursor createDragCursor ()
  {
    Image image = iconDragCursor.getImage();
    Cursor dragCursor = Toolkit.getDefaultToolkit ().createCustomCursor (image, new Point (0, 0), ""); //NORES
    return dragCursor;
  }

// -----------------------------------------------------------------------------

  public void updateTracePanel (TableNodeAdapter selectedNode)
  {
    if (ownerView == null) return;

    TracesPanel tracePanel = ownerView.getTracesPanel();

    if (!(selectedNode instanceof RequirementNode))
    {
      ownerView.setVisibleTracesPanel (false);
      return;
    }

    ownerView.setVisibleTracesPanel (true);

    RequirementNode reqNode = ((RequirementNode) selectedNode);

    TraceTable toTable = tracePanel.getTable ();
		Vector vTracesInfo = reqNode.getTracesInfo();

    toTable.updateModel (vTracesInfo);
	}

//------------------------------------------------------------------------------

  public TableNodeAdapter getRootNode()
  {
    TreeTableModelAdapter tableAdapter = (TreeTableModelAdapter)getModel();
    RVTreeTableModel tableModel = (RVTreeTableModel)tableAdapter.getTreeTableModel();
    TableNodeAdapter nodeRoot = (TableNodeAdapter)tableModel.getRoot();
    return nodeRoot;
  }

  private void findNonInitializedRequirements(TableNodeAdapter node, int numberOfRequirements, Vector objectIDs, HashMap mapID2Node)
  {
    Vector children = node.getChildren();
    for (int i = 0; i < children.size(); i++)
    {
      TableNodeAdapter childNode = (TableNodeAdapter)children.get(i);
      if (childNode instanceof RequirementNode)
      {
        numberOfRequirements++;
        if (((RequirementNode)childNode).getRequirement() == null)
        {
          CaliberObjectID objectID = ((RequirementTreeNode)childNode.getUserObject()).getAssociatedObjectID();
          objectIDs.add(objectID);
          mapID2Node.put(objectID, childNode);
        }
      }
      if (childNode.getChildCount() > 0)
        findNonInitializedRequirements(childNode, numberOfRequirements, objectIDs, mapID2Node);
    }
  }

  public boolean initAllRequirements()
  {
    TableNodeAdapter rootNode = getRootNode();
    Vector objectIDs = new Vector();
    HashMap mapIDs2Node = new HashMap();
    int numberOfRequirements = 0;
    findNonInitializedRequirements(rootNode, numberOfRequirements, objectIDs, mapIDs2Node);
    if (objectIDs.size() == 0)
      return true;
    Session session = SessionManager.getInstance().getSession(getSource());
    try
    {
      CaliberObjectID[] ids = (CaliberObjectID[])objectIDs.toArray(new CaliberObjectID[objectIDs.size()]);
      Requirement[] requirements = (Requirement[])session.get(ids, Requirement.class);
      for (int i = 0; i < ids.length; i++)
      {
        ((RequirementNode)mapIDs2Node.get(ids[i])).setRequirement(requirements[i]);
      }
    }
    catch (RemoteServerException ex)
    {
      return false;
    }
    return true;
  }

  private void updateAttributesPanel(Object selectedObject)
  {
    if (ownerView == null)
      return;
    AttributesPanel attrPanel = ownerView.getAttributesPanel();
    if (selectedObject instanceof Requirement)
      attrPanel.showAttributes((Requirement)selectedObject);
    else
      attrPanel.showAttributes(null);
  }

  public void treeWillCollapse(TreeExpansionEvent event)
  {
  }

  public void treeWillExpand (final TreeExpansionEvent event)
  {
    final TableNodeAdapter tableNode = (TableNodeAdapter)event.getPath ().getLastPathComponent ();
    ICaliberOperation operation = new ICaliberOperation()
    {
      Exception m_exceptionCatched = null;
      public void run()
      {
        FramingManager.showWaitCursor(true);
        m_exceptionCatched = initRequirementSubtree(tableNode);
      }

      public boolean getResult()
      {
        return (m_exceptionCatched == null);
      }

      public void setCanceled()
      {
      }

      public void onSuccess()
      {
        FramingManager.showWaitCursor(false);
      }

      public void onError()
      {
        FramingManager.showWaitCursor(false);
        String failMessage =
          "Failed to get requirement(s) info from server" + //RES Failed_to_get_requirements_info
          " " + m_source.getServer() + "."; //NORES
        if (m_exceptionCatched instanceof RemoteServerException)
        {
          failMessage += "\n"; //NORES
          failMessage += "Please verify that the server is running and accessible, then try to refresh view."; //RES Verify_server_then_refresh_view
        }
        else
        {
          String strExceptionMessage = MessageFormat.format("Exception {0} occurred: {1}", //RES Exception_class_occured_message
            new String[] {m_exceptionCatched.getClass().getName(), m_exceptionCatched.getLocalizedMessage()});
            failMessage += "\n"; //NORES
          failMessage += strExceptionMessage;
        }
        FramingManager.getInstance().showError(failMessage);
      }

      public void onCancel()
      {
        tableNode.removeAllChildren();
        tableNode.add(new TableNodeAdapter("Operation aborted...") //RES TableNode_Operation_aborted
        {
          public Icon getIcon (boolean bExpanded)
          {
            return ResourceManager.getIcon(ResourceManager.ErrorCross_icon);
          }
        });
        FramingManager.showWaitCursor(false);
      }
    };

    CaliberAccess caliberAccess = new CaliberAccess(operation);
    caliberAccess.perform();
  }
}
