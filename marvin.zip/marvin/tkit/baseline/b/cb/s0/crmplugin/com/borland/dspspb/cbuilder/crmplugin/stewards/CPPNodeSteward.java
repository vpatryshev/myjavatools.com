package com.borland.dspspb.cbuilder.crmplugin.stewards;

import java.io.*;
import java.util.*;
import java.awt.*;
import javax.swing.*;

import com.borland.primetime.editor.*;
import com.borland.primetime.ide.*;
import com.borland.primetime.node.*;
import com.borland.primetime.node.Project;
import com.borland.primetime.util.*;
import com.borland.primetime.vfs.*;

import com.borland.cbuilder.ide.*;
import com.borland.cbuilder.node.*;
import com.borland.cbuilder.parser.*;
import com.borland.cbuilder.util.*;
import com.borland.cbuilder.viewer.*;
import com.borland.dspspb.primetime.crmplugin.opentool.*;
import com.starbase.caliber.*;

public class CPPNodeSteward
  extends Tracer implements INodeSteward {

  private static final String STEWARD_ID = "C++.Source"; //NORES
  private static final String FIELD_ENDREQ = "_end"; //NORES
  private static final String FIELD_REQUIREMENT = "requirement"; //NORES
  private static final String FIELD_COMMENT = "comment"; //NORES
  private static final String TAG_PREFIX = "@"; //NORES

  private static final int OP_GETSTATUS = 0x0001;
  private static final int OP_CREATE = 0x0002;
  private static final int OP_UPDATE = 0x0003;
  private static final int OP_DELETE = 0x0004;
  private static final int OP_OPEN = 0x0005;

  /**
   * Tag that stores the custom comment locator
   */
  static final String COMMENT_TAG = TAG_PREFIX + FIELD_COMMENT;

  /**
   * Tag that identifies a requirement
   */
  static final String REQUIREMENT_TAG = TAG_PREFIX + FIELD_REQUIREMENT;

  static class LocatorHolder {
    private String commentLocator = null;
    private String requirementLocator = null;
  }

  /**
   * Constructs instance of Node Steward for C++ files
   */
  public CPPNodeSteward() {
    super(com.borland.dspspb.cbuilder.crmplugin.Main.class);

    EditorManager.registerContextActionProvider(new EditorContextActionProvider() {
      public Action getContextAction(EditorPane editor) {
        Node node = Browser.getActiveBrowser().getActiveNode();
        if (!(node instanceof CParseableFileNode)) {
          return null;
        }
        ActionGoToRequirement action = new ActionGoToRequirement(editor);
        return (action.findRequirementLocator() ? action : null);
      }

      public int getPriority() {
        return 0;
      }
    });
  }

  /**
   * Returns ID of this steward
   * @return String
   */
  public String getId() {
    return STEWARD_ID;
  }

  /**
   * Returns icon for this steward
   * @return Icon
   */
  public Icon getIcon() {
    return CPPFileNode.ICON;
  }

  /**
   * Return components that will handle D&D
   * @param node Node
   * @return Component[]
   */
  public Component[] getDropEagerComponents(Node node) {
    trace("getDropEagerComponents {0}", node.getDisplayName()); //NORES
    if (node == null || !(node instanceof CParseableFileNode)) {
      return null;
    }

    Browser browser = Browser.getActiveBrowser();
    NodeViewer[] nodeViewers = browser.getViewers(node);
    Vector found = new Vector();

    for (int i = 0; i < nodeViewers.length; i++) {
      if (!(nodeViewers[i] instanceof CPPNodeSourceViewer)) {
        continue;
      }
      findDropEagerComponents(nodeViewers[i].getViewerComponent(), found);
    }
    return (Component[]) found.toArray(new Component[0]);
  }

  /**
   * Helper routine to dump a point
   * @param point Point
   * @return String
   */
  private static String dump(Point point) {
    if (point == null) {
      return "(null)"; //NORES
    }
    StringBuffer sbuf = new StringBuffer();
    sbuf.append('('); //NORES
    sbuf.append(point.y);
    sbuf.append(','); //NORES
    sbuf.append(point.x);
    sbuf.append(')'); //NORES
    return sbuf.toString();
  }

  /**
   * Helper routine to dump a requirement
   */
  private static String dump(RequirementInfo reqInfo) {
    StringBuffer sbuf = new StringBuffer();
    String[][] fields = reqInfo.getFields();
    for (int i = 0; i < fields.length; i++) {
      String[] field = fields[i];
      String key = field[0];
      String val = field[1];
      // Short circuit for now
      if (!"_name".equals(key)) {
        continue;
      }
      sbuf.append('['); //NORES
      sbuf.append(key);
      sbuf.append('='); //NORES
      sbuf.append(val);
      sbuf.append(']'); //NORES
    }
    return sbuf.toString();
  }

  /**
   * Mask a string that contains numbers
   * @todo Implement me
   * @param str String
   * @return String
   */
  private static String mask(String str) {
    StringBuffer sbuf = new StringBuffer();
    for (int i = 0; i < str.length(); i++) {
      sbuf.append(str.charAt(i));
    }
    return sbuf.toString();
  }

  /**
   * Unmasks a string that contains numbers
   * @todo Implement me
   * @param str String
   * @return String
   */
  private static String unmask(String str) {
    StringBuffer sbuf = new StringBuffer();
    for (int i = 0; i < str.length(); i++) {
      sbuf.append(str.charAt(i));
    }
    return sbuf.toString();
  }

  /**
   * Convert a point to a string
   * @param point Point
   * @return String
   */
  private static String pointToString(Point point) {
    String stry = mask(Integer.toString(point.y));
    String strx = mask(Integer.toString(point.x));
    return Strings.format("[{0},{1}]", strx, stry); // NORES
  }

  /**
   * Convert a string to a point
   * @param str String
   * @return Point
   */
  private static Point stringToPoint(String str) {
    StringTokenizer tokenizer = new StringTokenizer(str, "[],"); // NORES
    String tokenx = tokenizer.hasMoreTokens() ? unmask(tokenizer.nextToken()) : "-1"; //NORES
    int x = PrimitiveTypes.isNumber(tokenx) ? Integer.parseInt(tokenx) : -1;
    String tokeny = tokenizer.hasMoreTokens() ? unmask(tokenizer.nextToken()) : "-1"; //NORES
    int y = PrimitiveTypes.isNumber(tokeny) ? Integer.parseInt(tokeny) : -1;
    return new Point(x, y);
  }

  /**
   * Returns a locator associated with a particular location in a Node
   * @param node Node
   * @param point Point
   * @return String
   */
  public String getCommentLocator(Node node, Point point) {
    point = convertViewPointToEditorPoint(node, point);
    String locator = getLocator(node, point, true);
    trace("getCommentLocator() {0}  {1}: {2}", node.getDisplayName(), dump(point), locator);
    return locator;
  }

  /**
   * Return a locator for the specified position within the node
   * @param node Node
   * @param point Point
   * @return String
   */
  public String getRequirementLocator(Node node, Point point) {
    /**
     * Go figure - for getCommentLocator() it's in View coordinates
     * but not for getRequirementLocator
     */
//    point = convertViewPointToEditorPoint(node, point);
    String locator = getLocator(node, point, false);
    trace("getRequirementLocator() {0}  {1}: {2}", node.getDisplayName(), dump(point), locator);
    return locator;
  }

  private Point convertViewPointToEditorPoint(Node node, Point point) {
    Browser browser = Browser.getActiveBrowser();
    return Util.getEditorPosOfPoint(browser, node, point);
  }

  /**
   * Internal routine to find locators at a specified position within a node
   * @param node Node
   * @param point Point
   * @param comment boolean
   * @return String
   */
  private String getLocator(Node node, Point point, boolean comment) {
    if (node == null || !(node instanceof CParseableFileNode)) {
      return null;
    }

    if (point == null) {
      return null;
    }

    CBProject project = getCBProject();
    if (project == null) {
      return null;
    }

    CParseableFileNode cppFileNode = (CParseableFileNode) node;

    Url projectUrl = project.getProjectPath();
    Url fileUrl = cppFileNode.getUrl();

    String projectName = projectUrl.getName();
    String filePath = projectUrl.getRelativePath(fileUrl);

    LocatorHolder holder = new LocatorHolder();
    int status = performOperation(fileUrl, null, null, point, OP_GETSTATUS, holder);

    if (comment) {
      String customField;
      if ((status == CommentStatus.STATUS_CURRENT) && (holder.commentLocator != null)) {
        customField = holder.commentLocator;
      }
      else {
        customField = pointToString(point);
      }

      CPPCommentLocator commentLocator = new CPPCommentLocator();
      commentLocator.setFieldValue(CPPCommentLocator.FIELD_PROJECT, projectName);
      commentLocator.setFieldValue(CPPCommentLocator.FIELD_FILEPATH, filePath);

      commentLocator.setFieldValue(CPPCommentLocator.FIELD_CUSTOM, customField);
      String locator = commentLocator.toString();
      return locator;
    }
    else {
      return holder.requirementLocator;
    }
  }

  /**
   * Helper routine to retrieve a Point from a comment locator
   * @param commentLocator String
   * @return Point
   */
  private static Point pointFromCommentLocator(String commentLocator) {
    CPPCommentLocator locator = new CPPCommentLocator(commentLocator);
    String pointStr = locator.getFieldValue(CPPCommentLocator.FIELD_CUSTOM);
    return stringToPoint(pointStr);
  }

  /**
   * Returns the current active CBuilder project
   * @return CBProject
   */
  private CBProject getCBProject() {
    Project activeProject = Browser.getActiveBrowser().getActiveProject();
    if (activeProject instanceof CBProject) {
      return (CBProject) activeProject;
    }
    return null;
  }

  /**
   * Returns the status of a requirement
   * @param commentLocator String
   * @param requirementInfo RequirementInfo
   * @return int
   */
  public int getCommentStatus(String commentLocator, RequirementInfo requirementInfo) {
    int status = performOperation(commentLocator, requirementInfo, OP_GETSTATUS);
    trace("getCommentStatus() {0} {1} {2}", commentLocator, CommentStatus.getStatusDisplayName(status),
      dump(requirementInfo));
    return status;
  }

  /**
   * Returns the Url of a file relative to its project unless the path
   * is that of an absolute Url
   * @param project Project
   * @param fileRelativePath String
   * @return Url
   */
  private Url getFileUrl(Project project, String fileRelativePath) {
    String projectPath = project.getProjectPath().toString();
    String filePath;
    // Check if file is in project path (i.e. is represented by absolute path)
    if (fileRelativePath.indexOf("%|") == -1) //NORES
      {
      filePath = projectPath + "/" + fileRelativePath; //NORES
    }
    else {
      // Create correct Url string
      filePath = "file:///" + fileRelativePath; //NORES
    }

    try {
      return new Url(filePath);
    }
    catch (InvalidUrlException ex) {
      DebugTraces.printStackTrace(ex);
    }
    return null;
  }

  /**
   * Returns the file associated with a locator, assuming it applies to the
   * passed in project
   * @param locator String
   * @param project Project
   * @return Url
   */
  private Url getFileOfLocator(String commentLoc, Project project) {
    CPPCommentLocator commentLocator = new CPPCommentLocator(commentLoc);
    String fileRelativePath = commentLocator.getFieldValue(CPPCommentLocator.FIELD_FILEPATH);
    return getFileUrl(project, fileRelativePath);
  }

  /**
   * Returns the status of the comment associated with the specified locator
   * @param project CBProject
   * @param locator String
   * @param requirementInfo RequirementInfo
   * @return int
   */
  private int performOperation(Url fileUrl, String commentLocator,
    RequirementInfo requirementInfo, Point point, int operation, LocatorHolder holder) {

    // No browser, no go!!
    Browser browser = Browser.getActiveBrowser();
    if (browser == null) {
      return CommentStatus.STATUS_MISSING;
    }

    // No file, no go!!
    String content = Util.getContentOfIDEFile(browser, fileUrl);
    if (content == null) {
      return CommentStatus.STATUS_MISSING;
    }

    // Configure comment parser
    CRMCommentParser parser = new CRMCommentParser(fileUrl.getFileObject(), new StringReader(content));
    if (commentLocator != null) {
      parser.setCommentLocator(commentLocator);
    }
    else if (point != null) {
      parser.setPoint(point);
    }
    else {
      // Should not reach here cause the parser has really nothing in do in that case
      DebugTraces.ensure(false);
    }
    try {
      parser.parse();
      if (holder != null) {
        holder.commentLocator = parser.getCommentLocator();
        holder.requirementLocator = parser.getRequirementLocator();
      }
    }
    catch (ParseException ex) {
      DebugTraces.printStackTrace(ex);
      return CommentStatus.STATUS_MISSING;
    }

    // If we did not find a Token, the comment is missing
    if (parser.getCommentToken() == null) {
      // Maybe we're creating or updating
      if ((operation == OP_CREATE) || (operation == OP_UPDATE)) {
        String commentText = getCommentText(requirementInfo, commentLocator);
        if (point == null) {
          point = pointFromCommentLocator(commentLocator);
        }
        // Insert the text
        return insertText(fileUrl, point, browser, content, commentText);
      }
      return CommentStatus.STATUS_MISSING;
    }
    else {
      // Here we found the token.
      // Are we being asked to delete the comment
      Token commentToken = parser.getCommentToken();

      // Update the coordinate of the comment
      Point start = new Point(commentToken.beginColumn, commentToken.beginLine);
      Point end = new Point(commentToken.endColumn, commentToken.endLine);

      if (operation == OP_DELETE) {

        // Widen to account for "/*" + "*/"
        return deleteComment(fileUrl, browser, content, start, end);
        // Maybe we need to open the node
      }
      else if (operation == OP_OPEN) {
        // Navigate to the file
        Util.navigateTo(browser, getCBProject(), null, fileUrl, start.y, start.x, true);
      }
      else if (operation == OP_UPDATE) {
        // Here we're asked to update an existing comment
        int status = deleteComment(fileUrl, browser, content, start, end);
        if (status == CommentStatus.STATUS_CURRENT) {
          // Update content since we just modified it
          content = Util.getContentOfIDEFile(browser, fileUrl);
          String commentText = getCommentText(requirementInfo, commentLocator);
          return insertText(fileUrl, start, browser, content, commentText);
        }
        return CommentStatus.STATUS_MISSING;
      }
    }
    // NOTE: The comment could be out of date also
    return CommentStatus.STATUS_CURRENT;
  }

  private int insertText(Url fileUrl, Point point, Browser browser, String content, String commentText) {
    try {
      content = Util.insertTextAtPosition(content, commentText, point);
    }
    catch (IOException ex) {
      DebugTraces.printStackTrace(ex);
      return CommentStatus.STATUS_MISSING;
    }

    if (Util.setContentOfIDEFile(browser, fileUrl, content)) {
      return CommentStatus.STATUS_CURRENT;
    }

    return CommentStatus.STATUS_MISSING;
  }

  /**
   * Helper routine to delete a comment
   * @param fileUrl Url
   * @param browser Browser
   * @param content String
   * @param start Point
   * @param end Point
   * @param persist boolean
   * @return int
   */
  private int deleteComment(Url fileUrl, Browser browser, String content, Point start, Point end) {
    FileNode node = Util.getOpenedNode(browser, fileUrl);
    if (node != null) {
      Point[] pos = Util.widenEditorPosition(browser, node, start, end, -2, 2);
      if (pos != null) {
        start = pos[0];
        end = pos[1];
      }
    }

    // Delete the text
    try {
      content = Util.deleteTextAtPositions(content, start, end);
      trace("Deleting comment {0}-{1}", dump(start), dump(end)); //NORES
    }
    catch (IOException ex) {
      DebugTraces.printStackTrace(ex);
      return CommentStatus.STATUS_MISSING;
    }

    if (Util.setContentOfIDEFile(browser, fileUrl, content)) {
      return CommentStatus.STATUS_CURRENT;
    }

    // Something went wrong here!!
    return CommentStatus.STATUS_UNKNOWN;
  }

  /**
   * Returns the status of the comment associated with the specified locator
   * @param project CBProject
   * @param locator String
   * @param requirementInfo RequirementInfo
   * @return int
   */
  private int performOperation(String commentLocator, RequirementInfo requirementInfo, int operation) {

    CBProject project = getCBProject();
    if (project == null) {
      return CommentStatus.STATUS_UNKNOWN;
    }

    // Get file that contains comment
    Url fileUrl = getFileOfLocator(commentLocator, project);
    if (fileUrl == null || !VFS.exists(fileUrl)) {
      return CommentStatus.STATUS_NOTEXIST;
    }

    return performOperation(fileUrl, commentLocator, requirementInfo, null, operation, null);
  }

  /**
   * Returns the text to be stored for this requirement
   * @param requirementInfo RequirementInfo
   * @return String
   */
  public String getCommentText(RequirementInfo requirementInfo) {
    return getCommentText(requirementInfo, null);
  }

  /**
   * Returns the text to be stored for this requirement
   * @param requirementInfo RequirementInfo
   * @return String
   */
  public String getCommentText(RequirementInfo requirementInfo, String commentLocator) {
    JavaDocFormatter formatter = new JavaDocFormatter(getCommentLines(requirementInfo, commentLocator));
    String[] comment = formatter.getFormattedLines();
    String text = Util.stringArrayToString(comment);
    trace("getCommentText()");
    return text;
  }

  /**
   * Returns the first line to be stored in a comment
   * @param locator String
   * @return String
   */
  public static String getFirstCommentLine(String caliberLocator) {
    return REQUIREMENT_TAG + " " + caliberLocator; //NORES
  }

  /**
   * Returns the first line to be stored for the specified requirement
   * @param requirementInfo RequirementInfo
   * @return String
   */
  public static String getFirstCommentLine(RequirementInfo requirementInfo) {
    return REQUIREMENT_TAG + " " + requirementInfo.getLocator(); //NORES
  }

  /**
   * Returns the last line to be stored for a requirement
   * @return String
   */
  public static String getLastCommentLine() {
    return TAG_PREFIX + FIELD_ENDREQ; //NORES
  }

  /**
   * Returns the last line to be stored for a requirement
   * @return String
   */
  public static String getCustomLine(String commentLocator) {
    return COMMENT_TAG + " " + commentLocator;
  }

  /**
   * Returns lines for the specified requirement
   * @param requirementInfo RequirementInfo
   * @return String[]
   */
  static String[] getCommentLines(RequirementInfo requirementInfo, String commentLocator) {
    String[][] fields = requirementInfo.getFields();
    String[] lines = new String[fields.length + ((commentLocator != null) ? 3 : 2)];

    lines[0] = getFirstCommentLine(requirementInfo);

    for (int i = 0; i < fields.length; i++) {
      String name = fields[i][0];
      String value = fields[i][1];
      value = validateLine(value);
      String line = TAG_PREFIX + name + " " + value; //NORES
      lines[i + 1] = line;
    }

    if (commentLocator != null) {
      lines[lines.length - 2] = getCustomLine(commentLocator);
    }
    lines[lines.length - 1] = getLastCommentLine();

    return lines;
  }

  /**
   * Returns an array of actions for a Requirement
   * @param node Node
   * @param requirement Requirement
   * @return Action[]
   */
  public Action[] getActions(Node node, Requirement requirement) {
    trace("getActions() {0} {1}", node.getDisplayName(), requirement);
    return EmptyArrays.ACTION_EMPTY_ARRAY;
  }

  /**
   * Find Drop receiver components
   * @param c Component
   * @param found Vector
   */
  private void findDropEagerComponents(Component c, Vector found) {
    if (c instanceof EditorPane) {
      found.add(c);
    }
    if (c instanceof Container) {
      Component[] components = ((Container) c).getComponents();
      for (int i = 0; i < components.length; i++) {
        findDropEagerComponents(components[i], found);
      }
    }
  }

  /**
   * Request to update a comment
   * @param commentLocator String
   * @param requirementInfo RequirementInfo
   * @return int
   */
  public int updateComment(String commentLocator, RequirementInfo requirementInfo) {
    int status = performOperation(commentLocator, requirementInfo, OP_UPDATE);
    trace("updateComment() {0} {1} {2}", commentLocator, CommentStatus.getStatusDisplayName(status),
      dump(requirementInfo));
    return status;
  }

  /**
   * Handles request to open a comment
   * @param commentLocator String
   * @return boolean
   */
  public boolean openComment(String commentLocator) {
    int status = performOperation(commentLocator, null, OP_OPEN);
    trace("openComment() {0}", commentLocator);
    return true;
  }

  /**
   * Deletes the comment associated with this requirement
   * @param commentLocator String
   * @param requirementInfo RequirementInfo
   */
  public void deleteComment(String commentLocator, RequirementInfo requirementInfo) {
    performOperation(commentLocator, requirementInfo, OP_DELETE);
    trace("deleteComment() {0} {1}", commentLocator, dump(requirementInfo));
  }

  /**
   * Invoked to create a comment
   * @param commentLocator String
   * @param requirementInfo RequirementInfo
   * @return int
   */
  public int createComment(String commentLocator, RequirementInfo requirementInfo) {
    trace("createComment() {0} {1}", commentLocator, dump(requirementInfo));
    return performOperation(commentLocator, requirementInfo, OP_CREATE);
  }

  /**
   * Return the line that contains the specified tag
   * @param lines String[]
   * @param startPosition int
   * @param tagName String
   * @return int
   */
  static int findTagIndex(String[] lines, int startPosition, String tagName) {
    if (startPosition >= lines.length) {
      return -1;
    }

    String tag = TAG_PREFIX + tagName;

    for (int iLine = startPosition; iLine < lines.length; iLine++) {
      if (lines[iLine].indexOf(tag) != -1) {
        return iLine;
      }
    }

    return -1;
  }

  /**
   * Avoid Java comment symbols from resulting comment lines
   * @param line String
   * @return String
   */
  private static String validateLine(String line) {
    StringBuffer buffer = new StringBuffer(line);

    int pos = 0;

    while (true) {
      pos = buffer.indexOf("/*", pos); //NORES

      if (pos == -1) {
        break;
      }

      buffer.replace(pos, pos + 2, "/_*"); //NORES
      pos += 3;
    }

    pos = 0;

    while (true) {
      pos = buffer.indexOf("*/", pos); //NORES

      if (pos == -1) {
        break;
      }

      buffer.replace(pos, pos + 2, "*_/"); //NORES
      pos += 3;
    }

    return buffer.toString();
  }
}
