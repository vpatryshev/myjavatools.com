package com.borland.dspspb.primetime.crmplugin.gui.swingcomponents.tableproperties;

import javax.swing.table.DefaultTableModel;
import java.util.Vector;
import java.awt.Component;
import javax.swing.JTable;
import javax.swing.Icon;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.table.TableCellEditor;
import javax.swing.event.CellEditorListener;
import java.util.EventObject;
import javax.swing.event.ChangeEvent;
import com.borland.dspspb.primetime.crmplugin.gui.swingcomponents.tableproperties.internal.SwingInternalComponent;

public class PropertiesCellEditor implements TableCellEditor {

  private Vector comps;
  private Vector listeners = new Vector();

  private int editingRow = -1;

  public PropertiesCellEditor(Vector comps) {
    this.comps = comps;
  }

  public SwingInternalComponent getComponent(int row) {
    return (SwingInternalComponent)comps.get(row);
  }


  public Component getTableCellEditorComponent(	JTable table,
                          Object value,
                          boolean isSelected,
                          int row,
                          int column) {
    editingRow = row;
    SwingInternalComponent sic = getComponent(row);
    sic.setEditor(this);
    sic.updateUI();
    return sic.getInternalEditor();
  }

  public void addCellEditorListener(CellEditorListener l) { listeners.add(l); }
  public void removeCellEditorListener(CellEditorListener l) { listeners.remove(l); }

  public void cancelCellEditing() {
    fireEditingCanceled();
  }

  public Object getCellEditorValue() {return null;}
  public boolean isCellEditable(EventObject anEvent) {return true;}
  public boolean shouldSelectCell(EventObject anEvent) {return true;}

  public boolean stopCellEditing() {
    if(editingRow >= 0) {
      getComponent(editingRow).updateData();
    }
    fireEditingStopped();
    return true;
  }

  public void fireEditingStopped() {
    if(editingRow >= 0)getComponent(editingRow).setEditor(null);
    editingRow = -1;
    ChangeEvent evt = new ChangeEvent(this);
    Vector clones = (Vector)listeners.clone();
    for(int i = 0; i< clones.size(); i++) {
      ((CellEditorListener)clones.get(i)).editingStopped(evt);
    }
  }

  public void fireEditingCanceled() {
    if(editingRow >= 0)getComponent(editingRow).setEditor(null);
    editingRow = -1;
    ChangeEvent evt = new ChangeEvent(this);
    Vector clones = (Vector)listeners.clone();
    for(int i = 0; i< clones.size(); i++) {
      ((CellEditorListener)clones.get(i)).editingCanceled(evt);
    }
  }

}
