package com.borland.dspspb.cbuilder.crmplugin.stewards;

import java.io.*;
import java.util.*;

import java.awt.*;
import javax.swing.text.*;
import javax.swing.text.html.*;
import javax.swing.text.html.HTML.*;
import javax.swing.text.html.HTMLEditorKit.*;
import javax.swing.text.html.parser.ParserDelegator;

import com.borland.dspspb.primetime.crmplugin.opentool.*;
import com.borland.cbuilder.node.HTMLFileNode;
import com.borland.cbuilder.viewer.HtmlNodeSourceViewer;
import com.borland.primetime.editor.*;
import com.borland.primetime.ide.*;
import com.borland.primetime.node.*;
import com.borland.primetime.vfs.Url;
import com.borland.primetime.viewer.TextNodeViewer;
import javax.swing.Icon;
import com.borland.primetime.vfs.*;
import javax.swing.Action;
import com.borland.primetime.util.*;
import com.borland.dspspb.primetime.crmplugin.management.FramingManager;
import com.borland.dspspb.primetime.crmplugin.management.Utils;
import javax.swing.JOptionPane;

public class HtmlNodeSteward
  extends NodeStewardAdapter {
  private static final String STEWARD_ID = "HTML.Source"; //NORES
  private static final String LINE_SEPARATOR = System.getProperty("line.separator", "\n"); //NORES NORES
  private static final String COMMENT_PREFIX = "<!--"; //NORES
  private static final String COMMENT_POSTFIX = "-->"; //NORES
  private static final String REQUIREMENT_FIELD = "@requirement "; //NORES

  public HtmlNodeSteward() {
    super();
    EditorManager.registerContextActionProvider(new EditorContextActionProvider() {
      public Action getContextAction(EditorPane editor) {
        Node node = Browser.getActiveBrowser().getActiveNode();
        if (! (node instanceof HTMLFileNode)) {
          return null;
        }
        ActionGoToRequirement action = new ActionGoToRequirement(editor);

        return (action.findRequirementLocator() ? action : null);
      }

      public int getPriority() {
        return 0;
      }
    });
  }

  public String getId() {
    return STEWARD_ID;
  }

  public Icon getIcon() {
    return HTMLFileNode.ICON;
  }

  private void findDropEagerComponents(Component c, Vector found) {
    if (c instanceof EditorPane) {
      found.add(c);
    }
    if (c instanceof Container) {
      Component[] components = ( (Container) c).getComponents();
      for (int i = 0; i < components.length; i++) {
        findDropEagerComponents(components[i], found);
      }
    }
  }

  public Component[] getDropEagerComponents(Node node) {
    if (node == null || ! (node instanceof HTMLFileNode)) {
      return null;
    }
    Browser browser = Browser.getActiveBrowser();
    NodeViewer[] nodeViewers = browser.getViewers(node);
    Vector found = new Vector();
    for (int i = 0; i < nodeViewers.length; i++) {
      if (! (nodeViewers[i] instanceof HtmlNodeSourceViewer)) {
        continue;
      }
      findDropEagerComponents(nodeViewers[i].getViewerComponent(), found);
    }
    return (Component[]) found.toArray(new Component[0]);
  }

  private static String getText(Node node) {
    NodeViewer nodeViewer = Browser.getActiveBrowser().getActiveViewer(node);
    TextNodeViewer textNodeViewer = (TextNodeViewer) nodeViewer;
    final EditorPane editorPane = textNodeViewer.getEditor();
    Document document = editorPane.getDocument();
    EditorDocument editorDocument = (EditorDocument) document;
    try {
      String text = editorDocument.getText(0, editorDocument.getLength());
      return text;
    }
    catch (BadLocationException ex) {
    }
    return ""; //NORES
  }

  public String getCommentLocator(Node node, Point point) {
    if (node == null || ! (node instanceof HTMLFileNode)) {
      return null;
    }
    HTMLFileNode htmlFileNode = (HTMLFileNode) node;
    NodeViewer nodeViewer = Browser.getActiveBrowser().getActiveViewer(htmlFileNode);
    TextNodeViewer textNodeViewer = (TextNodeViewer) nodeViewer;
    final EditorPane editorPane = textNodeViewer.getEditor();
    int modelPos = editorPane.viewToModel(point);
    final int targetLineNo = editorPane.getLineNumber(modelPos);
//    final boolean debug = true;
//    if (debug) System.out.println("SSS ==================================================================="); //NORES
//    if (debug) System.out.println("SSS targetLineNo = " + targetLineNo); //NORES
    final Stack tags = new Stack();
    final String text = getText(htmlFileNode);
    try {
      new ParserDelegator().parse(new InputStreamReader(new ByteArrayInputStream(text.getBytes())),
        new ParserCallback() {
        boolean bSimple = false;
        boolean bFound = false;

        public void handleSimpleTag(Tag t, MutableAttributeSet a, int pos) {
          if (bFound) {
            return;
          }
          int tagLineNo = editorPane.getLineNumber(pos);
//          if (debug) System.out.println("SSS handleSimpleTag ( tagLineNo = " + tagLineNo + " ) : " + t); //NORES
          if (bSimple) {
            Tag tPrev = (Tag) tags.pop();
//            if (debug) System.out.println("SSS handleSimpleTag, pop previous SimpleTag " + tPrev); //NORES
          }
//          if (debug) System.out.println("SSS handleSimpleTag, push Tag " + t); //NORES
          tags.push(t);
          bSimple = true;
          if (tagLineNo == targetLineNo) {
//            if (debug) System.out.println("SSS handleSimpleTag, FOUND " + t); //NORES
            bFound = true;
          }
        }

        public void handleStartTag(Tag t, MutableAttributeSet a, int pos) {
          if (bFound) {
            return;
          }
          if (bSimple) {
            Tag tPrev = (Tag) tags.pop();
//            if (debug) System.out.println("SSS handleStartTag, pop previous SimpleTag " + tPrev); //NORES
            bSimple = false;
          }
          int tagLineNo = editorPane.getLineNumber(pos);
//          if (debug) System.out.println("SSS handleStartTag ( tagLineNo = " + tagLineNo + " ) : " + t); //NORES
          if (tagLineNo > targetLineNo) {
//            if (debug) System.out.println("SSS handleStartTag, FOUND previous SimpleTag"); //NORES
            bFound = true;
            return;
          }
//          if (debug) System.out.println("SSS handleStartTag, push Tag " + t); //NORES
          tags.push(t);
          if (tagLineNo == targetLineNo) {
//            if (debug) System.out.println("SSS handleStartTag, FOUND " + t); //NORES
            bFound = true;
            return;
          }
        }

        public void handleEndTag(Tag t, int pos) {
          if (bFound) {
            return;
          }
          if (bSimple) {
            Tag tPrev = (Tag) tags.pop();
//            if (debug) System.out.println("SSS handleEndTag, pop previous SimpleTag " + tPrev); //NORES
            bSimple = false;
          }
          int tagLineNo = editorPane.getLineNumber(pos);
//          if (debug) System.out.println("SSS handleEndTag ( tagLineNo = " + tagLineNo + " ) : " + t); //NORES
          if (tagLineNo >= targetLineNo) {
//            if (debug) System.out.println("SSS handleEndTag, FOUND " + t); //NORES
            bFound = true;
            return;
          }
          Tag tPrev = (Tag) tags.pop();
//          if (debug) System.out.println("SSS handleEndTag, pop Tag " + tPrev); //NORES
        }
      }

      ,
        true);
    }
    catch (IOException ex) {
    }
    String tagsLocator = tags2Locator(tags);
    int count = getTagsLocatorEntriesCounter(text, tags2Locator(tags));
    if (count > 1) {
      String message = Utils.format("Source code contains {0} entries of tags sequence {1}.", //RES HtmlNodeSteward_Multiple_tags_entries_found
        new Object[] {
        new Integer(count), tagsLocator}) +
        "\n" +
        "The comment will be added to the first one." + //RES HtmlNodeSteward_Add_comment_to_first_entry
        "\n" +
        "Do you wish to continue?"; //RES Do_you_wish_to_continue
      int confirmResult = FramingManager.getInstance().showConfirm(message);
      if (confirmResult != JOptionPane.OK_OPTION) {
        return null;
      }
    }
    Project project = Browser.getActiveBrowser().getActiveProject();
    Url projectUrl = project.getProjectPath();
    Url fileUrl = htmlFileNode.getUrl();
    String projectName = projectUrl.getName();
    String filePath = projectUrl.getRelativePath(fileUrl);
    HtmlCommentLocator commentLocator = new HtmlCommentLocator();
    commentLocator.setFieldValue(HtmlCommentLocator.FIELD_PROJECT, projectName);
    commentLocator.setFieldValue(HtmlCommentLocator.FIELD_FILEPATH, filePath);
    commentLocator.setFieldValue(HtmlCommentLocator.FIELD_TAGS, tagsLocator);
    return commentLocator.toString();
  }

  private int getTagsLocatorEntriesCounter(final String content, final String tagsLocator) {
    final StringBuffer result = new StringBuffer();
    InputStream inputStream = new ByteArrayInputStream(content.getBytes());
    final Stack tags = new Stack();
    try {
      new ParserDelegator().parse(new InputStreamReader(inputStream),
        new ParserCallback() {
        int count = 0;
        boolean bSimple = false;
        public void handleSimpleTag(Tag t, MutableAttributeSet a, int pos) {
          if (bSimple) {
            Tag tPrev = (Tag) tags.pop();
          }
          tags.push(t);
          bSimple = true;
          if (tagsLocator.equals(tags2Locator(tags))) {
            count++;
            result.setLength(0);
            result.append(count);
          }
        }

        public void handleStartTag(Tag t, MutableAttributeSet a, int pos) {
          if (bSimple) {
            Tag tPrev = (Tag) tags.pop();
            bSimple = false;
          }
          tags.push(t);
          if (tagsLocator.equals(tags2Locator(tags))) {
            count++;
            result.setLength(0);
            result.append(count);
          }
        }

        public void handleEndTag(Tag t, int pos) {
          if (bSimple) {
            Tag tPrev = (Tag) tags.pop();
            bSimple = false;
          }
          Tag tPrev = (Tag) tags.pop();
        }
      },
        true);
    }
    catch (Exception e) {

    }
    if (result.length() > 0) {
      return new Integer(result.toString()).intValue();
    }
    else {
      return 0;
    }

  }

  private static final String TAG_PREFIX = "<"; //NORES
  private static final String TAG_POSTFIX = ">"; //NORES

  private String tags2Locator(Vector tags) {
    String tagsLocator = ""; // NORES
    if (tags != null) {
      for (int i = 0; i < tags.size(); i++) {
        tagsLocator += TAG_PREFIX + tags.get(i).toString() + TAG_POSTFIX;
      }
    }
    return tagsLocator;
  }

  private String[] locator2Tags(String tagsLocator) {
    if (tagsLocator.length() == 0) {
      return EmptyArrays.STRING_EMPTY_ARRAY;
    }
    String[] tags = (TAG_POSTFIX + tagsLocator + TAG_PREFIX).split(TAG_POSTFIX + TAG_PREFIX, -1);
    return tags;
  }

  private boolean doParse(final String content, final String tagsLocator, final RequirementInfo requirementInfo, final int operation, final StringBuffer result) {
    InputStream inputStream = new ByteArrayInputStream(content.getBytes());
    final Stack tags = new Stack();
    try {
      new ParserDelegator().parse(new InputStreamReader(inputStream),
        new ParserCallback() {
        class CommentInfo {
          String comment;
          int pos;

          CommentInfo(String comment, int pos) {
            this.comment = comment;
            this.pos = pos;
          }
        }

        Vector commentsInfo = new Vector();
        boolean bSimple = false;
        boolean bFound = false;

        public void handleComment(char[] text, int pos) {
          if (bFound) {
            return;
          }
          commentsInfo.add(new CommentInfo(new String(text), pos));
        }

        public void handleSimpleTag(Tag t, MutableAttributeSet a, int pos) {
          if (bFound) {
            return;
          }
          if (bSimple) {
            Tag tPrev = (Tag) tags.pop();
          }
          tags.push(t);
          bSimple = true;
          if (tagsLocator.equals(tags2Locator(tags))) {
            if (operation == OP_COMMENT_GETPOSITION) {
              result.append(pos);
            }
            else if (operation == OP_COMMENT_GETSTATUS) {
              boolean bCommentFound = false;
              for (int i = 0; i < commentsInfo.size(); i++) {
                CommentInfo commentInfo = (CommentInfo) commentsInfo.get(i);
                if (isCreatedFrom(commentInfo.comment, requirementInfo)) {
                  int status = getStatus(commentInfo.comment, requirementInfo);
                  result.append(status);
                  bCommentFound = true;
                  break;
                }
              }
              if (!bCommentFound) {
                result.append(CommentStatus.STATUS_MISSING);
              }
            }
            else {
              String newContent = content;
              for (int i = 0; i < commentsInfo.size(); i++) {
                CommentInfo commentInfo = (CommentInfo) commentsInfo.get(i);
                if (isCreatedFrom(commentInfo.comment, requirementInfo)) {
                  pos = commentInfo.pos;
                  newContent = content.substring(0, pos) + content.substring(pos + commentInfo.comment.length() +
                    COMMENT_PREFIX.length() + COMMENT_POSTFIX.length() + 1);
                  break;
                }
              }
              if (operation == OP_COMMENT_DELETE) {
                result.append(newContent);
              }
              else if (operation == OP_COMMENT_UPDATE) {
                String commentText = getCommentText(requirementInfo);
                while (pos > 0) {
                  pos--;
                  if ( (content.charAt(pos) != ' ') && (content.charAt(pos) != '\t')) {
                    pos++;
                    break;
                  }
                }
                result.append(newContent.substring(0, pos));
                result.append(commentText);
                result.append(newContent.substring(pos));
              }
            }
            bFound = true;
          }
          commentsInfo.clear();
        }

        public void handleStartTag(Tag t, MutableAttributeSet a, int pos) {
          if (bFound) {
            return;
          }
          if (bSimple) {
            Tag tPrev = (Tag) tags.pop();
            bSimple = false;
          }
          tags.push(t);
          if (tagsLocator.equals(tags2Locator(tags))) {
            if (operation == OP_COMMENT_GETPOSITION) {
              result.append(pos);
            }
            else if (operation == OP_COMMENT_GETSTATUS) {
              boolean bCommentFound = false;
              for (int i = 0; i < commentsInfo.size(); i++) {
                CommentInfo commentInfo = (CommentInfo) commentsInfo.get(i);
                if (isCreatedFrom(commentInfo.comment, requirementInfo)) {
                  int status = getStatus(commentInfo.comment, requirementInfo);
                  result.append(status);
                  bCommentFound = true;
                  break;
                }
              }
              if (!bCommentFound) {
                result.append(CommentStatus.STATUS_MISSING);
              }
            }
            else {
              String newContent = content;
              for (int i = 0; i < commentsInfo.size(); i++) {
                CommentInfo commentInfo = (CommentInfo) commentsInfo.get(i);
                if (isCreatedFrom(commentInfo.comment, requirementInfo)) {
                  pos = commentInfo.pos;
                  newContent = content.substring(0, pos) + content.substring(pos + commentInfo.comment.length() +
                    COMMENT_PREFIX.length() + COMMENT_POSTFIX.length() + 1);
                  break;
                }
              }
              if (operation == OP_COMMENT_DELETE) {
                result.append(newContent);
              }
              else if (operation == OP_COMMENT_UPDATE) {
                String commentText = getCommentText(requirementInfo);
                while (pos > 0) {
                  pos--;
                  if ( (content.charAt(pos) != ' ') && (content.charAt(pos) != '\t')) {
                    pos++;
                    break;
                  }
                }
                result.append(newContent.substring(0, pos));
                result.append(commentText);
                result.append(newContent.substring(pos));
              }
            }
            bFound = true;
          }
          commentsInfo.clear();
        }

        public void handleEndTag(Tag t, int pos) {
          if (bFound) {
            return;
          }
          if (bSimple) {
            Tag tPrev = (Tag) tags.pop();
            bSimple = false;
          }
          Tag tPrev = (Tag) tags.pop();
        }
      }

      ,
        true);
    }
    catch (IOException ex) {
      return false;
    }

    return true;
  }

  private boolean isCreatedFrom(String comment, RequirementInfo requirementInfo) {
    try {
      String reqLocatorFromComment = getRequirementLocator(comment);
      String reqLocatorFromCommentNoVer = reqLocatorFromComment.substring(0, reqLocatorFromComment.lastIndexOf(RequirementLocator.FIELD_DELIMITER));
      String reqLocatorFromInfo = requirementInfo.getLocator();
      String reqLocatorFromInfoNoVer = reqLocatorFromInfo.substring(0, reqLocatorFromInfo.lastIndexOf(RequirementLocator.FIELD_DELIMITER));
      return reqLocatorFromCommentNoVer.equals(reqLocatorFromInfoNoVer);
    }
    catch (Exception e) {
    }
    return false;
  }

  private int getStatus(String comment, RequirementInfo requirementInfo) {
    try {
      String reqLocatorFromComment = getRequirementLocator(comment);
      String reqLocatorFromInfo = requirementInfo.getLocator();
      return (reqLocatorFromComment.equals(reqLocatorFromInfo) ? CommentStatus.STATUS_CURRENT : CommentStatus.STATUS_OUTOFDATE);
    }
    catch (Exception e) {
    }
    return CommentStatus.STATUS_OUTOFDATE;
  }

  public String getCommentText(RequirementInfo requirementInfo) {
    StringBuffer buffer = new StringBuffer();
    buffer.append(REQUIREMENT_FIELD + requirementInfo.getLocator());
    buffer.append(LINE_SEPARATOR);
    String[][] fields = requirementInfo.getFields();
    for (int i = 0; i < fields.length; i++) {
      String name = fields[i][0];
      String value = fields[i][1];
      String line = "@" + name + " " + value; //NORES
      buffer.append(line);
      if (i != fields.length - 1) {
        buffer.append(LINE_SEPARATOR);
      }
    }
    int pos = 0;
    while (true) {
      pos = buffer.indexOf("--", pos); //NORES
      if (pos == -1) {
        break;
      }
      buffer.replace(pos, pos + 2, "-_-"); //NORES
      pos += 2;
    }
    String result = COMMENT_PREFIX + buffer.toString() + COMMENT_POSTFIX + LINE_SEPARATOR;
    return result;
  }

  private static final int OP_COMMENT_GETPOSITION = 0;
  private static final int OP_COMMENT_GETSTATUS = 1;
  private static final int OP_COMMENT_UPDATE = 2;
  private static final int OP_COMMENT_DELETE = 3;

  public int createComment(String commentLocator, RequirementInfo requirementInfo) {
    return updateComment(commentLocator, requirementInfo);
  }

  public int updateComment(String commentLocator, RequirementInfo requirementInfo) {
    return performOperation(commentLocator, requirementInfo, OP_COMMENT_UPDATE);
  }

  public void deleteComment(String commentLocator, RequirementInfo requirementInfo) {
    performOperation(commentLocator, requirementInfo, OP_COMMENT_DELETE);
  }

  public int getCommentStatus(String commentLocator, RequirementInfo requirementInfo) {
    return performOperation(commentLocator, requirementInfo, OP_COMMENT_GETSTATUS);
  }

  private int performOperation(String commentLocator, final RequirementInfo requirementInfo, final int operation) {
    Project project = Browser.getActiveBrowser().getActiveProject();
    if (project == null) {
      return CommentStatus.STATUS_UNKNOWN;
    }
    HtmlCommentLocator htmlCommentLocator = new HtmlCommentLocator(commentLocator);
    String filePath = htmlCommentLocator.getFieldValue(HtmlCommentLocator.FIELD_FILEPATH);
    Url fileUrl = getUrlByPath(project, filePath);
    if (fileUrl == null) {
      return CommentStatus.STATUS_NOTEXIST;
    }
    String tagsLocator = htmlCommentLocator.getFieldValue(HtmlCommentLocator.FIELD_TAGS);

    InputStream inputStream = null;
    OutputStream outputStream = null;
    FileNode openedNode = getOpenedNode(fileUrl);
    EditorDocument doc = openedNode == null ? null : getEditorDocument(openedNode);
    if (openedNode != null && doc != null) {
      try {
        Buffer vfsBuffer = VFS.getBuffer(fileUrl);
        inputStream = vfsBuffer.getInputStream();
      }
      catch (IOException e) {
      }
    }
    else {
      try {
        File file = fileUrl.getFileObject();
        inputStream = new FileInputStream(file);
      }
      catch (IOException e) {
      }
    }
    if (inputStream == null) {
      return CommentStatus.STATUS_UNKNOWN;
    }
    String content = getContent(inputStream);
    try {
      inputStream.close();
    }
    catch (IOException e) {
    }

    StringBuffer strbufResult = new StringBuffer();
    boolean bSucceeded = doParse(content, tagsLocator, requirementInfo, operation, strbufResult);
    if (!bSucceeded) {
      return CommentStatus.STATUS_UNKNOWN;
    }

    if (operation == OP_COMMENT_GETSTATUS) {
      try {
        return new Integer(strbufResult.toString()).intValue();
      }
      catch (NumberFormatException ex1) {
        return CommentStatus.STATUS_UNKNOWN;
      }
    }

    if (openedNode != null && doc != null) {
      try {
        Buffer vfsBuffer = VFS.getBuffer(fileUrl);
        outputStream = vfsBuffer.getOutputStream();
      }
      catch (IOException e) {
      }
    }
    else {
      try {
        File file = fileUrl.getFileObject();
        outputStream = new FileOutputStream(file);
      }
      catch (IOException e) {
      }
    }
    if (outputStream == null) {
      return CommentStatus.STATUS_UNKNOWN;
    }

    try {
      outputStream.write(strbufResult.toString().getBytes());
      outputStream.flush();
      outputStream.close();
    }
    catch (ReadOnlyException e) {
      return CommentStatus.STATUS_UNKNOWN;
    }
    catch (IOException e) {
      return CommentStatus.STATUS_UNKNOWN;
    }

    return CommentStatus.STATUS_CURRENT;

  }

  private FileNode getOpenedNode(Url fileUrl) {
    com.borland.primetime.ide.Browser browser = com.borland.primetime.ide.Browser.getActiveBrowser();
    if (browser == null) {
      return null;
    }
    Node[] nodes = browser.getAllOpenNodes();
    FileNode srcNode = null;
    for (int i = 0; i < nodes.length; i++) {
      if (nodes[i] instanceof FileNode &&
        ( (FileNode) nodes[i]).getUrl().equals(fileUrl)) {
        srcNode = (FileNode) nodes[i];
        break;
      }
    }
    return srcNode;
  }

  private EditorDocument getEditorDocument(FileNode node) {
    if (node == null) {
      return null;
    }
    EditorPane editorPane = EditorManager.getEditor(node);
    if (editorPane == null) {
      return null;
    }
    return (EditorDocument) editorPane.getDocument();
  }

  private String getContent(InputStream inputStream) {
    StringBuffer buffer = new StringBuffer();
    BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
    try {
      do {
        String readString = reader.readLine();
        if (readString == null) {
          break;
        }
        buffer.append(readString);
        buffer.append('\n'); //NORES
      }
      while (true);
    }
    catch (IOException e) {
      return null;
    }
    return buffer.toString();
  }

  public boolean openComment(String commentLocator) {
    Project project = Browser.getActiveBrowser().getActiveProject();
    if (project == null) {
      return false;
    }
    HtmlCommentLocator htmlCommentLocator = new HtmlCommentLocator(commentLocator);
    String filePath = htmlCommentLocator.getFieldValue(JavaCommentLocator.FIELD_FILEPATH);
    Url fileUrl = getUrlByPath(project, filePath);
    if (fileUrl == null) {
      return false;
    }

    FileNode fileNode = project.getNode(fileUrl);
    if (fileNode == null) {
      return false;
    }
    try {
      Browser.getActiveBrowser().setActiveNode(fileNode, true);
    }
    catch (Exception e) {
      return false;
    }

    HtmlNodeSourceViewer sourceViewer = (HtmlNodeSourceViewer) Browser.getActiveBrowser().getViewerOfType(fileNode, HtmlNodeSourceViewer.class);
    if (sourceViewer == null) {
      return false;
    }
    try {
      Browser.getActiveBrowser().setActiveViewer(fileNode, sourceViewer, true);
    }
    catch (Exception e) {
      return false;
    }

    EditorPane editorPane = sourceViewer.getEditor();
    String content = editorPane.getText();
    String tagsLocator = htmlCommentLocator.getFieldValue(HtmlCommentLocator.FIELD_TAGS);
    StringBuffer strbufResult = new StringBuffer();
    boolean bSucceeded = doParse(content, tagsLocator, null, OP_COMMENT_GETPOSITION, strbufResult);
    if (!bSucceeded) {
      return false;
    }
    int pos;
    try {
      pos = new Integer(strbufResult.toString()).intValue();
    }
    catch (NumberFormatException ex) {
      return false;
    }
    int line = editorPane.getLineNumber(pos);
    editorPane.gotoLine(line);
    editorPane.requestFocus();
    return true;
  }

  private Url getUrlByPath(Project project, String filePath) {
    if (project == null) {
      return null;
    }
    String projectPath = project.getProjectPath().toString();
    String fileFullPath;
    // Check if file is in project path (i.e. is represented by absolute path)
    if (filePath.indexOf("%|") == -1) //NORES
      {
      fileFullPath = projectPath + "/" + filePath; //NORES
    }
    else {
      // Create correct Url string
      fileFullPath = "file:///" + filePath; //NORES
    }
    try {
      return new Url(fileFullPath);
    }
    catch (InvalidUrlException e) {
    }
    return null;
  }

  public String getRequirementLocator(Node node, Point point) {
    if (! (node instanceof HTMLFileNode)) {
      return null;
    }
    String text = getText(node);
    if (text.length() == 0) {
      return null;
    }
    NodeViewer nodeViewer = Browser.getActiveBrowser().getActiveViewer(node);
    TextNodeViewer textNodeViewer = (TextNodeViewer) nodeViewer;
    final EditorPane editorPane = textNodeViewer.getEditor();
    final int targetLineNo = point.y;
    final StringBuffer strbufRequirementLocator = new StringBuffer();
    try {
      new ParserDelegator().parse(new InputStreamReader(new ByteArrayInputStream(text.getBytes())),
        new ParserCallback() {
        boolean bSimple = false;
        boolean bFound = false;

        public void handleComment(char[] text, int pos) {
          if (bFound) {
            return;
          }
          int commentLineNo = editorPane.getLineNumber(pos);
          if (commentLineNo > targetLineNo) {
            return;
          }
          String comment = new String(text);
          int commentLinesCount = getLinesCount(comment);
          if ( (targetLineNo >= commentLineNo) && (targetLineNo <= commentLineNo + commentLinesCount)) {
            bFound = true;
            String requirementLocator = getRequirementLocator(comment);
            if (requirementLocator != null) {
              strbufRequirementLocator.append(requirementLocator);
            }
          }
        }
      }
      ,
        true);
    }
    catch (IOException ex) {
    }

    String requirementLocator = strbufRequirementLocator.toString();
    if (requirementLocator.length() == 0) {
      return null;
    }
    return requirementLocator;
  }

  private int getLinesCount(String text) {
    if (text == null) {
      return 0;
    }
    return text.split("\n").length; //NORES
  }

  private String getRequirementLocator(String comment) {
    String[] lines = comment.split("\n"); //NORES
    String line0 = lines[0];
    int requirementFieldIndex = line0.indexOf(REQUIREMENT_FIELD);
    if (requirementFieldIndex != -1) {
      String requirementLocator = line0.substring(requirementFieldIndex + REQUIREMENT_FIELD.length()).trim();
      return requirementLocator;
    }
    return null;
  }
}
