package com.borland.dspspb.primetime.crmplugin.actions;

import com.borland.dspspb.primetime.crmplugin.resources.*;
import com.borland.dspspb.primetime.crmplugin.view.*;

public class ActionToggleDetails extends PluginStateAction
{
  public ActionToggleDetails ()
  {
    super
      ("Toggle Details Panel", //RES ActionToggleDetails_shorttext
       "Show/hide requirement details panel", //RES ActionToggleDetails_longtext
       ResourceManager.ActionToggleDetails_icon);
  }

  public boolean getState (Object object)
  {
    PluginView pluginView = (PluginView) object;

		return pluginView.isDetailsVisible ();
  }

  public void setState (Object object, boolean bState)
  {
    PluginView pluginView = (PluginView) object;

    pluginView.setDetailsVisible (bState);
  }
}
