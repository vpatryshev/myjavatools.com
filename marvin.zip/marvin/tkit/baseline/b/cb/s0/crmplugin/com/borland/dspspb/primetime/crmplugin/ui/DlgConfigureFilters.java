// Created: Jun 14, 2004

package com.borland.dspspb.primetime.crmplugin.ui;

import java.util.Vector;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

import com.borland.dspspb.primetime.crmplugin.dialog.*;
import com.borland.dspspb.primetime.crmplugin.filter.*;
import com.borland.dspspb.primetime.crmplugin.resources.ResourceManager;
import com.borland.dspspb.primetime.crmplugin.management.Utils;
import com.borland.dspspb.primetime.crmplugin.resources.ResourceManager;
import com.borland.primetime.help.HelpTopic;
import com.borland.primetime.help.PrimetimeHelp;

public class DlgConfigureFilters extends PluginDialog
  implements ActionListener, ListSelectionListener, IUpdatableDialog

{
  private static ImageIcon iconFilter =
    ResourceManager.getIcon (ResourceManager.DlgConfigureFilters_icon);

  // Filters list
  private JPanel filtersPanel = null;
  private JList filtersList = null;
  private JButton btnNew = null;
  private JButton btnDelete = null;

	// Filter settings
  private JPanel descriptionPanel = null;
  private JLabel lblName = null;
  private JTextField txtName = null;

  // Condition panel
  private JPanel conditionPanel = null;
  private JList conditionList = null;
  private JButton btnAdd = null;
  private JButton btnEdit = null;
  private JButton btnRemove = null;

  private static Insets insetsLbl = new Insets (3, 5, 2, 5);
  private static Insets insetsTxt = new Insets (0, 5, 5, 5);
  private static Insets insetsBtn = new Insets (5, 5, 5, 5);

  private Vector vFilters = null;


  public DlgConfigureFilters (Component owner)
  {
    super (owner, "Configure Filters"); //RES DlgConfigureFilters_title
    setHelpTopic (PrimetimeHelp.createTopic (PrimetimeHelp.BOOK_UserGuide, "ui/dialogs/dlgcaliberconfigurefilters.html")); //NORES
  }

	public JComponent getContentUI ()
	{
		createFiltersPanel ();
		createDescriptionPanel ();
    createConditionPanel ();

    JPanel contentPanel = new JPanel (new GridBagLayout ());

    GridBagConstraints c = new GridBagConstraints();

    c.anchor = GridBagConstraints.NORTHWEST;
    c.gridx = 0;
    c.gridy = 0;
    c.gridwidth = 1;
    c.gridheight = GridBagConstraints.REMAINDER;
    c.weightx = 0.0;
    c.weighty = 1.0;
    c.fill = GridBagConstraints.VERTICAL;
    contentPanel.add (filtersPanel, c);

    c.gridx = 1;
    c.gridy = 0;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.gridheight = 1;
    c.weightx = 1.0;
    c.weighty = 0.0;
    c.fill = GridBagConstraints.HORIZONTAL;
    contentPanel.add (descriptionPanel, c);

    c.gridx = 1;
    c.gridy = 2;
    c.gridwidth = 1;
    c.weightx = 1.0;
    c.weighty = 1.0;
    c.fill = GridBagConstraints.BOTH;
    contentPanel.add (conditionPanel, c);

    initControls ();

		return contentPanel;
	}

	private void createFiltersPanel ()
	{
    filtersPanel = new JPanel (new GridBagLayout ());
    filtersPanel.setBorder
      (BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(),
       " Filters ")); //RES DlgConfigureFilters_Border1_text

    filtersList = new JList ();
    filtersList.setSelectionMode (ListSelectionModel.SINGLE_SELECTION);
    btnNew = new JButton ("New"); //RES DlgConfigureFilters_BtnNew_text
    btnNew.setMnemonic('N'); //RES DlgConfigureFilters_BtnNew_mnemonic
    btnDelete = new JButton ("Delete"); //RES DlgConfigureFilters_BtnDelete_text
    btnDelete.setMnemonic('D'); //RES DlgConfigureFilters_BtnDelete_mnemonic

    GridBagConstraints c = new GridBagConstraints();

    c.anchor = GridBagConstraints.NORTHWEST;
    c.gridx = 0;
    c.gridy = 0;
    c.gridwidth = 2;
    c.weightx = 1.0;
    c.weighty = 1.0;
    c.fill = GridBagConstraints.BOTH;
    filtersPanel.add (new JScrollPane (filtersList), c);

    c.gridx = 0;
    c.gridy = 1;
    c.gridwidth = 1;
    c.weightx = 0.5;
    c.weighty = 0.0;
    c.insets = insetsBtn;
    c.fill = GridBagConstraints.NONE;
    filtersPanel.add (btnNew, c);

    c.gridx = 1;
    c.gridy = 1;
    c.weightx = 0.5;
    c.weighty = 0.0;
    c.insets = insetsBtn;
    c.fill = GridBagConstraints.NONE;
    filtersPanel.add (btnDelete, c);
	}

  private void createDescriptionPanel ()
  {
    descriptionPanel = new JPanel (new GridBagLayout ());
    descriptionPanel.setBorder
      (BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(),
       " Filter Settings ")); //RES DlgConfigureFilters_Border2_text

    lblName = new JLabel ("Name:"); //RES DlgConfigureFilters_Name_text
    lblName.setDisplayedMnemonic('M'); //RES DlgConfigureFilters_Name_mnemonic
    txtName = new JTextField (20);
    lblName.setLabelFor(txtName);

    GridBagConstraints c = new GridBagConstraints();

    // Name
    c.anchor = GridBagConstraints.NORTHWEST;
    c.gridx = 0;
    c.gridy = 0;
    c.gridwidth = 1;
    c.weightx = 0.0;
    c.weighty = 0.0;
    c.insets = insetsLbl;
    c.fill = GridBagConstraints.NONE;
    descriptionPanel.add (lblName, c);

    c.gridx = 1;
    c.gridy = 0;
    c.gridwidth = GridBagConstraints.REMAINDER;
    c.weightx = 1.0;
    c.weighty = 1.0;
    c.insets = insetsTxt;
    c.fill = GridBagConstraints.HORIZONTAL;
    descriptionPanel.add (txtName, c);
  }

  private void createConditionPanel ()
  {
    conditionPanel = new JPanel (new GridBagLayout ());
    conditionPanel.setBorder
      (BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(),
       " Criteria "));  //RES DlgConfigureFilters_Border3_text

    conditionList = new JList ();
    conditionList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    btnAdd = new JButton ("Add..."); //RES DlgConfigureFilters_Add_text
    btnAdd.setMnemonic('A'); //RES DlgConfigureFilters_Add_mnemonic
    btnEdit = new JButton ("Edit..."); //RES DlgConfigureFilters_Edit_text
    btnEdit.setMnemonic ('E'); //RES DlgConfigureFilters_Edit_mnemonic
    btnRemove = new JButton ("Remove"); //RES DlgConfigureFilters_Remove_text
    btnRemove.setMnemonic('R'); //RES DlgConfigureFilters_Remove_mnemonic

    ButtonsGroup buttonsGroup = new ButtonsGroup (ButtonsGroup.RIGHT);
    buttonsGroup.addButton (btnAdd, this);
    buttonsGroup.addButton (btnEdit, this);
    buttonsGroup.addButton (btnRemove, this);

    GridBagConstraints c = new GridBagConstraints();

    c.anchor = GridBagConstraints.NORTHWEST;
    c.gridx = 0;
    c.gridy = 0;
    c.gridwidth = 2;
    c.weightx = 1.0;
    c.weighty = 1.0;
    c.fill = GridBagConstraints.BOTH;
    conditionPanel.add (new JScrollPane (conditionList), c);

    c.gridx = 0;
    c.gridy = 1;
    c.gridwidth = 1;
    c.weightx = 1.0;
    c.weighty = 0.0;
    c.fill = GridBagConstraints.HORIZONTAL;
    conditionPanel.add (buttonsGroup, c);
  }

// -----------------------------------------------------------------------------

  private void initControls ()
  {
    Filter [] filters = FilterManager.getInstance ().getFilters ();

    vFilters = new Vector (filters.length);

    for (int i = 0; i < filters.length; i++)
    {
      Filter filter = filters [i];

      if (filter.getPredefined()) continue;

      Filter newFilter = (Filter) filter.clone ();
      vFilters.add (newFilter);
    }

    filtersList.setListData (vFilters);
    filtersList.setValueIsAdjusting (true);
    filtersList.setCellRenderer (new FilterCellRenderer ());
    filtersList.addListSelectionListener (this);

    if (vFilters.size () == 0)
    {
      doNew ();
    }

    filtersList.setSelectedIndex (0);

    btnNew.addActionListener (this);
    btnDelete.addActionListener (this);
  }

// -----------------------------------------------------------------------------

  private void updateCondition ()
  {
    conditionList.removeAll ();

    Filter selectedFilter = (Filter) filtersList.getSelectedValue ();

    if (selectedFilter == null) return;

    Criterion [] criteria = selectedFilter.getCriteria ();
    conditionList.setListData (criteria);
  }

// -----------------------------------------------------------------------------

  private class FilterCellRenderer extends DefaultListCellRenderer
  {
    public Component getListCellRendererComponent
      (JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
    {
      String filterName = ""; //NORES

      Filter filter = (Filter) value;
      if (filter != null) filterName = filter.getName ();

      super.getListCellRendererComponent (list, filterName, index, isSelected, cellHasFocus);
      setIcon (iconFilter);

      return this;
    }
  }

// -----------------------------------------------------------------------------
// ActionListener implementation

  public void actionPerformed(ActionEvent e)
  {
    Object eventSource = e.getSource();

    if (eventSource == btnNew)
    {
      doNew ();
    }
    else if (eventSource == btnDelete)
    {
      doDelete ();
    }
    else if (eventSource == btnAdd)
    {
      doAdd ();
    }
    else if (eventSource == btnEdit)
    {
      doEdit ();
    }
    else if (eventSource == btnRemove)
    {
      doRemove ();
    }
  }

  private void doNew ()
  {
    Vector names = new Vector (vFilters.size());

    for (int i = 0; i < vFilters.size(); i++)
    {
      names.add (((Filter) vFilters.get (i)).getName ());
    }

    Filter newFilter = new Filter
      (Utils.generateNewName ("New Filter {0}", names)); //RES FilterManager_New_Filter_N_pattern
    vFilters.add (newFilter);

    filtersList.setListData (vFilters);
    filtersList.setSelectedValue (newFilter, true);

    txtName.selectAll ();
    txtName.requestFocus ();
  }

  private void doDelete ()
  {
    Filter selectedFilter = (Filter) filtersList.getSelectedValue ();

    if (selectedFilter == null) return;

    FilterManager.getInstance ().removeFilter (selectedFilter);

    vFilters.remove (selectedFilter);
    filtersList.setListData (vFilters);

    updateCondition();
  }

  private void doAdd ()
  {
    int selectedIndex = conditionList.getSelectedIndex ();

    EditCriterionDialog dlg = new EditCriterionDialog (this, selectedIndex == -1);

    if (dlg.showDialog ())
    {
      Criterion criterion = dlg.getCriterion ();

      Filter selectedFilter = (Filter) filtersList.getSelectedValue();

      selectedFilter.insertCriterion (criterion, selectedIndex + 1);
      conditionList.setListData (selectedFilter.getCriteria ());
      conditionList.setSelectedIndex (selectedIndex + 1);
    }
  }

  private void doEdit ()
  {
    Criterion selectedCriterion = (Criterion) conditionList.getSelectedValue ();

    if (selectedCriterion == null) return;

    int selectedIndex = conditionList.getSelectedIndex ();

    EditCriterionDialog dlg = new EditCriterionDialog (this, selectedCriterion, selectedIndex == 0);

    if (dlg.showDialog ())
    {
      Filter selectedFilter = (Filter) filtersList.getSelectedValue();

      Criterion[] criteria = selectedFilter.getCriteria ();
      Criterion criterion = dlg.getCriterion ();
      selectedFilter.replaceCriterion (criteria[selectedIndex], criterion);
      conditionList.setListData (selectedFilter.getCriteria ());
      conditionList.setSelectedIndex (selectedIndex);
    }
  }

  private void doRemove ()
  {
    Filter selectedFilter = (Filter) filtersList.getSelectedValue();

    Criterion [] criteria = selectedFilter.getCriteria ();
    selectedFilter.removeCriterion (criteria [conditionList.getSelectedIndex ()]);
    conditionList.setListData (selectedFilter.getCriteria ());
  }

  public void onOk ()
  {
    FilterManager filterManager = FilterManager.getInstance();

    // Remove old filters
    Filter [] oldFilters = filterManager.getFilters();

    for (int i = 0; i < oldFilters.length; i++)
    {
      filterManager.removeFilter (oldFilters [i]);
    }

    // Create new filters
    for (int i = 0; i < vFilters.size(); i++)
    {
      filterManager.addFilter ((Filter) vFilters.get(i));
    }
  }

// -----------------------------------------------------------------------------

	public void valueChanged (ListSelectionEvent e)
	{
    Filter selectedFilter = (Filter) filtersList.getSelectedValue ();

    if (selectedFilter == null)
    {
      txtName.setText (""); //NORES
    }
    else
    {
      txtName.setText (selectedFilter.getName ());
    }

    updateCondition ();
	}

	public void updateDialog ()
	{
    Filter selectedFilter = (Filter) filtersList.getSelectedValue ();
    boolean isSelection = (selectedFilter != null);

    if (isSelection)
    {
      if (!selectedFilter.getName ().equals (txtName.getText ()))
      {
        selectedFilter.setName (txtName.getText ());
        filtersList.repaint ();
      }
    }

    boolean isCriterionSelected = (conditionList.getSelectedIndex () != -1);

    btnDelete.setEnabled (isSelection);

    txtName.setEnabled (isSelection);

    btnAdd.setEnabled (isSelection);
    btnEdit.setEnabled (isSelection && isCriterionSelected);
    btnRemove.setEnabled (isSelection && isCriterionSelected);
	}
}
