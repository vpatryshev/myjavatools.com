package com.borland.dspspb.primetime.crmplugin.gui.swingcomponents.tableproperties.internal;

import java.util.Vector;
import java.awt.Component;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import java.awt.event.*;
import com.borland.dspspb.primetime.crmplugin.gui.abstractcomponents.AbstractViewComponent;
import com.borland.dspspb.primetime.crmplugin.gui.swingcomponents.tableproperties.PropertiesCellEditor;

public abstract class SwingInternalComponent extends AbstractViewComponent {
  private String displayName;
  private PropertiesCellEditor editor;

  public void setEditor(PropertiesCellEditor editor) { this.editor = editor; }
  public PropertiesCellEditor getEditor() { return editor; }

  public void setDisplayName(String displayName) { this.displayName = displayName; }
  public String getDisplayName() { return displayName; }

  public SwingInternalComponent(String name, String displayName) {
    setName(name);
    setDisplayName(displayName);
  }

  public Object getUI() {
    return null;
  }

  public abstract Component getInternalRenderer();
  public abstract Component getInternalEditor();

  public abstract void updateUI();
  public abstract void updateData();

  protected ActionListener stopEditingListener = new ActionListener() {
    public void actionPerformed(ActionEvent evt) {
      if(getEditor() != null)getEditor().stopCellEditing();
    }
  };
  protected KeyListener escapeListener = new KeyAdapter() {
    public void keyPressed(KeyEvent evt) {
      if(KeyEvent.VK_ESCAPE == evt.getKeyCode()) {
        if(getEditor() != null)getEditor().cancelCellEditing();
      }
    }
  };

  protected FocusListener lostListener = new FocusListener(){
    public void focusGained(FocusEvent evt) {}
    public void focusLost(FocusEvent evt) {
      if(getEditor() != null)getEditor().stopCellEditing();
    }
  };

}
