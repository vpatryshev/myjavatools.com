package com.borland.dspspb.primetime.crmplugin.gui.dialogs;

import javax.swing.*;

public class AdrenalinDialogButton extends JButton {
    public AdrenalinDialogButton(String buttonType) {
        super(buttonType);
        this.buttonType = buttonType;
    }

    public String getButtonType() {
        return buttonType;
    }

    public static final String OK = " OK ";
    public static final String CANCEL = " Cancel ";
    public static final String HELP = " Help ";
    public static final String ABORT = " Abort ";
    public static final String IGNORE = " Ignore ";
    public static final String RETRY = " Retry ";
    public static final String YES = " Yes ";
    public static final String NO = " No ";
    private String buttonType = null;
}
