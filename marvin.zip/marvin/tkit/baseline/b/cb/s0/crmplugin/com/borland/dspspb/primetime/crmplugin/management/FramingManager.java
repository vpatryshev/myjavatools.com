package com.borland.dspspb.primetime.crmplugin.management;

import com.borland.primetime.ide.Browser;
import com.borland.primetime.node.Project;
import java.awt.Frame;
import java.awt.Component;
import java.awt.Cursor;
import javax.swing.JOptionPane;
import com.borland.primetime.ide.MessageCategory;
import com.borland.primetime.node.Node;
import java.io.File;
import java.io.*;
import com.borland.primetime.util.WaitCursor;


public class FramingManager
{
  private static FramingManager instance;
  private static Component m_glassPane = null;
  private String m_homedirname = System.getProperty("user.dir") + File.separator + "crmplugin" + File.separator; //NORES
  private static boolean m_bWaitShown = false;
  private static WaitCursor m_waitCursor;

  private FramingManager()
  {
    if (Browser.getActiveBrowser() != null)
    {
      m_glassPane = Browser.getActiveBrowser().getGlassPane();
      m_waitCursor = new WaitCursor(Browser.getActiveBrowser());
    }
  }

  public static FramingManager getInstance()
  {
    if (instance == null)
    {
      instance = new FramingManager();
      instance.init();
    }
    return instance;
  }

  private void init()
  {
  }

////////////////////////////////////////////////////////////////////////////////
// Window Management

  public Frame getMainFrame()
  {
    return Browser.getActiveBrowser();
  }

  public static void showWaitCursor(boolean bShow)
  {
//    if (m_glassPane == null)
//      return;
//    m_glassPane.setVisible(bShow);
//    m_glassPane.setCursor(new Cursor(bShow ? Cursor.WAIT_CURSOR : Cursor.DEFAULT_CURSOR));
    if (m_waitCursor == null)
      return;
    if (bShow && !m_bWaitShown)
    {
      m_waitCursor.set();
      m_bWaitShown = true;
    }
    else if (!bShow && m_bWaitShown)
    {
      m_waitCursor.restore();
      m_bWaitShown = false;
    }
  }

////////////////////////////////////////////////////////////////////////////////
// IDEProject Management

  public IDEProject getActiveIDEProject()
  {
    Browser browser = Browser.getActiveBrowser();
    if (browser == null)
      return null;
    Project project = browser.getActiveUserProject();
    if (project == null)
      return null;
    return new IDEProject(project);
  }

  public Node getActiveNode()
  {
    Browser browser = Browser.getActiveBrowser();
    if (browser == null)
      return null;
    Node node = browser.getActiveNode();
    return node;
  }

////////////////////////////////////////////////////////////////////////////////
// Config Management
  private String getProperty(String propName)
  {
    return null;
  }

  public void setProperty(String propName, String propValue)
  {
  }

////////////////////////////////////////////////////////////////////////////////
// Log Management


////////////////////////////////////////////////////////////////////////////////
// Status Bar Management


////////////////////////////////////////////////////////////////////////////////
// Resource Management

////////////////////////////////////////////////////////////////////////////////
// Message Panel Management

  public void addMessage(String message)
  {
  }

  public void clearMessages()
  {
  }

////////////////////////////////////////////////////////////////////////////////
// Message Dialog (???) Management

  private static String MESSAGEDIALOG_TITLE = "CaliberRM Plugin"; //RES MessageDialog_title
  public void showMessage(Component parentComponent, String message)
  {
    JOptionPane.showMessageDialog(parentComponent, message,
      MESSAGEDIALOG_TITLE,
      JOptionPane.INFORMATION_MESSAGE);
    return;
  }

  public void showWarning(Component parentComponent, String message)
  {
    JOptionPane.showMessageDialog(parentComponent, message,
      MESSAGEDIALOG_TITLE,
      JOptionPane.WARNING_MESSAGE);
    return;
  }

  public void showError(Component parentComponent, String message)
  {
    JOptionPane.showMessageDialog(parentComponent, message,
      MESSAGEDIALOG_TITLE,
      JOptionPane.ERROR_MESSAGE);
    return;
  }

  public void showMessage(String message)
  {
    showMessage(getMainFrame(), message);
  }

  public void showWarning(String message)
  {
    showWarning(getMainFrame(), message);
  }

  public void showError(String message)
  {
    showError(getMainFrame(), message);
  }

  public int showConfirm(Component parentComponent, String message)
  {
    int result = JOptionPane.showConfirmDialog
      (parentComponent, message,
       MESSAGEDIALOG_TITLE,
       JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
    return result;
  }

  public int showConfirm(String message)
  {
    return showConfirm(getMainFrame(), message);
  }

////////////////////////////////////////////////////////////////////////////////
// File (???) Management

  public void setHomeDirName(String homedirname)
  {
    if (new File(homedirname).exists())
      m_homedirname = homedirname;
  }

  public File getPluginFile(String filename)
  {
    if (filename == null)
      return null;
    File pluginFile = new File(m_homedirname, filename);
    return pluginFile;
  }
}
