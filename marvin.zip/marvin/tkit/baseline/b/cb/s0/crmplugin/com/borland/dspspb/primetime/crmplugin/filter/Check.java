package com.borland.dspspb.primetime.crmplugin.filter;

public class Check
{
  public static final String NOTHING  = "";         //NORES
  public static final String EXISTS   = "EXISTS";   //NORES
  public static final String EQ       = "EQ";       //NORES
  public static final String LT       = "LT";       //NORES
  public static final String LE       = "LE";       //NORES
  public static final String GT       = "GT";       //NORES
  public static final String GE       = "GE";       //NORES
  public static final String BETWEEN  = "BETWEEN";  //NORES
  public static final String ONEOF    = "ONEOF";    //NORES
  public static final String CONTAINS = "CONTAINS"; //NORES

  private static final Check CHECKNOTHING  = new Check(NOTHING);
  private static final Check CHECKEXISTS   = new Check(EXISTS);
  private static final Check CHECKEQ       = new Check(EQ);
  private static final Check CHECKLT       = new Check(LT);
  private static final Check CHECKLE       = new Check(LE);
  private static final Check CHECKGT       = new Check(GT);
  private static final Check CHECKGE       = new Check(GE);
  private static final Check CHECKBETWEEN  = new Check(BETWEEN);
  private static final Check CHECKONEOF    = new Check(ONEOF);
  private static final Check CHECKCONTAINS = new Check(CONTAINS);

  private String m_code;

  public Check()
  {
  }

  public Check(String code)
  {
    m_code = code;
  }

  public String getCode()
  {
    return m_code;
  }

  public void setCode(String code)
  {
    this.m_code = code;
  }

//------------------------------------------------------------------------------

  public String getName()
  {
    return m_code;
  }

  public static Check getCheck(String code)
  {
    if (code != null)
    {
      if (code.equals(Check.NOTHING))
        return CHECKNOTHING;
      if (code.equals(Check.EXISTS))
        return CHECKEXISTS;
      if (code.equals(Check.EQ))
        return CHECKEQ;
      if (code.equals(Check.LT))
        return CHECKLT;
      if (code.equals(Check.LE))
        return CHECKLE;
      if (code.equals(Check.GT))
        return CHECKGT;
      if (code.equals(Check.GE))
        return CHECKGE;
      if (code.equals(Check.BETWEEN))
        return CHECKBETWEEN;
      if (code.equals(Check.ONEOF))
        return CHECKONEOF;
      if (code.equals(Check.CONTAINS))
        return CHECKCONTAINS;
    }
    return CHECKNOTHING;
  }

  public static Check[] getChecks(String type)
  {
    if (type != null)
    {
      if (type.equals(Field.TYPE_STRING))
        return new Check[] {CHECKEXISTS, CHECKEQ, CHECKCONTAINS, CHECKONEOF};
      else if (type.equals(Field.TYPE_TEXT))
        return new Check[] {CHECKEXISTS, CHECKCONTAINS};
      else if (type.equals(Field.TYPE_ENUM) ||
          type.equals(Field.TYPE_USER))
        return new Check[] {CHECKEXISTS, CHECKEQ, CHECKONEOF};
      else if (type.equals(Field.TYPE_VERSION))
        return new Check[] {CHECKEXISTS, CHECKEQ, CHECKLT, CHECKLE, CHECKGT, CHECKGE, CHECKBETWEEN, CHECKONEOF};
    }
    return new Check[] {CHECKEXISTS};
  }

  public String toString()
  {
    return getName();
  }

}
