package com.borland.dspspb.primetime.crmplugin.opentool;

import java.awt.*;
import javax.swing.*;

import com.borland.primetime.node.Node;
import com.starbase.caliber.Requirement;

public interface INodeSteward
{
  public String getId();
  public Icon getIcon();
  public Action[] getActions(Node node, Requirement requirement);
  public Component[] getDropEagerComponents(Node node);
  public String getRequirementLocator (Node node, Point point);
  public String getCommentText(RequirementInfo requirementInfo);
  public String getCommentLocator(Node node, Point point);
  public int getCommentStatus(String commentLocator, RequirementInfo requirementInfo);
  public boolean openComment(String commentLocator);
  public int createComment (String commentLocator, RequirementInfo requirementInfo);
  public int updateComment (String commentLocator, RequirementInfo requirementInfo);
  public void deleteComment (String commentLocator, RequirementInfo requirementInfo);
}
