package com.borland.dspspb.primetime.crmplugin.actions;
import java.awt.event.*;
import javax.swing.*;

import com.borland.dspspb.primetime.crmplugin.resources.*;
import com.borland.dspspb.primetime.crmplugin.view.*;
import com.borland.dspspb.primetime.crmplugin.view.rvtreetable.*;
import com.borland.dspspb.primetime.crmplugin.opentool.CommentStatus;
import com.borland.dspspb.primetime.crmplugin.management.FramingManager;

public class ActionDeleteTraces extends PluginUpdateAction
{
  public ActionDeleteTraces()
  {
    super
      ("Delete Traces", //RES ActionDeleteTraces_shorttext
       "Delete selected traces and associated requirement comments", //RES ActionDeleteTraces_longtext
       ResourceManager.ActionDeleteTraces_icon);
  }

  public void actionPerformed (ActionEvent e)
  {
    TraceTable traceTable = (TraceTable) e.getSource();

    int [] selectedRows = traceTable.getSelectedRows ();
    int nSelected = selectedRows.length;
    int nUnknown = 0;

    if (nSelected == 0) return;

    String message = (nSelected > 1)
      ? "Do you really want to delete " + nSelected + " traces?" //RES ActionDeleteTraces_confirm1,ActionDeleteTraces_confirm2
      : "Do you really want to delete trace?"; //RES ActionDeleteTraces_confirm3

    String title = "Delete Traces"; //RES ActionDeleteTraces_title

    int confirmResult = FramingManager.getInstance().showConfirm(message);
    if (confirmResult != JOptionPane.OK_OPTION) return;


    RequirementNode requirementNode = null;
    TraceInfo [] tracesInfo = new TraceInfo [nSelected];

    for (int i = 0; i < nSelected; i++)
    {
      TraceInfo traceInfo = traceTable.getData () [selectedRows [i]];

      if (traceInfo.getStatus () == CommentStatus.STATUS_UNKNOWN) nUnknown++;

      tracesInfo [i] = traceInfo;
      requirementNode = traceInfo.getRequirementNode();
    }

    requirementNode.deleteTraces (tracesInfo);

    traceTable.updateModel (requirementNode.getTracesInfo ());
    ActionUpdateComments.updateRequirementTable (requirementNode);

    if (nUnknown != 0)
    {
      message = "" + nUnknown + " "; //NORES
      message += (nUnknown == 1
        ? "of associated comments has not been deleted because of Unknown status." //RES ActionDeleteTraces_message1
        : "of associated comments have not been deleted because of Unknown status."); //RES ActionDeleteTraces_message2
      FramingManager.getInstance().showWarning(message);
    }
  }

  public void update (Object source)
  {
    TraceTable traceTable = (TraceTable) source;
    setEnabled (traceTable.getSelectedRowCount () > 0);
  }
}
