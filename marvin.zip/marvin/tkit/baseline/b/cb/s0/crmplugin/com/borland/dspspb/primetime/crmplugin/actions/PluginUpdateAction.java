package com.borland.dspspb.primetime.crmplugin.actions;

import com.borland.primetime.actions.UpdateAction;
import javax.swing.ImageIcon;
import java.awt.event.ActionEvent;
import com.borland.dspspb.primetime.crmplugin.resources.ResourceManager;

public class PluginUpdateAction extends UpdateAction
{
  public PluginUpdateAction (String shortText, String longText, String iconhKey)
  {
    super ();

    ImageIcon icon = ResourceManager.getIcon (iconhKey);

    setShortText (shortText);
    setLongText (longText);
    setSmallIcon (icon);
  }

  public void actionPerformed (ActionEvent actionEvent)
  {
    System.out.println("Action: " + getShortText ()); //NORES
  }
}
