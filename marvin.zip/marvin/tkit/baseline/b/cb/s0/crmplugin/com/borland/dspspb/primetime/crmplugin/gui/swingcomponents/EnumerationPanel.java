package com.borland.dspspb.primetime.crmplugin.gui.swingcomponents;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class EnumerationPanel extends JPanel {
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  JLabel leftTitle = new JLabel();
  JList leftList = new JList();
  JPanel centerPanel = new JPanel(new GridBagLayout());
  GridLayout gridLayout1 = new GridLayout();
  JButton addButton = new JButton("Add...");
  JButton upButton = new JButton("Move up");
  JButton removeButton = new JButton("Remove");
  JButton downButton = new JButton("Move down");
  JPanel downPodporka = new JPanel();
  JScrollPane leftPane = new JScrollPane(leftList,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED );
  DefaultListModel leftListModel = new DefaultListModel();

  public EnumerationPanel(String leftLabelText ) {

    leftTitle.setText(leftLabelText);
    leftList.setModel( leftListModel);
    this.setLayout(gridBagLayout1);
    centerPanel.setLayout(gridLayout1);

  addButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        addButton_actionPerformed(e);
      }
    });
  removeButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        removeButton_actionPerformed(e);
      }
    });
    upButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        upButton_actionPerformed(e);
      }
    });
    downButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        downButton_actionPerformed(e);
      }
    });
    gridLayout1.setRows(4);
    gridLayout1.setColumns(1);
    gridLayout1.setHgap(3);
    gridLayout1.setVgap(6);
    this.add(leftTitle,       new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
      ,GridBagConstraints.NORTHWEST, GridBagConstraints.NONE, new Insets(6, 12, 0, 0), 0, 0));
    this.add(leftPane,           new GridBagConstraints(0, 1, 1, 1, 1.0, 0.0
      ,GridBagConstraints.NORTHWEST, GridBagConstraints.BOTH, new Insets(3, 12, 6, 0), 100, 0));

    centerPanel.add(addButton, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
      ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 12, 0, 0), 0, 0));
  centerPanel.add(removeButton, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
      ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(12, 12, 12, 12), 0, 0));
  centerPanel.add(upButton, new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
      ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(12, 12, 12, 12), 0, 12));
  centerPanel.add(downButton, new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0
      ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 12, 0, 0), 0, 0));

  this.add(centerPanel,                 new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0
      ,GridBagConstraints.NORTHWEST, GridBagConstraints.BOTH, new Insets(3, 6, 40, 6), 0, 0));

    this.add(downPodporka,        new GridBagConstraints(0, 3, 5, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0));
  }

  public DefaultListModel getListModel()
  {
     return leftListModel;
  }


  void addButton_actionPerformed(ActionEvent e)
  {
    String text = JOptionPane.showInputDialog(null, "Add Value", "Add", JOptionPane.QUESTION_MESSAGE);
    if(text != null && text.trim().length() != 0)
    {
      leftListModel.addElement( text );
        }
  }


  void removeButton_actionPerformed(ActionEvent e)
  {
     while ( leftList.getSelectedIndex()!=-1 )
     {
        leftListModel.removeElementAt( leftList.getSelectedIndex() );
     }
  }

  void upButton_actionPerformed(ActionEvent e)
  {
      int index = leftList.getSelectedIndex();
      if ( index > 0 )
      {
         Object tmp = leftListModel.elementAt( index-1 );
         leftListModel.setElementAt( leftListModel.getElementAt(index),index-1);
         leftListModel.setElementAt( tmp,index );
         leftList.setSelectedIndex( index-1 );
      }
  }
  void downButton_actionPerformed(ActionEvent e)
  {
      int index = leftList.getSelectedIndex();
      if ( index < leftListModel.size()-1 )
      {
         Object tmp = leftListModel.elementAt( index+1 );
         leftListModel.setElementAt( leftListModel.getElementAt(index),index+1);
         leftListModel.setElementAt( tmp,index );
         leftList.setSelectedIndex( index+1 );
      }
  }

}
