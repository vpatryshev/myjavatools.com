package com.borland.dspspb.primetime.crmplugin.gui.swingcomponents.tableproperties;

import javax.swing.table.DefaultTableModel;
import java.util.Vector;
import javax.swing.table.TableCellRenderer;
import java.awt.Component;
import javax.swing.JTable;
import javax.swing.Icon;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JButton;
import com.borland.dspspb.primetime.crmplugin.gui.swingcomponents.tableproperties.internal.SwingInternalComponent;

public class PropertiesCellRenderer implements TableCellRenderer {

  private Vector comps;

  public PropertiesCellRenderer(Vector comps) {
    this.comps = comps;
  }

  public SwingInternalComponent getComponent(int row) {
    return (SwingInternalComponent)comps.get(row);
  }


  public Component getTableCellRendererComponent(	JTable table,
                          Object value,
                          boolean isSelected,
                          boolean hasFocus,
                          int row,
                          int column) {
    SwingInternalComponent sic = getComponent(row);
    sic.updateUI();
    return sic.getInternalRenderer();
  }

}
