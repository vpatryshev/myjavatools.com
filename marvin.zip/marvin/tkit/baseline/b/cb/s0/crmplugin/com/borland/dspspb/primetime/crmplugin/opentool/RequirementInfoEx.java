package com.borland.dspspb.primetime.crmplugin.opentool;

public class RequirementInfoEx extends RequirementInfo
{
  public void setLocator (String locator)
  {
    strLocator = locator;
  }

  public void setFieldValue (String key, String value)
  {
    int keyIndex = vNames.indexOf (key);

    if (keyIndex == -1)
    {
      vNames.add (key);
      vValues.add (value);
    }
    else
    {
      vValues.setElementAt (value, keyIndex);
    }
  }
}
