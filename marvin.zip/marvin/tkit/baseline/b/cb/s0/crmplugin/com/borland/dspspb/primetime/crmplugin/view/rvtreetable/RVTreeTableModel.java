package com.borland.dspspb.primetime.crmplugin.view.rvtreetable;

import java.util.Vector;

import com.borland.dspspb.primetime.crmplugin.management.CaliberManager;
import com.borland.dspspb.primetime.crmplugin.gui.treetable.AbstractTreeTableModel;
import com.borland.dspspb.primetime.crmplugin.gui.treetable.TableNodeAdapter;
import com.borland.dspspb.primetime.crmplugin.gui.treetable.TreeTableModel;
import com.starbase.caliber.Requirement;

public class RVTreeTableModel extends AbstractTreeTableModel
{
  private Vector currentColumns = new Vector();

// -----------------------------------------------------------------------------

  public RVTreeTableModel(Object root, Vector currentColumns)
  {
    super(root);
    this.currentColumns = currentColumns;
  }

// -----------------------------------------------------------------------------

  public int getColumnCount()
  {
    return currentColumns.size();
  }

  public String getColumnName(int column)
  {
    return currentColumns.get(column).toString();
  }

  public Class getColumnClass(int column)
  {
    if (column == 0)
      return TreeTableModel.class;
    else
      return String.class;
  }

  public Object getValueAt(Object node, int column)
  {
    if (node instanceof ProjectNode)
    {
      ProjectNode projectNode = (ProjectNode)node;
      return (column == 0 ? projectNode.getText() : ""); //NORES
    }

    if (node instanceof RequirementTypeNode)
    {
      RequirementTypeNode requirementTypeNode = (RequirementTypeNode)node;
      return (column == 0 ? requirementTypeNode.getText() : ""); //NORES
    }

    if (!(node instanceof RequirementNode))
      return ""; //NORES


    RequirementNode requirementNode = (RequirementNode)node;
    RVTableColumn tableColumn = (RVTableColumn)currentColumns.get (column);
    String fieldName = tableColumn.getName();

    return requirementNode.getFieldValue(fieldName);
  }

  public int getChildCount(Object parent)
  {
    return ((TableNodeAdapter)parent).getChildCount();
  }

  public Object getChild(Object parent, int index)
  {
    return ((TableNodeAdapter)parent).getChildAt(index);
  }

// -----------------------------------------------------------------------------

  public Vector getColumns()
  {
    return currentColumns;
  }

  public void setColumns (Vector columns)
  {
    currentColumns = columns;
  }
}
