package com.borland.dspspb.primetime.crmplugin.gui.actions.toolbar;

import javax.swing.JButton;
import java.awt.Dimension;
import com.borland.dspspb.primetime.crmplugin.gui.actions.SwingAction;
import javax.swing.plaf.ButtonUI;
import com.borland.dspspb.primetime.crmplugin.gui.actions.SwingCheckBoxAction;

public class ToolBarButton extends JButton {

    public ToolBarButton(SwingAction action) {
        super(action);
        //setFocusable(false);
        setBorderPainted(false);
        setRolloverEnabled(true);
        setUI(ToolBarButtonUI.ourUI);
        setupButton();
    }

    public SwingAction getAdrenalinAction() { return (SwingAction)getAction(); }

    private void setupButton() {
        SwingAction action = getAdrenalinAction();
        setEnabled(action.isEnabled());
        if(action instanceof SwingCheckBoxAction) {
            setSelected(((SwingCheckBoxAction)action).isChecked());
        }
    }


    public void updateButton() {
        setupButton();
    }

    public void setForceRollover(boolean forceRollover) {
        if(forceRollover) {
            setModel(new javax.swing.DefaultButtonModel(){
                public boolean isRollover() { return true; }
            });
        }else {
            setModel(new javax.swing.DefaultButtonModel());
        }
    }
}
