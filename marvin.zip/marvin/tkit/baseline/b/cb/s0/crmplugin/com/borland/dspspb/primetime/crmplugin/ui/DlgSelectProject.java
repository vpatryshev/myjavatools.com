package com.borland.dspspb.primetime.crmplugin.ui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import com.borland.dspspb.primetime.crmplugin.dialog.*;
import com.borland.dspspb.primetime.crmplugin.management.*;
import com.borland.primetime.ui.*;
import com.borland.primetime.help.HelpTopic;
import com.borland.primetime.help.PrimetimeHelp;
import com.starbase.caliber.*;
import com.starbase.caliber.server.*;

public class DlgSelectProject extends PluginDialog
  implements ItemListener, DialogValidator, IUpdatableDialog
{
  private JLabel lblProject = null;
  private JComboBox cbProject = null;
  private JLabel lblBaseline = null;
  private JComboBox cbBaseline = null;

  private Source source = null;
  private Session session = null;
  private Project [] projects = null;
  private boolean isInitialized = false;

  public DlgSelectProject (Component owner, Source source)
  {
    super (owner, "Change Project"); //RES DlgSelectProject_title
    setHelpTopic (PrimetimeHelp.createTopic (PrimetimeHelp.BOOK_UserGuide, "ui/dialogs/dlgcaliberchangeproject.html")); //NORES

//    this.source = (Source) source.clone ();
    this.source = source;
    session = SessionManager.getInstance().getSession(source);

    // Load Caliber projects
    FramingManager.showWaitCursor(true);
    projects = CaliberManager.getProjects (session);
    FramingManager.showWaitCursor(false);
    if (projects == null)
    {
      String failMessage =
        "Failed to get list of projects from server " + //RES DlgSelectProject_GetProjectsFailed
        source.getServer() + "." + "\n" + //NORES NORES
        "Please verify that the server is running and accessible."; //RES DlgSelectProject_VerifyServer
      FramingManager.getInstance().showError(this, failMessage);
      return;
    }
    isInitialized = true;
  }

  public JComponent getContentUI ()
  {
    JPanel panel = new JPanel (new GridBagLayout ());

    lblProject = new JLabel ("Project:"); //RES DlgSelectProject_Project_text
    lblProject.setDisplayedMnemonic('P'); //RES DlgSelectProject_Project_mnemonic
    cbProject = new JComboBox ();
    lblProject.setLabelFor(cbProject);

    lblBaseline = new JLabel ("Baseline:"); //RES DlgSelectProject_Baseline_text
    lblBaseline.setDisplayedMnemonic('B'); //RES DlgSelectProject_Baseline_mnemonic
    cbBaseline = new JComboBox ();
    lblBaseline.setLabelFor(cbBaseline);

    initControls ();

    GridBagConstraints constraints = new GridBagConstraints ();
    Insets insetsLbl = new Insets (3, 5, 2, 5);
    Insets insetsTxt = new Insets (0, 5, 5, 5);
    Insets insetsBtn = new Insets (-2, 5, 5, 0);

    constraints.anchor = GridBagConstraints.NORTHWEST;
    constraints.weightx = 0.0;
    constraints.weighty = 0.0;

    // Project
    constraints.gridx = 0;
    constraints.gridy = 0;
    constraints.insets = insetsLbl;
    constraints.fill = GridBagConstraints.NONE;
    panel.add (lblProject, constraints);

    constraints.gridx = 1;
    constraints.gridy = 0;
    constraints.insets = insetsTxt;
    constraints.fill = GridBagConstraints.HORIZONTAL;
    panel.add (cbProject, constraints);

    // Filter
    constraints.gridx = 0;
    constraints.gridy = 1;
    constraints.insets = insetsLbl;
    constraints.fill = GridBagConstraints.NONE;
    panel.add (lblBaseline, constraints);

    constraints.gridx = 1;
    constraints.gridy = 1;
    constraints.weightx = 1.0;
    constraints.weighty = 1.0;
    constraints.insets = insetsTxt;
    constraints.fill = GridBagConstraints.HORIZONTAL;
    panel.add (cbBaseline, constraints);

    return panel;
  }

  private void initControls ()
  {
    // Initialize dialog controls
    cbProject.addItemListener(this);
    String currentProjectId = source.getProjectId();
    for (int i = 0; i < projects.length; i++)
    {
      Project project = projects[i];
      cbProject.addItem(project);
      String projectId = "" + project.getID().getIDNumber(); //NORES

      if (projectId.equals(currentProjectId))
      {
        cbProject.setSelectedItem(project);
      }
    }

    cbProject.setRenderer(new ProjectRenderer());
    cbBaseline.setRenderer (new BaselineRenderer ());
  }

// -----------------------------------------------------------------------------

  public Source getSource ()
  {
    return source;
  }

// -----------------------------------------------------------------------------
// IUpdatableDialog implementation

  public void updateDialog ()
  {
    cbProject.setEnabled (session != null);
    cbBaseline.setEnabled (session != null);
  }

// -----------------------------------------------------------------------------
// DialogValidator implementation

  public boolean validateDialog ()
  {
    int selectedIndex = cbProject.getSelectedIndex ();

    if (selectedIndex == -1)
    {
      showValidationMessage ("No project selected.\nPlease select project.", cbProject); //RES DlgSelectProject_NoProject_message
      return false;
    }

    selectedIndex = cbBaseline.getSelectedIndex ();

    if (selectedIndex == -1)
    {
      showValidationMessage ("No baseline selected.\nPlease select baseline.", cbBaseline);  //RES DlgSelectProject_NoBaseline_message
      return false;
    }

    return true;
  }

  public boolean showDialog ()
  {
    if (isInitialized)
      return super.showDialog();
    return false;
  }

  public void onOk ()
  {
    // Transfer dialog data to the Source object
    Project selectedProject = (Project) cbProject.getSelectedItem();
    String projectId = "" + selectedProject.getID().getIDNumber(); //NORES
    source.setProjectId (projectId);
    source.setProjectName (selectedProject.getName ());

    Baseline selectedBaseline = (Baseline) cbBaseline.getSelectedItem();
    String baselineId = "" + selectedBaseline.getID().getIDNumber(); //NORES
    source.setBaselineId (baselineId);
    source.setBaselineName (selectedBaseline.getName());
  }

// -----------------------------------------------------------------------------

  public void itemStateChanged (ItemEvent e)
  {
    // Load baselines for current project
    Object selectedObject = cbProject.getSelectedItem();

    if (!(selectedObject instanceof Project)) return;

    Project selectedProject = (Project) selectedObject;

    if (selectedProject == null) return;

    cbBaseline.removeAllItems();
    String currentBaselineId = source.getBaselineId ();

    try
    {
      Baseline [] baselines = selectedProject.getBaselines ();

      for (int i = 0; i < baselines.length; i++)
      {
        Baseline baseline = baselines [i];
        cbBaseline.addItem (baseline);
        String baselineId = "" + baseline.getID().getIDNumber(); //NORES

        if (baselineId.equals (currentBaselineId))
        {
          cbBaseline.setSelectedItem (baseline);
        }
      }
    }
    catch (RemoteServerException ex)
    {
      System.err.println ("DlgSelectProject: RemoteServerException"); //NORES
    }
  }

// -----------------------------------------------------------------------------

  private class ProjectRenderer extends DefaultListCellRenderer
  {
    public Component getListCellRendererComponent
      (JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
    {
      String projectName = ""; //NORES

      Project rmProject = (Project) value;
      if (rmProject != null) projectName = rmProject.getName ();

      super.getListCellRendererComponent (list, projectName, index, isSelected, cellHasFocus);
      return this;
    }
  }

  private class BaselineRenderer extends DefaultListCellRenderer
  {
    public Component getListCellRendererComponent
      (JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
    {
      String baselineName = ""; //NORES

      Baseline baseline = (Baseline) value;
      if (baseline != null) baselineName = baseline.getName ();

      super.getListCellRendererComponent (list, baselineName, index, isSelected, cellHasFocus);
      return this;
    }
  }
}
