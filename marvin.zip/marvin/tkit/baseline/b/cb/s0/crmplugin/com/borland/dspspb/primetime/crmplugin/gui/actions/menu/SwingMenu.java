package com.borland.dspspb.primetime.crmplugin.gui.actions.menu;

import java.util.Vector;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.event.MenuListener;
import javax.swing.event.MenuEvent;
import javax.swing.MenuElement;
import javax.swing.ImageIcon;

public class SwingMenu {
    private String name;
    private int mnemonic;
    private String clientName;
    private Vector sections = new Vector();
    private JMenu menu = null;

    public SwingMenu(String name, String clientName, int mnemonic) {
        this.name = name;
        this.mnemonic = mnemonic;
        this.clientName = clientName;
    }

    public String getName() { return name; }
    public String getClientName() { return clientName; }

    public MenuSection[] getSections() {
        return (MenuSection[])sections.toArray(new MenuSection[0]);
    }

    public MenuSection addMenuSection() { return addMenuSection(-1); }
    public MenuSection addMenuSection(int addIndex) {
        MenuSection newSection = new MenuSection(this);
        if(addIndex < 0)sections.add(newSection);
        else sections.add(addIndex, newSection);
        rebuildMenu();
        return newSection;
    }

    void rebuildMenu() { menu = null; }

    public MenuSection getMenuSection(int number) { return (MenuSection)sections.get(number); }

    public JMenu getMenu() {
        if(menu == null) {
            menu = new JMenu(name);
            menu.addMenuListener(new MenuListener() {
                public void menuCanceled(MenuEvent e) {}

                public void menuDeselected(MenuEvent e) {}

                public void menuSelected(MenuEvent e) {
                    updateMenu();
                }
            });
            MenuSection[] sections = getSections();
            boolean newSect = false;
            for(int i = 0; i < sections.length; i++) {
                IMenuItem[] items = sections[i].getMenuItems();
                if(newSect && items.length != 0) {
                    menu.addSeparator();
                    newSect = false;
                }
                for(int j = 0; j < items.length; j++) {
                    menu.add((JMenuItem)items[j]);
                    newSect = true;
                }
            }
            if(mnemonic > 0)
                menu.setMnemonic(mnemonic);

            boolean hasImages = false;
            for(int i=0; i<menu.getItemCount(); i++) {
                JMenuItem jitem = menu.getItem(i);
                if(jitem == null)continue;
                if(jitem.getIcon() != null) {
                    hasImages = true;
                    break;
                }
            }
            if(hasImages) {
                for(int i=0; i<menu.getItemCount(); i++) {
                    JMenuItem jitem = menu.getItem(i);
                    if(jitem == null)continue;
                    if(jitem.getIcon() == null) {
                        jitem.setIcon(new ImageIcon(getClass().getClassLoader().getResource("com/borland/dspspb/resources/images/general/blank.gif")));
                    }
                }
            }
        }
        return menu;
    }

    public void updateMenu() {
        MenuSection[] sections = getSections();
        for(int i=0; i<sections.length; i++) {
            sections[i].updateSection();
        }
    }

    public MenuSection getSection(int section) {
        return (MenuSection)getSections()[section];
    }

    public boolean isVisible() { return true; }

}

