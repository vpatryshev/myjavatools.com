package com.borland.dspspb.primetime.crmplugin.gui.swingcomponents.tableproperties.internal;

import java.util.Vector;
import java.awt.Component;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JCheckBox;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CheckBoxInternalComponent extends SwingInternalComponent {

    public CheckBoxInternalComponent(String name, String displayName, boolean value) {
        this(name, displayName);
        setValue(value);
    }
  public CheckBoxInternalComponent(String name, String displayName) {
    super(name, displayName);
    cb.addActionListener(stopEditingListener);
  }

  private JCheckBox cb = new JCheckBox();

  public Component getInternalRenderer() {
    JCheckBox chb = new JCheckBox( (String)null, "true".equals(getValue()) );
    chb.setEnabled(isEditable());
    return chb;
  }

  public Component getInternalEditor() {
    cb.setAlignmentX( JCheckBox.CENTER_ALIGNMENT );
    cb.setEnabled(isEditable());
    return cb;
  }

  public void updateUI() {
    cb.getModel().setSelected( "true".equals(getValue()) );
  }
  public void updateData() {
    setValue( cb.getModel().isSelected() ? "true" : "false" );
  }

    public boolean getBooleanValue() {
        return "true".equals(getValue());
    }

    public void setValue(boolean value) {
        setValue(value ? "true" : "false");
    }

}
