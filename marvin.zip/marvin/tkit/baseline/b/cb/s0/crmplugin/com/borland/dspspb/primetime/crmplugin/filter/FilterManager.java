package com.borland.dspspb.primetime.crmplugin.filter;

import java.io.*;
import java.net.*;
import java.rmi.dgc.*;
import java.text.*;
import java.util.*;

import com.borland.dspspb.primetime.crmplugin.*;
import com.borland.dspspb.primetime.crmplugin.management.*;
import com.borland.dspspb.primetime.crmplugin.util.smartxml.*;
import com.borland.dspspb.primetime.crmplugin.view.rvtreetable.*;


public class FilterManager
{
  private static String NEW_FILTER = "New Filter"; //RES FilterManager_New_Filter_0
  private static String NEW_FILTER_N_PATTERN = "New Filter {0}"; //RES FilterManager_New_Filter_N_pattern
  private static String FILTERSDIRNAME = ".filters"; //NORES
  private static String FILTERSDIRFULLNAME = System.getProperty("user.home") + File.separator + FILTERSDIRNAME + File.separator; //NORES

  private static FilterManager manager = null;
  private static Vector filters = new Vector();
  private static Field[] m_fields = new Field[0];

  public static Filter NOFILTER = new Filter("(No Filter)"); //RES Filter_NoFilter_text

  protected FilterManager()
  {
    NOFILTER.setId("Predefined Filter 0"); //NORES
    NOFILTER.setDescription("Predefined: no filter is applied"); //RES Filter_Predefined_description
    NOFILTER.setPredefined(true);
  }

  public static final synchronized FilterManager getInstance ()
  {
    if (manager == null)
    {
      manager = new FilterManager ();
      manager.init ();
    }

    return manager;
  }

  private void init ()
  {
    // Add predefined filters
    filters.add(NOFILTER);
    // Add custom filters
    File fileFilterDir = new File(FILTERSDIRFULLNAME);
    if (!fileFilterDir.exists())
    {
      fileFilterDir.mkdirs();
    }
    String[] filenameFilters = fileFilterDir.list();
    for (int i = 0; i < filenameFilters.length; i++)
    {
       Filter filter = (Filter)DomManager.getInstance ().readConvertable (FILTERSDIRFULLNAME + filenameFilters[i]);
       filters.add(filter);
    }
    // Build fields set
    Vector columns = PluginManager.getInstance().getAllColumns();
    m_fields = new Field[columns.size()];
    for (int i = 0; i < columns.size(); i++)
    {
      RVTableColumn column = (RVTableColumn)columns.get(i);
      m_fields[i] = new Field(column.getName(), getFieldType(column.getName()), column.getDisplayName());
    }
  }

// -----------------------------------------------------------------------------

  private void addFilterFile (Filter filter)
  {
    if (filter == null)
      return;
    String filenameFilter = FILTERSDIRFULLNAME + filter.getFilename();
    DomManager.getInstance ().writeConvertable (filenameFilter, filter);
  }

  private void removeFilterFile (Filter filter)
  {
    if (filter == null)
      return;
    File fileFilter = new File(FILTERSDIRFULLNAME + filter.getFilename());
    fileFilter.delete();
  }

  public Filter[] getFilters ()
  {
    return (Filter[])filters.toArray(new Filter[filters.size()]);
  }

  public void addFilter (Filter filter)
  {
    filters.add (filter);
    addFilterFile (filter);
  }

  public void removeFilter (Filter filter)
  {
    if (filter.getPredefined())
      return;
    filters.remove (filter);
    removeFilterFile(filter);
  }

  public Filter findFilter (String id)
  {
    for (int i = 0; i < filters.size(); i++)
    {
      Filter filter = (Filter) filters.get (i);

      if (filter.getId().equals(id))
        return filter;
    }

    return null;
  }

  public Filter findFilterByName (String name)
  {
    if (name == null)
      return null;
    for (int i = 0; i < filters.size(); i++)
    {
      Filter filter = (Filter) filters.get (i);

      if (name.equals(filter.getName()))
        return filter;
    }

    return null;
  }

  public void replaceFilter(Filter filterOld, Filter filterNew)
  {
    if (filterOld == null)
      addFilter(filterNew);
    else
    {
      int idx = filters.indexOf(filterOld);
      if (idx >= 0)
      {
        removeFilterFile(filterOld);
        filters.set(idx, filterNew);
        addFilterFile(filterNew);
      }
      else
        addFilter(filterNew);
    }
  }

  public int getFiltersCount()
  {
    return filters.size();
  }

// -----------------------------------------------------------------------------

  public boolean isPredefined(String name)
  {
    for (int i = 0; i < filters.size(); i++)
    {
      Filter filter = (Filter)filters.get(i);
      if (filter.getPredefined() && filter.getName().equals(name))
      {
        return true;
      }
    }
    return false;
  }

  public String generateNewName()
  {
    Vector names = new Vector();
    for (int i = 0; i < getFiltersCount(); i++)
    {
      names.add(((Filter)filters.get(i)).getName());
    }
    return generateNewName(names);
  }

  public String generateNewName(Vector names)
  {
    return Utils.generateNewName(NEW_FILTER, NEW_FILTER_N_PATTERN, names);
  }

  public static String generateId()
  {
    try
    {
      return MessageFormat.format("{0}-{1}-{2}", //NORES
                                  new Object[]
                                  {java.net.InetAddress.getLocalHost().getCanonicalHostName(),
                                   java.net.InetAddress.getLocalHost().getHostAddress(),
                                   new VMID ()});
    }
    catch (UnknownHostException ex)
    {
      return ""; //NORES
    }
  }

  public Field[] getFields()
  {
    return m_fields;
  }

  public Field getField(String fieldId)
  {
    if (fieldId != null)
    {
      for (int i = 0; i < m_fields.length; i++)
      {
        if (m_fields[i].getId().equals(fieldId))
          return m_fields[i];
      }
    }
    return Field.UNKNOWN;
  }

  private String getFieldType(String fieldId)
  {
    if (fieldId == null)
      return Field.TYPE_UNKNOWN;
    if (fieldId.equals(RVTableColumn.TCN_NAME))
      return Field.TYPE_STRING;
    if (fieldId.equals(RVTableColumn.TCN_DESCRIPTION))
      return Field.TYPE_TEXT;
    if (fieldId.equals(RVTableColumn.TCN_VERSION))
      return Field.TYPE_VERSION;
    if (fieldId.equals(RVTableColumn.TCN_PRIORITY))
      return Field.TYPE_ENUM;
    if (fieldId.equals(RVTableColumn.TCN_OWNER))
      return Field.TYPE_USER;
    if (fieldId.equals(RVTableColumn.TCN_STATUS))
      return Field.TYPE_ENUM;
    return Field.TYPE_UNKNOWN;
  }

  public static String[] getFieldValues(String type)
  {
    return null;
  }

  public static Date adjustDate(Date date)
  {
    Calendar calendar = Calendar.getInstance();
    calendar.setTime(date);
    calendar.set(Calendar.HOUR, 0);
    calendar.set(Calendar.MINUTE, 0);
    calendar.set(Calendar.SECOND, 0);
    calendar.set(Calendar.MILLISECOND, 0);
    return calendar.getTime();
  }

  private static SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yy hh:mm"); //NORES

  public static DateFormat getDateFormat()
  {
    return dateFormat;
  }
  public String formatValue(String value, String type)
  {
    if (value == null)
      return ""; //NORES
    if (type == null)
      return value;
    if (type.equals(Field.TYPE_DATE))
    {
      if (value.equals(Filter.CURRENT_DATE))
        return value;
      Date date = new Date();
      try
      {
        date.setTime(Long.parseLong(value));
      }
      catch (Exception exc)
      {
        return value;
      }
      value = getDateFormat().format(date);
    }
    return value;
  }

}
