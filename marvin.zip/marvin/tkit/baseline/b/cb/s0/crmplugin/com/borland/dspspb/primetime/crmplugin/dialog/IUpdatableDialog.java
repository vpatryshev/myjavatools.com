package com.borland.dspspb.primetime.crmplugin.dialog;

public interface IUpdatableDialog
{
  public void updateDialog ();
}
