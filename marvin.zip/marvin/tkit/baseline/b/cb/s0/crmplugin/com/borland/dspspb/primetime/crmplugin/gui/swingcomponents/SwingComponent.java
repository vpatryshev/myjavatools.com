package com.borland.dspspb.primetime.crmplugin.gui.swingcomponents;

import javax.swing.JPanel;
import javax.swing.JComponent;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import java.util.Collection;
import java.awt.GridLayout;
import com.borland.dspspb.primetime.crmplugin.gui.abstractcomponents.AbstractViewComponent;
import java.awt.Font;

public abstract class SwingComponent extends AbstractViewComponent
{
   public abstract JComponent getMainComponent();
   private JPanel mainPanel = new JPanel();
   private JLabel label = new JLabel();
   private String displayName;

   public String getDisplayName()
   {
     return displayName;
   }

   public void setDisplayName(String displayName)
   {
     this.displayName = displayName;
   }
   public SwingComponent()
   {
   }

   public SwingComponent( String name,String displayName,Object value )
   {
     this ( name,displayName );
     setValue(value);
   }

   public SwingComponent( String name,String displayName,Collection values )
   {
      this( name,displayName );
      this.setValues ( values );
   }

   public SwingComponent( String name,String displayName )
   {
     setName( name );
     mainPanel.setLayout( new BorderLayout() );
     label.setFont( new Font("Arial",Font.BOLD,12 ) );
     label.setName( displayName );
     mainPanel.add( label,BorderLayout.NORTH );
     mainPanel.setName( name );
     this.displayName=displayName;
   }

   public Object getUI()
   {

      if ( isMandatory() ) label.setText("(*) "+getDisplayName());
      else
      label.setText ( getDisplayName() );
      mainPanel.add( getMainComponent(),BorderLayout.CENTER );
      return mainPanel;
   }

}
