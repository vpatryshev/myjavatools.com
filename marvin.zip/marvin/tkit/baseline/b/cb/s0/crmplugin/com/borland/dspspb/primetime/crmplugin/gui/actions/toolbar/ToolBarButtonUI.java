package com.borland.dspspb.primetime.crmplugin.gui.actions.toolbar;

import javax.swing.AbstractButton;
import javax.swing.ButtonModel;
import javax.swing.GrayFilter;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.ButtonUI;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import javax.swing.plaf.basic.BasicButtonUI;

public class ToolBarButtonUI extends BasicButtonUI {

    private Dimension getIconSize(JComponent c) {
        AbstractButton b = (AbstractButton)c;
        Icon icon = b.getIcon();
        if(icon == null)return new Dimension(22,22);
        int iconWidth = icon.getIconWidth();
        int iconHeight = icon.getIconHeight();
        int buttonWidth = b.getSize().width;
        int buttonHeight = b.getSize().height;
        return new Dimension(iconWidth+iconWidth/2+1, iconHeight+iconHeight/2+1);
        //return new Dimension(buttonWidth, buttonHeight);
    }

    public Dimension getMinimumSize(JComponent c) { return getIconSize(c); }
    public Dimension getMaximumSize(JComponent c) { return getIconSize(c); }
    public Dimension getPreferredSize(JComponent c) { return getIconSize(c); }

    public static ComponentUI createUI(JComponent c) {
        return ourUI;
    }

    public void paint(Graphics g, JComponent c) {
        AbstractButton b = (AbstractButton)c;
        ButtonModel model = b.getModel();
        if (!model.isEnabled()) {
            paintGrayedIcon(g, c);
        } else if ((model.isArmed() && model.isPressed())) {
            paintPressedIcon(g, c);
            g.setColor(dnColor);
            g.drawLine(0, 0, c.getSize().width - 1, 0);
            g.drawLine(0, 0, 0, c.getSize().height - 1);
            g.setColor(upColor);
            g.drawLine(c.getSize().width - 1, 1, c.getSize().width - 1, c.getSize().height - 1);
            g.drawLine(1, c.getSize().height - 1, c.getSize().width - 1, c.getSize().height - 1);
        } else if(model.isSelected()) {
            //g.setColor(upColor);
            //g.fillRect(0,0, c.getSize().width, c.getSize().height);
            paintPressedIcon(g, c);
            g.setColor(dnColor);
            g.drawLine(0, 0, c.getSize().width - 1, 0);
            g.drawLine(0, 0, 0, c.getSize().height - 1);
            g.setColor(upColor);
            g.drawLine(c.getSize().width - 1, 1, c.getSize().width - 1, c.getSize().height - 1);
            g.drawLine(1, c.getSize().height - 1, c.getSize().width - 1, c.getSize().height - 1);
        } else if (model.isRollover()) {
            paintIcon(g, c);
            g.setColor(upColor);
            g.drawLine(0, 0, c.getSize().width - 1, 0);
            g.drawLine(0, 0, 0, c.getSize().height - 1);
            g.setColor(dnColor);
            g.drawLine(c.getSize().width - 1, 1, c.getSize().width - 1, c.getSize().height - 1);
            g.drawLine(1, c.getSize().height - 1, c.getSize().width - 1, c.getSize().height - 1);
        } else {
            paintIcon(g, c);
        }
    }

    protected void paintIcon(Graphics g, JComponent c) {
        AbstractButton b = (AbstractButton)c;
        Icon icon = b.getIcon();
        if(icon == null)return;
        int iconWidth = icon.getIconWidth();
        int iconHeight = icon.getIconHeight();
        int buttonWidth = b.getSize().width;
        int buttonHeight = b.getSize().height;
        int x = buttonWidth / 2 - iconWidth / 2;
        int y = buttonHeight / 2 - iconHeight / 2;
        icon.paintIcon(c, g, x, y);
    }

    protected void paintPressedIcon(Graphics g, JComponent c) {
        AbstractButton b = (AbstractButton)c;
        Icon icon = b.getIcon();
        if (icon == null)return;
        int iconWidth = icon.getIconWidth();
        int iconHeight = icon.getIconHeight();
        int buttonWidth = b.getSize().width;
        int buttonHeight = b.getSize().height;
        int x = buttonWidth / 2 - iconWidth / 2;
        int y = buttonHeight / 2 - iconHeight / 2;
        icon.paintIcon(c, g, x + 1, y + 1);
    }

    protected void paintGrayedIcon(Graphics g, JComponent c) {
        AbstractButton b = (AbstractButton)c;
        Icon icon = b.getIcon();
        if (icon == null) {
            return;
        }
        Icon grayedIcon = getGrayedIcon(icon, b);
        if (grayedIcon == null) {
            return;
        }
        int iconWidth = icon.getIconWidth();
        int iconHeight = icon.getIconHeight();
        int buttonWidth = b.getSize().width;
        int buttonHeight = b.getSize().height;
        int x = buttonWidth / 2 - iconWidth / 2;
        int y = buttonHeight / 2 - iconHeight / 2;
        grayedIcon.paintIcon(c, g, x, y);
    }

    private Icon getGrayedIcon(Icon icon, AbstractButton b) {
        Image image = ((ImageIcon)icon).getImage();
        return image != null ? new ImageIcon(GrayFilter.createDisabledImage(image)) : icon;
    }

    public static ToolBarButtonUI ourUI = new ToolBarButtonUI();
    private static Color bgColor = Color.lightGray;
    private static Color upColor = bgColor.brighter();
    private static Color dnColor = bgColor.darker();
}
