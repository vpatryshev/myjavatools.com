package com.borland.dspspb.primetime.crmplugin.opentool;
import java.io.Serializable;
import java.util.Vector;

public class RequirementInfo implements Serializable
{
  protected String strLocator = null;
  protected Vector vNames = new Vector ();
  protected Vector vValues = new Vector ();

  public String getLocator ()
  {
    return strLocator;
  }

  public String [][] getFields ()
  {
    String [][] fields = new String [vNames.size ()][2];

    for (int i = 0; i < vNames.size (); i++)
    {
      fields [i][0] = (String) vNames.get (i);
      fields [i][1] = (String) vValues.get (i);
    }

    return fields;
  }

  public String getFieldValue (String key)
  {
    int keyIndex = vNames.indexOf (key);

    return (keyIndex == -1 ? null : (String) vValues.get (keyIndex));
  }

// -----------------------------------------------------------------------------

  public void dump ()
  {
    System.out.println ("<< REQUIREMENT INFO [" + vNames.size() + "]"); //NORES

    for (int i = 0; i < vNames.size (); i++)
    {
      String name = (String) vNames.get (i);
      String value = getFieldValue (name);
      System.out.println ("   " + name + ": " + value); //NORES
    }

    System.out.println ("REQUIREMENT INFO >>"); //NORES
  }
}
