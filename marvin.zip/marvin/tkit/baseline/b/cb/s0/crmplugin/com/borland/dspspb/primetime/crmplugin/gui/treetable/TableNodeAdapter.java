
package com.borland.dspspb.primetime.crmplugin.gui.treetable;

import java.util.*;

import java.awt.*;
import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;

import com.borland.dspspb.primetime.crmplugin.resources.ResourceManager;


public class TableNodeAdapter
  extends DefaultMutableTreeNode
  implements ITableNode
{
  public static final Color DEFAULT_BG			= Color.white;
  public static final Color DEFAULT_FG			= Color.black;

  private Color background = DEFAULT_BG;
  private Color foreground = DEFAULT_FG;

  private static ImageIcon icon	= null;

  // Load icon(s)
  static
  {
    icon = ResourceManager.getIcon (ResourceManager.TableNodeAdapter_icon);
  }
  public TableNodeAdapter (Object userData)
  {
    super (userData);
  }

  public Color getBackground ()
  {
    return background;
  }

  public void setBackground (Color background)
  {
    this.background = (background == null ? DEFAULT_BG : background);
  }

  public Color getForeground ()
  {
    return foreground;
  }

  public void setForeground (Color foreground)
  {
    this.foreground = (foreground == null ? DEFAULT_FG : foreground);
  }

  public Icon getIcon (boolean bExpanded)
  {
    return icon;
  }

  public String getText ()
  {
    return getUserObject().toString();
  }

  public String getToolTipText ()
  {
    return getText ();
  }

  public boolean getAuxFlag ()
  {
    return false;
  }

// -----------------------------------------------------------------------------

  private Object context = null;

  public void setContext (Object context)
  {
    this.context = context;
  }

  public Object getContext ()
  {
    return context;
  }

// -----------------------------------------------------------------------------

  public void sort (Comparator comparator)
  {
    if (children == null) return;

    Collections.sort (children, comparator);

    for (int i = 0; i < children.size (); i++)
    {
      ((TableNodeAdapter) children.get (i)).sort (comparator);
    }
  }

  public void sortChildren ()
  {
    Comparator comparator = new NodesComparator ();

    if (children != null)
      Collections.sort (children, comparator);
  }

  private class NodesComparator implements Comparator
  {
    public int compare (Object o1, Object o2)
    {
      if (!(o1 instanceof ITableNode) || !(o2 instanceof ITableNode))
        return -1;

      ITableNode node1 = (ITableNode) o1;
      ITableNode node2 = (ITableNode) o2;

      return node1.getText().compareToIgnoreCase(node2.getText());
    }
  }

//  public TableNodeAdapter[] getChildren()
//  {
//    Enumeration enum = children();
//    Vector children = new Vector();
//    while (enum.hasMoreElements())
//    {
//      children.add(enum.nextElement());
//    }
//    return (TableNodeAdapter[])children.toArray(new TableNodeAdapter[0]);
//  }

  public Vector getChildren()
  {
    Enumeration myEnum = children();
    Vector children = new Vector();
    while (myEnum.hasMoreElements())
    {
      children.add(myEnum.nextElement());
    }
    return children;
  }

  public int getFontStyle ()
  {
    return Font.PLAIN;
  }
}
