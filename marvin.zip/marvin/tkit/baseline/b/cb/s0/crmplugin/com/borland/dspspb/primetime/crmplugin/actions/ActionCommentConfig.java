package com.borland.dspspb.primetime.crmplugin.actions;

import java.util.*;

import java.awt.event.*;

import com.borland.dspspb.primetime.crmplugin.*;
import com.borland.dspspb.primetime.crmplugin.gui.treetable.*;
import com.borland.dspspb.primetime.crmplugin.resources.*;
import com.borland.dspspb.primetime.crmplugin.ui.*;
import com.borland.dspspb.primetime.crmplugin.view.*;
import com.borland.dspspb.primetime.crmplugin.view.rvtreetable.*;
import com.starbase.caliber.*;


public class ActionCommentConfig extends PluginUpdateAction
{
  public ActionCommentConfig ()
  {
    super
      ("Configure Comment", //RES ActionCommentConfig_shorttext
       "Configure comments associated with Caliber requirements", //RES ActionCommentConfig_longtext
       ResourceManager.ActionCommentConfig_icon);
  }

	public void actionPerformed (ActionEvent e)
	{
    PluginView pluginView = (PluginView) e.getSource();

		Vector all = PluginManager.getAllCommentColumns ();
		Vector defaults = PluginManager.getDefaultCommentColumns ();
		Vector shown = PluginManager.getInstance ().getCommentFields ();

    RVTreeTable table = pluginView.getTable();
		TableNodeAdapter selectedNode = table.getSelectedNode();

    Requirement req = null;

		if (selectedNode != null && (selectedNode instanceof RequirementNode))
		{
			req = ((RequirementNode) selectedNode).getRequirement ();
		}

		DlgConfigureComment dlgConfigureComment = new DlgConfigureComment (null, req, all, defaults, shown);

	  if (dlgConfigureComment.showDialog ())
		{
			PluginManager.getInstance().setCommentFields (dlgConfigureComment.getValues());
		}
	}
}
