package com.borland.dspspb.primetime.crmplugin.gui.actions.menu;

import javax.swing.*;
import java.awt.Dimension;
import java.awt.Component;
import com.borland.dspspb.primetime.crmplugin.gui.actions.SwingAction;
import com.borland.dspspb.primetime.crmplugin.gui.actions.menu.IMenuItem;
import com.borland.dspspb.primetime.crmplugin.gui.actions.menu.MenuItem;

public class AdrenalinPopupMenu extends JPopupMenu {

    public AdrenalinPopupMenu() {
        super();
    }

    public JMenuItem add(Action action) {
        if(action instanceof SwingAction) {
            return addAction((SwingAction)action);
        }
        else {
            return super.add(action);
        }
    }

    public JMenuItem addAction(SwingAction action) {
        IMenuItem mi = MenuItem.createMenuItem(action);
        return super.add((JMenuItem)mi);
    }

    public void addSeparator() {
        super.addSeparator();
    }

    public void updatePopupMenu() {
        Component[] comps = getComponents();
        for(int i=0; i<comps.length; i++) {
            if(comps[i] instanceof IMenuItem) {
                ((IMenuItem)comps[i]).udpateMenuItem();
            }
        }
    }

    public void show(Component comp, int x, int y) {
        updatePopupMenu();
        super.show(comp, x, y);
    }

}
