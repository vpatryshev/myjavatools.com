package com.borland.dspspb.primetime.crmplugin.management;

import java.text.MessageFormat;
import java.util.Vector;
import java.util.logging.ConsoleHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.borland.dspspb.primetime.crmplugin.resources.ResourceManager;
import com.borland.dspspb.primetime.crmplugin.filter.Filter;
import com.borland.dspspb.primetime.crmplugin.filter.FilterManager;
import com.borland.primetime.mam.MamWhitespace;

public class Utils
{
  private static Logger m_logger;

  static
  {
    m_logger = Logger.getLogger("Caliberrm Logger"); //NORES
    m_logger.setLevel(Level.WARNING);
    ConsoleHandler consoleHandler = new ConsoleHandler();
    consoleHandler.setLevel(Level.ALL);
    m_logger.addHandler(consoleHandler);
  }

  public static Logger getLogger()
  {
    return m_logger;
  }

//------------------------------------------------------------------------------
// Formatting utils

  public static String format(String pattern, int i)
  {
    return format(pattern, new Integer(i));
  }

  public static String format(String pattern, Object arg)
  {
    Object[] args = {arg};
    return format(pattern, args);
  }

  public static String format(String pattern, Object[] args)
  {
    try
    {
      return MessageFormat.format(pattern, args);
    }
    catch (IllegalArgumentException ex)
    {
    }
    return pattern;
  }

  public static String generateNewName(String pattern, Vector names)
  {
    String newName;
    int i = 1;
    if (names == null || names.size() == 0)
      return Utils.format(pattern, i);
    do
    {
      newName = Utils.format(pattern, i);
      ++i;
    }
    while (names.contains(newName));
    return newName;
 }

  public static String generateNewName(String first, String pattern, Vector names)
  {
    String newName;
    if (names == null || !(names.contains(first)))
      return first;
    int i = 1;
    do
    {
      newName = Utils.format(pattern, i);
      ++i;
    }
    while (names.contains(newName));
    return newName;
  }

// -----------------------------------------------------------------------------

	public static String getSourceDescription (Source source)
	{
		StringBuffer buffer = new StringBuffer ();

	  String strName = "Name:"; //RES SourceDescription_Name_text
	  String strServer = "Server:"; //RES SourceDescription_Server_text
	  String strUser = "User:"; //RES SourceDescription_User_text
	  String strProject = "Project:"; //RES SourceDescription_Project_text
	  String strBaseline = "Baseline:"; //RES SourceDescription_Baseline_text
	  String strFilter = "Filter:"; //RES SourceDescription_Filter_text

		String name = source.getName ();
//		String description = source.getDescription ();
		String server = source.getServer ();
		String user = source.getLogin ();
		String project = source.getProjectName () + " [" + source.getProjectId() + "]"; //NORES
		String baseline = source.getBaselineName () + " [" + source.getBaselineId() + "]"; //NORES

    String filterId = source.getFilterId();
    Filter filterObject = FilterManager.getInstance().findFilter(filterId);
		String filter = (filterObject == null ? "" : filterObject.getName()); //NORES

		buffer.append ("<html>"); //NORES
    buffer.append ("<table cellpadding=0 cellspacing=0>"); //NORES
		buffer.append (getHtmlLine (strName, name));
//		buffer.append (getHtmlLine (strDescription, description));
		buffer.append (getHtmlLine (strServer, server));
		buffer.append (getHtmlLine (strUser, user));
		buffer.append (getHtmlLine (strProject, project));
		buffer.append (getHtmlLine (strBaseline, baseline));
		buffer.append (getHtmlLine (strFilter, filter));
    buffer.append ("</table>"); //NORES
		buffer.append ("</html>"); //NORES

		return buffer.toString ();
  }

	private static String getHtmlLine (String name, String value)
	{
		StringBuffer buffer = new StringBuffer ();

    buffer.append ("<tr>"); //NORES

    buffer.append ("<td>"); //NORES
		buffer.append ("<b>"); //NORES
	  buffer.append ("&nbsp;"); //NORES
	  buffer.append (name);
		buffer.append ("&nbsp;</b>"); //NORES
    buffer.append ("</td>"); //NORES

    buffer.append ("<td>"); //NORES
		buffer.append (value);
    buffer.append ("</td>"); //NORES

    buffer.append ("</tr>"); //NORES

	  return buffer.toString ();
	}

// -----------------------------------------------------------------------------

  private static final String ILLEGAL_CHARS = "/\\*?\":"; //NORES

  public static String convertToFilename (String name)
  {
    StringBuffer result = new StringBuffer ();

    for (int i = 0; i < name.length (); i++)
    {
      char nextChar = name.charAt (i);

      if (ILLEGAL_CHARS.indexOf (nextChar) != -1)
      {
        result.append ("_" + (int) nextChar); //NORES
      }
      else if (nextChar == '_') //NORES
      {
        result.append ("__"); //NORES
      }
      else
      {
        result.append (nextChar);
      }
    }

    return result.toString ();
  }
}
