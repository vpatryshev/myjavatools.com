package com.borland.dspspb.primetime.crmplugin.resources;

//NOTTRANSLATABLE

import javax.swing.*;


public class ResourceManager
{
  private static ClassLoader classLoader = ResourceManager.class.getClassLoader ();

// -----------------------------------------------------------------------------

  public static ImageIcon getIcon (String key)
  {
    String imageUrl = key;
    return new ImageIcon (classLoader.getResource (imageUrl));
  }

// -----------------------------------------------------------------------------

  // Resource names
  // Actions
  public static final String Main_ActionGroupCRMPlugin_icon = "com/borland/dspspb/resources/images/caliber/caliber-rm_6.gif";
  public static final String SourceLWNodeMenu_ActionRun_icon = "com/borland/dspspb/resources/images/caliber/server.gif";
  public static final String SourceLWNodeMenu_ActionRemove_icon = "com/borland/dspspb/resources/images/caliber/delete.gif";

  public static final String ActionToggleDetails_icon = "com/borland/dspspb/resources/images/reqview/description_pane.gif";
  public static final String ActionEditSources_icon = "com/borland/dspspb/resources/images/reqview/edit_sources.gif";
  public static final String ActionSelectSource_icon = "com/borland/dspspb/resources/images/reqview/select_source.gif";
  public static final String ActionLogout_icon = "com/borland/dspspb/resources/images/caliber/logout.gif";
  public static final String ActionSelectProject_icon = "com/borland/dspspb/resources/images/reqview/select_project.gif";
  public static final String ActionTableOptions_icon = "com/borland/dspspb/resources/images/reqview/configure_table.gif";
  public static final String ActionCommentConfig_icon = "com/borland/dspspb/resources/images/reqview/configure_comment.gif";
  public static final String ActionEditFilters_icon = "com/borland/dspspb/resources/images/reqview/edit_filters.gif";
  public static final String ActionCheckForUpdate_icon = "com/borland/dspspb/resources/images/reqview/update_all_comments.gif";
  public static final String ActionGoToFile_icon = "com/borland/dspspb/resources/images/reqview/goto_file.gif";
  public static final String ActionSelectFilter_icon = "com/borland/dspspb/resources/images/reqview/select_filter.gif";
  public static final String ActionHierarchicalNumbers_icon="com/borland/dspspb/resources/images/caliber/hierarchical_numbers.gif";
  public static final String ActionSerialNumbers_icon = "com/borland/dspspb/resources/images/caliber/serial_numbers.gif";
  public static final String ActionRefresh_icon = "com/borland/dspspb/resources/images/reqview/refresh.gif";
  public static final String ActionUpdateComment_icon = "com/borland/dspspb/resources/images/caliber/checkforupdate.gif";
  public static final String ActionRunCaliberRMClient_icon = "com/borland/dspspb/resources/images/caliber/caliber-rm_6.gif";
  public static final String ActionDeleteTraces_icon = "com/borland/dspspb/resources/images/caliber/delete.gif";

  // Nodes
  public static final String PluginLWNode_icon = "com/borland/dspspb/resources/images/caliber/caliber-rm_6.gif";
  public static final String SourceLWNode_icon = "com/borland/dspspb/resources/images/caliber/server.gif";
  public static final String SourceNode_Connected_icon = "com/borland/dspspb/resources/images/reqview/server.gif";
  public static final String SourceNode_Disconnected_icon = "com/borland/dspspb/resources/images/reqview/server-disconnected.gif";
  public static final String ProjectNode_Opened_icon = "com/borland/dspspb/resources/images/caliber/project-closed_6.gif";
  public static final String ProjectNode_Closed_icon = "com/borland/dspspb/resources/images/caliber/project-closed_6.gif";
  public static final String TableNodeAdapter_icon = "com/borland/dspspb/resources/images/general/blank.gif";
  public static final String RequirementTypeNode_Opened_icon = "com/borland/dspspb/resources/images/caliber/reqtype-opened_6.gif";
  public static final String RequirementTypeNode_Closed_icon = "com/borland/dspspb/resources/images/caliber/reqtype-closed_6.gif";
  public static final String RequirementNode_icon = "com/borland/dspspb/resources/images/caliber/requirement_6.gif";
  public static final String RequirementNode_Unknown_icon = "com/borland/dspspb/resources/images/caliber/requirement_black.gif";
  public static final String RequirementNode_Current_icon = "com/borland/dspspb/resources/images/caliber/requirement_green.gif";
  public static final String RequirementNode_OutOfDate_icon = "com/borland/dspspb/resources/images/caliber/requirement_yellow.gif";
  public static final String RequirementNode_Missing_icon = "com/borland/dspspb/resources/images/caliber/requirement_red.gif";
  public static final String RequirementNode_NotExist_icon = "com/borland/dspspb/resources/images/caliber/requirement_red.gif";
  public static final String ErrorCross_icon = "com/borland/dspspb/resources/images/ui/error.gif";

  public static final String DetailsPanel_Description_icon = "com/borland/dspspb/resources/images/ui/multiline.gif";
  public static final String DetailsPanel_Traceability_icon = "com/borland/dspspb/resources/images/reqview/comment_trace.gif";
  public static final String DetailsPanel_UserAttributes_icon = "com/borland/dspspb/resources/images/reqview/user_attributes.gif";

  // Dialogs
  public static final String DlgLogin_image = "com/borland/dspspb/resources/images/caliber_login1.jpg";
  public static final String DlgConfigureConnections_Connection_icon="com/borland/dspspb/resources/images/caliber/server.gif";
  public static final String DlgConfigureFilters_icon = "com/borland/dspspb/resources/images/reqview/edit_filters.gif";
  public static final String DlgConfigureComment_arrowup_icon = "com/borland/dspspb/resources/images/ui/arrowup.gif";
  public static final String DlgConfigureComment_arrowdown_icon = "com/borland/dspspb/resources/images/ui/arrowdown.gif";

  // RVTreeTable
  public static final String RVTreeTable_DragCursor_icon = "com/borland/dspspb/resources/images/reqview/drag_cursor2.gif";

  // Wait icom
  public static final String WaitClock_icon = "com/borland/dspspb/resources/images/ui/wait_clock.gif";
}
