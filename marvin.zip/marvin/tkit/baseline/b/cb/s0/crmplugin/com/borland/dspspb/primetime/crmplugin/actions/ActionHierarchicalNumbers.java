package com.borland.dspspb.primetime.crmplugin.actions;

import com.borland.dspspb.primetime.crmplugin.resources.*;
import com.borland.dspspb.primetime.crmplugin.view.*;

public class ActionHierarchicalNumbers extends PluginStateAction
{
	public ActionHierarchicalNumbers ()
	{
    super
      ("Hierarchical Numbers", //RES ActionHierarchicalNumbers_shorttext
       "Show/hide requirements' hierarchical numbers", //RES ActionHierarchicalNumbers_longtext
       ResourceManager.ActionHierarchicalNumbers_icon);
	}

	public boolean getState (Object object)
	{
    PluginView pluginView = (PluginView) object;

    return pluginView.isHierarchicalNumbers ();
	}

	public void setState (Object object, boolean state)
	{
    PluginView pluginView = (PluginView) object;

		pluginView.setHierarchicalNumbers (state);
		pluginView.getTable ().updateUI ();
	}
}
