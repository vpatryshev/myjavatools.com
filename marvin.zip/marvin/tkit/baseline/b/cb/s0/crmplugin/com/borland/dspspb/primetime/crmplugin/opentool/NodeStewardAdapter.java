package com.borland.dspspb.primetime.crmplugin.opentool;

import java.awt.*;
import javax.swing.*;

import com.borland.primetime.node.*;
import com.starbase.caliber.*;

public class NodeStewardAdapter implements INodeSteward
{
  public String getId()
  {
    return null;
  }

	public Icon getIcon ()
	{
		return null;
	}

	public Component[] getDropEagerComponents(Node node)
  {
    return null;
  }

  public String getCommentLocator(Node node, Point point)
  {
    return null;
  }

  public int getCommentStatus(String commentLocator, RequirementInfo requirementInfo)
  {
    return 0;
  }

  public boolean openComment(String commentLocator)
  {
    return false;
  }

  public String getCommentText(RequirementInfo requirementInfo)
  {
    return null;
  }

  public Action[] getActions(Node node, Requirement requirement)
  {
    return null;
  }

  public int updateComment (String commentLocator, RequirementInfo requirementInfo)
  {
    return 0;
  }

  public String getRequirementLocator(Node node, Point point)
  {
    return null;
  }

  public void deleteComment (String commentLocator, RequirementInfo requirementInfo)
  {
  }

  public int createComment (String commentLocator, RequirementInfo requirementInfo)
  {
    return 0;
  }
}
