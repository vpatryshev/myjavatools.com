package com.borland.dspspb.primetime.crmplugin.view;

import com.borland.primetime.ide.view.ViewFactory;
import com.borland.primetime.ide.view.View;
import com.borland.primetime.ide.Browser;
import com.borland.primetime.ide.view.ViewType;

public class PluginViewFactory implements ViewFactory
{
  public PluginViewFactory ()
  {
  }

  public View createView (Browser browser)
  {
    return new PluginWorkspaceView ();
  }

  public boolean canCreateView (Browser browser)
  {
    return true;
  }

  public ViewType getViewType ()
  {
    return new PluginViewType ();
  }
}
