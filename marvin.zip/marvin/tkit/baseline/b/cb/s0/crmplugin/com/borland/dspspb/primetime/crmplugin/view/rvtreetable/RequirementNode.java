package com.borland.dspspb.primetime.crmplugin.view.rvtreetable;

import java.io.IOException;
import java.util.Vector;

import java.awt.*;
import java.awt.datatransfer.*;
import javax.swing.*;

import com.borland.dspspb.primetime.crmplugin.PluginManager;
import com.borland.dspspb.primetime.crmplugin.filter.*;
import com.borland.dspspb.primetime.crmplugin.gui.treetable.TableNodeAdapter;
import com.borland.dspspb.primetime.crmplugin.management.CaliberManager;
import com.borland.dspspb.primetime.crmplugin.opentool.*;
import com.borland.dspspb.primetime.crmplugin.resources.ResourceManager;
import com.borland.dspspb.primetime.crmplugin.view.PluginView;
import com.starbase.caliber.*;
import com.starbase.caliber.external.xgeneric.*;
import com.starbase.caliber.external.xgeneric.File;
import com.starbase.caliber.server.RemoteServerException;
import java.util.HashMap;

public class RequirementNode extends TableNodeAdapter implements Transferable
{
  private static Color reqBackground				= Color.white;
  private static Color reqForeground				= Color.black;
  private static Color reqForegroundAux			= Color.gray;

	private static ImageIcon iconUnknown = ResourceManager.getIcon (ResourceManager.RequirementNode_icon);
  private static ImageIcon iconCurrent = ResourceManager.getIcon (ResourceManager.RequirementNode_Current_icon);
	private static ImageIcon iconOutOfDate = ResourceManager.getIcon (ResourceManager.RequirementNode_OutOfDate_icon);
  private static ImageIcon iconMissing = ResourceManager.getIcon (ResourceManager.RequirementNode_Missing_icon);
	private static ImageIcon iconNotExist = ResourceManager.getIcon (ResourceManager.RequirementNode_NotExist_icon);

  private Requirement m_requirement = null;
  private Vector m_tracesInfo = new Vector();
  private int m_status = CommentStatus.STATUS_UNKNOWN;
  private boolean m_bAux = false;


  public RequirementNode (Object data)
  {
    super (data);
  }

  public Color getBackground ()
  {
    return reqBackground;
  }

  public Color getForeground ()
  {
    return (m_bAux ? reqForegroundAux : reqForeground);
  }

  public int getFontStyle ()
  {
    return (m_bAux ? Font.ITALIC : Font.PLAIN);
  }

  public Icon getIcon (boolean bExpanded)
  {
    m_isExpanded = bExpanded;
    return getStatusIcon(m_status);
  }

  public String getText ()
  {
    if (m_requirement == null)
      return "<error while loading requirement info>"; //NORES

    PluginView pluginView = (PluginView) getContext ();

    RequirementTreeNode treeNode = (RequirementTreeNode) getUserObject();

    StringBuffer buffer = new StringBuffer ();

    if (pluginView.isHierarchicalNumbers())
    {
      buffer.append (treeNode.getHierarchyNumber());
      buffer.append (" "); //NORES
    }

    buffer.append (m_requirement.getName ());

    if (pluginView.isSerialNumbers())
    {
      buffer.append (" - "); //NORES
      buffer.append (treeNode.getSerialNumberTag ());
    }

    return buffer.toString ();
  }

  public String getToolTipText ()
  {
    if (getRequirement() != null)
    {
      try
      {
        return getRequirement().getProject().getName() + "/" + getRequirement().getName(); //NORES
      }
      catch (RemoteServerException e)
      {
      }
      return getRequirement().getName();
    }
    return ""; //NORES
  }

  private void initAssociatedObject(Session session)
  {
    try
    {
      RequirementTreeNode rtnRequirement = (RequirementTreeNode)getUserObject();
      setRequirement (session.getRequirement(rtnRequirement.getAssociatedObjectID().getIDNumber()));
//      m_requirement = (Requirement)session.get(rtnRequirement.getAssociatedObjectID());
    }
    catch (RemoteServerException ex)
    {
    }
  }

  public Requirement getRequirement()
  {
    return m_requirement;
  }

  public void setRequirement(Requirement requirement)
  {
    m_requirement = requirement;
    updateFieldsMap ();

    setAuxFlag();

    Session session = requirement.getSession();
    m_tracesInfo.removeAllElements();
    Trace[] traces = requirement.getTracesTo();

    for (int i = 0; i < traces.length; i++)
    {
      Trace caliberTrace = traces [i];
      CaliberObjectID toID = caliberTrace.getTraceToID();

      if (!toID.getAssociatedObjectClass().equals(XGenericObject.class)) continue;

      CaliberObject toObject = null;

      try
      {
        toObject = session.get (toID);
      }
      catch (Throwable e)
      {
        continue;
      }

      if (!(toObject instanceof File)) continue;

			// Check if trace object can be managed by any registered steward
      File toFile = (File) toObject;
      String name = toFile.getName();

      if (NodeStewardsManager.findSteward(name) == null)
      	continue;

      TraceInfo traceInfo = new TraceInfo(this, caliberTrace);
      traceInfo.setTraceObject(toFile);
      m_tracesInfo.add (traceInfo);
    }

		checkTraces (false);
  }

  public void setAuxFlag()
  {
    PluginView pluginView = (PluginView)getContext();
    Filter filter = FilterManager.getInstance().findFilter(pluginView.getSource().getFilterId());
    if (filter != null)
      m_bAux = !filter.accept(m_requirement);
    else
      m_bAux = false;
  }

//------------------------------------------------------------------------------

  public static DataFlavor REQUIREMENT_FLAVOR = new DataFlavor
    (RequirementNode.class, "CaliberRM Requirement Flavor"); //NORES

  private static DataFlavor[] REQUIREMENT_FLAVOR_ARRAY = new DataFlavor[] {REQUIREMENT_FLAVOR};

  public DataFlavor[] getTransferDataFlavors()
  {
    return REQUIREMENT_FLAVOR_ARRAY;
  }

  public boolean isDataFlavorSupported(DataFlavor flavor)
  {
    return (flavor == REQUIREMENT_FLAVOR);
  }

  public Object getTransferData (DataFlavor flavor)
    throws UnsupportedFlavorException, IOException
  {
    RequirementInfo commentInfo = getRequirementInfo (m_requirement, PluginManager.getInstance ().getCommentFields ());
    return commentInfo;
  }

	public static RequirementInfo getRequirementInfo (Requirement req, Vector fields)
	{
    RequirementInfoEx reqInfo = new RequirementInfoEx ();

    // Coomon requirement info
    String server = CaliberManager.getRequirementField (req, RVTableColumn.TCN_SERVER);
    String projectId = CaliberManager.getRequirementField (req, RVTableColumn.TCN_PROJECTID);
    String reqId = CaliberManager.getRequirementField (req, RVTableColumn.TCN_REQID);
    String version = CaliberManager.getRequirementField (req, RVTableColumn.TCN_VERSION);

    reqInfo.setLocator (new RequirementLocator (server, projectId, reqId, version).toString ());

    // Selected fields for comment
    for (int i = 0; i < fields.size(); i++)
    {
      RVTableColumn column = (RVTableColumn) fields.get (i);
      String tagName = column.getName ();
      String tagValue = CaliberManager.getRequirementField (req, tagName);

      reqInfo.setFieldValue (tagName, tagValue);
    }

    return reqInfo;
  }

// -----------------------------------------------------------------------------

	public Vector getTracesInfo ()
	{
		return m_tracesInfo;
	}

//------------------------------------------------------------------------------

  public void checkTraces (boolean bUpdate)
  {
    m_status = CommentStatus.STATUS_UNKNOWN;

    Vector vTracesInfo = getTracesInfo();

    for (int i = 0; i < vTracesInfo.size(); i++)
    {
      TraceInfo traceInfo = (TraceInfo) vTracesInfo.get (i);
      File rmFile = traceInfo.getTraceObject();
      String stewardId = rmFile.getName();
	    INodeSteward nodeSteward = NodeStewardsManager.findSteward (stewardId);

			if (nodeSteward == null)
			{
        traceInfo.setStatus (CommentStatus.STATUS_UNKNOWN);
			}
      else
      {
        String commentLocator = rmFile.getPath ();

        int commentStatus = nodeSteward.getCommentStatus
          (commentLocator, getRequirementInfo (m_requirement, PluginManager.getInstance ().getCommentFields ()));

        traceInfo.setStatus (commentStatus);
      }

      setResultState();
    }
  }

  public void updateTraces ()
  {
    m_status = CommentStatus.STATUS_UNKNOWN;

    Vector vTracesInfo = getTracesInfo();

    for (int i = 0; i < vTracesInfo.size(); i++)
    {
      TraceInfo traceInfo = (TraceInfo) vTracesInfo.get (i);
      updateTrace (traceInfo);
    }
  }

  public void updateTrace (TraceInfo traceInfo)
  {
    File rmFile = traceInfo.getTraceObject ();
    String stewardId = rmFile.getName ();
    INodeSteward nodeSteward = NodeStewardsManager.findSteward (stewardId);

    if (nodeSteward == null)
    {
      traceInfo.setStatus (CommentStatus.STATUS_UNKNOWN);
    }
    else
    {
      String commentLocator = rmFile.getPath ();

      int commentStatus = nodeSteward.updateComment
        (commentLocator, getRequirementInfo (m_requirement, PluginManager.getInstance ().getCommentFields ()));

      traceInfo.setStatus (commentStatus);
    }

    setResultState ();
  }

  public void deleteTraces (TraceInfo [] tracesInfo)
  {
    Session session = m_requirement.getSession ();
    TraceManager traceManager = session.getTraceManager ();

    for (int i = 0; i < tracesInfo.length; i++)
    {
      TraceInfo traceInfo = tracesInfo [i];

      try
      {
        // Delete caliber trace
        traceManager.deleteTrace (traceInfo.getCaliberTrace ());
        m_tracesInfo.remove (traceInfo);

        // Delete associated comment
        String stewardId = traceInfo.getTraceObject ().getName();

        INodeSteward steward = NodeStewardsManager.findSteward(stewardId);

        if (steward == null) continue;

        String commentLocator = traceInfo.getTraceObject().getPath();
        steward.deleteComment (commentLocator, getRequirementInfo (m_requirement, PluginManager.getInstance ().getCommentFields ()));
      }
      catch (RemoteServerException ex)
      {
        System.err.println ("Failed to delete Caliber trace"); //NORES
      }
    }

    // Update requiremen version
    initAssociatedObject (session);
  }

//------------------------------------------------------------------------------

  private boolean m_isExpanded = false;

  public boolean isExpanded()
  {
    return m_isExpanded;
  }

  private void setResultState ()
  {
    m_status = CommentStatus.STATUS_UNKNOWN;
    Vector vTraces = getTracesInfo();

    for (int i = 0; i < vTraces.size(); i++)
    {
      TraceInfo traceInfo = (TraceInfo) vTraces.get (i);
      m_status = Math.max (m_status, traceInfo.getStatus ());
    }
  }

// -----------------------------------------------------------------------------

	public static ImageIcon getStatusIcon (int status)
	{
    switch (status)
		{
			case CommentStatus.STATUS_UNKNOWN: return iconUnknown;
			case CommentStatus.STATUS_CURRENT: return iconCurrent;
			case CommentStatus.STATUS_OUTOFDATE: return iconOutOfDate;
			case CommentStatus.STATUS_MISSING: return iconMissing;
			case CommentStatus.STATUS_NOTEXIST: return iconNotExist;
		}

		return iconUnknown;
	}

// -----------------------------------------------------------------------------

  private HashMap fieldsMap = new HashMap ();

  private void updateFieldsMap ()
  {
    fieldsMap.clear();
    Vector allFields = PluginManager.getAllColumns ();

    for (int i = 0; i < allFields.size(); i++)
    {
      RVTableColumn field = (RVTableColumn) allFields.get (i);
      String fieldName = field.getName();
      String fieldValue = CaliberManager.getInstance().getRequirementField (m_requirement, fieldName);
      fieldsMap.put (fieldName, fieldValue);
    }
  }

  public String getFieldValue (String fieldName)
  {
    String fieldValue = (String) fieldsMap.get (fieldName);
    return (fieldValue == null ? "" : fieldValue); //NORES
  }
}
