package com.borland.dspspb.primetime.crmplugin.opentool;

import com.borland.primetime.node.LightweightNode;
import com.borland.primetime.node.Project;
import com.borland.primetime.node.Node;
import javax.swing.Icon;
import com.borland.dspspb.primetime.crmplugin.resources.ResourceManager;
import com.borland.primetime.ide.ProjectView;
import com.borland.dspspb.primetime.crmplugin.resources.ResourceManager;

public class PluginLWNode extends LightweightNode
{
  public PluginLWNode(Project project)
  {
    super(project, project, "CaliberRM"); //RES PluginLWNode_Name_text
  }

  public PluginLWNode(Project project, Node node, String name)
  {
    super(project, node, name);
  }

  public String getDisplayName()
  {
    return getName();
  }

  public Icon getDisplayIcon()
  {
    return ResourceManager.getIcon(ResourceManager.PluginLWNode_icon);
  }
}

