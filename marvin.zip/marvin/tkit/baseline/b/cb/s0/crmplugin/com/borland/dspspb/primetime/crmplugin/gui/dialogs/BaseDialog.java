package com.borland.dspspb.primetime.crmplugin.gui.dialogs;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.BevelBorder;
import javax.swing.border.Border;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.*;
import java.util.Enumeration;
import java.util.Vector;

public abstract class BaseDialog extends JDialog implements ActionListener  {
    Vector actions = new Vector();
    ButtonGroup bg = new ButtonGroup();
    public static final String OK = "Ok";
    public static final String CANCEL = "Cancel";
    private String result = null;

    public BaseDialog (Frame frame)
                {
                        super (frame);
                }


    public void actionPerformed(ActionEvent e) {
        JComponent source = (JComponent) e.getSource();
        result = source.getName();
        if ( BaseDialog.OK.equals( result ) ){
            try {
                validateResult();
            } catch(Exception ex){
                JOptionPane.showMessageDialog(this,ex.getMessage(),"Validation failed.",JOptionPane.WARNING_MESSAGE);
                return;
            }
        }
        this.dispose();
    }

    protected void validateResult() throws Exception{

    }

    public JButton addCustomAction ( Action action ){
        JButton customButton = new JButton(action);
        bg.add(customButton);
        return customButton;
    }
    public void addAction(String idStr){
        addAction(idStr,idStr,idStr.charAt(0));
    }

    public void addAction(String id,String displayName){
        addAction(id,displayName,'`');
    }

    public void addAction(String id,String displayName,char mnemonic){
        JButton button = new JButton(displayName);
        if ( mnemonic!='`' )
        button.setMnemonic(mnemonic);
        button.setName(id);
        bg.add(button);
        button.addActionListener(this);
    }

    public void show(){
        JComponent c = (JComponent) this.getContentComponent();
        if (getOwner() != null)
          setLocationRelativeTo(getOwner());
        else
        {
          Dimension ss = getToolkit().getScreenSize();
          Dimension ds = getSize();
          int x = (ss.width - ds.width) / 2;
          int y = (ss.height - ds.height) / 2;
          setLocation(x, y);
        }
        EmptyBorder eb = new EmptyBorder(10,10,10,10);
        BevelBorder bb = new BevelBorder(BevelBorder.RAISED);
        Border resultBorder = BorderFactory.createCompoundBorder(eb,bb);
        c.setBorder(resultBorder);
        this.getContentPane().add(getContentComponent(),BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        Enumeration buttons = bg.getElements();
        while ( buttons.hasMoreElements() ){
            buttonPanel.add((Component)buttons.nextElement());
        }
        this.getContentPane().add(buttonPanel,BorderLayout.SOUTH);
//				pack();
        super.show();
    }

    public String getResult(){
      return result;
    }

    public boolean isOk(){
      return BaseDialog.OK.equals( result );
    }

    abstract protected JComponent getContentComponent();
}
