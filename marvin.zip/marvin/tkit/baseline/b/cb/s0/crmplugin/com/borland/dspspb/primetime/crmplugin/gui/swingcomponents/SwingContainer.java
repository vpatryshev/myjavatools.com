package com.borland.dspspb.primetime.crmplugin.gui.swingcomponents;

import javax.swing.JPanel;
import java.util.Vector;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import javax.swing.JComponent;
import java.util.Iterator;
import java.awt.Insets;
import java.util.Comparator;
import java.util.Collections;
import com.borland.dspspb.primetime.crmplugin.gui.abstractcomponents.AbstractViewContainer;
import com.borland.dspspb.primetime.crmplugin.gui.abstractcomponents.AbstractViewComponent;

public class SwingContainer extends AbstractViewContainer
{
    private static Comparator orderComparator = new Comparator()
    {
        public int compare (Object o1,Object o2)
        {
           AbstractViewComponent c1=(AbstractViewComponent)o1;
           AbstractViewComponent c2=(AbstractViewComponent)o2;
           if ( c1.getOrder() > c2.getOrder() ) return 1;
           else return -1;
        }
    };

    protected JPanel uiPanel = new JPanel();

    public SwingContainer()
    {
       uiPanel.setLayout( new GridBagLayout() );
    }


    public Object getUI()
    {
       uiPanel.removeAll();
       GridBagConstraints gbc = new GridBagConstraints();
       gbc.weightx = 1.0;
       gbc.weighty = 0.0;
       gbc.gridx = GridBagConstraints.REMAINDER;
       gbc.fill = GridBagConstraints.BOTH;
       gbc.insets = new Insets(6,6,6,7);
       Vector sortedObjects = new Vector();
       sortedObjects.addAll( this.getComponents() );
       Collections.sort ( sortedObjects,orderComparator );
       Iterator i = sortedObjects.iterator();
       while ( i.hasNext() )
       {
          AbstractViewComponent nextComp = (AbstractViewComponent)i.next();
          uiPanel.add( (JComponent)nextComp.getUI(),gbc );
       }
       gbc.weighty=1.0;
       uiPanel.add ( new JPanel(),gbc );
       return uiPanel;
    }


}
