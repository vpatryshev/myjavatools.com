package com.borland.dspspb.primetime.crmplugin.gui.swingcomponents.tableproperties.internal;

import java.util.Vector;
import java.awt.Component;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ComboBoxInternalComponent extends SwingInternalComponent {

  private Vector items = new Vector();

  public Vector getItems() { return items; }

    public void addChoiceValue(Object value) {
        items.add(value);
    }

  public ComboBoxInternalComponent(String name, String displayName) {
    super(name, displayName);
    cb.addActionListener(stopEditingListener);
  }

  private JComboBox cb = new JComboBox();

  public Component getInternalRenderer() {
    return getInternalEditor();
  }

  public Component getInternalEditor() {
    cb.setEnabled( isEditable() );
    return cb;
  }

  public void updateUI() {
    cb.removeActionListener(stopEditingListener);
    cb.setModel( new DefaultComboBoxModel(items) );
    cb.setSelectedItem( getValue() );
    cb.addActionListener(stopEditingListener);
  }
  public void updateData() {
    setValue( cb.getSelectedItem() );
  }

}
