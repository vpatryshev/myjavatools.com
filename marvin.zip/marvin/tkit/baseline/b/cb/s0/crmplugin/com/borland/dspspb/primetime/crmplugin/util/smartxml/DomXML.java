package com.borland.dspspb.primetime.crmplugin.util.smartxml;

import java.lang.reflect.*;

import org.w3c.dom.*;
import com.borland.primetime.util.EmptyArrays;

public class DomXML {

  public static void setAttr(Element element, String name, String value) {
    if(value == null)return;
    element.setAttribute(name, value);
  }
  public static void setAttr(Element element, String name, boolean value) {
    setAttr(element, name, ""+value); //NORES
  }
  public static void setAttr(Element element, String name, int value) {
    setAttr(element, name, ""+value); //NORES
  }

  public static String getAttr(Element element, String name) {
    if(!element.hasAttribute(name))return null;
    return element.getAttribute(name);
  }
  public static boolean getAttrBoolean(Element element, String name, boolean defaultValue) {
    String attr = getAttr(element, name);
    if(attr == null)return defaultValue;
    return toBoolean(attr);
  }
  public static int getAttrInt(Element element, String name, int defaultValue) {
    String attr = getAttr(element, name);
    if(attr == null)return defaultValue;
    return toInt(attr);
  }

  public static void setElement(Element element, String name, String value) {
    if(value == null)return;
    Element elem = element.getOwnerDocument().createElement(name);
    setText(elem, value);
    element.appendChild(elem);
  }
  public static void setElement(Element element, String name, boolean value) {
    setElement(element, name, ""+value); //NORES
  }
  public static void setElement(Element element, String name, int value) {
    setElement(element, name, ""+value); //NORES
  }

  public static String getElement(Element element, String name) {
    Element elem = findElement(element, name);
        if(elem == null)return null;
    return getText(elem);
  }
  public static boolean getElementBoolean(Element element, String name, boolean defaultValue) {
    String val = getElement(element, name);
    if(val == null)return defaultValue;
    return toBoolean(val);
  }
  public static int getElementInt(Element element, String name, int defaultValue) {
    String val = getElement(element, name);
    if(val == null)return defaultValue;
    return toInt(val);
  }

  public static String[] getValuesArray(Element element, String name) {
        return getNodeValues(element.getElementsByTagName(name));
  }
    public static int[] getValuesArrayInt(Element element, String name) {
        String[] vals = getValuesArray(element, name);
        int[] ivals = new int[vals.length];
        for(int i=0; i<vals.length; i++) {
            ivals[i] = toInt(vals[i]);
        }
        return ivals;
    }
    public static boolean[] getValuesArrayBoolean(Element element, String name) {
        String[] vals = getValuesArray(element, name);
        boolean[] bvals = new boolean[vals.length];
        for(int i=0; i<vals.length; i++) {
            bvals[i] = toBoolean(vals[i]);
        }
        return bvals;
    }

  public static void setValuesArray(Element element, String name, String[] values) {
        for(int i=0; i<values.length; i++) {
      setElement(element, name, values[i]);
    }
  }
    public static void setValuesArray(Element element, String name, int[] values) {
        for(int i=0; i<values.length; i++) {
            setElement(element, name, values[i]);
        }
    }
    public static void setValuesArray(Element element, String name, Integer[] values) {
        for(int i=0; i<values.length; i++) {
            setElement(element, name, values[i].intValue());
        }
    }
    public static void setValuesArray(Element element, String name, boolean[] values) {
        for(int i=0; i<values.length; i++) {
            setElement(element, name, values[i]);
        }
    }
    public static void setValuesArray(Element element, String name, Boolean[] values) {
        for(int i=0; i<values.length; i++) {
            setElement(element, name, values[i].booleanValue());
        }
    }


    private static String[] getNodeValues(NodeList nl) {
        String[] ret = new String[nl.getLength()];
        for(int i=0; i<nl.getLength(); i++) {
            Element elem = (Element)nl.item(i);
            ret[i] = DomXML.getText(elem);
        }
        return ret;
    }

  public static Element findElement(Element element, String name) {
    NodeList nl = element.getElementsByTagName(name);
    if(nl == null || nl.getLength() == 0)return null;
    return (Element)nl.item(0);
  }

  private static void setText(Element elem, String text) {
    Text txt = elem.getOwnerDocument().createTextNode(text);
    elem.appendChild(txt);
  }


  public static void addConvertable(Element elem, String name, Convertable c) {
        Element ch = fromConvertable(elem.getOwnerDocument(), name, c);
        elem.appendChild(ch);
  }

  public static void setConvertables(Element elem, String name, Convertable[] cs) {
    for(int i=0; i<cs.length; i++) {
      addConvertable(elem, name, cs[i]);
    }
  }

    public static Convertable getConvertable(Element elem, String name) {
        Element ch = findElement(elem, name);
        if(ch == null)return null;
        return toConvertable(ch);
    }

    public static Convertable[] getConvertables(Element elem, String name) {
        NodeList nl = elem.getElementsByTagName(name);
        Convertable[] ret = new Convertable[nl.getLength()];
        for(int i=0; i<nl.getLength(); i++) {
            Element ch = (Element)nl.item(i);
            ret[i] = toConvertable(ch);
        }
        return ret;
    }

//---------------------------------------------------------------------------//

    static Element fromConvertable(Document doc, String name, Convertable c) {
        if(c == null)return null;
        Class clz = c.getClass();
        Element rootElem = doc.createElement(name);
        rootElem.setAttribute("class", clz.getName()); //NORES

        Method[] methods = clz.getMethods();

        for(int i=0; i<methods.length; i++) {
            Method m1 = methods[i];
            if(!Modifier.isPublic(m1.getModifiers()))continue;
            if(Modifier.isStatic(m1.getModifiers()))continue;
            String getterName = m1.getName();
            if(!getterName.startsWith("get"))continue; //NORES
            String mName = getterName.substring(3);
            Class retClz = m1.getReturnType();

            Object obj = null;
            try {
                obj = m1.invoke(c, EmptyArrays.OBJECT_EMPTY_ARRAY);
            }catch(Exception exc) { continue; }

            if(obj == null)continue;
            else if(obj instanceof Integer) {
                DomXML.setAttr(rootElem, mName, ((Integer)obj).intValue());
            }
            else if(obj instanceof Boolean) {
                DomXML.setAttr(rootElem, mName, ((Boolean)obj).booleanValue());
            }
            else if(obj instanceof String) {
                DomXML.setAttr(rootElem, mName, (String)obj);
            }
            else if(obj instanceof Convertable) {
                DomXML.addConvertable(rootElem, mName, (Convertable)obj);
            }
            else if(obj instanceof Integer[]) {
                DomXML.setValuesArray(rootElem, mName, (Integer[])obj);
            }
            else if(obj instanceof Boolean[]) {
                DomXML.setValuesArray(rootElem, mName, (Boolean[])obj);
            }
            else if(obj instanceof String[]) {
                DomXML.setValuesArray(rootElem, mName, (String[])obj);
            }
            else if(obj instanceof Convertable[]) {
                DomXML.setConvertables(rootElem, mName, (Convertable[])obj);
            }

        }

        return rootElem;
    }

    static Convertable toConvertable(Element elem) {
        if(elem == null)return null;

        Class clz = null;
        Convertable c_obj = null;
        try {
            clz = Class.forName(elem.getAttribute("class")); //NORES
            c_obj = (Convertable)clz.newInstance();
        }catch(Exception exc) {
            return null;
        }
        if(c_obj == null)return null;

        Method[] methods = clz.getMethods();

        for(int i=0; i<methods.length; i++) {
            Method m1 = methods[i];
            if(!Modifier.isPublic(m1.getModifiers()))continue;
            if(Modifier.isStatic(m1.getModifiers()))continue;
            String setterName = m1.getName();
            if(!setterName.startsWith("set"))continue; //NORES
            String mName = setterName.substring(3);
            Class[] pTypes = m1.getParameterTypes();
            if(pTypes.length != 1)continue;
            Class retClz = pTypes[0];
            //System.out.println(""+mName+" : "+retClz); //NORES

            Object obj = null;
            if(retClz.equals(int.class)) {
                obj = new Integer( DomXML.getAttrInt(elem, mName, -1) );
            }
            else if(retClz.equals(boolean.class)) {
                obj = new Boolean( DomXML.getAttrBoolean(elem, mName, false) );
            }
            else if(retClz.equals(String.class)) {
                obj = DomXML.getAttr(elem, mName);
            }
            else if(Convertable.class.isAssignableFrom(retClz)) {
//            else if(retClz.isAssignableFrom(Convertable.class)) {
                obj = DomXML.getConvertable(elem, mName);
            }
            else if(retClz.equals(int[].class)) {
                obj = DomXML.getValuesArrayInt(elem, mName);
            }
            else if(retClz.equals(boolean[].class)) {
                obj = DomXML.getValuesArrayBoolean(elem, mName);
            }
            else if(retClz.equals(String[].class)) {
                obj = DomXML.getValuesArray(elem, mName);
            }
            else if(Convertable[].class.isAssignableFrom(retClz)) {
                //System.out.println("QQQ");
//            else if(retClz.isArray() && Convertable.class.isAssignableFrom(retClz.getComponentType())) {
//            else if(retClz.isAssignableFrom(Convertable[].class)) {
                Convertable[] cs = DomXML.getConvertables(elem, mName);
                Convertable[] co = (Convertable[])java.lang.reflect.Array.newInstance(retClz.getComponentType(), cs.length);
                for(int j=0; j<cs.length; j++)co[j] = cs[j];
                obj = co;
                //System.out.println("Obj="+obj+">"+mName); //NORES
            }

            if(obj == null)continue;
            try {
                m1.invoke(c_obj, new Object[]{obj});
            }catch(Exception exc) { continue; }


        }

        return c_obj;
    }



    private static String getText(Element elem) {
        if(elem == null)return null;
        Text txt = (Text)elem.getFirstChild();
        if(txt == null)return null;
        return txt.getNodeValue();
    }

  private static boolean toBoolean(String str) {
    return "true".equals(str) || "yes".equals(str); //NORES
  }

  private static int toInt(String str) {
    try {
      return Integer.parseInt(str);
    }catch(Exception exc) {
      return 0;
    }
  }


}
