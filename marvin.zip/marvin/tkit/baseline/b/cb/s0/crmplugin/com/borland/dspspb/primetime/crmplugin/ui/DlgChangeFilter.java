package com.borland.dspspb.primetime.crmplugin.ui;

import com.borland.dspspb.primetime.crmplugin.dialog.PluginDialog;
import com.borland.dspspb.primetime.crmplugin.filter.FilterManager;
import com.borland.dspspb.primetime.crmplugin.filter.Filter;
import com.borland.dspspb.primetime.crmplugin.management.Source;
import com.borland.primetime.help.HelpTopic;
import com.borland.primetime.help.PrimetimeHelp;

import javax.swing.*;
import java.awt.*;


public class DlgChangeFilter extends PluginDialog
{
  private JPanel contentPanel = null;
  private JLabel lblFilter = null;
  private JComboBox cbFilter = null;

  private Source selectedSource = null;

  public DlgChangeFilter (Component owner, Source selectedSource)
  {
    super (owner, "Change Filter"); //RES DlgChangeFilter_title
    setHelpTopic (PrimetimeHelp.createTopic (PrimetimeHelp.BOOK_UserGuide, "ui/dialogs/dlgcaliberchangefilter.html")); //NORES

    this.selectedSource = selectedSource;
  }

  public JComponent getContentUI ()
  {
    contentPanel = new JPanel (new GridBagLayout ());

    lblFilter = new JLabel ("Filter:"); //RES DlgChangeFilter_Filter_text
    cbFilter = new JComboBox (FilterManager.getInstance ().getFilters ());
    cbFilter.setSelectedItem (FilterManager.getInstance().findFilter (selectedSource.getFilterId()));

    if (cbFilter.getSelectedIndex () == -1) cbFilter.setSelectedIndex (0);

    GridBagConstraints constraints = new GridBagConstraints ();

    constraints.anchor = GridBagConstraints.NORTHWEST;

		constraints.anchor = GridBagConstraints.NORTHWEST;
		constraints.gridx = 0;
		constraints.gridy = 0;
		constraints.weightx = 0.0;
		constraints.weighty = 1.0;
		constraints.fill = GridBagConstraints.NONE;
		constraints.insets = new Insets (3, 0, 0, 5);
		contentPanel.add (lblFilter, constraints);

		constraints.gridx = 1;
		constraints.gridy = 0;
		constraints.weightx = 1.0;
		constraints.weighty = 1.0;
		constraints.insets = new Insets (0, 0, 0, 0);;
		constraints.fill = GridBagConstraints.HORIZONTAL;
		contentPanel.add (cbFilter, constraints);

    return contentPanel;
  }

  public Filter getResult ()
  {
    return (Filter) cbFilter.getSelectedItem ();
  }
}
