package com.borland.dspspb.primetime.crmplugin.gui.swingcomponents;

import javax.swing.JTabbedPane;
import javax.swing.JComponent;
import javax.swing.BorderFactory;
import com.borland.dspspb.primetime.crmplugin.gui.abstractcomponents.AbstractViewContainer;
import javax.swing.JScrollPane;
import java.awt.Dimension;
import java.util.HashMap;
import java.awt.Component;

public class SwingTabSheet extends AbstractViewContainer
{

    private JTabbedPane mainComponent = new JTabbedPane();
    private HashMap indexNames = new HashMap();

    public Object getUI()
    {
       return mainComponent;
    }

    public void addTab(String name,SwingContainer container)
    {
       super.addComp(name,container);
       Component comp = new JScrollPane((JComponent)container.getUI());
       indexNames.put(comp,name);
       mainComponent.addTab( name,comp );
    }

    public String getSelectedTabName()
    {
       return (String)indexNames.get(mainComponent.getSelectedComponent());
    }

    public JTabbedPane getTabbedPane()
    {
        return mainComponent;
    }
}
