package com.borland.dspspb.primetime.crmplugin.actions;

import javax.swing.ImageIcon;

import com.borland.dspspb.primetime.crmplugin.resources.ResourceManager;
import com.borland.primetime.actions.StateAction;

abstract public class PluginStateAction extends StateAction
{
  public PluginStateAction (String shortText, String longText, String iconhKey)
  {
    super ();

    ImageIcon icon = ResourceManager.getIcon (iconhKey);

    setShortText (shortText);
    setLongText (longText);
    setSmallIcon (icon);
  }
}
