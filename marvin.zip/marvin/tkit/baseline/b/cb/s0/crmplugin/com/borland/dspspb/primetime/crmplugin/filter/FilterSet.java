package com.borland.dspspb.primetime.crmplugin.filter;

import java.util.Vector;
import com.borland.dspspb.primetime.crmplugin.util.smartxml.Convertable;

public class FilterSet implements Convertable
{
  Vector filters = null;

  public FilterSet()
  {
    filters = new Vector();
  }

  public Filter[] getFilters()
  {
    return (Filter[])filters.toArray(new Filter[filters.size()]);
  }

  public void setFilters(Filter[] filters)
  {
    this.filters.clear();

    for (int i = 0; i < filters.length; i++)
    {
      this.filters.add(filters[i]);
    }
  }

//------------------------------------------------------------------------------

  public void addFilter(Filter filter)
  {
    filters.add(filter);
  }

  public void removeFilter(Filter filter)
  {
    filters.remove(filter);
  }

  public Filter findFilter(String name)
  {
    if (name == null)
      return null;
    for (int i = 0; i < filters.size(); i++)
    {
      Filter filter = (Filter)filters.get(i);

      if (filter.getName().equals(name))
        return filter;
    }
    return null;
  }

  public void replaceFilter(Filter filterOld, Filter filterNew)
  {
    if (filterOld == null)
      addFilter(filterNew);
    else
    {
      int idx = filters.indexOf(filterOld);
      if (idx >= 0)
      {
        filters.set(idx, filterNew);
      }
      else
        addFilter(filterNew);
    }

  }
}
