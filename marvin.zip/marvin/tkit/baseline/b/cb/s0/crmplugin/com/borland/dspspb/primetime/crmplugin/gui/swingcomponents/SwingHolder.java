package com.borland.dspspb.primetime.crmplugin.gui.swingcomponents;

import javax.swing.JPanel;
import java.util.Vector;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import javax.swing.JComponent;
import java.util.Iterator;
import java.awt.Insets;
import java.util.Comparator;
import java.util.Collections;
import com.borland.dspspb.primetime.crmplugin.gui.abstractcomponents.AbstractViewContainer;
import com.borland.dspspb.primetime.crmplugin.gui.abstractcomponents.AbstractViewComponent;
import java.awt.BorderLayout;

public class SwingHolder extends SwingContainer
{
  public SwingHolder()
    {
     uiPanel.setLayout( new BorderLayout() );
    }


    public Object getUI()
    {
       uiPanel.removeAll();
     Vector sortedObjects = new Vector();
       sortedObjects.addAll( this.getComponents() );
     Iterator i = sortedObjects.iterator();
     if(i.hasNext())
       {
          AbstractViewComponent nextComp = (AbstractViewComponent)i.next();
      uiPanel.add( (JComponent)nextComp.getUI(), BorderLayout.CENTER);
       }
     return uiPanel;
    }


}
