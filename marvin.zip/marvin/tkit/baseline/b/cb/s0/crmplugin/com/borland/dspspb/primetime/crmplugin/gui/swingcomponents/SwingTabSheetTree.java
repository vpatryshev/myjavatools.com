package com.borland.dspspb.primetime.crmplugin.gui.swingcomponents;

import javax.swing.JTabbedPane;
import javax.swing.JComponent;
import javax.swing.BorderFactory;
import com.borland.dspspb.primetime.crmplugin.gui.abstractcomponents.AbstractViewContainer;
import javax.swing.JScrollPane;
import java.awt.Dimension;
import java.util.HashMap;
import java.awt.Component;
import javax.swing.JSplitPane;
import javax.swing.JList;
import javax.swing.JPanel;
import java.awt.CardLayout;
import java.util.Vector;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.JTree;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.MutableTreeNode;
import javax.swing.event.TreeSelectionListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeNode;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class SwingTabSheetTree extends AbstractViewContainer
{

  private JSplitPane mainComponent = new JSplitPane();
  private CardLayout layout = new CardLayout();
  private JPanel panel = new JPanel(layout);
  private HashMap namesToNodes = new HashMap();
    private Icon expIcon = new ImageIcon(getClass().getClassLoader().getResource("com/borland/dspspb/resources/images/ui/expanded.gif"));
    private Icon colIcon = new ImageIcon(getClass().getClassLoader().getResource("com/borland/dspspb/resources/images/ui/collapsed.gif"));

  private DefaultMutableTreeNode rootNode = new DefaultMutableTreeNode("root");
  private DefaultTreeModel treeModel = new DefaultTreeModel(rootNode);
  private JTree tree = new JTree(treeModel);

  private Vector names = new Vector();

    public Object getUI()
  {
    mainComponent.setOrientation(JSplitPane.HORIZONTAL_SPLIT);
    JScrollPane jsp = new JScrollPane( tree );
    jsp.setBorder( BorderFactory.createEtchedBorder() );
    panel.setBorder( BorderFactory.createEtchedBorder() );
    mainComponent.add( jsp, JSplitPane.LEFT);
    mainComponent.add(panel, JSplitPane.RIGHT);
    tree.addTreeSelectionListener(new TreeSelectionListener(){
      public void valueChanged(TreeSelectionEvent event) {
        TreePath tp = tree.getSelectionPath();
        if(tp == null)return;
        DefaultMutableTreeNode tn = (DefaultMutableTreeNode)tp.getLastPathComponent();
        String name=  (String)tn.getUserObject();
        layout.show(panel, name);
      }
    });
    tree.expandRow(0);
    tree.setShowsRootHandles(true);
    tree.setRootVisible(false);
    tree.setCellRenderer(new DefaultTreeCellRenderer() {
        public Component getTreeCellRendererComponent(JTree tree, Object value, boolean sel, boolean expanded,
                                                  boolean leaf, int row, boolean hasFocus) {
        JLabel comp = (JLabel)super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);
//				comp.setIcon( leaf ? null : (expanded ? expIcon : colIcon) );
        comp.setIcon( null );
        return comp;
      }
    });

    tree.setSelectionInterval(0,0);
    jsp.setPreferredSize(new Dimension(140, 340));
    mainComponent.setDividerSize(5);
    mainComponent.setDividerLocation(150);
    tree.requestFocus();

       return mainComponent;
    }

  public void addTab(String name, SwingContainer container) {
    addTab(name, container, true);
  }
  public void addTab(String name, SwingContainer container, boolean inScrollPane) {
    addTab(rootNode, name, container, inScrollPane);
  }

  public void addTab(String parentName, String name, SwingContainer container) {
    addTab(parentName, name, container, true);
  }
  public void addTab(String parentName, String name, SwingContainer container, boolean inScrollPane) {
    DefaultMutableTreeNode tn = (DefaultMutableTreeNode)namesToNodes.get(parentName);
    addTab(tn, name, container, inScrollPane);
  }

  private void addTab(DefaultMutableTreeNode parent, String name,SwingContainer container, boolean inScrollPane)
    {
     super.addComp(name,container);
     Component comp = null;
     if(inScrollPane) {
        comp = new JScrollPane((JComponent)container.getUI());
     }else {
    comp = (Component)container.getUI();
     }
     panel.add(comp, name);
     DefaultMutableTreeNode tn = new DefaultMutableTreeNode(name);
     parent.add(tn);
     namesToNodes.put(name, tn);
  }

    public String getSelectedTabName()
  {
    TreePath tp = tree.getSelectionPath();
    if(tp == null)return null;
    DefaultMutableTreeNode tn = (DefaultMutableTreeNode)tp.getLastPathComponent();
    return (String)tn.getUserObject();
  }

  public JSplitPane getSplitPane()
    {
        return mainComponent;
    }
}
