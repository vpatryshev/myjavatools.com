
package com.borland.dspspb.primetime.crmplugin.gui.treetable;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.util.Vector;

public class RowHeaderView extends JList
  implements ListSelectionListener
{
  private	Vector listData					= new Vector ();
  private JTable table						= null;

  public RowHeaderView (JTable table)
  {
    this.table = table;

    JTableHeader header = table.getTableHeader ();

    setFixedCellHeight (table.getRowHeight());
    setSelectionMode (table.getSelectionModel().getSelectionMode ());
    setBackground (header.getBackground());

    setCellRenderer (new RowHeaderCellRenderer ());
    addListSelectionListener (this);

    updateRowHeader ();
  }

  public void updateRowHeader ()
  {
    listData.removeAllElements ();
    int rowCount = table.getRowCount ();

    setFixedCellWidth (rowCount == 0 ? 1 : -1);

    for (int i = 1; i <= rowCount; i++)
    {
      listData.add (" " + String.valueOf (i) + " "); //NORES
    }

    setListData (listData);
    repaint ();
  }

  public void updateUI ()
  {
    super.updateUI();

    if (table != null) // updateUI() is invoked from JList's super constructor, so this checking is necessary!
    {
      setFixedCellHeight (table.getRowHeight ());
      setBackground (table.getTableHeader ().getBackground ());
    }
  }

// -----------------------------------------------------------------------------
// List selection listener

  public void valueChanged (ListSelectionEvent e)
  {
    // Synchronize selection between row header and table
    // Assume table has "single" selection mode
    int selectedRow = getSelectedIndex ();

//    if (selectedRow == -1)
//      table.clearSelection ();
//    else

    if (selectedRow != -1)
      table.setRowSelectionInterval (selectedRow, selectedRow);

// Doesn't work:
//    table.setRowSelectionInterval (e.getFirstIndex (), e.getLastIndex ());
// But why?
  }

// -----------------------------------------------------------------------------
// List cell renderer

  private class RowHeaderCellRenderer extends JLabel implements ListCellRenderer
  {
    public RowHeaderCellRenderer ()
    {
      setHorizontalAlignment (JLabel.RIGHT);
      setOpaque (true);
    }

    public Component getListCellRendererComponent
      (JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
    {
      JTableHeader header = table.getTableHeader ();

      if (header != null)
      {
        setBackground (isSelected ? header.getBackground ().darker () : header.getBackground ());
        setForeground (isSelected ? table.getSelectionForeground () : header.getForeground ());
        setFont (header.getFont ());
        setBorder (UIManager.getBorder ("TableHeader.cellBorder")); //NORES
      }

      setText ((value == null) ? "" : value.toString ()); //NORES

      return this;
    }
  }
}
