package com.borland.dspspb.primetime.crmplugin.gui.actions.menu;

import javax.swing.JMenuItem;
import com.borland.dspspb.primetime.crmplugin.gui.actions.SwingAction;
import com.borland.dspspb.primetime.crmplugin.gui.actions.SwingCheckBoxAction;
import javax.swing.Action;

public class MenuItem extends JMenuItem implements IMenuItem {
    public static IMenuItem createMenuItem(SwingAction action) {
        //if(action.getValue(Action.SMALL_ICON) == null) {
        //    action.putValue(Action.SMALL_ICON, ResourceManager.getInstance().getImageIcon("com/borland/dspspb/resources/images/general/blank.gif"));
        //}
        if(action instanceof SwingCheckBoxAction) {
            return new CheckBoxMenuItem((SwingCheckBoxAction)action);
        }
        else return new MenuItem(action);
    }

    public MenuItem(SwingAction action) {
        super(action);
    }

    public SwingAction getAdrenalinAction() {
        return (SwingAction)getAction();
    }

    public void udpateMenuItem() {
        SwingAction action = getAdrenalinAction();
        setEnabled(action.isEnabled());
    }
}
