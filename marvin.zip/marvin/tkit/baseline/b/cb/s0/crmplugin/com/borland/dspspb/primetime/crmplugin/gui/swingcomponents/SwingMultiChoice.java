package com.borland.dspspb.primetime.crmplugin.gui.swingcomponents;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.Iterator;
import com.borland.dspspb.primetime.crmplugin.gui.abstractcomponents.AbstractChoiceComponent;
import java.util.Collection;
import java.util.Vector;
import java.util.Enumeration;


public class SwingMultiChoice  extends AbstractChoiceComponent
{
    private MultiChoicePanel mainComponent;
    public SwingMultiChoice(String name,String leftTitle,String rightTitle )
    {
        mainComponent = new MultiChoicePanel(leftTitle,rightTitle );
        setName ( name );
    }

    public Vector getValues()
    {
       Vector values = super.getValues();
       Enumeration myEnum = mainComponent.getRightListModel().elements();
       while ( myEnum.hasMoreElements() )
       {
          values.add( myEnum.nextElement().toString() );
       }
       values.remove( null );
       return values;
    }

    public Object getUI()
    {
       mainComponent.getLeftListModel().clear();
       mainComponent.getRightListModel().clear();

       mainComponent.setPreferredSize(new Dimension(300,(int)mainComponent.getPreferredSize().getHeight() ));
       Iterator i = this.getChoiceValues().iterator();
       while ( i.hasNext() )
       {
            mainComponent.getLeftListModel().addElement( i.next() );
       }
       i = this.getValues().iterator();
       while ( i.hasNext() )
       {
            mainComponent.getRightListModel().addElement( i.next() );
       }
       return mainComponent;
    }
}
