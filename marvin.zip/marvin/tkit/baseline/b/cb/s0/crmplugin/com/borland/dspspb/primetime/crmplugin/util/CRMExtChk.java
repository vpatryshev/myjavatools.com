package com.borland.dspspb.primetime.crmplugin.util;

import com.borland.launcher.JavaLauncher;
import com.borland.primetime.util.Platform;

public class CRMExtChk
{
  CRMExtChk()
  {
  }

  public static boolean isExtRegistered(String ext)
  {
    if (Platform.WIN32)
    {
      try
      {
        String regKeyExtDefault = JavaLauncher.readRegistryStringValue(JavaLauncher.HKEY_CLASSES_ROOT, ext, ""); //NORES
        if (regKeyExtDefault != null)
        {
          String regKeyTypeShellCommand = JavaLauncher.readRegistryStringValue(JavaLauncher.HKEY_CLASSES_ROOT, regKeyExtDefault + "\\shell\\open\\command", ""); //NORES
          if (regKeyTypeShellCommand != null)
            return true;
        }
      }
      catch (Exception e)
      {
      }
      return false;
    }
    else
      return true;
  }
}
