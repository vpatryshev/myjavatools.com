package com.borland.dspspb.primetime.crmplugin.management;

public interface ICaliberOperation extends Runnable
{
  public boolean getResult();
  public void setCanceled();
  public void onSuccess();
  public void onError();
  public void onCancel();
}
