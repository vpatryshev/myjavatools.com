package com.borland.dspspb.primetime.crmplugin.util.smartxml;

import java.io.*;
import org.w3c.dom.*;

public class XMLWriter
{
  private static XMLWriter instance = null;
    private boolean friendlyOuptut = true;
  protected XMLWriter(){}
  public static XMLWriter getInstance()
  {
    if(instance == null)
    {
      instance = new XMLWriter();
    }
    return instance;
  }

    public void setFriendlyOutput(boolean friendlyOutput) {
        this.friendlyOuptut = friendlyOuptut;
    }

  public void write(Document doc, PrintStream writer)
  {
    printNode(doc, writer);
    writer.flush();
  }
  public void write(Document doc, OutputStream os)
  {
    try
    {
      printNode(doc, new PrintStream(os, true, "UTF-8")); //NORES
    }
    catch (UnsupportedEncodingException ex)
    {
      printNode(doc, new PrintStream(os));
    }
  }

  public String toLiteralXML(Document doc) {
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    write(doc, baos);
    try {
      baos.close();
    }catch(Exception exc) {exc.printStackTrace();}
    return baos.toString();
  }

    private void printNode(Node node, PrintStream myWriter) {
        printNode(node, myWriter, friendlyOuptut ? "" : null); //NORES
    }
  private void printNode(Node node, PrintStream myWriter, String tab)
  {
    if(node == null)return;

    switch(node.getNodeType())
    {
      case Node.DOCUMENT_NODE:
      {
        printNode(((Document)node).getDocumentElement(), myWriter);
        break;
      }

      case Node.DOCUMENT_TYPE_NODE:
      {
        DocumentType docType = (DocumentType)node;
        myWriter.print("<!DOCTYPE "); //NORES
        myWriter.print(docType.getName()+' ');
        String systemID = docType.getSystemId();
        String publicID = docType.getPublicId();
        if(systemID!=null && systemID.length()!=0)
        myWriter.print("SYSTEM \""+systemID+"\" "); //NORES
        if(publicID!=null && publicID.length()!=0)
        myWriter.print("PUBLIC \""+publicID+"\""); //NORES
        myWriter.println();
        break;
      }

      case Node.ELEMENT_NODE:
      {
                if(tab != null)myWriter.print(tab);
        myWriter.print('<');
        myWriter.print(node.getNodeName());
        NamedNodeMap attrs = node.getAttributes();
        for(int i=0; i<attrs.getLength(); i++)
        {
                    if(i != 0) {
                        if(tab != null) {
                            myWriter.println();
                            myWriter.print(tab);
                            for(int j=0; j<=node.getNodeName().length(); j++) {
                                myWriter.print(' ');
                            }
                        }
                    }
          Attr attr = (Attr)attrs.item(i);
          myWriter.print(' ');
          myWriter.print(attr.getNodeName ());
          myWriter.print("=\""); //NORES
          myWriter.print(normalize(attr.getNodeValue()));
          myWriter.print('"'); //NORES
        }

        NodeList children = node.getChildNodes();
        if(children == null || children.getLength() == 0)
        {
          myWriter.print("/>"); //NORES
                    if(tab != null)myWriter.println();
        }
        else
        {
          myWriter.print(">"); //NORES

                    if(children.getLength() != 1 || children.item(0).getNodeType() != Node.TEXT_NODE) {
                        if(tab != null)myWriter.println();
                    }

          for(int i=0; i<children.getLength(); i++)
          {
            printNode(children.item(i), myWriter, (tab==null?null:tab+"  ")); //NORES
          }

                    if(children.getLength() != 1 || children.item(0).getNodeType() != Node.TEXT_NODE) {
                        if(tab != null) {
                            myWriter.println();
                            myWriter.print(tab);
                        }
                    }
          myWriter.print("</"); //NORES
          myWriter.print(node.getNodeName());
          myWriter.print('>');
                    if(tab != null)myWriter.println();
        }
        break;
      }

      case Node.ENTITY_REFERENCE_NODE:
      {
        myWriter.print('&');
        myWriter.print(node.getNodeName());
        myWriter.print(';');
        break;
      }

      case Node.CDATA_SECTION_NODE:
      {
        myWriter.print("<![CDATA["); //NORES
        myWriter.print(node.getNodeValue());
        myWriter.print("]]>"); //NORES
        break;
      }

      case Node.TEXT_NODE:
      {
        String text = node.getNodeValue();
        if(text != null)
        {
          myWriter.print(normalize(text.trim()));
                    //if(tab != null)myWriter.println();
        }
        break;
      }

      case Node.PROCESSING_INSTRUCTION_NODE:
      {
        myWriter.print("<?"); //NORES
        myWriter.print(node.getNodeName());
        String data = node.getNodeValue();
        if(data != null && data.length() > 0)
        {
          myWriter.print (' ');
          myWriter.print(data);
        }
        myWriter.print ("?>"); //NORES
        break;
      }

      case Node.COMMENT_NODE:
      {
        myWriter.print("<!--"); //NORES
        myWriter.print(node.getNodeValue());
        myWriter.println("-->"); //NORES
        break;
      }
    }
  }

  protected String normalize(String s)
  {
    StringBuffer str = new StringBuffer();

    int len = (s != null) ? s.length() : 0;
    for(int i=0; i<len; i++)
    {
      char ch = s.charAt(i);
      switch(ch)
      {
        case '<' : str.append("&lt;");   break; //NORES
        case '>' : str.append("&gt;");   break; //NORES
        case '&' : str.append("&amp;");  break; //NORES
        case '\"': str.append("&quot;"); break; //NORES
        case '\'': str.append("&apos;"); break; //NORES
        default  : str.append(ch);
      }
    }
    return str.toString();
  }

}
