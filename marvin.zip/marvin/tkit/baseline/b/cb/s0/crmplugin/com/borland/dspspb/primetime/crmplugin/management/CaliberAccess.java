package com.borland.dspspb.primetime.crmplugin.management;

import com.borland.dspspb.primetime.crmplugin.ui.WaitDialog;

public class CaliberAccess
{
  private ICaliberOperation m_operation;
  private AccessWrapperThread m_accessWrapperThread;
  public WaitDialog m_waitDialog = null;
  private int m_waitDialogDelay = 3000;

  private String m_WaitDialogTitle = "Please wait"; //RES CaliberAccess_WaitDialog_Title
  private String m_WaitDialogMessage = "Retrieving information from server..."; //RES CaliberAccess_WaitDialog_Message

  public CaliberAccess(ICaliberOperation operation)
  {
    m_operation = operation;
    m_accessWrapperThread = new AccessWrapperThread(m_operation);
  }

  public void setTitle(String title)
  {
    if (title != null && title.length() > 0)
      m_WaitDialogTitle = title;
  }

  public void setMessage(String message)
  {
    if (message != null && message.length() > 0)
      m_WaitDialogMessage = message;
  }

  public void setWaitDialogDelay(int delay)
  {
    m_waitDialogDelay = delay;
  }

  public void perform()
  {
    int delay = 0;
    m_accessWrapperThread.start();
    while (m_accessWrapperThread.isAlive() && (delay < m_waitDialogDelay))
    {
      try
      {
        Thread.sleep(100);
        delay += 100;
      }
      catch (InterruptedException ex)
      {
      }
    }

    if (m_accessWrapperThread.isAlive())
    {
      m_waitDialog = new WaitDialog(FramingManager.getInstance().getMainFrame(),
                                    m_WaitDialogTitle, m_WaitDialogMessage);
      m_waitDialog.show();
      if (m_waitDialog.isCanceled())
      {
        m_accessWrapperThread.setCanceled();
        m_operation.onCancel();
// Wait for completing access thread (and operation)
//        if (m_accessWrapperThread.isAccessThreadAlive())
//        {
//          FramingManager.showWaitCursor(true);
//          while (m_accessWrapperThread.isAccessThreadAlive())
//          {
//            try
//            {
//              Thread.sleep(100);
//            }
//            catch (InterruptedException ex1)
//            {
//            }
//          }
//          FramingManager.showWaitCursor(false);
//        }
//        return;
      }
    }

    if (!m_operation.getResult())
      m_operation.onError();
    else
      m_operation.onSuccess();
  }

  public boolean isCanceled()
  {
    return m_accessWrapperThread.isCanceled();
  }

  private class AccessWrapperThread extends Thread
  {
    private ICaliberOperation m_operation;
    private boolean m_bCanceled = false;
    private Thread m_accessThread = null;

    public AccessWrapperThread(ICaliberOperation operation)
    {
      m_operation = operation;
    }

    public void run()
    {
      m_accessThread = new Thread(m_operation);
      m_accessThread.start();
//      FramingManager.showWaitCursor(true);
      while (!isCanceled() && m_accessThread.isAlive())
      {
        try
        {
          Thread.sleep(30);
        }
        catch (InterruptedException e)
        {
        }
      }
      if (!isCanceled() && m_waitDialog != null)
      {
        m_waitDialog.dispose();
      }
//      FramingManager.showWaitCursor(false);
    }

    public boolean isCanceled()
    {
      return m_bCanceled;
    }

    public void setCanceled()
    {
      m_bCanceled = true;
      m_operation.setCanceled();
    }

    public boolean isAccessThreadAlive()
    {
      if (m_accessThread != null)
        return m_accessThread.isAlive();
      return false;
    }
  }
}
