package com.borland.dspspb.primetime.crmplugin.gui.swingcomponents;

import com.borland.dspspb.primetime.crmplugin.gui.abstractcomponents.AbstractViewComponent;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;
import javax.swing.tree.TreeNode;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.DefaultMutableTreeNode;
import java.util.Vector;
import java.util.Enumeration;
import java.util.HashMap;
import javax.swing.table.TableCellRenderer;
import java.awt.Component;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;
import java.awt.FlowLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;
import javax.swing.JScrollPane;
import javax.swing.ImageIcon;
import javax.swing.SwingUtilities;
import java.awt.Point;

public class SwingTreeTable extends AbstractViewComponent
{
     private JTable myTable = new JTable();
     private JScrollPane myPane = new JScrollPane ( myTable );
     private TreeTableModel myTableModel = new TreeTableModel();
     private static ImageIcon iconCollapsed;
     private static ImageIcon iconExpanded;

     public SwingTreeTable(String[] names )
     {
         this();
         myTableModel.setColumnNames (names);
     }

     public SwingTreeTable()
     {
        myTable.setModel( myTableModel );
        myTable.setRowHeight( 22 );
        myTable.setDefaultRenderer( DefaultMutableTreeNode.class,new TreeTableCellRenderer() );
        loadIcons();
        myTable.addMouseListener( new MouseAdapter()
        {
            public void mouseClicked(MouseEvent ev)
            {
                 if ( SwingUtilities.isLeftMouseButton ( ev ) )
                 {
                      JTable table = (JTable)ev.getSource();
                      TreeTableModel model = (TreeTableModel)table.getModel();
                      Point coords =new Point ( ev.getX(),ev.getY() );
                      int column = table.columnAtPoint(coords);
                      if ( column == 0 )
                      {
                         int row =  table.rowAtPoint(coords);
                         if ( row!=-1 )
                         {
                             DefaultMutableTreeNode node = (DefaultMutableTreeNode)table.getValueAt( row,column );
                             model.expandNode(node);
                             table.getSelectionModel().setSelectionInterval(row,row );

                         }
                      }
                 }
            }
        });
     }
    private void loadIcons ()
    {
        if ( iconCollapsed!=null );
        iconCollapsed = new ImageIcon(getClass().getClassLoader().getResource("com/borland/dspspb/resources/images/ui/collapsed.gif"));
        iconExpanded = new ImageIcon(getClass().getClassLoader().getResource("com/borland/dspspb/resources/images/ui/expanded.gif"));
   }


class TreeTableCellRenderer extends DefaultTableCellRenderer
{
   public Component getTableCellRendererComponent(JTable tabl, Object value, boolean isSelected, boolean hasFocus, int row, int column)
   {
         if ( column == 0 )
         {
            JPanel result = new JPanel();
            result.setLayout( new FlowLayout(FlowLayout.LEFT) );
            if ( value instanceof String )
            {
              return super.getTableCellRendererComponent( tabl,value,isSelected,hasFocus,row,column );
            }

            final DefaultMutableTreeNode  node = (DefaultMutableTreeNode)value;
            JLabel dumbLabel = new JLabel();
            dumbLabel.setPreferredSize( new Dimension((node.getLevel()-1)*16,0) );
            result.add ( dumbLabel );
            final JTable table = tabl;

            final TreeTableModel model = (TreeTableModel)table.getModel();
            if ( node.getAllowsChildren() )
            {
               JLabel expandLabel = new JLabel();
               if ( model.isExpanded (node) )
               {
                 expandLabel.setIcon( iconExpanded );
               }
               else
               {
                 expandLabel.setIcon( iconCollapsed );
               }
               expandLabel.setBackground( Color.white );
               expandLabel.setPreferredSize( new Dimension(iconExpanded.getIconWidth(),iconCollapsed.getIconHeight() ) );
               result.add ( expandLabel );
            }
            Object val = node.getUserObject();
            if ( val == null ) val = "null object";
            JLabel textLabel = new JLabel(val.toString());
            result.add ( textLabel  );
            if ( isSelected )
            {
               result.setBackground( table.getSelectionBackground() );
               textLabel.setBackground( Color.white );
            }
            else
            {
               result.setBackground( Color.white );
               textLabel.setBackground( Color.white );
            }
            return result;
         }
         else return super.getTableCellRendererComponent( tabl,value,isSelected,hasFocus,row,column );
   }
}
public JTable getTable()
{
   return myTable;
}

public class TreeTableModel extends AbstractTableModel {
    private String[] columnNames = new String[]{"Default column"};
    private DefaultMutableTreeNode rootNode;
    private Vector expandedNodes = new Vector();
    private HashMap otherDataMap = new HashMap();

    private void setColumnNames ( String[] columnN )
    {
       this.columnNames = columnN;
       if ( rootNode == null ) rootNode = new DefaultMutableTreeNode();
       this.fireTableStructureChanged();
    }

    public int getColumnCount()
    {
        return columnNames.length;
    }
    public DefaultMutableTreeNode getRoot()
    {
       if ( rootNode == null ) rootNode = new DefaultMutableTreeNode();
        return rootNode;
    }
    public boolean isExpanded ( TreeNode node )
    {
        return expandedNodes.contains( node );
    }

    public void expandNode(TreeNode node)
    {
       if ( expandedNodes.contains( node ) ) expandedNodes.remove ( node );
       else
       expandedNodes.add( node );
       fireTableDataChanged();
    }

    public DefaultMutableTreeNode addData ( DefaultMutableTreeNode parent,Object value,Object[] otherValues,boolean allowChildren )
    {
      DefaultMutableTreeNode childNode = new DefaultMutableTreeNode ( value,allowChildren );
      parent.add( childNode );
      otherDataMap.put ( childNode,otherValues );
      fireTableDataChanged();
      return childNode;
    }

    public DefaultMutableTreeNode addData ( DefaultMutableTreeNode parent,Object value,Object[] otherValues )
    {
          return addData(parent,value,otherValues ,true );
    }
    public void removeData( int index )
    {
       DefaultMutableTreeNode removableNode = this.getNodeByIndex( index );
       otherDataMap.remove ( removableNode );
       removableNode.removeFromParent();
       expandedNodes.remove( removableNode );
       this.fireTableDataChanged();
    }

    public int getRowCount()
    {
        int rowCount = 0;
        rowCount+=getChildCount( rootNode );
        return rowCount;
    }

    private int getChildCount(TreeNode currNode)
    {
        int result=0;
        Enumeration e = currNode.children();
        while ( e.hasMoreElements() )
        {
           DefaultMutableTreeNode nextNode = (DefaultMutableTreeNode)e.nextElement();
           if ( expandedNodes.contains(nextNode) )
           {
              result+=getChildCount( nextNode );
           }
           result++;
        }
        return result;
    }

    public String getColumnName(int col) {
        return columnNames[col];
    }
    private DefaultMutableTreeNode getNodeByIndex(DefaultMutableTreeNode currNode,int currIndex,int index )
    {
       Enumeration e = currNode.children();
       while ( e.hasMoreElements() )
       {

          DefaultMutableTreeNode nextElement =(DefaultMutableTreeNode)e.nextElement();
          if ( currIndex == index ) return nextElement;
          currIndex++;
          if ( expandedNodes.contains(nextElement) )
          {
             DefaultMutableTreeNode result = getNodeByIndex(nextElement,currIndex,index);
             currIndex+=getChildCount( nextElement );
             if ( result!=null ) return result;
          }
       }
       return null;
    }
    public DefaultMutableTreeNode getNodeByIndex(int index)
    {
       return getNodeByIndex(rootNode,0,index);
    }

    public Object getValueAt(int row, int col)
    {
            DefaultMutableTreeNode treeNode = getNodeByIndex ( row );
            if ( treeNode==null )
            return "Node at (row="+row+",col="+col+") not found !";

        if ( col==0 )
        {
               return treeNode;
        }
        else
        {
           Object[] data = (Object[])otherDataMap.get ( treeNode );

           return data[col-1];
        }
    }

    public Class getColumnClass(int c) {
        return getValueAt(0, c).getClass();
    }
 }


 public Object getUI()
 {
     return myPane;
 }

}
