package com.borland.dspspb.primetime.crmplugin;

import java.util.*;

import com.borland.dspspb.primetime.crmplugin.management.*;
import com.borland.dspspb.primetime.crmplugin.opentool.*;
import com.borland.dspspb.primetime.crmplugin.ui.*;
import com.borland.dspspb.primetime.crmplugin.view.*;
import com.borland.dspspb.primetime.crmplugin.view.rvtreetable.*;
import com.borland.primetime.ide.*;
import com.borland.primetime.ide.view.*;
import com.borland.primetime.ide.workspace.*;
import com.borland.primetime.ide.workspace.event.*;
import com.borland.primetime.ide.workspace.event.ViewAdapter;
import com.borland.primetime.node.*;
import com.starbase.caliber.Session;

public class PluginManager extends ViewAdapter
{
  private static PluginManager pluginManager = null;
  private PluginView currentView = null;
	private static Vector commentFields = null;


  public static synchronized PluginManager getInstance ()
  {
    if (pluginManager == null)
    {
      pluginManager = new PluginManager ();
      pluginManager.init ();
    }

    return pluginManager;
  }

  private void init ()
  {
    Browser browser = Browser.getActiveBrowser ();

    if (browser != null)
    {
      Workspace.addStaticViewListener (this);
      Browser.addStaticBrowserListener (new BrowserAdapter()
      {
        public void browserNodeActivated(Browser browser, Node node)
        {
          NodeStewardsManager.setDropTargets(node);
        }
      });

      NodeStewardsManager.setDropTargets(browser.getActiveNode());
    }

		commentFields = PluginManager.getDefaultCommentColumns ();
  }

// -----------------------------------------------------------------------------

  private static RVTableColumn RVTC_NAME = new RVTableColumn (RVTableColumn.TCN_NAME, RVTableColumn.TCDN_NAME);
  private static RVTableColumn RVTC_TYPE = new RVTableColumn (RVTableColumn.TCN_TYPE, RVTableColumn.TCDN_TYPE);
  private static RVTableColumn RVTC_VERSION = new RVTableColumn (RVTableColumn.TCN_VERSION, RVTableColumn.TCDN_VERSION);
  private static RVTableColumn RVTC_OWNER = new RVTableColumn (RVTableColumn.TCN_OWNER, RVTableColumn.TCDN_OWNER);
  private static RVTableColumn RVTC_STATUS = new RVTableColumn (RVTableColumn.TCN_STATUS, RVTableColumn.TCDN_STATUS);
  private static RVTableColumn RVTC_PRIORITY = new RVTableColumn (RVTableColumn.TCN_PRIORITY, RVTableColumn.TCDN_PRIORITY);
  private static RVTableColumn RVTC_DESCRIPTION = new RVTableColumn (RVTableColumn.TCN_DESCRIPTION, RVTableColumn.TCDN_DESCRIPTION);
  private static RVTableColumn RVTC_SERVER = new RVTableColumn (RVTableColumn.TCN_SERVER, RVTableColumn.TCDN_SERVER);
  private static RVTableColumn RVTC_PROJECTID = new RVTableColumn (RVTableColumn.TCN_PROJECTID, RVTableColumn.TCDN_PROJECTID);
  private static RVTableColumn RVTC_PROJECTNAME = new RVTableColumn (RVTableColumn.TCN_PROJECTNAME, RVTableColumn.TCDN_PROJECTNAME);
  private static RVTableColumn RVTC_BASELINEID = new RVTableColumn (RVTableColumn.TCN_BASELINEID, RVTableColumn.TCDN_BASELINEID);
  private static RVTableColumn RVTC_BASELINENAME = new RVTableColumn (RVTableColumn.TCN_BASELINENAME, RVTableColumn.TCDN_BASELINENAME);
  private static RVTableColumn RVTC_REQID = new RVTableColumn (RVTableColumn.TCN_REQID, RVTableColumn.TCDN_REQID);

  private static Vector allColumns = new Vector ();
  static
  {
    allColumns.add (RVTC_NAME);
    allColumns.add (RVTC_VERSION);
    allColumns.add (RVTC_OWNER);
    allColumns.add (RVTC_PRIORITY);
    allColumns.add (RVTC_STATUS);
  }

  private static Vector defaultColumns = new Vector ();
  static
  {
    defaultColumns.add (RVTC_NAME);
    defaultColumns.add (RVTC_VERSION);
    defaultColumns.add (RVTC_STATUS);
    defaultColumns.add (RVTC_PRIORITY);
    defaultColumns.add (RVTC_OWNER);
  }

  private static Vector allCommentColumns = new Vector ();
  static
  {
    allCommentColumns.add (RVTC_NAME);
    allCommentColumns.add (RVTC_DESCRIPTION);
    allCommentColumns.add (RVTC_TYPE);
    allCommentColumns.add (RVTC_SERVER);
    allCommentColumns.add (RVTC_PROJECTNAME);
    allCommentColumns.add (RVTC_VERSION);
    allCommentColumns.add (RVTC_OWNER);
    allCommentColumns.add (RVTC_PRIORITY);
    allCommentColumns.add (RVTC_STATUS);
  }

  private static Vector defaultCommentColumns = new Vector ();
  static
  {
    defaultCommentColumns.add (RVTC_NAME);
    defaultCommentColumns.add (RVTC_DESCRIPTION);
    defaultCommentColumns.add (RVTC_TYPE);
    defaultCommentColumns.add (RVTC_SERVER);
    defaultCommentColumns.add (RVTC_PROJECTNAME);
//    defaultCommentColumns.add (RVTC_VERSION);
//    defaultCommentColumns.add (RVTC_OWNER);
    defaultCommentColumns.add (RVTC_PRIORITY);
    defaultCommentColumns.add (RVTC_STATUS);
  }

  public static Vector getAllColumns ()
  {
    return allColumns;
  }

  public static Vector getDefaultColumns ()
  {
    return defaultColumns;
  }

  public static Vector getAllCommentColumns ()
  {
    return allCommentColumns;
  }

  public static Vector getDefaultCommentColumns ()
  {
    return defaultCommentColumns;
  }

// -----------------------------------------------------------------------------

  public PluginView getView ()
  {
    return currentView;
  }

  public PluginView openView (Source source)
  {
    // Check connection
    if (source == null) return null;

    if (source.getSession () == null)
    {
      DlgCaliberLogin dlgLogin = new DlgCaliberLogin (FramingManager.getInstance ().getMainFrame (), source);

      if (!dlgLogin.showDialog () || source.getSession () == null) return null;
    }

    Workspace workspace = WorkspaceManager.getWorkspace (Browser.getActiveBrowser ());

    View[] views = workspace.getViews(PluginViewType.PLUGIN_VIEWTYPE);
    if (views != null && views.length > 0)
    {
      for (int i = 0; i < views.length; i++)
      {
        if (!(views[i] instanceof PluginWorkspaceView))
          continue;
        PluginWorkspaceView pluginWorkspaceView = (PluginWorkspaceView)views[i];
        PluginView pluginView = (PluginView)pluginWorkspaceView.getContent();
        if (pluginView == null)
          continue;
        Source viewSource = pluginView.getSource();
        if (source.getId().equals(viewSource.getId()))
        {
          workspace.setViewActive(pluginWorkspaceView);
          return pluginView;
        }
      }
    }

    // Create and open view
    View view = ViewManager.createView (Browser.getActiveBrowser (), PluginViewType.PLUGIN_VIEWTYPE);
    ((PluginWorkspaceView) view).setTitle (source.getName ());

    workspace.openView (view);
    workspace.setViewActive (view);

    PluginView pluginView = (PluginView) view.getContent ();
    pluginView.runSource (source);

    return pluginView;
  }

  public void closeView()
  {
    if (currentView == null)
      return;

    Workspace workspace = WorkspaceManager.getWorkspace (Browser.getActiveBrowser ());
    View view = WorkspaceManager.getWorkspace (Browser.getActiveBrowser ()).getActiveView ();
    workspace.closeView (view);
  }

// -----------------------------------------------------------------------------
// ViewAdapter extensions

  public void viewActivated (ViewEvent viewEvent)
  {
    View view = viewEvent.getView ();

    if (view instanceof PluginWorkspaceView)
    {
      currentView = (PluginView) view.getContent ();
    }
  }

  public void viewClosed (ViewEvent viewEvent)
  {
    currentView = null;
  }

// -----------------------------------------------------------------------------

	public Vector getCommentFields ()
	{
		return commentFields;
  }

	public void setCommentFields (Vector fields)
	{
		commentFields = fields;
	}

// -----------------------------------------------------------------------------

  public static PluginWorkspaceView [] getSessionViews (Session session)
  {
    Workspace workspace = WorkspaceManager.getWorkspace (Browser.getActiveBrowser ());

    View [] views = workspace.getViews (PluginViewType.PLUGIN_VIEWTYPE);

    ArrayList sessionViews = new ArrayList ();

    for (int iView = 0; iView < views.length; iView++)
    {
      PluginWorkspaceView pluginWorkspaceView = (PluginWorkspaceView) views [iView];

      PluginView pluginView = (PluginView) pluginWorkspaceView.getContent ();

      if (pluginView.getSource ().getSession () == session)
      {
        sessionViews.add (pluginWorkspaceView);
      }
    }

    return (PluginWorkspaceView []) sessionViews.toArray (new PluginWorkspaceView [0]);
  }

  public static void closeView (View view)
  {
    Workspace workspace = WorkspaceManager.getWorkspace (Browser.getActiveBrowser ());
    workspace.closeView (view);
  }
}
