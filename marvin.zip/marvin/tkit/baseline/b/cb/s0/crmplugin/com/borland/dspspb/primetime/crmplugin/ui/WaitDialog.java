package com.borland.dspspb.primetime.crmplugin.ui;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.event.*;

import com.borland.primetime.ui.*;
import com.borland.primetime.util.*;
import com.borland.dspspb.primetime.crmplugin.resources.ResourceManager;

public class WaitDialog extends DefaultDialog implements ActionListener
{
  private String m_text;
  private ImageIcon m_iconWaitClock = ResourceManager.getIcon (ResourceManager.WaitClock_icon);
  private JTextArea m_message = new MessageLabel(true)
  {
    public Dimension getPreferredSize()
    {
      Dimension d = super.getPreferredSize();
      d.width = Math.max(d.width, 250);
      return d;
    }
  };
  private ButtonStrip buttons = new ButtonStrip();
  private JButton cancelButton = buttons.createCancelButton(true);
  private boolean m_bCanceled = false;

  public WaitDialog(Component owner, String caption, String text)
  {
    super(owner, caption, true);

    m_text = text;
    m_text += "\n\nPress Cancel button to interrupt operation."; //RES WaitDialog_Press_Cancel_to_interrupt

    setDefaultCloseOperation(DISPOSE_ON_CLOSE);

    try
    {
      jbInit();
      pack();
    }
    catch (Exception ex)
    {
      ex.printStackTrace();
    }
  }

  protected void jbInit() throws Exception
  {
    JLabel label = new JLabel();
    label.setIcon(m_iconWaitClock);

    m_message.setText(m_text);
    m_message.setEditable(false);
    m_message.setBackground(label.getBackground());
    m_message.setForeground(label.getForeground());
    m_message.setFont(label.getFont());

    JComponent panel = (JComponent)getContentPane();

    panel.setBorder(Util.createDefaultEmptyBorder());
    panel.setLayout(new GridBagLayout());
    panel.add(label, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0,
                                              GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 0, 0));
    panel.add(m_message, new GridBagConstraints(1, 0, 1, 1, 0.0, 1.0,
                                              GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(0, 12, 0, 0), 0, 0));

    panel.add(buttons, new GridBagConstraints(0, 1, 2, 1, 0.0, 0.0,
                                              GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(12, 0, 0, 0), 0, 0));

    setSize(getPreferredSize());
    setResizable(false);

    setDefaultButton(cancelButton);
    cancelButton.addActionListener(this);
  }

  protected void closeDialog()
  {
    setVisible(false);
    dispose();
  }

  public void actionPerformed(ActionEvent e)
  {
    if (e.getSource() == cancelButton)
    {
      m_bCanceled = true;
      closeDialog();
    }
  }

  public boolean isCanceled()
  {
    return m_bCanceled;
  }
}
