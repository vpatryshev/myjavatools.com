package com.borland.dspspb.primetime.crmplugin.gui.actions.toolbar;

import javax.swing.JPanel;
import javax.swing.BoxLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JSeparator;
import java.awt.Dimension;
import javax.swing.border.Border;
import javax.swing.UIManager;
import javax.swing.SwingUtilities;
import javax.swing.AbstractButton;
import java.awt.Component;
import java.util.Vector;

public class ButtonPanel extends JPanel {
        public ButtonPanel() { this(HORIZONTAL); }

        public ButtonPanel(int align) {
            super();
            alignment = align;
            if (alignment == HORIZONTAL) {
                setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
            } else {
                setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
            }
            setBorder(BorderFactory.createCompoundBorder(BorderFactory.createEtchedBorder(), BorderFactory.createEmptyBorder(2,2,2,2)));
        }

        public void addButton(AbstractButton button) {
            add(button);
        }

        public void addSeparator() {
            add(new JSeparator(getSeparatorAlignment()){
                private Dimension dim = new Dimension(4,22);
                public Dimension getMaximumSize() {return dim;}
                public Dimension getMinimumSize() {return dim;}
                public Dimension getPreferredSize() {return dim;}
            });
        }

        private int getAlignment() {
            return alignment;
        }
        private int getSeparatorAlignment() {
            return alignment == HORIZONTAL ? VERTICAL : HORIZONTAL;
        }

        public void setBorder(Border border) {
            super.setBorder(BorderFactory.createCompoundBorder(
                                border,
                                BorderFactory.createEmptyBorder(1, 1, 1, 1)));
        }

        public void setBorder(int t, int l, int b, int r) {
            setBorder(BorderFactory.createMatteBorder(t, l, b, r, UIManager.getColor("controlShadow")));
        }

        public AbstractButton[] getButtons() {
            Component[] comps = super.getComponents();
            Vector buttons = new Vector();
            for(int i=0; i<comps.length; i++) {
                if(comps[i] instanceof AbstractButton) {
                    buttons.add(comps[i]);
                }
            }
            return (AbstractButton[])buttons.toArray(new AbstractButton[0]);
        }

        private int alignment;
        public static int HORIZONTAL = SwingUtilities.HORIZONTAL;
        public static int VERTICAL = SwingUtilities.VERTICAL;
}
