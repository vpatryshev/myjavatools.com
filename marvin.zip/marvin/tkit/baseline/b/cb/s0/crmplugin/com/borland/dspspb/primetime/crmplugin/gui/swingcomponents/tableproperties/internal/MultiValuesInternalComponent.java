package com.borland.dspspb.primetime.crmplugin.gui.swingcomponents.tableproperties.internal;

import java.util.Vector;
import java.awt.Component;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JButton;
import java.awt.Dimension;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import com.borland.dspspb.primetime.crmplugin.gui.swingcomponents.tableproperties.external.MultiStringDialog;

public class MultiValuesInternalComponent extends SwingInternalComponent {
    private Icon icon = new ImageIcon(getClass().getClassLoader().getResource("com/borland/dspspb/resources/images/ui/general.gif"));

  private Vector items = new Vector();

  public Vector getItems() { return items; }

  public String getRendererValue() {
    String val = "";
    Vector vals = getValues();
    for(int i=0; i<vals.size(); i++) {
      if(i != 0)val += ", ";
      val += (String)vals.get(i);
    }
    return val;
  }

  public MultiValuesInternalComponent(String name, String displayName) {
    super(name, displayName);
  }

  private JTextField tf = new JTextField();

  public Component getInternalRenderer() {
    JPanel panel = new JPanel(new BorderLayout());
    JLabel label = new JLabel(getRendererValue());
    label.setOpaque(true);
    panel.setBackground(tf.getBackground());
    panel.add( label, BorderLayout.CENTER );
    JButton btn = new JButton(icon);
    btn.setPreferredSize(new Dimension(22,22));
    btn.setEnabled(isEditable());
    panel.add( btn, BorderLayout.EAST);
    return panel;
  }

  public Component getInternalEditor() {
    JPanel panel = new JPanel(new BorderLayout());
    tf.setEditable( false );
    tf.setEnabled( false );
    panel.add( tf, BorderLayout.CENTER );
    JButton btn = new JButton(icon);
    btn.setPreferredSize(new Dimension(22,22));
    panel.add( btn, BorderLayout.EAST);
    btn.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent evt) {
                MultiStringDialog md = new MultiStringDialog(MultiValuesInternalComponent.this);
                md.show();
      }
    });
    btn.setEnabled( isEditable() );
    return panel;
  }

  public void updateUI() {
    tf.setText( getRendererValue() );
  }
  public void updateData() {	}

}
