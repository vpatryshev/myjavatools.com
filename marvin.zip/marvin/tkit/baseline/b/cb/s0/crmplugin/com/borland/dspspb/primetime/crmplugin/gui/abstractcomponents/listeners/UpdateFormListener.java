package com.borland.dspspb.primetime.crmplugin.gui.abstractcomponents.listeners;

import java.util.HashMap;

public interface UpdateFormListener {
    public void formUpdated (HashMap params );

}
