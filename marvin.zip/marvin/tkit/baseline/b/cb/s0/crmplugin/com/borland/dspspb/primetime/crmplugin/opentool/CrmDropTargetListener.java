package com.borland.dspspb.primetime.crmplugin.opentool;

import com.borland.dspspb.primetime.crmplugin.PluginManager;
import com.borland.dspspb.primetime.crmplugin.gui.treetable.TreeTableModelAdapter;
import com.borland.dspspb.primetime.crmplugin.view.rvtreetable.RVTreeTable;
import com.borland.dspspb.primetime.crmplugin.view.rvtreetable.RequirementNode;
import com.borland.primetime.ide.Browser;
import com.borland.primetime.node.Node;
import com.starbase.caliber.Requirement;
import com.starbase.caliber.Trace;
import com.starbase.caliber.external.xgeneric.XGenericObjectManager;

import java.awt.datatransfer.Transferable;
import java.awt.dnd.*;
import com.borland.dspspb.primetime.crmplugin.management.FramingManager;

public class CrmDropTargetListener implements DropTargetListener
{
  DropTarget m_dtOld = null;

  private static CrmDropTargetListener defaultListener = new CrmDropTargetListener(null);

  public CrmDropTargetListener(DropTarget dtOld)
  {
    m_dtOld = dtOld;
  }

  public static CrmDropTargetListener getDefault()
  {
    return defaultListener;
  }

// interface implementation ----------------------------------------------------

  public void dragEnter(DropTargetDragEvent dtde)
  {
    if (!isDragAcceptable(dtde))
    {
      if (m_dtOld != null)
        m_dtOld.dragEnter(dtde);
      else
        dtde.rejectDrag();
    }
  }

  public void dragOver(DropTargetDragEvent dtde)
  {
    if (!isDragAcceptable(dtde))
    {
      if (m_dtOld != null)
        m_dtOld.dragOver(dtde);
      else
      {
//        dtde.rejectDrag();
      }
    }
  }

  public void dropActionChanged(DropTargetDragEvent dtde)
  {
    if (!isDragAcceptable(dtde))
    {
      if (m_dtOld != null)
        m_dtOld.dropActionChanged(dtde);
      else
        dtde.rejectDrag();
    }
  }


  public void drop(DropTargetDropEvent dtde)
  {
    if (isDropAcceptable(dtde))
    {
      doDrop(dtde);
    }
    else
    {
      if (m_dtOld != null)
        m_dtOld.drop(dtde);
    }
  }

  public void dragExit(DropTargetEvent dte)
  {
    if (m_dtOld != null)
      m_dtOld.dragExit(dte);
  }

// drop target helpers ---------------------------------------------------------

  public static boolean isDragAcceptable(DropTargetDragEvent dtde)
  {
    int dropAction = dtde.getDropAction();
    return (dropAction == DnDConstants.ACTION_COPY || dropAction == DnDConstants.ACTION_MOVE) &&
      dtde.isDataFlavorSupported(RequirementNode.REQUIREMENT_FLAVOR);
  }

  public static boolean isDropAcceptable(DropTargetDropEvent dtde)
  {
    int dropAction = dtde.getDropAction();
    return (dropAction == DnDConstants.ACTION_COPY || dropAction == DnDConstants.ACTION_MOVE) &&
      dtde.isDataFlavorSupported(RequirementNode.REQUIREMENT_FLAVOR);
  }

  private void doDrop(DropTargetDropEvent dtde)
  {
    Browser activeBrowser = Browser.getActiveBrowser();
    Node activeNode = activeBrowser.getActiveNode();
    INodeSteward nodeSteward = NodeStewardsManager.findSteward(activeNode);
    if (nodeSteward == null)
    {
      dtde.rejectDrop();
      return;
    }

    Requirement requirement = PluginManager.getInstance().getView().getSelectedRequirement();
    String stewardId = nodeSteward.getId();
    String commentLocator = nodeSteward.getCommentLocator(activeNode, dtde.getLocation());
    if (commentLocator == null)
      return;

    RequirementNode requirementNode = (RequirementNode)PluginManager.getInstance().getView().getSelectedNode();
    try
    {
      XGenericObjectManager xgManager = requirement.getSession().getXGenericObjectManager();
      Trace traceToFile = xgManager.createFileTrace
        (requirement, true, stewardId, commentLocator);

      // Reloading of requirement is needed to obtain new version
      requirement = (Requirement)traceToFile.getFromObject();
      requirementNode.setRequirement(requirement);
    }
    catch (Exception e)
    {
      FramingManager.getInstance().showError("Cannot create comment: error while creating trace."); //RES CrmDropTargetListener_Failed_to_create_comment1
      dtde.rejectDrop();
      return;
    }

    try
    {
      Transferable transferable = dtde.getTransferable();
      Object transferData = transferable.getTransferData(RequirementNode.REQUIREMENT_FLAVOR);
      //      nodeSteward.doDrop(activeNode, (RequirementInfo)transferData, dtde.getLocation());
      nodeSteward.updateComment(commentLocator, (RequirementInfo)transferData);
    }
    catch (Exception e)
    {
      FramingManager.getInstance().showError("Cannot create comment: error while retrieving requirement info."); //RES CrmDropTargetListener_Failed_to_create_comment2
      dtde.rejectDrop();
      return;
    }

    // Update table view
    requirementNode.checkTraces(false);
    RVTreeTable table = PluginManager.getInstance().getView().getTable();
    int selectedRow = table.getSelectedRow();
    TreeTableModelAdapter model = (TreeTableModelAdapter)table.getModel();
    model.fireTableRowsUpdated(selectedRow, selectedRow);
    table.updateTracePanel(requirementNode);

    dtde.acceptDrop(DnDConstants.ACTION_COPY);
    dtde.dropComplete(true);
  }
}
