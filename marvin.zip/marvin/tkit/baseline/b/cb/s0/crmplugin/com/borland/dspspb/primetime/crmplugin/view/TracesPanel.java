package com.borland.dspspb.primetime.crmplugin.view;

import java.util.Vector;
import java.awt.*;

import javax.swing.*;

public class TracesPanel extends JPanel
{
  private TracePanelToolbar toolBar = null;
  private TraceTable table = null;

  public TracesPanel ()
  {
    setLayout(new BorderLayout());

    table = new TraceTable (new Vector(0));
    toolBar = new TracePanelToolbar (table);
    PluginToolbar.setHinter (toolBar);

		add (toolBar, BorderLayout.NORTH);
		add (new JScrollPane (table), BorderLayout.CENTER);
  }

  public TraceTable getTable ()
  {
    return table;
  }
}
