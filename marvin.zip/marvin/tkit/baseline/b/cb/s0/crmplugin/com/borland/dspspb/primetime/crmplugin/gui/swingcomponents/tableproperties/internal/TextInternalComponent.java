package com.borland.dspspb.primetime.crmplugin.gui.swingcomponents.tableproperties.internal;

import java.util.Vector;
import java.awt.Component;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Dimension;
import com.borland.dspspb.primetime.crmplugin.gui.swingcomponents.tableproperties.external.MultilineDialog;

public class TextInternalComponent extends SwingInternalComponent {
    private Icon icon = new ImageIcon(getClass().getClassLoader().getResource("com/borland/dspspb/resources/images/ui/multiline.gif"));

  public TextInternalComponent(String name, String displayName) {
    super(name, displayName);
    tf.addKeyListener(escapeListener);
    tf.addFocusListener(lostListener);
  }

  public String getInternalValue() {
    String value = (String)getValue();
    String intValue = ( value == null ? null : value.replace('\n',' ') );
    return intValue;
  }

  private JTextField tf = new JTextField();

  public Component getInternalRenderer() {
    JPanel panel = new JPanel(new BorderLayout());
    JLabel label = new JLabel(getInternalValue());
    if(!isEditable())label.setOpaque(true);
    panel.setBackground(tf.getBackground());
    panel.add( label, BorderLayout.CENTER );
    JButton btn = new JButton(icon);
    btn.setPreferredSize(new Dimension(22,22));
    btn.setEnabled(isEditable());
    panel.add( btn, BorderLayout.EAST);
    return panel;
  }

  public Component getInternalEditor() {
    JPanel panel = new JPanel(new BorderLayout());
    panel.add( tf, BorderLayout.CENTER );
    JButton btn = new JButton(icon);
    btn.setPreferredSize(new Dimension(22,22));
    panel.add( btn, BorderLayout.EAST);
    btn.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent evt) {
                MultilineDialog md = new MultilineDialog(TextInternalComponent.this);
                md.show();
      }
    });
    tf.setEditable( isEditable() );
    btn.setEnabled( isEditable() );
    return panel;
  }

  public void updateUI() {
    tf.setText( getInternalValue() );
  }

  public void updateData() {
    setValue( tf.getText() );
  }

}
