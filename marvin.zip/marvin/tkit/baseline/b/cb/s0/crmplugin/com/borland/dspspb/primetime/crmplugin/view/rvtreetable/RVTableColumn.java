package com.borland.dspspb.primetime.crmplugin.view.rvtreetable;

public class RVTableColumn
{
  private String name;
  private String displayName;

  // These names used as comment tags
  public static final String TCN_NAME = "_name"; //NORES
  public static final String TCN_TYPE = "_type"; //NORES
  public static final String TCN_VERSION = "_version"; //NORES
  public static final String TCN_OWNER = "_owner"; //NORES
  public static final String TCN_STATUS = "_status"; //NORES
  public static final String TCN_PRIORITY = "_priority"; //NORES
  public static final String TCN_DESCRIPTION = "_description"; //NORES
  public static final String TCN_SERVER = "_server"; //NORES
  public static final String TCN_PROJECTID = "_projectid"; //NORES
  public static final String TCN_PROJECTNAME = "_projectname"; //NORES
  public static final String TCN_BASELINEID = "_baselineid"; //NORES
  public static final String TCN_BASELINENAME = "_baselinename"; //NORES
  public static final String TCN_REQID = "_reqid"; //NORES

  public static String TCDN_NAME = "Name"; //RES RVTableColumn_Name_text
  public static String TCDN_TYPE = "Type"; //RES RVTableColumn_Type_text
  public static String TCDN_VERSION = "Version"; //RES RVTableColumn_Version_text
  public static String TCDN_OWNER = "Owner"; //RES RVTableColumn_Owner_text
  public static String TCDN_STATUS = "Status"; //RES RVTableColumn_Status_text
  public static String TCDN_PRIORITY = "Priority"; //RES RVTableColumn_Priority_text
  public static String TCDN_DESCRIPTION = "Description"; //RES RVTableColumn_Description_text
  public static String TCDN_SERVER = "Server"; //RES RVTableColumn_Server_text
  public static String TCDN_PROJECTID = "Project ID"; //RES RVTableColumn_ProjectId_text
  public static String TCDN_PROJECTNAME = "Project Name"; //RES RVTableColumn_ProjectName_text
  public static String TCDN_BASELINEID = "Baseline ID"; //RES RVTableColumn_BaselineId_text
  public static String TCDN_BASELINENAME = "Baseline Name"; //RES RVTableColumn_BaselineName_text
  public static String TCDN_REQID = "Requirement ID"; //RES RVTableColumn_RequirementId_text

  public RVTableColumn(String name)
  {
    this(name, name);
  }

  public RVTableColumn(String name, String displayName)
  {
    this.name = name;
    this.displayName = displayName;
  }

  public void setName(String name)
  {
    this.name = name;
  }

  public void setDisplayName(String displayName)
  {
    this.displayName = displayName;
  }

  public String getName()
  {
    return name;
  }

  public String getDisplayName()
  {
    return displayName;
  }

//------------------------------------------------------------------------------

  public String toString()
  {
    return getDisplayName();
  }

  public boolean equals (Object object)
  {
    if (!(object instanceof RVTableColumn)) return false;

    RVTableColumn rvtc = (RVTableColumn) object;

    return this.displayName.equals (rvtc.getDisplayName());
  }
}
