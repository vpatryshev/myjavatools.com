package com.borland.dspspb.primetime.crmplugin.util.smartxml;

public interface Convertable
{
}
