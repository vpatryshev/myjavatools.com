package com.borland.dspspb.cbuilder.crmplugin.stewards;

public class CPPCommentLocator {

  public static final int FIELD_PROJECT = 0;
  public static final int FIELD_FILEPATH = 1;
  public static final int FIELD_CUSTOM = 2;

  protected int FIELDS_NUM = 3;

  private static final String FIELDS_DELIMITER = ":"; //NORES

  private String[] fieldValues = null;

  public CPPCommentLocator() {
    fieldValues = new String[FIELDS_NUM];
    for (int i = 0; i < FIELDS_NUM; i++) {
      fieldValues[i] = ""; //NORES
    }
  }

  public CPPCommentLocator(String commentLocator) {
    fieldValues = commentLocator.split(FIELDS_DELIMITER, FIELDS_NUM);
  }

  public String getFieldValue(int fieldIndex) {
    return fieldValues[fieldIndex];
  }

  public void setFieldValue(int fieldIndex, String fieldValue) {
    fieldValues[fieldIndex] = fieldValue;
  }

  public String toString() {
    StringBuffer buffer = new StringBuffer();

    for (int i = 0; i < FIELDS_NUM; i++) {
      buffer.append(fieldValues[i]);
      buffer.append(FIELDS_DELIMITER);
    }

    // Remove trailing delimiter
    buffer.deleteCharAt(buffer.length() - 1);

    return buffer.toString();
  }

  public void dump() {
    System.out.println("<< COMMENT LOCATOR:"); //NORES
    for (int i = 0; i < fieldValues.length; i++) {
      System.out.println("   [" + i + "]: " + fieldValues[i]); //NORES
    }
    System.out.println("COMMENT LOCATOR >>"); //NORES
  }
}
