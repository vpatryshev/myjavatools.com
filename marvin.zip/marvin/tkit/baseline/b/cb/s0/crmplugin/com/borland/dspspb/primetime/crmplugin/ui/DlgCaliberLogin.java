package com.borland.dspspb.primetime.crmplugin.ui;

import java.awt.*;
import java.awt.Image;
import javax.swing.*;
import javax.swing.border.*;

import com.borland.dspspb.primetime.crmplugin.dialog.*;
import com.borland.dspspb.primetime.crmplugin.management.*;
import com.borland.dspspb.primetime.crmplugin.resources.*;
import com.borland.primetime.ui.*;
import com.starbase.caliber.*;
import com.starbase.caliber.server.*;


public class DlgCaliberLogin extends PluginDialog
	implements DialogValidator
{
	private static final Point controlsOffset = new Point (101, 91);
	private static final ImageIcon
		bgImage = ResourceManager.getIcon (ResourceManager.DlgLogin_image);

	private JLabel lblHost = null;
	private JTextField txtHost = null;
	private JLabel lblUser = null;
	private JTextField txtUser = null;
	private JLabel lblPassword = null;
	private JPasswordField txtPassword = null;
	private JButton btnConnect = null;

	private Source source = null;
	private Session m_session = null;

	public DlgCaliberLogin (Component owner, Source source)
	{
		super (owner, "Login"); //RES DlgLogin_title

		this.source = source;
		setResizable (false);
		setStandard (false);
	}

	protected Dimension getMinimumDialogSize ()
	{
		return new Dimension (bgImage.getIconWidth (), bgImage.getIconHeight ());
	}

	public JComponent getContentUI ()
	{
		JPanel panel = new JPanel (new GridBagLayout ());

		panel.setOpaque (false);
		panel.setBorder (new BackgroundBorder (bgImage.getImage ()));

		JComponent controlsPanel = createControlsPanel ();

		GridBagConstraints c = new GridBagConstraints ();

		c.anchor = GridBagConstraints.NORTHWEST;
		c.gridx = 0;
		c.gridy = 0;
		c.weightx = 1.0;
		c.weighty = 1.0;
		c.fill = GridBagConstraints.NONE;

		int offsetx = (getMinimumDialogSize ().width - controlsPanel.getPreferredSize ().width) / 2;
		c.insets = new Insets (controlsOffset.y, offsetx, 0, 0);
		panel.add (controlsPanel, c);

		return panel;
	}

	private JComponent createControlsPanel ()
	{
		JPanel panel = new JPanel (new GridBagLayout ());
		panel.setOpaque (false);

		lblHost = new JLabel ("Host:"); //RES DlgLogin_Host_text
		txtHost = new JTextField (17);
		lblUser = new JLabel ("User:"); //RES DlgLogin_User_text
		txtUser = new JTextField ();
		lblPassword = new JLabel ("Password:"); //RES DlgLogin_Password_text
		txtPassword = new JPasswordField ();
		btnConnect = new JButton ("Connect"); //RES DlgLogin_Connect_text

		lblHost.setDisplayedMnemonic ('H'); //RES DlgLogin_Host_mnemonic
		lblHost.setLabelFor (txtHost);
		lblUser.setDisplayedMnemonic ('U'); //RES DlgLogin_User_mnemonic
		lblUser.setLabelFor (txtUser);
		lblPassword.setDisplayedMnemonic ('P'); //RES DlgLogin_Password_mnemonic
		lblPassword.setLabelFor (txtPassword);

		GridBagConstraints c = new GridBagConstraints ();
		Insets labelInsets = new Insets (3, 0, 0, 27);
		Insets textInsets = new Insets (0, 0, 3, 0);

		// Host
		c.anchor = GridBagConstraints.NORTHWEST;
		c.gridx = 0;
		c.gridy = 0;
		c.weightx = 0.0;
		c.weighty = 0.0;
		c.fill = GridBagConstraints.NONE;
		c.insets = labelInsets;
		panel.add (lblHost, c);

		c.gridx = 1;
		c.gridy = 0;
		c.weightx = 1.0;
		c.weighty = 0.0;
		c.insets = textInsets;
		c.fill = GridBagConstraints.NONE;
		panel.add (txtHost, c);

		// User
		c.gridx = 0;
		c.gridy = 1;
		c.weightx = 0.0;
		c.weighty = 0.0;
		c.fill = GridBagConstraints.NONE;
		c.insets = labelInsets;
		panel.add (lblUser, c);

		c.gridx = 1;
		c.gridy = 1;
		c.weightx = 1.0;
		c.weighty = 0.0;
		c.insets = textInsets;
		c.fill = GridBagConstraints.HORIZONTAL;
		panel.add (txtUser, c);

		// Password
		c.gridx = 0;
		c.gridy = 2;
		c.weightx = 0.0;
		c.weighty = 0.0;
		c.fill = GridBagConstraints.NONE;
		c.insets = labelInsets;
		panel.add (lblPassword, c);

		c.gridx = 1;
		c.gridy = 2;
		c.gridwidth = 1;
		c.gridheight = 1;
		c.weightx = 1.0;
		c.weighty = 0.0;
		c.insets = textInsets;
		c.fill = GridBagConstraints.HORIZONTAL;
		panel.add (txtPassword, c);

		// Connect
		c.anchor = GridBagConstraints.EAST;
		c.gridx = 1;
		c.gridy = 3;
		c.gridwidth = 1;
		c.gridheight = 1;
		c.weightx = 1.0;
		c.weighty = 1.0;
		c.insets = textInsets;
		c.fill = GridBagConstraints.NONE;
		panel.add (btnConnect, c);

		initControls ();

		return panel;
	}

// -----------------------------------------------------------------------------

	private void initControls ()
	{
		txtHost.setText (source.getServer ());
		txtHost.setEditable (false);
		txtHost.setFocusable (false);

		txtUser.setText (source.getLogin ());
		txtUser.selectAll ();

		setDefaultButton (btnConnect);

		// Trick for binding "Escape" key to dialog cancel action
		setCancelButton (new JButton ());
	}

// -----------------------------------------------------------------------------
// DialogValidator implementation

	public boolean validateDialog ()
	{
		String strUser = txtUser.getText ().trim ();

		if (strUser.length () == 0)
		{
			txtUser.setText (""); //NORES
			showValidationMessage ("User login name is empty.", txtUser); //RES DlgLogin_EmptyLoginName
			return false;
		}

		// Data OK. Do login
		if (doLogin ())
		{
			updateData ();
			return true;
		}

		return false;
	}

// -----------------------------------------------------------------------------

	private void updateData ()
	{
		source.setLogin (txtUser.getText ().trim ());
		source.setSession (m_session);
	}

// -----------------------------------------------------------------------------

	private boolean doLogin ()
	{
		String strHost = txtHost.getText ().trim ();
		String strser = txtUser.getText ().trim ();
		String strPassword = new String (txtPassword.getPassword ());

		Cursor currentCursor = getCursor ();
		setCursor (Cursor.getPredefinedCursor (Cursor.WAIT_CURSOR));

		CaliberServer server = new CaliberServer (strHost);
		String failReason = ""; //NORES

		try
		{
			m_session = server.login (strser, strPassword);
		}
		catch (InvalidLoginException ex)
		{
			failReason = "Invalid user id or password has been entered."; //RES DlgLogin_InvalidLoginException
		}
		catch (AccountDisabledException ex)
		{
			failReason = "User's account has been disabled by the administrator."; //RES DlgLogin_AccountDisabledException
		}
		catch (LicenseExpirationException ex)
		{
			failReason = "The license on the remote Caliber server has expired."; //RES DlgLogin_LicenseExpirationException
		}
		catch (NoAvailableLicenseException ex)
		{
			failReason = "All available floating licenses on the CaliberRM server are in use."; //RES DlgLogin_NoAvailableLicenseException
		}
		catch (PasswordExpiredException ex)
		{
			failReason = "The current user's password has expired."; //RES DlgLogin_PasswordExpiredException
		}
		catch (UserMustChangePasswordException ex)
		{
			failReason = "User must change password in order to login to the system."; //RES DlgLogin_UserMustChangePasswordException
		}
		catch (RemoteServerException ex)
		{
			failReason = "Server exception occurred. Please verify that the server is running and accessible."; //RES DlgLogin_RemoteServerException
		}
		catch (Exception ex)
		{
			failReason = "Exception occurred. Please verify that the server is running and accessible."; //RES DlgLogin_AnyOtherException
		}
		finally
		{
			setCursor (currentCursor);
		}

		if (m_session == null)
		{
			String failMessage =
				"Failed to connect to server " + //RES DlgLogin_ConnectionFailed
				strHost + "." + //NORES
				"\n" + failReason; //NORES
			FramingManager.getInstance ().showError (this, failMessage);
			txtUser.requestFocus ();
			return false;
		}
    else
    {
      source.savePassword(strPassword);
    }


		return m_session != null;
	}

// -----------------------------------------------------------------------------
// This Border class draws image as a component background

	private class BackgroundBorder
		implements Border
	{
		private Image image = null;

		public BackgroundBorder (Image image)
		{
			this.image = image;
		}

		public void paintBorder (Component c, Graphics g, int x, int y, int width, int height)
		{
			g.drawImage (image, 0, 0, null);
		}

		public Insets getBorderInsets (Component c)
		{
			return new Insets (0, 0, 0, 0);
		}

		public boolean isBorderOpaque ()
		{
			return true;
		}
	}

// -----------------------------------------------------------------------------

	public class LogonThread extends Thread
	{
		private boolean m_bInterrupted = false;

		public void run ()
		{
			String strHost = txtHost.getText ().trim ();
			String strUser = txtUser.getText ().trim ();
			String strPassword = new String (txtPassword.getPassword ());

			try
			{
				CaliberServer server = new CaliberServer (strHost);
				m_session = server.login (strUser, strPassword);
			}
			catch (RemoteServerException ex)
			{
				m_session = null;
				if (!isInterrupted ())
				{
					String message = "Failed to connect to server " + strHost + ".";  //RES DlgLogin_ConnectionFailed,NORES

					if (ex.getMessage () != null)
						message += "\n\n" + ex.getLocalizedMessage (); //NORES

					JOptionPane.showMessageDialog
						(null, message,
						 "Connection Error", //RES DlgLogin_ConnectionError
						 JOptionPane.ERROR_MESSAGE);

//          DlgLogin.this.showWaitCursor(false);
					return;
				}
			}
			if (isInterrupted ())
			{
				if (m_session != null)
					m_session.logout ();
				m_session = null;
			}
			else
			{
//        doOk();
			}
//      DlgLogin.this.showWaitCursor(false);
		}

		public void cancel ()
		{
			// interrupt();
			if (m_session != null)
				m_session.logout ();
			m_session = null;
			stop ();
		}

		public boolean isInterrupted ()
		{
			return m_bInterrupted;
		}

		public void interruptThread ()
		{
			m_bInterrupted = true;
		}
	}

	public class WrapperLogonThread extends Thread
	{
		private LogonThread m_logonThread;

		public WrapperLogonThread (LogonThread logonThread)
		{
			m_logonThread = logonThread;
		}

		public void run ()
		{
			m_logonThread.start ();
			while (!m_logonThread.isInterrupted () && m_logonThread.isAlive ())
			{
				try
				{
					Thread.sleep (300);
				}
				catch (InterruptedException e)
				{
				}
			}
			if (m_logonThread.isInterrupted ())
				m_logonThread.cancel ();
		}
	}
}
