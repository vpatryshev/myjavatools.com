package com.borland.dspspb.primetime.crmplugin.view;

import java.util.*;

import java.awt.*;
import javax.swing.*;

import com.borland.dspspb.primetime.crmplugin.*;
import com.borland.dspspb.primetime.crmplugin.management.*;
import com.borland.dspspb.primetime.crmplugin.view.rvtreetable.*;
import com.borland.dspspb.primetime.crmplugin.gui.treetable.*;
import com.starbase.caliber.Requirement;


public class PluginView extends JPanel
{
  private PluginToolbar pluginToolbar = null;

  private JSplitPane reqPanel = null;
  private JScrollPane reqTablePane = null;
  private RVTreeTable reqTable = null;
  private DetailsPanel reqDetails = null;

  public PluginView ()
  {
  }

  public void init ()
  {
    setLayout (new BorderLayout ());

    // Create toolbar
    pluginToolbar = new PluginToolbar (this);
    PluginToolbar.setHinter (pluginToolbar);

    add (pluginToolbar, BorderLayout.WEST); // Use with vertical toolbar

    // Create details panel
    reqDetails = new DetailsPanel ();

    // Create empty table for initial view
    reqTable = createReqTable ();
    reqTablePane = new JScrollPane (reqTable);
    reqTablePane.setRowHeaderView (new RowHeaderView (reqTable));

    reqPanel = new JSplitPane (JSplitPane.HORIZONTAL_SPLIT, reqTablePane, reqDetails);
    reqPanel.setContinuousLayout (true);
    reqPanel.setDividerLocation (550);

    add (reqPanel, BorderLayout.CENTER);
  }

  private RVTreeTable createReqTable ()
  {
    TableNodeAdapter emptyRoot = new TableNodeAdapter ("<empty root>"); //NORES
    Vector defaultColumns = PluginManager.getDefaultColumns();
    RVTreeTableModel tableModel = new RVTreeTableModel (emptyRoot, defaultColumns);
    RVTreeTable table = new RVTreeTable (this, tableModel);

    return table;
  }

// -----------------------------------------------------------------------------
// Show/hide details panel

  public void setDetailsVisible (boolean bVisible)
  {
    if (bVisible)
    {
      reqPanel.setBottomComponent (reqDetails);
      reqPanel.setDividerLocation (reqPanel.getLastDividerLocation());
    }
    else
    {
      reqPanel.setLastDividerLocation (reqPanel.getDividerLocation ());
      reqPanel.setBottomComponent (null);
    }
  }

  public boolean isDetailsVisible ()
  {
    return (reqPanel.getBottomComponent () == reqDetails);
  }

  public DetailsPanel getDetailsPanel()
  {
    return reqDetails;
  }

  public DescriptionPanel getDescriptionPanel()
  {
    if (getDetailsPanel() == null)
      return null;
    return getDetailsPanel().getDescriptionPanel();
  }

  public TracesPanel getTracesPanel()
  {
    if (getDetailsPanel() == null)
      return null;
    return getDetailsPanel().getTracesPanel();
  }

  public AttributesPanel getAttributesPanel()
  {
    if (getDetailsPanel() == null)
      return null;
    return getDetailsPanel().getAttributesPanel();
  }

  public void setVisibleTracesPanel (boolean bShow)
  {
    TracesPanel tracesPanel = getTracesPanel();
     Component [] childs = tracesPanel.getComponents();

     for (int i = 0; i < childs.length; i++)
     {
       childs [i].setVisible(bShow);
     }
  }

  public RVTreeTable getTable ()
  {
    return reqTable;
  }

  public TableNodeAdapter getSelectedNode()
  {
    RVTreeTable ttable = getTable();
    if (ttable == null)
      return null;
    return ttable.getSelectedNode ();
  }

  public Requirement getSelectedRequirement()
  {
    TableNodeAdapter selectedNode = getSelectedNode ();
    if (selectedNode == null || !(selectedNode instanceof RequirementNode))
      return null;
    return ((RequirementNode)selectedNode).getRequirement();
  }

//------------------------------------------------------------------------------

  public Source getSource()
  {
    if (reqTable != null)
      return reqTable.getSource();
    return null;
  }

  public void runSource(Source source)
  {
    reqTable.runSource(source);
  }

  public void showRequirementNode(int requirementIDNumber)
  {
    reqTable.showRequirementNode(requirementIDNumber);
  }

// -----------------------------------------------------------------------------

  private boolean bHierarchicalNumbers = false;
  private boolean bSerialNumbers = false;

	public void setHierarchicalNumbers (boolean state)
	{
    bHierarchicalNumbers = state;
	}

  public boolean isHierarchicalNumbers ()
  {
    return bHierarchicalNumbers;
  }

	public void setSerialNumbers (boolean state)
	{
    bSerialNumbers = state;
	}

  public boolean isSerialNumbers ()
  {
    return bSerialNumbers;
  }
}
