package com.borland.dspspb.primetime.crmplugin.filter;

public class Field
{
  public static final String TYPE_UNKNOWN = "unknown"; //NORES
  public static final String TYPE_STRING  = "string";  //NORES
  public static final String TYPE_TEXT    = "text";    //NORES
  public static final String TYPE_DATE    = "date";    //NORES
  public static final String TYPE_INT     = "int";     //NORES
  public static final String TYPE_VERSION = "version"; //NORES
  public static final String TYPE_BOOL    = "bool";    //NORES
  public static final String TYPE_ENUM    = "enum";    //NORES
  public static final String TYPE_USER    = "user";    //NORES

  public static final Field UNKNOWN = new Field("", TYPE_UNKNOWN, ""); //NORES

  private String m_id;
  private String m_type;
  private String m_name;

  public Field()
  {
  }

  public Field(String id, String type, String name)
  {
    m_id = id;
    m_type = type;
    m_name = name;
  }

  public String getId()
  {
    return m_id;
  }

  public void setId(String id)
  {
    m_id = id;
  }

  public String getType()
  {
    return m_type;
  }

  public void setType(String type)
  {
    m_type = type;
  }

  public String getName()
  {
    return m_name;
  }

  public void setName(String name)
  {
    m_name = name;
  }

//------------------------------------------------------------------------------

  public String toString()
  {
    return getName();
  }
}
