package com.borland.dspspb.primetime.crmplugin.actions;

import java.io.*;

import java.awt.event.*;

import com.borland.dspspb.primetime.crmplugin.management.*;
import com.borland.dspspb.primetime.crmplugin.resources.*;
import com.borland.dspspb.primetime.crmplugin.view.*;
import com.starbase.caliber.*;
import com.starbase.caliber.server.*;
import javax.swing.JOptionPane;
import com.borland.dspspb.primetime.crmplugin.util.CRMExtChk;

public class ActionRunCaliberRMClient extends PluginUpdateAction
{
  public ActionRunCaliberRMClient()
  {
    super
      ("Launch CaliberRM Viewer", //RES ActionRunCaliberRMClient_shorttext
       "Launch CaliberRM Requirement Viewer", //RES ActionRunCaliberRMClient_longtext
       ResourceManager.ActionRunCaliberRMClient_icon);
  }

  public void update (Object object)
  {
    PluginView pluginView = (PluginView) object;
    setEnabled (pluginView.getSelectedRequirement() != null);
  }

  native boolean checkCRM(String strCRMKey);

  public void actionPerformed(ActionEvent e)
  {
    boolean bCRMViewerInstalled = CRMExtChk.isExtRegistered(".crm"); //NORES
    if (!bCRMViewerInstalled)
    {
      int confirmResult = FramingManager.getInstance().showConfirm(
        "CaliberRM Requirement Viewer is not installed properly.\nDo you wish to continue?"); //RES ActionRunCaliberRMClient_Viewer_not_installed_text
      if (confirmResult != JOptionPane.OK_OPTION)
        return;
    }

    PluginView pluginView = (PluginView)e.getSource();
    Source source = pluginView.getSource();
    Requirement requirement = pluginView.getSelectedRequirement();
    int projectId = 0;
    try
    {
      projectId = requirement.getProject().getID().getIDNumber();
    }
    catch (RemoteServerException rse)
    {
      FramingManager.getInstance().showError(
        "Failed to launch CaliberRM Viewer." + //RES ActionRunCaliberRMClient_Failed1_text
        "\n" + //NORES
        "Error while retrieving requirement info."); //RES ActionRunCaliberRMClient_Error_to_get_info
      return;
    }
    String tmpDirName = System.getProperty("java.io.tmpdir"); //NORES
    File tmpdir = new File(tmpDirName);
    String[] crmfilenames = tmpdir.list(new FilenameFilter()
    {
      public boolean accept(File dir, String name)
      {
        return name.endsWith(".crm");
      }
    });
    for (int i = 0; i < crmfilenames.length; i++)
    {
      File crmfile = new File(tmpdir, crmfilenames[i]);
      crmfile.delete();
    }
    int requirementId = requirement.getID().getIDNumber();
    StringBuffer sbParams = new StringBuffer();
    sbParams.append(source.getServer().length() > 0 ? source.getServer() : requirement.getSession().getCaliberServer().getHost());
    sbParams.append(','); //NORES
    sbParams.append(projectId);
    sbParams.append(','); //NORES
    sbParams.append(requirementId);
    String tmpFileName = tmpDirName + "CRM_" + projectId + "_" + requirementId + ".crm"; //NORES
    BufferedWriter bw = null;
    try
    {
      FileWriter fw = new FileWriter(tmpFileName);
      bw = new BufferedWriter(fw);
      bw.write(sbParams.toString());
      bw.close();
    }
    catch (IOException ioe)
    {
      FramingManager.getInstance().showError(
        "Failed to launch CaliberRM Viewer." + //RES ActionRunCaliberRMClient_Failed1_text
        "\n" + //NORES
        "Error while creating temporary file for viewer."); //RES ActionRunCaliberRMClient_Error_to_create_file
      return;
    }

    String url = "file://" + tmpFileName; //NORES
    try
    {
      BrowserLauncher.openURL(url);
    }
    catch (IOException ex)
    {
      FramingManager.getInstance().showError(
        "\n" + //NORES
        ex.getMessage()); //RES ActionRunCaliberRMClient_Error_to_create_file
      return;
    }
  }
}
