package com.borland.dspspb.primetime.crmplugin.management;

import com.borland.dspspb.primetime.crmplugin.util.smartxml.Convertable;
import com.starbase.caliber.Session;

 public class Source implements Cloneable, Convertable
{
  private String m_id = ""; //NORES
  private String m_name	= ""; //NORES
  private String m_description = ""; //NORES
  private String m_server = ""; //NORES
  private String m_projectid = ""; //NORES
  private String m_baselineid = ""; //NORES
  private String m_filterid = ""; //NORES

  private String m_projectname = ""; //NORES
  private String m_baselinename = ""; //NORES

  transient private String login = ""; //NORES
  transient private String password	= ""; //NORES

  public Source()
  {
    m_id = SourceManager.generateId();
  }

  public Source (String name, String server)
  {
    this();
    this.m_name = name;
    this.m_server = server;
  }

// -----------------------------------------------------------------------------

  public String getId ()
  {
    return m_id;
  }

  public String getName ()
  {
    return m_name;
  }

  public String getDescription ()
  {
    return m_description;
  }

  public String getServer ()
  {
    return m_server;
  }

  public String getProjectId ()
  {
    return m_projectid;
  }

  public String getBaselineId ()
  {
    return m_baselineid;
  }

  public String getFilterId ()
  {
    return m_filterid;
  }

  public void setId (String id)
  {
    this.m_id = id;
  }

  public void setName (String name)
  {
    this.m_name = name;
  }

  public void setDescription (String description)
  {
    this.m_description = description;
  }

  public void setServer (String server)
  {
    this.m_server = server;
  }

  public void setProjectId (String projectid)
  {
    this.m_projectid = projectid;
  }

  public void setBaselineId (String baselineid)
  {
    this.m_baselineid = baselineid;
  }

  public void setFilterId (String filterid)
  {
    this.m_filterid = filterid;
  }

//------------------------------------------------------------------------------

  public String getLogin ()
  {
    return login;
  }

  public String loadPassword ()
  {
    return password;
  }

  public void setLogin (String login)
  {
    this.login = login;
  }

  public void savePassword (String password)
  {
    this.password = password;
  }

//------------------------------------------------------------------------------

  public String getProjectName ()
  {
    return m_projectname;
  }

  public void setProjectName (String name)
  {
    m_projectname = name;
  }

  public String getBaselineName ()
  {
    return m_baselinename;
  }

  public void setBaselineName (String name)
  {
    m_baselinename = name;
  }

//------------------------------------------------------------------------------

  public String getFilename()
  {
    String fileName = Utils.convertToFilename (m_name);
    return fileName + ".xml"; //NORES
  }

  public Object clone()
  {
    Source other = new Source();
    other.setId(this.getId());
    other.setName(this.getName());
    other.setDescription(this.getDescription());
    other.setServer(this.getServer());
    other.setProjectId(this.getProjectId());
    other.setBaselineId(this.getBaselineId());
    other.setFilterId(this.getFilterId());
    other.savePassword(this.loadPassword());
    other.setLogin(this.getLogin());
    other.setProjectName(this.getProjectName());
    other.setBaselineName(this.getBaselineName());

    return other;
  }

  public String toString()
  {
    return m_name;
  }

//------------------------------------------------------------------------------

  public Session getSession()
  {
    return SessionManager.getInstance().getSession(this);
  }

  public void setSession(Session session)
  {
    SessionManager.getInstance().setSession(this, session);
  }
}
