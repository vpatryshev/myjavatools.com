package com.borland.dspspb.primetime.crmplugin.actions;

import com.borland.dspspb.primetime.crmplugin.resources.*;
import com.borland.dspspb.primetime.crmplugin.view.*;

public class ActionSerialNumbers extends PluginStateAction
{
	public ActionSerialNumbers ()
	{
    super
      ("Serial Numbers", //RES ActionSerialNumbers_shorttext
       "Show/hide requirements' serial numbers", //RES ActionSerialNumbers_longtext
       ResourceManager.ActionSerialNumbers_icon);
	}

	public boolean getState (Object object)
	{
    PluginView pluginView = (PluginView) object;

    return pluginView.isSerialNumbers ();
	}

	public void setState (Object object, boolean state)
	{
    PluginView pluginView = (PluginView) object;

    pluginView.setSerialNumbers (state);
    pluginView.getTable ().updateUI ();
	}
}
