package com.borland.dspspb.primetime.crmplugin.gui.swingcomponents;

import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JButton;
import com.borland.dspspb.primetime.crmplugin.gui.abstractcomponents.AbstractViewComponent;
import com.borland.dspspb.primetime.crmplugin.gui.actions.toolbar.ButtonPanel;

public class SwingStatePanel extends AbstractViewComponent
{
    private JPanel mainPanel = new JPanel();
    private ButtonPanel buttonPanel = new ButtonPanel();

    public SwingStatePanel(String title)
    {
        mainPanel.setLayout( new BorderLayout() );
        mainPanel.add(new JLabel(title),BorderLayout.WEST );
    }

    public void addButton( JButton button )
    {
        buttonPanel.add( button );
    }

    public Object getUI()
    {
        mainPanel.add (buttonPanel, BorderLayout.CENTER);
        return mainPanel;
    }

}
