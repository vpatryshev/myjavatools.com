package com.borland.dspspb.primetime.crmplugin.gui.swingcomponents;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.Iterator;
import com.borland.dspspb.primetime.crmplugin.gui.abstractcomponents.AbstractChoiceComponent;
import java.util.Collection;
import java.util.Vector;
import java.util.Enumeration;
import com.borland.dspspb.primetime.crmplugin.gui.actions.toolbar.ButtonPanel;

public class SwingMultiChoice1  extends AbstractChoiceComponent
{
    private JPanel internalPanel = new JPanel();
    private JPanel mainPanel = new JPanel();
    private JScrollPane scrollPane = new JScrollPane(internalPanel);
    private JLabel displayNameLabel = new JLabel();
    private String displayName;
    private ButtonPanel buttonPanel = new ButtonPanel(ButtonPanel.HORIZONTAL);

    public SwingMultiChoice1(String name,String displayName )
    {
        setName ( name );
        this.displayName = displayName;
        displayNameLabel.setFont( new Font("Arial",Font.BOLD,12 ) );
        mainPanel.setLayout( new BorderLayout() );
        mainPanel.add( scrollPane,BorderLayout.CENTER );
        mainPanel.add( displayNameLabel,BorderLayout.NORTH );
        internalPanel.setLayout( new BorderLayout() );
        JPanel dumbPanel = new JPanel();
        dumbPanel.setBackground( Color.white );
        internalPanel.add(dumbPanel,BorderLayout.CENTER);
        internalPanel.setBackground( Color.white );
    }

    public Vector getValues()
    {
       Vector values = super.getValues();
       AbstractButton[] buttons = buttonPanel.getButtons();
       for(int i=0; i<buttons.length; i++) {
           JCheckBox box = (JCheckBox)buttons[i];
           if(box.isSelected() && !values.contains(box.getText()))values.add(box.getText());
           if(!box.isSelected())values.remove(box.getText());
       }
       values.remove( null );
       return values;
    }

    public Object getUI()
    {
       if(isMandatory()) displayNameLabel.setText("(*) "+displayName);
       else displayNameLabel.setText (displayName );
       Iterator i = this.getChoiceValues().iterator();
       int size = 0;
       while(i.hasNext())
       {
           String text = (String)i.next();
           JCheckBox cb = new JCheckBox(text);
           cb.setBorder( BorderFactory.createEmptyBorder(0,6,0,0) );
           cb.setBackground( Color.white );
           if ( this.getValues().contains(text ) ) cb.setSelected( true );
           buttonPanel.add( cb );
           size++;
       }
       scrollPane.setPreferredSize(new Dimension(100,100));
       internalPanel.add(buttonPanel, BorderLayout.NORTH);
       return mainPanel;
    }
}
