package com.borland.dspspb.primetime.crmplugin.view.rvtreetable;

import java.awt.*;
import javax.swing.*;

import com.borland.dspspb.primetime.crmplugin.gui.treetable.TableNodeAdapter;
import com.borland.dspspb.primetime.crmplugin.resources.ResourceManager;
import com.starbase.caliber.*;


public class ProjectNode extends TableNodeAdapter
{
  private static Color reqBackground				= new Color (213, 230, 234);
  private static Color reqForeground				= Color.black;

  private static ImageIcon iconOpened	= null;
  private static ImageIcon iconClosed	= null;

  private Project m_project = null;
  private Baseline m_baseline = null;

  // Load icons
  static
  {
    iconOpened = ResourceManager.getIcon(ResourceManager.ProjectNode_Opened_icon);
    iconClosed = ResourceManager.getIcon(ResourceManager.ProjectNode_Closed_icon);
  }

  public ProjectNode (Object data)
  {
    super (data);
  }

  public Color getBackground ()
  {
    return reqBackground;
  }

  public Color getForeground ()
  {
    return reqForeground;
  }

  public int getFontStyle ()
  {
    return Font.BOLD;
  }

  public Icon getIcon (boolean bExpanded)
  {
    return (bExpanded ? iconOpened : iconClosed);
  }

  public void setProject(Project project)
  {
    m_project = project;
  }

  public Project getProject()
  {
    return m_project;
  }

  public void setBaseline(Baseline baseline)
  {
    m_baseline = baseline;
  }

  public Baseline getBaseline()
  {
    return m_baseline;
  }


  public String getText ()
  {
    if (getProject() != null)
    {
      if (getBaseline() != null)
      {
        StringBuffer buffer = new StringBuffer();
        buffer.append(getProject().getName());
        buffer.append(" ("); //NORES
        buffer.append(getBaseline().getName());
        buffer.append(')'); //NORES
        return buffer.toString();
      }
      return getProject().getName();
    }
    return ""; //NORES
  }

  public String getToolTipText ()
  {
    return getText();
  }
}
