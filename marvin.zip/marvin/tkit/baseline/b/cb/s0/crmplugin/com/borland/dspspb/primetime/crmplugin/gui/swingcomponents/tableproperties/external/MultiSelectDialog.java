package com.borland.dspspb.primetime.crmplugin.gui.swingcomponents.tableproperties.external;

import javax.swing.JComponent;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import java.awt.Dimension;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.util.Vector;
import com.borland.dspspb.primetime.crmplugin.gui.dialogs.AdrenalinDialog;
import javax.swing.JPanel;
import com.borland.dspspb.primetime.crmplugin.gui.swingcomponents.tableproperties.internal.MultiChoiceInternalComponent;

public class MultiSelectDialog extends AdrenalinDialog {
  private MultiChoiceInternalComponent comp;
  private JTable table;
  private MSTableModel tm;

  public MultiSelectDialog(MultiChoiceInternalComponent comp) {
        super(null);
    this.comp = comp;
    super.setTitle( comp.getDisplayName() );
  }

    public JPanel createContentPane() {
    Vector allVals = comp.getItems();
    Vector selVals = comp.getValues();
    tm = new MSTableModel( allVals, selVals );
    table = new JTable( tm );
        JPanel mainPanel = new JPanel();
    JScrollPane jsp = new JScrollPane(table);
        mainPanel.add(jsp);
        return mainPanel;
  }


    public void doOk() {
        comp.setValues( tm.getSelectedValues() );
        comp.updateUI();
        comp.getEditor().fireEditingStopped();
    }

    public void doCancel() {
        comp.getEditor().fireEditingCanceled();
    }

  public static class MSTableModel extends DefaultTableModel {
    private Vector allValues;
    private Vector selValues;

    public MSTableModel(Vector allValues, Vector selValues) {
      this.allValues = allValues;
      this.selValues = (Vector)selValues.clone();
    }

    public String getValue(int row) { return (String)allValues.get(row); }
    public boolean isSelected(int row) { return selValues.contains( getValue(row) ); }

    public Object getValueAt(int row, int col) {
      if(col == 0)return new Boolean(isSelected(row));
      else if(col == 1)return getValue(row);
      else return null;
    }

    public Vector getSelectedValues() { return selValues; }

    public void setValueAt(Object object, int row, int col) {
      boolean is = ((Boolean)object).booleanValue();
      if(is) {
        if(!isSelected(row))selValues.add(getValue(row));
      }else {
        selValues.remove(getValue(row));
      }
      fireTableDataChanged();
    }

    public String getColumnName(int col) {
      if(col==0)return " ";
      else if(col==1)return "Value";
      else return null;
    }

    public int getRowCount() {
      if(allValues == null)return 0;
      return allValues.size();
    }
    public int getColumnCount() { return 2; }
    public Class getColumnClass(int col) {
      return col == 0 ? Boolean.class : String.class;
    }
    public boolean isCellEditable(int row, int col) { return (col == 0); }
  }
}
