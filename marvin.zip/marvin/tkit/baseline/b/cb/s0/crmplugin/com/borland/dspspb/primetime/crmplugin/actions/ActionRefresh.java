package com.borland.dspspb.primetime.crmplugin.actions;

import java.util.*;

import java.awt.event.*;
import javax.swing.*;

import com.borland.dspspb.primetime.crmplugin.gui.treetable.*;
import com.borland.dspspb.primetime.crmplugin.resources.*;
import com.borland.dspspb.primetime.crmplugin.view.*;
import com.borland.dspspb.primetime.crmplugin.view.rvtreetable.*;
import com.starbase.caliber.*;
import com.borland.dspspb.primetime.crmplugin.management.ICaliberOperation;
import com.borland.dspspb.primetime.crmplugin.management.FramingManager;
import com.borland.dspspb.primetime.crmplugin.management.CaliberAccess;
import com.borland.dspspb.primetime.crmplugin.management.Source;
import com.starbase.caliber.server.*;
import java.lang.reflect.*;
import com.borland.dspspb.primetime.crmplugin.management.SessionManager;
import java.text.MessageFormat;

public class ActionRefresh extends PluginUpdateAction
{
  public ActionRefresh()
  {
    super
      ("Refresh", //RES ActionRefresh_shorttext
       "Refresh requirement table", //RES ActionRefresh_longtext
       ResourceManager.ActionRefresh_icon);
  }

  private void findExpandedIDs(JTree tree, TableNodeAdapter node, Vector expandedIDs)
  {
    Vector children = node.getChildren();
    for (int i = 0; i < children.size(); i++)
    {
      TableNodeAdapter childNode = (TableNodeAdapter)children.get(i);
      boolean isExpanded = true;

      if (childNode instanceof RequirementNode)
      {
        isExpanded = ((RequirementNode)childNode).isExpanded();
      }
      else if (childNode instanceof RequirementTypeNode)
      {
        isExpanded = ((RequirementTypeNode)childNode).isExpanded();
      }
      if (isExpanded)
      {
        if ((childNode instanceof RequirementTypeNode) || (childNode instanceof RequirementTypeNode))
        {
          CaliberObjectID expandedID = ((RequirementTreeNode)childNode.getUserObject()).getAssociatedObjectID();
          expandedIDs.add(new Integer(expandedID.getIDNumber()));
        }
        if (childNode.getChildCount() > 0)
          findExpandedIDs(tree, childNode, expandedIDs);
      }
    }
  }

  private int findSelectedID(RVTreeTable table)
  {
    TableNodeAdapter tableNode = table.getSelectedNode();
    if (!((tableNode instanceof RequirementTypeNode) || (tableNode instanceof RequirementNode)))
    {
      return -1;
    }
    return ((RequirementTreeNode)(tableNode.getUserObject())).getAssociatedObjectID().getIDNumber();
  }

  private void findNodesToExpand(TableNodeAdapter node, Vector expandedIDs, Vector nodesToExpand)
  {
    Vector children = node.getChildren();
    for (int i = 0; i < children.size(); i++)
    {
      TableNodeAdapter childNode = (TableNodeAdapter)children.get(i);
      if ((childNode instanceof RequirementNode) || (childNode instanceof RequirementTypeNode))
      {
        CaliberObjectID objectID = ((RequirementTreeNode)childNode.getUserObject()).getAssociatedObjectID();
        if (expandedIDs.contains(new Integer(objectID.getIDNumber())))
        {
          nodesToExpand.add(childNode);
        }
      }
      if (childNode.getChildCount() > 0)
        findNodesToExpand(childNode, expandedIDs, nodesToExpand);
    }
  }

  public void actionPerformed(ActionEvent e)
  {
    PluginView pluginView = (PluginView)e.getSource();
    final RVTreeTable table = pluginView.getTable();
    ICaliberOperation operation = new ICaliberOperation()
    {
      boolean m_bResult = true;
      boolean m_bCanceled = false;
      Vector expandedIDs = new Vector();
      Vector nodesToExpand = new Vector();
      int selectedIDNumber = -1;
      Vector m_exceptionsCatched = new Vector();

      public void run()
      {
        FramingManager.showWaitCursor(true);
        final TableNodeAdapter rootNode = table.getRootNode();
        findExpandedIDs(table.getTree(), rootNode, expandedIDs);
        selectedIDNumber = findSelectedID(table);
        final Source source = table.getSource();
        if (table.isSourceFailed())
        {
//          m_bResult = false;
          Session session = null;
          CaliberServer server = new CaliberServer(source.getServer());
          for (int i = 0; i < 10; i++)
          {
            try
            {
              try
              {
                Thread.sleep(100);
              }
              catch (InterruptedException ex1)
              {
              }
              session = server.login(source.getLogin(), source.loadPassword());
              if (session == null)
                continue;
              source.setSession(session);
              table.setSourceFailed(false);
//              m_bResult = true;
              break;
            }
            catch (Exception ex)
            {
            }
            if (m_bCanceled)
            {
              m_bResult = true;
              return;
// ??? - to run source with (not connected) postfix
//              source.setSession(null);
//              break;
            }
          }
        }

       Session session = SessionManager.getInstance().getSession(source);
       RequirementTreeManager requirementTreeManager = (RequirementTreeManager)session.getManager(RequirementTree.class);
       requirementTreeManager.getCache().clear();

       table.rerunSource(source);
       if (m_bCanceled)
         return;

        if (expandedIDs.size() == 0)
          return;
        findNodesToExpand(rootNode, expandedIDs, nodesToExpand);
        if (nodesToExpand.size() == 0)
          return;

        table.getTree().removeTreeWillExpandListener(table);
        for (int i = nodesToExpand.size() - 1; i >= 0; i--)
        {
          if (m_bCanceled)
            break;
          TableNodeAdapter nodeToExpand = (TableNodeAdapter)nodesToExpand.get(i);
          Exception exceptionCatched = table.initRequirementSubtree(nodeToExpand);
          if (exceptionCatched != null)
            m_exceptionsCatched.add(exceptionCatched);
          table.expandNode(nodeToExpand);
          m_bResult = m_bResult && (exceptionCatched == null);
          nodesToExpand.remove(nodeToExpand);
        }
        table.getTree().addTreeWillExpandListener(table);
      }

      public boolean getResult()
      {
        return m_bResult;
      }

      public void setCanceled()
      {
        m_bCanceled = true;
      }

      public void onSuccess()
      {
        FramingManager.showWaitCursor(false);
        if (selectedIDNumber != -1)
          table.showRequirementNode(selectedIDNumber);
      }

      public void onError()
      {
        FramingManager.showWaitCursor(false);
        String failMessage =
          "Failed to get requirement(s) info from server" + //RES Failed_to_get_requirements_info
          " " + table.getSource().getServer() + "."; //NORES
        boolean bRemoteServerExceptionOccured = false;
        for (int i = 0; i < m_exceptionsCatched.size(); i++)
        {
          if (m_exceptionsCatched.get(i) instanceof RemoteServerException)
          {
            bRemoteServerExceptionOccured = true;
            break;
          }
        }
        if (bRemoteServerExceptionOccured)
        {
          failMessage += "\n"; //NORES
          failMessage += "Please verify that the server is running and accessible, then try to refresh view."; //RES Verify_server_then_refresh_view
        }
        else
        {
          int showCount = m_exceptionsCatched.size() > 6 ? 3 : m_exceptionsCatched.size();
          for (int i = 0; i < showCount; i++)
          {
            Exception exceptionCatched = (Exception)m_exceptionsCatched.get(i);
            String strExceptionMessage = MessageFormat.format("Exception {0} occurred: {1}", //RES Exception_class_occured_message
              new String[] {exceptionCatched.getClass().getName(), exceptionCatched.getLocalizedMessage()});
            failMessage += "\n"; //NORES
            failMessage += strExceptionMessage;
            if (m_exceptionsCatched.size() > 6)
            {
              failMessage += "\n"; //NORES
              failMessage += "..."; //NORES
              failMessage += "\n"; //NORES
              String strTotal = MessageFormat.format("Total number of exceptions occurred: {0}", //RES Total_number_of exceptions
                  new Integer[] {new Integer(m_exceptionsCatched.size())});
              failMessage += strTotal;
            }
          }
        }
        FramingManager.getInstance().showError(failMessage);
      }

      public void onCancel()
      {
        for (int i = 0; i < nodesToExpand.size(); i++)
        {
          TableNodeAdapter nodeToExpand = (TableNodeAdapter)nodesToExpand.get(i);
          nodeToExpand.removeAllChildren();
          nodeToExpand.add(new TableNodeAdapter("Operation aborted...") //RES TableNode_Operation_aborted
          {
            public Icon getIcon(boolean bExpanded)
            {
              return ResourceManager.getIcon(ResourceManager.ErrorCross_icon);
            }
          });
          table.expandNode(nodeToExpand);
        }
        FramingManager.showWaitCursor(false);
      }
    };

    CaliberAccess caliberAccess = new CaliberAccess(operation);
    caliberAccess.perform();
  }
}
