package com.borland.dspspb.primetime.crmplugin.opentool;

public class CommentStatus
{
  public static final int STATUS_UNKNOWN = -1;
  public static final int STATUS_CURRENT = 0;
  public static final int STATUS_OUTOFDATE = 1;
  public static final int STATUS_MISSING = 2;
  public static final int STATUS_NOTEXIST = 3;

  public static String getStatusDisplayName (int status)
	{
		switch (status)
		{
			case STATUS_CURRENT:
				return "Current"; //RES CommentStatus_Current
			case STATUS_OUTOFDATE:
				return "Out of Date"; //RES CommentStatus_OutOfDate
			case STATUS_MISSING:
				return "Missed"; //RES CommentStatus_Missed
			case STATUS_NOTEXIST:
				return "No File"; //RES CommentStatus_NoFile
			default:	return "Unknown"; //RES CommentStatus_Unknown
		}
	}
}
