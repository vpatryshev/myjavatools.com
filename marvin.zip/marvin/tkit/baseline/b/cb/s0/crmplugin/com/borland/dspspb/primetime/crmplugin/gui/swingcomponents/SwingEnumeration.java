package com.borland.dspspb.primetime.crmplugin.gui.swingcomponents;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.Iterator;
import com.borland.dspspb.primetime.crmplugin.gui.abstractcomponents.AbstractChoiceComponent;
import java.util.Collection;
import java.util.Vector;
import java.util.Enumeration;


public class SwingEnumeration  extends AbstractChoiceComponent
{
    private EnumerationPanel mainComponent;
    public SwingEnumeration(String name,String leftTitle  )
    {
        mainComponent = new EnumerationPanel(leftTitle );
        setName ( name );
    }

    public Vector getValues()
    {
       Vector values = super.getValues();
       Enumeration myEnum = mainComponent.getListModel().elements();
       while ( myEnum.hasMoreElements() )
     {
          values.add( myEnum.nextElement() );
       }
       values.remove( null );
       return values;
    }

    public Object getUI()
    {
       mainComponent.getListModel().clear();

       mainComponent.setPreferredSize(new Dimension(300,(int)mainComponent.getPreferredSize().getHeight() ));
       Iterator i = this.getChoiceValues().iterator();
       while ( i.hasNext() )
       {
            mainComponent.getListModel().addElement( i.next() );
       }
     return mainComponent;
    }
}
