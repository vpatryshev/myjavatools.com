package com.borland.dspspb.primetime.crmplugin.gui.swingcomponents.tableproperties.internal;

import java.util.Vector;
import java.awt.Component;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.event.FocusListener;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class StringInternalComponent extends SwingInternalComponent {

    public StringInternalComponent(String name, String displayName, String value) {
        this(name, displayName);
        setValue(value);
    }

  public StringInternalComponent(String name, String displayName) {
    super(name, displayName);
    tf.addKeyListener(escapeListener);
    tf.addFocusListener(lostListener);
  }

  private JTextField tf = new JTextField();

  public Component getInternalRenderer() {
    JLabel label = new JLabel((String)getValue());
    if(!isEditable())label.setOpaque(true);
    return label;
  }

  public Component getInternalEditor() {
    tf.setEditable( isEditable() );
    return tf;
  }

  public void updateUI() {
        String val = (String)getValue();
    tf.setText( val );
  }
  public void updateData() {
    setValue( tf.getText() );
  }

    public String getStringValue() {
        return (String)getValue();
    }
}
