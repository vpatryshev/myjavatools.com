package com.borland.dspspb.primetime.crmplugin.opentool;

import java.util.*;

import java.awt.*;
import java.awt.dnd.*;

import com.borland.dspspb.primetime.crmplugin.*;
import com.borland.dspspb.primetime.crmplugin.management.*;
import com.borland.dspspb.primetime.crmplugin.view.*;
import com.borland.dspspb.primetime.crmplugin.view.rvtreetable.*;
import com.borland.primetime.ide.*;
import com.borland.primetime.ide.view.*;
import com.borland.primetime.ide.workspace.*;
import com.borland.primetime.node.*;
import com.starbase.caliber.external.xgeneric.*;

public class NodeStewardsManager
{
  private static final String NODESTEWARDS_FILE = "nodestewards.xml"; //NORES
  private static HashMap m_hmType2Steward = new HashMap();

  public static void registerSteward(Class nodeClass, INodeSteward nodeSteward)
  {
    if (!m_hmType2Steward.containsKey(nodeClass.getName()))
      m_hmType2Steward.put(nodeClass.getName(), nodeSteward);
  }

  public static INodeSteward findSteward(Node node)
  {
    if (node == null)
      return null;
    return (INodeSteward)m_hmType2Steward.get(node.getClass().getName());
  }

  public static void setDropTargets(Node node)
  {
    if (node == null)
      return;
    INodeSteward nodeSteward = findSteward(node);
    if (nodeSteward == null)
    {
      return;
    }
    Component[] components = nodeSteward.getDropEagerComponents(node);
    if (components == null || components.length == 0)
    {
      return;
    }
    for (int i = 0; i < components.length; i++)
    {
      Component component = components[i];
      if (component.getDropTarget() == null)
      {
        new DropTarget(component, CrmDropTargetListener.getDefault());
      }
      else
      {
        new DropTarget(component, new CrmDropTargetListener(component.getDropTarget()));
      }
    }
  }

  public static void openTraces (TraceInfo [] traces)
  {
    for (int i = 0; i < traces.length; i++)
    {
      openTrace (traces [i]);
    }
  }

// -----------------------------------------------------------------------------

  public static INodeSteward [] getRegisteredStewards ()
  {
    Collection values = m_hmType2Steward.values();
    return (INodeSteward []) values.toArray(new INodeSteward[values.size()]);
  }

  public static INodeSteward findSteward (String stewardId)
	{
		INodeSteward [] stewards = getRegisteredStewards();
		for	(int i = 0; i < stewards.length; i++)
		{
			INodeSteward steward = stewards [i];
      String id = steward.getId();
      if (id == null)
        continue;
			if (id.equals(stewardId))
        return steward;
		}
		return null;
	}

// -----------------------------------------------------------------------------

  public static void openTrace (TraceInfo traceInfo)
  {
    File traceObject = traceInfo.getTraceObject();
    String stewardId = traceObject.getName();

    INodeSteward steward = findSteward (stewardId);

    if (steward == null) return;

    String commentLocator = traceObject.getPath();
    steward.openComment (commentLocator);
  }

  public static void openRequirement (String reqLocator)
  {
    RequirementLocator requirementLocator = new RequirementLocator (reqLocator);

    String server = requirementLocator.getServer();
    String projectId = requirementLocator.getProjectId();
    String requirementId = requirementLocator.getRequirementId();

    Source source = new Source ("Open Requirement...", server); //RES Source_OpenRequirement_name
    source.setProjectId (projectId);
    source.setId (requirementId); // REQUIREMENT ID HERE!!!!!!!

    // Try to find existing session
    Source[] sources = SourceManager.getInstance().getSources();
    for (int i = 0; i < sources.length; i++)
    {
      if (source.getServer().equals(sources[i].getServer()))
      {
        if (sources[i].getSession() != null)
        {
          source.setLogin(sources[i].getLogin());
        }
      }
    }

    PluginWorkspaceView pluginWorkspaceView = findPluginView (source.getName());
    PluginView pluginView = null;

    if (pluginWorkspaceView == null)
    {
      pluginView = PluginManager.getInstance().openView(source);
    }
    else
    {
      pluginView = (PluginView)pluginWorkspaceView.getContent();
      pluginView.runSource (source);

      Workspace workspace = WorkspaceManager.getWorkspace(Browser.getActiveBrowser());
      workspace.setViewActive(pluginWorkspaceView);
    }

    if (pluginView != null)
      pluginView.showRequirementNode (new Integer(requirementId).intValue());
  }

  private static PluginWorkspaceView findPluginView (String title)
  {
    Workspace workspace = WorkspaceManager.getWorkspace (Browser.getActiveBrowser ());

    View [] views = workspace.getViews(PluginViewType.PLUGIN_VIEWTYPE);

    if (views == null) return null;

    for (int i = 0; i < views.length; i++)
    {
      View view = views [i];

      if (view.getTitle().equals(title))
      {
        return (PluginWorkspaceView) view;
      }
    }

    return null;
  }
}
