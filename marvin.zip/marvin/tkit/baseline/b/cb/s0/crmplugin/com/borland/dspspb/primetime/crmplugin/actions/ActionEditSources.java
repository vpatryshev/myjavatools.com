package com.borland.dspspb.primetime.crmplugin.actions;

import java.awt.event.*;

import com.borland.dspspb.primetime.crmplugin.management.*;
import com.borland.dspspb.primetime.crmplugin.resources.*;
import com.borland.dspspb.primetime.crmplugin.ui.*;

public class ActionEditSources extends PluginUpdateAction
{
  public ActionEditSources ()
  {
    super
      ("Configure Connections...", //RES ActionEditSources_shorttext
       "Configure connections to Caliber servers", //RES ActionEditSources_longtext
       ResourceManager.ActionEditSources_icon);

    setMnemonic('C'); //RES ActionEditSources_mnemonic
  }

  public void actionPerformed (ActionEvent e)
  {
    DlgConfigureConnections dlg = new DlgConfigureConnections (FramingManager.getInstance ().getMainFrame ());
    dlg.showDialog ();
  }
}
