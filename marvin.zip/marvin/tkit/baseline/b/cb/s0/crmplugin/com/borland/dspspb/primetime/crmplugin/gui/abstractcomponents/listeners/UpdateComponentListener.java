package com.borland.dspspb.primetime.crmplugin.gui.abstractcomponents.listeners;

import com.borland.dspspb.primetime.crmplugin.gui.abstractcomponents.AbstractViewComponent;

public interface UpdateComponentListener {
        public void componentUpdated ( AbstractViewComponent component );
}
