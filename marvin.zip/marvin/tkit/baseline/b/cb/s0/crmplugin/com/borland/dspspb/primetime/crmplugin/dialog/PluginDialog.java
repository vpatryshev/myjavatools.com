package com.borland.dspspb.primetime.crmplugin.dialog;

import java.net.URL;
import java.util.*;
import java.util.Timer;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import com.borland.primetime.help.HelpTopic;
import com.borland.primetime.help.viewer.HelpSystem;
import com.borland.primetime.ui.*;
import com.borland.primetime.ui.DialogValidator;

public abstract class PluginDialog extends DefaultDialog
{
  private JButton btnOk = null;
  private JButton btnCancel = null;
  private JButton btnHelp = null;
  private Timer timer = null;
  private boolean isStandard = true;

  private boolean bOk = false;
  private JButton defaultOkButton = null;
  private JButton defaultCancelButton = null;
  private JButton defaultHelpButton = null;
  private ActionListener buttonsListener = null;
  private HelpTopic helpTopic = new DefaultHelpTopic ();

  public PluginDialog(Component owner, String title)
  {
    super(owner, title, true);

    buttonsListener = new ButtonsListener();
  }

  // For overriding...
  public abstract JComponent getContentUI();

  public void onOk() {};

  public void onCancel() {};

  public void setHelpTopic(HelpTopic helpTopic)
  {
    this.helpTopic = helpTopic;
  }

// -----------------------------------------------------------------------------

  public void setDefaultButton (JButton btn)
  {
    super.setDefaultButton (btn);

    defaultOkButton = btn;
    defaultOkButton.addActionListener (buttonsListener);
  }

  public void setCancelButton (JButton btn)
  {
    super.setCancelButton (btn);

    defaultCancelButton = btn;
    defaultCancelButton.addActionListener (buttonsListener);
  }

  public void setHelpButton (JButton btn)
  {
    super.setHelpButton (btn);

    defaultHelpButton = btn;
    defaultHelpButton.addActionListener (buttonsListener);
  }

// -----------------------------------------------------------------------------

  private JPanel createButtonsPanel ()
  {
    JPanel buttonsPanel = new JPanel (new BorderLayout ());

    JPanel linePanel = new JPanel ();

    linePanel.setPreferredSize (new Dimension (1, 2));
    linePanel.setBorder (BorderFactory.createCompoundBorder
                         (BorderFactory.createMatteBorder (1, 0, 0, 0, Color.GRAY),
                          BorderFactory.createMatteBorder (0, 0, 1, 0, Color.WHITE)));


    ButtonStrip bs = new ButtonStrip ();
    btnOk = bs.createOkButton (true);
    btnCancel = bs.createCancelButton (true);
    btnHelp = bs.createHelpButton (true);

    setDefaultButton (btnOk);
    setCancelButton (btnCancel);
    setHelpButton (btnHelp);

    buttonsPanel.add (linePanel, BorderLayout.NORTH);
    buttonsPanel.add (bs, BorderLayout.CENTER);

    return buttonsPanel;
  }

  public boolean showDialog ()
  {
    // Create content panel
    if (isStandard)
    {
			getContentPane ().setLayout (new BorderLayout ());

			JPanel panel = new JPanel (new BorderLayout ());

			panel.setBorder (BorderFactory.createEmptyBorder (10, 5, 5, 5));
			panel.add (getContentUI (), BorderLayout.CENTER);

			getContentPane ().add (panel, BorderLayout.CENTER);
			getContentPane ().add (createButtonsPanel (), BorderLayout.SOUTH);
		}
    else
    {
      getContentPane ().add (getContentUI ());
      // ... and we do not response for anything...
    }

    pack ();
    startUpdateTimer ();
    show ();

    return bOk;
  }

  public void setStandard (boolean bStandard)
  {
    this.isStandard = bStandard;
  }

// -----------------------------------------------------------------------------
// Standard buttons listener

  private class ButtonsListener implements ActionListener
  {
    public void actionPerformed (ActionEvent event)
    {
      Object source = event.getSource();

      // OK pressed
      if (source == defaultOkButton)
      {
        if (PluginDialog.this instanceof DialogValidator)
        {
          if (((DialogValidator)PluginDialog.this).validateDialog())
          {
            closeDialog(true);
          }
        }
        else
        {
          closeDialog(true);
        }
      }
      // Cancel pressed
      else if (source == defaultCancelButton)
      {
        closeDialog(false);
      }
      // Help pressed
      else if (source == defaultHelpButton)
      {
        HelpSystem.showHelp
          (helpTopic.getUrlString(), PluginDialog.this, "CaliberRM plugin"); //RES CaliberHelp_title
      }
    }
  }

  public void closeDialog (boolean bResult)
  {
    stopUpdateTimer ();
    bOk = bResult;

    if (bResult) onOk ();
    else onCancel ();

    dispose ();
  }

// -----------------------------------------------------------------------------

  private void startUpdateTimer ()
  {
    // Check if dialog is updatable or timer alredy started
    if (!(this instanceof IUpdatableDialog) || timer != null) return;

    timer = new Timer ();
    timer.schedule (new DialogUpdateTask (), 0, 300);
  }

  private void stopUpdateTimer ()
  {
    if (timer != null) timer.cancel ();
    timer = null;
  }

  private class DialogUpdateTask extends TimerTask
  {
    public void run ()
    {
      ((IUpdatableDialog) PluginDialog.this).updateDialog ();
    }
  }

// -----------------------------------------------------------------------------

  public void showValidationMessage (String message, JComponent focusComponent)
  {
    JOptionPane.showMessageDialog
      (this, message,
       "Dialog Data Validation", //RES PluginDialog_ValidationWarning_text
       JOptionPane.WARNING_MESSAGE);

    if (focusComponent != null) focusComponent.requestFocus ();
  }

  protected Dimension getMinimumDialogSize ()
  {
    return getContentPane ().getPreferredSize();
  }

  private static class DefaultHelpTopic implements HelpTopic
  {
    public String getUrlString()
    {
      URL url = this.getClass().getClassLoader().getResource ("com/borland/dspspb/resources/help/HelpNotFound.html"); //NORES
      return url.toString();
    }
  }
}
