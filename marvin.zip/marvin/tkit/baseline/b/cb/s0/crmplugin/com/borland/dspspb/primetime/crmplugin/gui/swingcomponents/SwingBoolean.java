package com.borland.dspspb.primetime.crmplugin.gui.swingcomponents;

import javax.swing.JCheckBox;
import javax.swing.JComponent;

public class SwingBoolean extends SwingComponent
{
    private JCheckBox checkBox = new JCheckBox();

    public SwingBoolean ( String name,String displayName )
    {
       setName (name);
       checkBox.setText( displayName );
       setDisplayName( displayName );
    }

    public SwingBoolean ( String name,String displayName,boolean value )
    {
        this ( name,displayName );
        this.setValue( value+"" );
    }


   public JComponent getMainComponent()
   {
       return checkBox;
   }

   public void setValue(Object value)
   {
      checkBox.setSelected("true".equalsIgnoreCase( (String)value ) );
   }

   public Object getValue()
   {
     return checkBox.isSelected()+"";
   }


   public boolean getBooleanValue()
   {
     return checkBox.isSelected();
   }

   public void setBooleanValue( boolean val )
   {
      checkBox.setSelected(val);
   }

   public Object getUI()
   {
      return checkBox;
   }

}
