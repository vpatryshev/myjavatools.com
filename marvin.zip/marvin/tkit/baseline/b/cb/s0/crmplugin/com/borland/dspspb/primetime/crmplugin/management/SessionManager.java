package com.borland.dspspb.primetime.crmplugin.management;

import java.util.HashMap;
import com.starbase.caliber.Session;

public class SessionManager
{
  private static SessionManager instance;

  private SessionManager()
  {
  }

  public static SessionManager getInstance()
  {
    if (instance == null)
    {
      instance = new SessionManager();
      instance.init();
    }
    return instance;
  }

  private void init()
  {
  }

// -----------------------------------------------------------------------------
// Session management

  private static HashMap m_sessionMap = new HashMap();

  public Session getSession(Source source)
  {
    if (source == null)
      return null;
    return (Session)m_sessionMap.get(getSourceKey(source));
  }

  public void setSession(Source source, Session session)
  {
    if (source == null)
      return;
    Session currentSession = getSession(source);
    if (currentSession != null)
    {
      try
      {
        currentSession.logout();
      }
      catch (Exception e)
      {
      }
      m_sessionMap.remove(getSourceKey(source));
    }
    if (session == null)
      m_sessionMap.remove(getSourceKey(source));
    else
      m_sessionMap.put(getSourceKey(source), session);
  }

  public static String getSourceKey(Source source)
  {
    return source.getServer() + ":" + source.getLogin(); //NORES
  }
}
