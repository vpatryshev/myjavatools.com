package com.borland.dspspb.primetime.crmplugin.gui.actions.menu;

import java.util.Vector;
import javax.swing.JMenuItem;
import com.borland.dspspb.primetime.crmplugin.gui.actions.SwingAction;

public class MenuSection {
    private SwingMenu menu;
    private Vector menuItems = new Vector();

    MenuSection(SwingMenu menu) { this.menu = menu; }

    public IMenuItem[] getMenuItems() {
        return (IMenuItem[])menuItems.toArray(new IMenuItem[0]);
    }

    public SwingAction[] getActions() {
        IMenuItem[] items = getMenuItems();
        SwingAction[] actions = new SwingAction[items.length];
        for(int i=0; i<items.length; i++) {
            actions[i] = items[i].getAdrenalinAction();
        }
        return actions;
    }



    public void addAction(SwingAction action) { addAction(action, -1); }
    public void addAction(SwingAction action, int addIndex) {
        IMenuItem mi = MenuItem.createMenuItem(action);
        if(addIndex < 0)menuItems.add(mi);
        else menuItems.add(addIndex, mi);
        menu.rebuildMenu();
    }

    public void updateSection() {
        IMenuItem[] items = getMenuItems();
        for(int i=0; i<items.length; i++) {
            items[i].udpateMenuItem();
        }
    }
}
