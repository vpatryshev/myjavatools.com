package com.borland.dspspb.primetime.crmplugin.gui.swingcomponents.tableproperties;

import javax.swing.table.DefaultTableModel;
import java.util.Vector;
import com.borland.dspspb.primetime.crmplugin.gui.swingcomponents.tableproperties.internal.SwingInternalComponent;

public class PropertiesTableModel extends DefaultTableModel {

  private Vector mcomps;

  public PropertiesTableModel(Vector comps) {
    this.mcomps = comps;
  }

  public SwingInternalComponent getComponent(int row) {
    return (SwingInternalComponent)mcomps.get(row);
  }

  public Object getValueAt(int row, int col) {
    SwingInternalComponent sic = getComponent(row);
    if(col==0) {
      if(!sic.isMandatory())return sic.getDisplayName();
      else return "<html><b>"+sic.getDisplayName()+" *</html>";
    }
    else if(col==1) return sic;
    else return null;
  }

  public void setValueAt(Object object, int row, int col) {
//		System.out.println("Set Value At!!!");
  }

  public String getColumnName(int col) {
    if(col==0)return "Name";
    else if(col==1)return "Value";
    else return null;
  }

  public int getRowCount() {
    if(mcomps == null)return 0;
    return mcomps.size();
  }
  public int getColumnCount() { return 2; }
  public Class getColumnClass(int col) {
    return col == 0 ? String.class : SwingInternalComponent.class;
  }
  public boolean isCellEditable(int row, int col) { return (col == 1); }

}
