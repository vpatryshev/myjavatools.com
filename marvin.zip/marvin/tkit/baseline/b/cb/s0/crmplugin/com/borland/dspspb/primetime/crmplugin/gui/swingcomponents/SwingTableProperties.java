package com.borland.dspspb.primetime.crmplugin.gui.swingcomponents;

import com.borland.dspspb.primetime.crmplugin.gui.abstractcomponents.AbstractViewComponent;
import javax.swing.*;
import java.util.*;
import java.awt.*;
import com.borland.dspspb.primetime.crmplugin.gui.abstractcomponents.AbstractViewContainer;
import java.awt.event.FocusListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeEvent;
import com.borland.dspspb.primetime.crmplugin.gui.swingcomponents.tableproperties.*;
import com.borland.dspspb.primetime.crmplugin.gui.swingcomponents.tableproperties.internal.SwingInternalComponent;

public class SwingTableProperties extends AbstractViewContainer {

  private static JComboBox myTemplatePanel = new JComboBox();
  public static Color getBGColor() { return myTemplatePanel.getBackground(); }

  private JPanel mainPanel;
  private JTable myTable;
  private PropertiesTableModel myModel;
  private PropertiesCellRenderer myRenderer;
  private PropertiesCellEditor myEditor;

  public Object getUI() {
    if(mainPanel == null) {
      buildUI();
    }
        return mainPanel;
  }

  public SwingTableProperties () {
  }

  public void stopEditing() {
    myEditor.stopCellEditing();
  }

  private void buildUI() {
    mainPanel = new JPanel(new BorderLayout());
    Iterator it = super.getComponents().iterator();
    Vector vprops = new Vector();
    while(it.hasNext()) {
      Object nxt = it.next();
      if(nxt instanceof SwingInternalComponent) {
        vprops.add(nxt);
      }
    }
    Collections.sort(vprops, new Comparator(){
      public int compare(Object o1, Object o2) {
        SwingInternalComponent sic1 = (SwingInternalComponent)o1;
        SwingInternalComponent sic2 = (SwingInternalComponent)o2;
        return sic1.getOrder() - sic2.getOrder();
      }
    });
    myModel = new PropertiesTableModel(vprops);
    myTable = new JTable(myModel);
    myTable.setRowHeight(21);
    myRenderer = new PropertiesCellRenderer(vprops);
    myEditor = new PropertiesCellEditor(vprops);
    myTable.setDefaultRenderer(SwingInternalComponent.class, myRenderer);
    myTable.setDefaultEditor(SwingInternalComponent.class, myEditor);
    myTable.setPreferredScrollableViewportSize(new Dimension(400,400));
    myTable.setMinimumSize(new Dimension(400,400));

    mainPanel.add(new JScrollPane(myTable), BorderLayout.CENTER);

  }

}
