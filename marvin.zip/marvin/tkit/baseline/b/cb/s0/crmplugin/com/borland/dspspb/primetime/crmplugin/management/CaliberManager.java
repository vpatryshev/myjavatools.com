package com.borland.dspspb.primetime.crmplugin.management;

import javax.swing.JEditorPane;
import javax.swing.text.Document;

import com.borland.dspspb.primetime.crmplugin.view.rvtreetable.RVTableColumn;
import com.starbase.caliber.*;
import com.starbase.caliber.attribute.UDAListValue;
import com.starbase.caliber.server.RemoteServerException;

public class CaliberManager
{
  private static CaliberManager rmManager = null;
  private static JEditorPane editorPane = new JEditorPane();

  protected CaliberManager ()
  {
  }

  public static final synchronized CaliberManager getInstance ()
  {
    if (rmManager == null)
    {
      rmManager = new CaliberManager ();
    }

    return rmManager;
  }

// -----------------------------------------------------------------------------

  public static Project [] getProjects (Session session)
  {
    try
    {
      return session.getProjects ();
    }
    catch (RemoteServerException ex)
    {
      return null;
    }
  }

  public Project getProject (Source source)
  {
    Session session = source.getSession();
    if (session == null)
      return null;

    try
    {
      Project project = null;
      ProjectManager projectManager = (ProjectManager) session.getManager (Project.class);
      if (source.getProjectId() == null || source.getProjectId().length() == 0)
      {
        if (source.getProjectName() != null && source.getProjectName().length() > 0)
        {
          Project[] allProjects = projectManager.getAllProjects();
          for (int i = 0; i < allProjects.length; i++)
          {
            if (allProjects[i].getName().equals(source.getProjectName()))
            {
              return allProjects[i];
            }
          }
        }
      }
      else
      {
        ProjectID projectId = new ProjectID(new Integer(source.getProjectId()).intValue());
        return projectManager.getAllProjects (new CaliberObjectID [] {projectId})[0];
      }
    }
    catch (RemoteServerException ex)
    {
    }
    catch (NumberFormatException ex)
    {
    }
    return null;
  }

  public Baseline getBaseline(Source source)
  {
    Project project = getProject(source);
    if (project == null)
      return null;
    try
    {
      Baseline [] baselines = project.getBaselines ();
      for (int i = 0; i < baselines.length; i++)
      {
        Baseline baseline = baselines [i];
        String baselineId = "" + baseline.getID().getIDNumber(); //NORES
        if (baselineId.equals (source.getBaselineId()))
        {
          return baseline;
        }
      }
    }
    catch (RemoteServerException ex)
    {
    }
    return null;
  }

// -----------------------------------------------------------------------------

  public static String getRequirementField(Requirement req, String fieldName)
  {
    String fieldValue = ""; //NORES

    // For preview
    if (req == null)
      return "<" + fieldName + ">"; //NORES

    try
    {
      if (fieldName.equals(RVTableColumn.TCN_SERVER))
      {
        fieldValue = req.getSession ().getCaliberServer ().getHost ();
      }
      else if (fieldName.equals(RVTableColumn.TCN_PROJECTID))
      {
        fieldValue = "" + req.getProject ().getID().getIDNumber(); //NORES
      }
      else if (fieldName.equals(RVTableColumn.TCN_PROJECTNAME))
      {
        fieldValue = req.getProject ().getName();
      }
      else if (fieldName.equals(RVTableColumn.TCN_BASELINEID))
      {
        fieldValue = "" + req.getBaseline ().getID().getIDNumber(); //NORES
      }
      else if (fieldName.equals(RVTableColumn.TCN_BASELINENAME))
      {
        fieldValue = req.getBaseline ().getName();
      }
      else if (fieldName.equals(RVTableColumn.TCN_REQID))
      {
        fieldValue = String.valueOf (req.getID ().getIDNumber ());
      }
      else if (fieldName.equals(RVTableColumn.TCN_NAME))
      {
        fieldValue = req.getName();
      }
      else if (fieldName.equals(RVTableColumn.TCN_TYPE))
      {
        fieldValue = req.getRequirementType().getName();
      }
      else if (fieldName.equals(RVTableColumn.TCN_VERSION))
      {
        RequirementID reqID = req.getRequirementID();

        StringBuffer buffer = new StringBuffer ();
        buffer.append (reqID.getMajorVersionNumber());
        buffer.append ('.'); //NON-NLS
        buffer.append (reqID.getMinorVersionNumber());

        return buffer.toString();
      }
      else if (fieldName.equals(RVTableColumn.TCN_OWNER))
      {
        User owner = req.getOwner();
        if (owner != null)
        {
          String name = owner.getName();

          if (name != null && name.length() != 0)
          {
            fieldValue = name;
          }
          else
          {
            fieldValue = owner.getFirstName() + " " + owner.getLastName(); //NORES
          }
        }
      }
      else if (fieldName.equals(RVTableColumn.TCN_STATUS))
      {
        UDAListValue values = req.getStatus();
        int selected = values.getSelectedIndex();

        fieldValue = values.get(Math.max(0, selected)).toString();
      }
      else if (fieldName.equals(RVTableColumn.TCN_PRIORITY))
      {
        UDAListValue values1 = req.getPriority();
        int selected1 = values1.getSelectedIndex();

        fieldValue = values1.get(Math.max(0, selected1)).toString();
      }
      else if (fieldName.equals(RVTableColumn.TCN_DESCRIPTION))
      {

        RequirementDescription description = req.getDescription();

        // Convert comment from HTML to plain text
        if (description != null)
        {
          String descText = description.getText();
          editorPane.setContentType("text/html"); //NORES
          editorPane.setText(descText);
          Document doc = editorPane.getDocument();
          fieldValue = doc.getText(1, doc.getLength());
        }
      }
    }
    catch (Exception ex)
    {
      return ""; //NORES
    }

    return fieldValue;
  }
}
