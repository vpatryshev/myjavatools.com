package com.borland.dspspb.primetime.crmplugin.actions;

import java.awt.event.*;
import javax.swing.*;

import com.borland.dspspb.primetime.crmplugin.filter.*;
import com.borland.dspspb.primetime.crmplugin.gui.treetable.*;
import com.borland.dspspb.primetime.crmplugin.management.*;
import com.borland.dspspb.primetime.crmplugin.resources.*;
import com.borland.dspspb.primetime.crmplugin.view.*;
import com.borland.dspspb.primetime.crmplugin.view.rvtreetable.*;
import com.borland.dspspb.primetime.crmplugin.ui.DlgChangeFilter;
import com.starbase.caliber.*;

public class ActionSelectFilter extends PluginUpdateAction
{
  public ActionSelectFilter ()
  {
    super
      ("Change Filter...", //RES ActionSelectFilter_shorttext
       "Change current requirements filter", //RES ActionSelectFilter_longtext
       ResourceManager.ActionSelectFilter_icon);
  }

  public void update (Object object)
  {
    PluginView pluginView = (PluginView) object;

    Session session = null;

    Source source = pluginView.getSource();
    session = SessionManager.getInstance().getSession(source);

    setEnabled (session != null);
  }

  public void actionPerformed(ActionEvent e)
  {
    PluginView pluginView = (PluginView) e.getSource();

    Source source = pluginView.getSource();

    DlgChangeFilter dlgChangeFilter = new DlgChangeFilter (pluginView, source);

    if (dlgChangeFilter.showDialog ())
    {
      Filter filter = dlgChangeFilter.getResult ();
      RVTreeTable table = pluginView.getTable ();
      source.setFilterId (filter.getId ());
      TreeIterator.traverse (table.getRootNode (), new FilterUpdater ());
      table.updateUI ();
    }
  }

  private class FilterUpdater implements INodeProcessor
  {
    public boolean accept (TableNodeAdapter node)
    {
      return (node instanceof RequirementNode);
    }

    public boolean process (TableNodeAdapter node)
    {
      RequirementNode requirementNode = (RequirementNode) node;
      requirementNode.setAuxFlag();
      return true;
    }
  }
}
