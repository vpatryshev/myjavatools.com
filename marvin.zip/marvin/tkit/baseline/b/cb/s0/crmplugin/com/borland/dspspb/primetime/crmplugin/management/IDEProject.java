package com.borland.dspspb.primetime.crmplugin.management;

import javax.swing.JOptionPane;
import com.borland.primetime.node.Project;
import com.borland.primetime.node.Node;
import com.borland.dspspb.primetime.crmplugin.opentool.PluginLWNode;
import com.borland.dspspb.primetime.crmplugin.opentool.SourceLWNode;
import java.util.Vector;
import com.borland.primetime.vfs.Url;
import com.borland.primetime.node.FileNode;
import com.borland.primetime.ide.Browser;

public class IDEProject
{
  private Project m_project = null;
  public IDEProject(Object project)
  {
    m_project = (Project)project;
  }

  public String getName()
  {
    if (m_project == null)
      return null;
    String projectName = m_project.getUrl().getName();
    return projectName;
  }

  private PluginLWNode findPluginLWNode()
  {
    if (m_project == null)
      return null;
    PluginLWNode pluginLWNode = null;
    Node[] nodes = m_project.getChildren();
    if (nodes != null && nodes.length > 0)
    {
      for (int i = 0; i < nodes.length; i++)
      {
        if (nodes[i] instanceof PluginLWNode)
        {
          pluginLWNode = (PluginLWNode)nodes[i];
          break;
        }
      }
    }
    return pluginLWNode;
  }

  public Source findSource(String sourceId)
  {
    PluginLWNode pluginLWNode = findPluginLWNode();
    if (pluginLWNode == null)
      return null;
    Node[] nodes = pluginLWNode.getChildren();
    if (nodes != null && nodes.length > 0)
    {
      for (int i = 0; i < nodes.length; i++)
      {
        if (nodes[i] instanceof SourceLWNode)
        {
          SourceLWNode sourceLWNode = (SourceLWNode)nodes[i];
          String nodeSourceId = sourceLWNode.getProperty(SourceLWNode.PROPERTY_CATEGORY, SourceLWNode.PROPERTY_NAME, null);
          if (nodeSourceId != null && nodeSourceId.equals(sourceId))
            return SourceManager.getInstance().findSource(nodeSourceId);
        }
      }
    }
    return null;
  }

  public void checkSources()
  {
    PluginLWNode pluginLWNode = findPluginLWNode();
    if (pluginLWNode == null)
      return;
//    pluginLWNode.refreshChildren();
    Node[] nodes = pluginLWNode.getChildren();
    if (nodes != null && nodes.length > 0)
    {
      for (int i = 0; i < nodes.length; i++)
      {
        if (nodes[i] instanceof SourceLWNode)
        {
          SourceLWNode sourceLWNode = (SourceLWNode)nodes[i];
          if (sourceLWNode.getSource() == null)
            sourceLWNode.setParent(null);
        }
      }
    }
    if (!pluginLWNode.hasChildren())
    {
      pluginLWNode.setParent(null);
    }
  }

  public void addSource(Source source)
  {
    PluginLWNode pluginLWNode = findPluginLWNode();
    if (findSource(source.getId()) != null)
      return;
//    String sourceNodeName = (String)JOptionPane.showInputDialog(FramingManager.getInstance().getMainFrame(),
//      "Source name:", "Add To Project", JOptionPane.QUESTION_MESSAGE, null, null, source.getName());
    String sourceNodeName = source.getName();
    if (sourceNodeName == null || sourceNodeName.length() == 0)
      return;
    if (pluginLWNode == null)
    {
      pluginLWNode = new PluginLWNode(m_project);
    }

    SourceLWNode sourceLWNode = null;
    Node[] nodes = pluginLWNode.getChildren();
    if (nodes != null && nodes.length > 0)
    {
      for (int i = 0; i < nodes.length; i++)
      {
        if ((nodes[i] instanceof SourceLWNode) && sourceNodeName.equals(nodes[i].getDisplayName()))
        {
          sourceLWNode = (SourceLWNode)nodes[i];
          break;
        }
      }
    }
    if (sourceLWNode == null)
    {
      sourceLWNode = new SourceLWNode(m_project, pluginLWNode, sourceNodeName);
    }
    sourceLWNode.setProperty(SourceLWNode.PROPERTY_CATEGORY, SourceLWNode.PROPERTY_NAME, source.getId());
  }

  private String generateNewName(PluginLWNode pluginLWNode, Source source)
  {
    if (pluginLWNode == null)
      return source.getName();
    Node[] nodes = pluginLWNode.getChildren();
    Vector names = new Vector();
    if (nodes != null && nodes.length > 0)
    {
      for (int i = 0; i < nodes.length; i++)
      {
        if ((nodes[i] instanceof SourceLWNode) && nodes[i].getDisplayName() != null)
        {
          names.add(nodes[i].getDisplayName());
        }
      }
    }
    return Utils.generateNewName(source.getName(), names);
  }

  public Vector getProjectSourceIds ()
  {
    Vector vAddedSourceIds = new Vector ();

    PluginLWNode pluginLWNode = findPluginLWNode();

    if (pluginLWNode == null)
      return vAddedSourceIds;

//    pluginLWNode.refreshChildren();

    Node [] nodes = pluginLWNode.getChildren();

    if (nodes != null && nodes.length > 0)
    {
      for (int i = 0; i < nodes.length; i++)
      {
        if (nodes[i] instanceof SourceLWNode)
        {
          SourceLWNode sourceLWNode = (SourceLWNode)nodes[i];
          Source nodeSource = sourceLWNode.getSource();

          if (nodeSource != null) vAddedSourceIds.add (nodeSource.getId ());
        }
      }
    }

    return vAddedSourceIds;
  }
}
