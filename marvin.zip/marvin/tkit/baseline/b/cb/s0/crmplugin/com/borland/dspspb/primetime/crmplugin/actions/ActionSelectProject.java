package com.borland.dspspb.primetime.crmplugin.actions;

import java.awt.event.*;

import com.borland.dspspb.primetime.crmplugin.management.*;
import com.borland.dspspb.primetime.crmplugin.resources.*;
import com.borland.dspspb.primetime.crmplugin.ui.*;
import com.borland.dspspb.primetime.crmplugin.view.*;
import com.starbase.caliber.*;

public class ActionSelectProject extends PluginUpdateAction
{
  public ActionSelectProject ()
  {
    super
      ("Change Project...", //RES ActionSelectProject_shorttext
       "Change current Caliber project", //RES ActionSelectProject_longtext
       ResourceManager.ActionSelectProject_icon);
  }

  public void update (Object object)
  {
    PluginView pluginView = (PluginView) object;

    Source source = pluginView.getSource();
    Session session = SessionManager.getInstance().getSession(source);

    setEnabled (session != null);
  }

  public void actionPerformed(ActionEvent e)
  {
    PluginView pluginView = (PluginView) e.getSource();

    Source source = pluginView.getSource();

    DlgSelectProject dlg = new DlgSelectProject(FramingManager.getInstance().getMainFrame(), source);
    if (dlg.showDialog())
    {
      pluginView.runSource(dlg.getSource());
    }
  }
}
