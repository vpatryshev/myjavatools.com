package com.borland.dspspb.primetime.crmplugin.ui;

import com.borland.dspspb.primetime.crmplugin.dialog.ButtonsGroup;
import com.borland.dspspb.primetime.crmplugin.dialog.IUpdatableDialog;
import com.borland.dspspb.primetime.crmplugin.dialog.PluginDialog;
import com.borland.dspspb.primetime.crmplugin.opentool.INodeSteward;
import com.borland.dspspb.primetime.crmplugin.opentool.NodeStewardsManager;
import com.borland.dspspb.primetime.crmplugin.resources.ResourceManager;
import com.borland.dspspb.primetime.crmplugin.view.rvtreetable.RVTableColumn;
import com.borland.dspspb.primetime.crmplugin.view.rvtreetable.RequirementNode;
import com.borland.primetime.help.PrimetimeHelp;
import com.starbase.caliber.Requirement;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.awt.event.*;
import java.util.Vector;

public class DlgConfigureComment
  extends PluginDialog
  implements ActionListener, ItemListener, IUpdatableDialog
{
  static final Color COLOR_NAMEROW				= new Color (210, 210, 210);

  private static ImageIcon iconArrowUp 		= ResourceManager.getIcon (ResourceManager.DlgConfigureComment_arrowup_icon);
  private static ImageIcon iconArrowDown	= ResourceManager.getIcon (ResourceManager.DlgConfigureComment_arrowdown_icon);

  private JTable myTable;
  private JButton btnHideAll;
  private JButton btnShowAll;
  private JButton btnMoveUp;
  private JButton btnMoveDown;
  private JButton btnSetDefault;
  private JComboBox cbStewards;
  private static int selectedStewardIndex = 0;

  private Vector all;
  private Vector defaults;
  private boolean [] checked;

  private JScrollPane previewScrollPane = null;
  private JEditorPane editorPane = null;
  private Requirement req = null;

  private static final String columnNames []	=
  {
    "Field Name" //RES DlgConfigureComment_FieldName_text
  };

  public DlgConfigureComment
    (Component owner, Requirement req, Vector all, Vector defaults, Vector shown)
  {
    super (owner, "Configure Comment"); //RES DlgConfigureComment_title
    setHelpTopic (PrimetimeHelp.createTopic (PrimetimeHelp.BOOK_UserGuide, "ui/dialogs/dlgcaliberconfigurecomment.html")); //NORES

    this.req = req;
    this.defaults = defaults;
    this.all = all;

    checked = new boolean [all.size ()];

    for (int i = 0; i < all.size (); i++)
    {
      checked[i] = shown.contains (all.get (i));
    }
  }

  private JPanel createButtonsPanel ()
  {
    ButtonsGroup panel = new ButtonsGroup (ButtonsGroup.CENTER);

    btnMoveUp = new JButton ("Move Up", iconArrowUp); //RES DlgConfigureComment_MoveUp_text
    btnMoveUp.setMnemonic('U'); //RES DlgConfigureComment_MoveUp_mnemonic
    btnMoveDown = new JButton ("Move Down", iconArrowDown); //RES DlgConfigureComment_MoveDown_text
    btnMoveDown.setMnemonic('D'); //RES DlgConfigureComment_MoveDown_mnemonic
    btnHideAll = new JButton ("Hide All"); //RES DlgConfigureComment_HideAll_text
    btnHideAll.setMnemonic('H'); //RES DlgConfigureComment_HideAll_mnemonic
    btnShowAll = new JButton ("Show All"); //RES DlgConfigureComment_ShowAll_text
    btnShowAll.setMnemonic('S'); //RES DlgConfigureComment_ShowAll_mnemonic
    btnSetDefault = new JButton ("Set Default"); //RES DlgConfigureComment_SetDefault_text
    btnSetDefault.setMnemonic('T'); //RES DlgConfigureComment_SetDefault_mnemonic

    panel.addButton (btnMoveUp, this);
    panel.addButton (btnMoveDown, this);
    panel.addButton (btnShowAll, this);
    panel.addButton (btnHideAll, this);
//    panel.addButton (btnSetDefault, this);

    panel.setBorder (BorderFactory.createEtchedBorder ());
    return panel;
  }

	private JPanel createLanguagePanel ()
	{
		JPanel panel = new JPanel (new FlowLayout (FlowLayout.LEFT));

	  JLabel lblLanguages = new JLabel ("Available Handlers:"); //RES DlgConfigureComment_Handlers_text
	  lblLanguages.setDisplayedMnemonic ('A'); //RES DlgConfigureComment_Handlers_mnemonic

    INodeSteward [] stewards = NodeStewardsManager.getRegisteredStewards ();

    cbStewards = new JComboBox (stewards);
    if (selectedStewardIndex >= 0 && selectedStewardIndex < stewards.length)
      cbStewards.setSelectedIndex(selectedStewardIndex);
    cbStewards.setEditable (false);
    cbStewards.setRenderer (new StewardCellRenderer ());
    lblLanguages.setLabelFor(cbStewards);

	  panel.add (lblLanguages);
		panel.add (cbStewards);

	  cbStewards.addItemListener (this);

	  return panel;
  }

	public JComponent getContentUI ()
	{
    JPanel contentPanel = new JPanel (new BorderLayout ());

    myTable = new JTable ();
    JScrollPane tablePane = new JScrollPane(myTable);

    myTable.setModel (new MyTableModel ());
    myTable.setDefaultRenderer (JCheckBox.class, new FieldNameRenderer ());
    myTable.addMouseListener (new MyTableMouseListener ());
    myTable.addKeyListener (new MyTableKeyAdapter ());
    myTable.setRowSelectionAllowed (true);
    myTable.setColumnSelectionAllowed (false);
    myTable.getTableHeader ().setReorderingAllowed (false);
    myTable.getTableHeader ().setDefaultRenderer (new HeaderRenderer ());
    myTable.setGridColor (Color.lightGray);
    myTable.getSelectionModel ().setSelectionMode (ListSelectionModel.SINGLE_SELECTION);
    myTable.setAutoResizeMode (JTable.AUTO_RESIZE_LAST_COLUMN);
    myTable.setPreferredScrollableViewportSize (new Dimension (600, 16 * Math.min(20, all.size())));
    myTable.setRowSelectionInterval (0, 0);

    JPanel tbbtnPanel = new JPanel (new BorderLayout ());
    tbbtnPanel.add (tablePane, BorderLayout.CENTER);
    tbbtnPanel.add (createButtonsPanel (), BorderLayout.SOUTH);

		JComponent languagePanel = createLanguagePanel();
    JComponent previewComp = createPreviewPane();

	  JPanel previewPanel = new JPanel (new BorderLayout ());

	  previewPanel.add (languagePanel, BorderLayout.NORTH);
	  previewPanel.add (previewComp, BorderLayout.CENTER);

  	contentPanel.add (tbbtnPanel, BorderLayout.NORTH);
    contentPanel.add (previewPanel, BorderLayout.CENTER);

    updatePreview ();

// -----------------------------------------------------------------------------

    // Register Enter/Escape keyboard action
    myTable.registerKeyboardAction (new ActionListener ()
    {
      public void actionPerformed (ActionEvent ae)
      {
        doDefaultClick ();
      }
    }, KeyStroke.getKeyStroke (KeyEvent.VK_ENTER, 0),
       JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

    myTable.registerKeyboardAction (new ActionListener ()
    {
      public void actionPerformed (ActionEvent ae)
      {
        closeDialog (false);
      }
    }, KeyStroke.getKeyStroke (KeyEvent.VK_ESCAPE, 0),
       JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

    return contentPanel;
  }

  public Vector getValues ()
  {
    Vector values = new Vector ();

    for (int i = 0; i < checked.length; i++)
    {
      if (checked [i])
      {
        values.add (all.get (i));
      }
    }

    return values;
  }

//------------------------------------------------------------------------------

  class MyTableModel extends AbstractTableModel
  {
    public int getColumnCount ()
    {
      return columnNames.length;
    }

    public int getRowCount ()
    {
      return all.size ();
    }

    public String getColumnName (int col)
    {
      return columnNames [col];
    }

    public Object getValueAt (int row, int col)
    {
      RVTableColumn field = (RVTableColumn) all.get(row);
      return field.getDisplayName();
    }

    public Class getColumnClass (int c)
    {
      return (JCheckBox.class);
    }

    public boolean isCellEditable (int row, int col)
    {
      return false;
    }
  }

//------------------------------------------------------------------------------

  class FieldNameRenderer extends JCheckBox implements TableCellRenderer
  {
    public Component getTableCellRendererComponent (JTable table, Object value,
                                                    boolean isSelected, boolean hasFocus,
                                                    int row, int col)
    {
      setBackground (isSelected ? table.getSelectionBackground () : table.getBackground ());
      setForeground (isSelected ? table.getSelectionForeground () : table.getForeground ());
      setSelected (checked[row]);
      setText (value.toString ());

      return this;
    }
  }

// -----------------------------------------------------------------------------

  private class StewardCellRenderer extends DefaultListCellRenderer
  {
    public Component getListCellRendererComponent
      (JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
    {
      String stewardName = ""; //NORES

      INodeSteward steward = (INodeSteward) value;
      if (steward != null) stewardName = steward.getId ();

      super.getListCellRendererComponent (list, stewardName, index, isSelected, cellHasFocus);
      setIcon (steward.getIcon());

      return this;
    }
  }

//------------------------------------------------------------------------------

  class MyTableMouseListener extends MouseAdapter
  {
    public void mousePressed (MouseEvent e)
    {
      int row = myTable.rowAtPoint (e.getPoint ());

      if (e.getPoint ().x <= myTable.getRowHeight ())
      {
        checked[row] = !checked[row];
        updatePreview();
      }

      myTable.setRowSelectionInterval (row, row);
      myTable.repaint ();
    }
  }

//------------------------------------------------------------------------------

  class MyTableKeyAdapter extends KeyAdapter
  {
    public void keyReleased (KeyEvent e)
    {
      int keyCode = e.getKeyCode ();
      if (keyCode == KeyEvent.VK_SPACE)
      {
        int row = myTable.getSelectedRow ();
        if (row != -1)
        {
          checked [row] = !checked[row];
          myTable.repaint ();
					updatePreview();
        }
      }
    }
  }

//------------------------------------------------------------------------------

  public void actionPerformed (ActionEvent event)
  {
    Object source = event.getSource ();

    if (source == btnShowAll)
    {
      allShowHide (true);
    }
    else if (source == btnHideAll)
    {
      allShowHide (false);
    }
    else if (source == btnMoveUp)
    {
      moveUp ();
    }
    else if (source == btnMoveDown)
    {
      moveDown ();
    }
    else if (source == btnSetDefault)
    {
      selectDefault();
    }

    updatePreview();
  }

//------------------------------------------------------------------------------

  public void moveUp ()
  {
    int idx = myTable.getSelectedRow ();

    if (idx == 0)
    {
      return;
    }

    Object up = all.get (idx - 1);
    all.setElementAt (all.get (idx), idx - 1);
    all.setElementAt (up, idx);

    boolean bup = checked[idx - 1];
    checked[idx - 1] = checked[idx];
    checked[idx] = bup;

    myTable.setRowSelectionInterval (idx - 1, idx - 1);
		myTable.repaint();
  }

  public void moveDown ()
  {
    int idx = myTable.getSelectedRow ();

    if (idx == all.size () - 1)
    {
      return;
    }

    Object down = all.get (idx + 1);
    all.setElementAt (all.get (idx), idx + 1);
    all.setElementAt (down, idx);

    boolean bdown = checked[idx + 1];
    checked[idx + 1] = checked[idx];
    checked[idx] = bdown;

    myTable.setRowSelectionInterval (idx + 1, idx + 1);
  }

  void allShowHide (boolean bShow)
  {
    for (int i = 0; i < checked.length; i++)
    {
      checked[i] = bShow;
    }

		myTable.repaint ();
  }

  private void selectDefault ()
  {
    for (int i = 0; i < all.size (); i++)
    {
      checked [i] = defaults.contains (all.get (i));
    }

    myTable.repaint ();
  }

//------------------------------------------------------------------------------

  public JComponent createPreviewPane ()
  {
			editorPane = new JEditorPane ();
			editorPane.setBorder (BorderFactory.createEtchedBorder ());
			editorPane.setEditable (false);
			editorPane.setFocusable (false);

			editorPane.setForeground (new Color (0, 128, 0));
			editorPane.setFont (new Font ("Monospaced", Font.PLAIN, 12)); //NORES

			previewScrollPane = new JScrollPane (editorPane);

			String borderTitle = " Preview "; //RES DlgConfigureComment_Preview_text
			previewScrollPane.setBorder
			  (BorderFactory.createTitledBorder (BorderFactory.createEtchedBorder (), borderTitle));

			// Following settings really affects only component height
			previewScrollPane.setPreferredSize (new Dimension (1, 150));

			return previewScrollPane;
	}

  private void updatePreview ()
  {
    Vector selectedFields = new Vector ();

    for (int i = 0; i < all.size(); i++)
    {
      if (checked [i]) selectedFields.add (all.get (i));
    }

    INodeSteward selectedSteward = (INodeSteward) cbStewards.getSelectedItem();

    if (selectedSteward == null) return;

		String newComment = selectedSteward.getCommentText (RequirementNode.getRequirementInfo (req, getValues ()));

    editorPane.setText (newComment);
    editorPane.setCaretPosition(0);
  }

	public void updateDialog ()
	{
    int selectedRow = myTable.getSelectedRow ();

    btnMoveUp.setEnabled (selectedRow > 0);
    btnMoveDown.setEnabled (selectedRow != myTable.getRowCount () - 1);

    int selCount = 0;

    for (int i = 0; i < checked.length; i++)
    {
      if (checked [i]) selCount++;
    }

    btnHideAll.setEnabled (selCount > 0);
    btnShowAll.setEnabled (selCount != checked.length);
	}

	public void itemStateChanged (ItemEvent e)
	{
    Object source = e.getSource();

    if (source != cbStewards) return;

    updatePreview();
	}

  public void onOk()
  {
    super.onOk();
    selectedStewardIndex = cbStewards.getSelectedIndex();
  }

// -----------------------------------------------------------------------------
// Table header renderer

	public class HeaderRenderer extends JLabel implements TableCellRenderer
	{
		public HeaderRenderer ()
		{
			setBorder (BorderFactory.createCompoundBorder
								 (UIManager.getBorder ("TableHeader.cellBorder"), BorderFactory.createEmptyBorder (0, 5, 0, 5))); //NORES
		}

		public Component getTableCellRendererComponent
			(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
		{
			JTableHeader header = table.getTableHeader ();

			setForeground (header.getForeground ());
			setBackground (header.getBackground ());
			setFont (header.getFont ());

			setText (value.toString ());

			return this;
		}
	}
}
