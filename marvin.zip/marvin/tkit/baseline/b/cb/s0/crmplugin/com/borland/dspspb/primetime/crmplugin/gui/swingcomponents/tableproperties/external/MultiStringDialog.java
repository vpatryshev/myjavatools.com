package com.borland.dspspb.primetime.crmplugin.gui.swingcomponents.tableproperties.external;

import javax.swing.*;
import java.awt.Dimension;
import javax.swing.table.DefaultTableModel;
import java.util.Vector;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import com.borland.dspspb.primetime.crmplugin.gui.dialogs.AdrenalinDialog;
import com.borland.dspspb.primetime.crmplugin.gui.swingcomponents.tableproperties.internal.MultiValuesInternalComponent;

public class MultiStringDialog extends AdrenalinDialog {
  private MultiValuesInternalComponent comp;
  private JTable table;
  private MVTableModel tm;

  public MultiStringDialog(MultiValuesInternalComponent comp) {
        super(null);
    this.comp = comp;
    super.setTitle( comp.getDisplayName() );
  }

  public JPanel createContentPane() {
    Vector vals = comp.getValues();
    tm = new MVTableModel(vals);
    table = new JTable( tm );
    JPanel mainPanel = new JPanel(new BorderLayout());
    JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
    mainPanel.add(new JScrollPane(table), BorderLayout.CENTER);
    JButton addBtn = new JButton("Add");
    JButton remBtn = new JButton("Remove");
    JButton upBtn = new JButton("Up");
    JButton dnBtn = new JButton("Down");

    btnPanel.add(addBtn);
    btnPanel.add(remBtn);
    btnPanel.add(upBtn);
    btnPanel.add(dnBtn);

    mainPanel.add(btnPanel, BorderLayout.SOUTH);

    addBtn.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent evt) {
        String newVal = JOptionPane.showInputDialog(null, "New Value:", "Add", JOptionPane.QUESTION_MESSAGE);
        if(newVal != null) {
          tm.addValue(newVal);
          table.setRowSelectionInterval(tm.getRowCount()-1, tm.getRowCount()-1);
        }
      }
    });
    remBtn.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent evt) {
        int row = table.getSelectedRow();
        if(row < 0)return;
        tm.removeValue(row);
        int newRow = -1;
        if(tm.getRowCount() > 0)newRow = (row==0 ? 0 : row - 1);
        table.setRowSelectionInterval(newRow, newRow);
      }
    });
    upBtn.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent evt) {
        int row = table.getSelectedRow();
        if(row <= 0)return;
        tm.upValue(row);
        table.setRowSelectionInterval(row-1, row-1);
      }
    });
    dnBtn.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent evt) {
        int row = table.getSelectedRow();
        if(row < 0)return;
        if(row >= tm.getRowCount()-1)return;
        tm.dnValue(row);
        table.setRowSelectionInterval(row+1, row+1);
      }
    });

    return mainPanel;
  }

    public void doOk() {
        comp.setValues( tm.getValues() );
        comp.updateUI();
        comp.getEditor().fireEditingStopped();
    }

    public void doCancel() {
        comp.getEditor().fireEditingCanceled();
    }

  public static class MVTableModel extends DefaultTableModel {
    private Vector values;

    public MVTableModel(Vector values) {
      this.values = (Vector)values.clone();
    }

    public Vector getValues() { return values; }
    public String getValue(int row) { return (String)values.get(row); }

    public Object getValueAt(int row, int col) {
      if(col == 0)return getValue(row);
      else return null;
    }

    public void addValue(String value) {
      values.add(value);
      fireTableDataChanged();
    }

    public void removeValue(int row) {
      if(row < 0)return;
      values.remove(row);
      fireTableDataChanged();
    }

    public void upValue(int row) {
      if(row <= 0)return;
      String val = getValue(row);
      String upVal = getValue(row - 1);
      values.set(row - 1, val);
      values.set(row, upVal);
      fireTableDataChanged();
    }
    public void dnValue(int row) {
      if(row < 0)return;
      if(row >= getRowCount()-1)return;
      String val = getValue(row);
      String dnVal = getValue(row + 1);
      values.set(row + 1, val);
      values.set(row, dnVal);
      fireTableDataChanged();
    }

    public void setValueAt(Object object, int row, int col) {}

    public String getColumnName(int col) {
      if(col==0)return "Values";
      else return null;
    }

    public int getRowCount() {
      if(values == null)return 0;
      return values.size();
    }
    public int getColumnCount() { return 1; }
    public Class getColumnClass(int col) {
      return String.class;
    }
    public boolean isCellEditable(int row, int col) { return false; }
  }
}
