package com.borland.dspspb.primetime.crmplugin.actions;
import java.awt.event.*;

import com.borland.dspspb.primetime.crmplugin.opentool.*;
import com.borland.dspspb.primetime.crmplugin.resources.*;
import com.borland.dspspb.primetime.crmplugin.view.*;
import com.borland.dspspb.primetime.crmplugin.view.rvtreetable.*;
import com.borland.dspspb.primetime.crmplugin.management.FramingManager;

public class ActionOpenComments extends PluginUpdateAction
{
  public ActionOpenComments()
  {
    super
      ("Open Comments", //RES ActionGoToFile_shorttext
       "Open comments associated with selected traces", //RES ActionGoToFile_longtext
       ResourceManager.ActionGoToFile_icon);
  }

  public void actionPerformed (ActionEvent e)
  {
    TraceTable traceTable = (TraceTable) e.getSource();
    int nUnknown = 0;

    int [] selectedRows = traceTable.getSelectedRows ();

    for (int i = 0; i < selectedRows.length; i++)
    {
      TraceInfo traceInfo = traceTable.getData () [selectedRows [i]];
      int status = traceInfo.getStatus ();

      if (status != CommentStatus.STATUS_UNKNOWN)
      {
        NodeStewardsManager.openTrace (traceInfo);
      }
      else
      {
        nUnknown++;
      }
    }

    if (nUnknown !=0)
    {
      String message = "" + nUnknown + " "; //NORES
      message += (nUnknown == 1
        ? "of associated comments has not been opened because of Unknown status." //RES ActionGoToFile_message1
        : "of associated comments have not been opened because of Unknown status."); //RES ActionGoToFile_message2
      FramingManager.getInstance().showWarning(message);
    }
  }

  public void update (Object source)
  {
    TraceTable traceTable = (TraceTable) source;
    setEnabled (traceTable.getSelectedRowCount () > 0);
  }
}
