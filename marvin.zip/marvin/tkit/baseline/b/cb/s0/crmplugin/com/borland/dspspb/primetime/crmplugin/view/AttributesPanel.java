package com.borland.dspspb.primetime.crmplugin.view;

import javax.swing.JPanel;
import javax.swing.JLabel;
import com.starbase.caliber.Requirement;
import com.starbase.caliber.attribute.AttributeValue;
import com.starbase.caliber.attribute.Attribute;
import com.starbase.caliber.server.*;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import com.starbase.caliber.RequirementType;
import java.util.Vector;
import com.starbase.caliber.CustomTab;
import javax.swing.BorderFactory;
import javax.swing.JScrollPane;
import com.starbase.caliber.attribute.UDABooleanValue;
import com.starbase.caliber.attribute.UDADateValue;
import com.starbase.caliber.attribute.UDAFloatValue;
import com.starbase.caliber.attribute.UDAIntegerValue;
import com.starbase.caliber.attribute.UDAListValue;
import com.starbase.caliber.attribute.UDATextValue;
import javax.swing.JComponent;
import javax.swing.JCheckBox;

public class AttributesPanel extends JScrollPane
{
  private JPanel m_panel = new JPanel(new GridBagLayout());

  public AttributesPanel()
  {
    this.setViewportView(m_panel);
  }

  public void showAttributes(Requirement requirement)
  {
    m_panel.removeAll();
    if (requirement == null)
    {
      updateUI();
      return;
    }
    GridBagConstraints c = new GridBagConstraints();
    c.gridx = 0;
    c.anchor = GridBagConstraints.NORTHWEST;
    c.weightx = 1.0;
    c.weighty = 0.0;
    c.gridheight = 1;
    c.gridwidth = 1;
    c.fill = GridBagConstraints.HORIZONTAL;
    Insets insets = new Insets(3, 3, 3, 3);
    c.insets = insets;
    int gridy = 0;
    try
    {
      RequirementType requirementType = requirement.getRequirementType();
      CustomTab[] customTabs = requirementType.getCustomTabs();
      AttributeValue[] attrValues = requirement.getAttributeValues();
      for (int i = 0; i < customTabs.length; i++)
      {
        JPanel tabPanel = buildCustomTabPanel(customTabs[i], attrValues);
        if (tabPanel == null)
          continue;
        c.gridy = gridy++;
        m_panel.add(tabPanel, c);
      }
    }
    catch (RemoteServerException e)
    {
    }

    c.gridy = gridy;
    c.weightx = 1.0;
    c.weighty = 1.0;
    c.fill = GridBagConstraints.BOTH;
    m_panel.add(new JLabel(), c);
    updateUI();
  }

  private JPanel buildCustomTabPanel(CustomTab customTab, AttributeValue[] reqAttrValues)
  {
    JPanel panel = new JPanel(new GridBagLayout());
    try
    {
      Attribute[] tabAttrs = customTab.getAttributes();
      Vector tabAttrNames = new Vector();
      for (int i = 0; i < tabAttrs.length; i++)
      {
        tabAttrNames.add(tabAttrs[i].getName());
      }

      GridBagConstraints c = new GridBagConstraints();
      c.anchor = GridBagConstraints.NORTHWEST;
      c.weighty = 0.0;
      c.gridheight = 1;
      c.gridwidth = 1;
      Insets insets = new Insets(3, 3, 3, 3);
      c.insets = insets;
      int gridy = 0;
      for (int i = 0; i < reqAttrValues.length; i++)
      {
        try
        {
          AttributeValue attrValue = reqAttrValues[i];
          String name = attrValue.getAttribute().getName();
          if (!tabAttrNames.contains(name))
          {
            continue;
          }
          c.gridy = gridy++;
          c.gridx = 0;
          c.weightx = 0.0;
          c.fill = GridBagConstraints.NONE;
          panel.add(new JLabel(name), c);
          c.gridx = 1;
          c.weightx = 1.0;
          c.fill = GridBagConstraints.HORIZONTAL;
          panel.add(getUDAComponent(attrValue), c);
        }
        catch (RemoteServerException ex)
        {
        }
      }
      c.gridx = 0;
      c.gridy = gridy;
      c.gridwidth = 2;
      c.weightx = 1.0;
      c.weighty = 1.0;
      c.fill = GridBagConstraints.BOTH;
      panel.add(new JLabel(), c);
    }
    catch (Exception e)
    {
      return null;
    }
    String borderTitle = " " + customTab.getName() + " "; //NORES
    panel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), borderTitle));
    return panel;
  }

  private JComponent getUDAComponent(AttributeValue attributeValue)
  {
    if (attributeValue instanceof UDABooleanValue)
    {
     JCheckBox checkBox = new JCheckBox("", ((UDABooleanValue)attributeValue).getValue()); //NORES
     checkBox.setEnabled(false);
     checkBox.setBorderPaintedFlat(true);
     return checkBox;
    }
    else if (attributeValue instanceof UDADateValue)
    {
      return new JLabel(((UDADateValue)attributeValue).getValue().toString());
    }
    else if (attributeValue instanceof UDAFloatValue)
    {
      return new JLabel(Float.toString(((UDAFloatValue)attributeValue).getValue()));
    }
    else if (attributeValue instanceof UDAIntegerValue)
    {
      return new JLabel(Integer.toString(((UDAIntegerValue)attributeValue).getValue()));
    }
    else if (attributeValue instanceof UDAListValue)
    {
      UDAListValue listValue = (UDAListValue)attributeValue;
      Object[] selectedObjects = listValue.getSelectedObjects();
      if (selectedObjects == null || selectedObjects.length == 0)
        return new JLabel ("<none>"); //RES AttributesPanel_None_text
      else if (selectedObjects.length == 1)
      {
       return new JLabel(((UDAListValue)attributeValue).getSelectedValue().toString());
      }
      else
      {
        StringBuffer bufSelected = new StringBuffer();
        for (int i = 0; i < selectedObjects.length; i++)
        {
          bufSelected.append(selectedObjects.toString());
          if (i != selectedObjects.length - 1)
            bufSelected.append(", "); //NORES
        }
        return new JLabel(bufSelected.toString());
      }
    }
    else if (attributeValue instanceof UDATextValue)
    {
      return new JLabel(((UDATextValue)attributeValue).getValue());
    }
    return new JLabel("<unknown type>"); //RES AttributesPanel_UnknownType_text
  }

}
