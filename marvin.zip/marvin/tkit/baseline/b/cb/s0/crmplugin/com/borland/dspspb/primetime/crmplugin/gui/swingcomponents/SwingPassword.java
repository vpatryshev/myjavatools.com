package com.borland.dspspb.primetime.crmplugin.gui.swingcomponents;

import javax.swing.*;

public class SwingPassword extends SwingComponent{
    private JPasswordField passwordField;

    public SwingPassword( String name,String displayName,Object value )
    {
        super ( name,displayName,value );
        passwordField = new JPasswordField();
        setValue(value);
     }
    public Object getValue ()
    {
      return new String( passwordField.getPassword());
    }

    public void setValue(Object value )
    {
        super.setValue(value);
        if ( passwordField!=null )
       passwordField.setText( (String)value );
    }


    public void setEditable( boolean editable)
    {
      passwordField.setEditable( editable );
    }

    public JComponent getMainComponent()
    {
       passwordField.setText( (String)getValue() );
       return passwordField;
    }
}
