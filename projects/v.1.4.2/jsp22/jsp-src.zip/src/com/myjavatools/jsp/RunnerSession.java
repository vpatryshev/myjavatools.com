package com.myjavatools.jsp;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSessionContext;
import java.util.Enumeration;
import javax.servlet.http.HttpSession;
import java.text.MessageFormat;
import java.util.Map;
import java.util.Collections;

/**
 * <p>Title: Command Line Interface to JSP</p>
 * <p>Description: Runs JSP in command-line context, sending output to stdout</p>
 * <p>Copyright: Copyright (c) 2003 Vlad Patryshev</p>
 * <p>Company: </p>
 * @author Vlad Patryshev
 * @version 2.0
 */

public class RunnerSession implements HttpSession {
  Map environment;

  public RunnerSession(Map environment) {
    this.environment = environment;
  }

  public long getCreationTime() {
    /**@todo Implement this javax.servlet.http.HttpSession method*/
    throw new NotImplementedException("getCreationTime");
  }
  public String getId() {
    return "jsp22_unique_singleton_session_id";
  }
  public long getLastAccessedTime() {
    /**@todo Implement this javax.servlet.http.HttpSession method*/
    throw new NotImplementedException("getLastAccessedTime");
  }
  public ServletContext getServletContext() {
    /**@todo Implement this javax.servlet.http.HttpSession method*/
    throw new NotImplementedException("getServletContext");
  }
  public void setMaxInactiveInterval(int parm1) {
    /**@todo Implement this javax.servlet.http.HttpSession method*/
    throw new NotImplementedException("setMaxInactiveInterval");
  }
  public int getMaxInactiveInterval() {
    /**@todo Implement this javax.servlet.http.HttpSession method*/
    throw new NotImplementedException("getMaxInactiveInterval");
  }
  public HttpSessionContext getSessionContext() {
    /**@todo Implement this javax.servlet.http.HttpSession method*/
    throw new NotImplementedException("getSessionContext");
  }
  public Object getAttribute(String parm1) {
    return environment.get(parm1);
  }
  public Object getValue(String parm1) {
    return getAttribute(parm1);
  }
  public Enumeration getAttributeNames() {
    return Collections.enumeration(environment.keySet());
  }
  public String[] getValueNames() {
    String[] result = new String[environment.size()];
    environment.keySet().toArray(result);
    return result;
  }
  public void setAttribute(String parm1, Object parm2) {
   environment.put(parm1, parm2);
  }
  public void putValue(String parm1, Object parm2) {
    /**@todo Implement this javax.servlet.http.HttpSession method*/
    throw new NotImplementedException("putValue");
  }
  public void removeAttribute(String parm1) {
    environment.remove(parm1);
  }
  public void removeValue(String parm1) {
    removeAttribute(parm1);
  }
  public void invalidate() {
  }
  public boolean isNew() {
    return true;
  }

  private class NotImplementedException extends UnsupportedOperationException {
    NotImplementedException(String methodName) {
      super((new MessageFormat("Method {0}() not yet implemented")).format(new String[] {methodName}));
    }
  }
}