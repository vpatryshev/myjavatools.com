package com.myjavatools.jsp;

import org.apache.catalina.core.ContainerBase;
import org.apache.catalina.*;
import org.apache.catalina.util.CharsetMapper;
import org.apache.catalina.deploy.LoginConfig;
import org.apache.catalina.deploy.NamingResources;
import javax.servlet.ServletContext;
import org.apache.catalina.deploy.ApplicationParameter;
import org.apache.catalina.deploy.SecurityConstraint;
import org.apache.catalina.deploy.ContextEjb;
import org.apache.catalina.deploy.ContextEnvironment;
import org.apache.catalina.deploy.ErrorPage;
import org.apache.catalina.deploy.FilterDef;
import org.apache.catalina.deploy.FilterMap;
import org.apache.catalina.deploy.ContextLocalEjb;
import org.apache.catalina.deploy.ContextResource;
import org.apache.catalina.deploy.ContextResourceLink;
import javax.naming.directory.DirContext;
import java.beans.PropertyChangeListener;
import java.io.IOException;
import javax.servlet.ServletException;
import org.apache.catalina.Context;
import org.apache.catalina.Wrapper;
import org.apache.catalina.session.StandardManager;

public class RunnerContext extends ContainerBase implements Context {
  ServletContext servletContext;

  public RunnerContext(ServletContext servletContext) {
    this.servletContext = servletContext;
    setManager(new StandardManager());
  }
  public String getInfo() {
    return "com.myjavatools.jsp.RunnerContext/1.0";
  }

  private Object applicationListenersObjects[] = new Object[0];
  public Object[] getApplicationListeners() { return applicationListenersObjects; }
  public void setApplicationListeners(Object listeners[]) { applicationListenersObjects = listeners;  }

  boolean available = false;
  public boolean getAvailable()                 { return available; }
  public void setAvailable(boolean available)   { this.available = available; }

  boolean configured = false;
  public boolean getConfigured()                 { return configured; }
  public void setConfigured(boolean configured)   { this.configured = configured; }

  boolean cookies = false;
  public boolean getCookies()                 { return cookies; }
  public void setCookies(boolean cookies)   { this.cookies = cookies; }

  boolean crossContext = false;
  public boolean getCrossContext()                 { return crossContext; }
  public void setCrossContext(boolean crossContext)   { this.crossContext = crossContext; }

  boolean distributable = false;
  public boolean getDistributable()                 { return distributable; }
  public void setDistributable(boolean distributable)   { this.distributable = distributable; }

  boolean override = false;
  public boolean getOverride()                 { return override; }
  public void setOverride(boolean override)   { this.override = override; }

  boolean privileged = false;
  public boolean getPrivileged()                 { return privileged; }
  public void setPrivileged(boolean privileged)   { this.privileged = privileged; }

  boolean reloadable = false;
  public boolean getReloadable()                 { return reloadable; }
  public void setReloadable(boolean reloadable)   { this.reloadable = reloadable; }

  private CharsetMapper charsetMapper = null;
  public CharsetMapper getCharsetMapper()                 { return charsetMapper; }
  public void setCharsetMapper(CharsetMapper charsetMapper)   { this.charsetMapper = charsetMapper; }

  String displayName = null;
  public String getDisplayName()                 { return displayName; }
  public void setDisplayName(String displayName)        { this.displayName = displayName; }

  String docBase = null;
  public String getDocBase()                 { return docBase; }
  public void setDocBase(String docBase)        { this.docBase = docBase; }

  private LoginConfig loginConfig = null;
  public LoginConfig getLoginConfig()                 { return loginConfig; }
  public void setLoginConfig(LoginConfig loginConfig)   { this.loginConfig = loginConfig; }

  private NamingResources namingResources = null;
  public NamingResources getNamingResources()                 { return namingResources; }
  public void setNamingResources(NamingResources namingResources)   { this.namingResources = namingResources; }

  public String getPath()                 { return getName(); }
  public void setPath(String path)        { setName(path); }

  String publicId = null;
  public String getPublicId()                 { return publicId; }
  public void setPublicId(String publicId)        { this.publicId = publicId; }

  public int getSessionTimeout()  { return 0; }
  public void setSessionTimeout(int whocares) {}

  String wrapperClass = null;
  public String getWrapperClass()                 { return wrapperClass; }
  public void setWrapperClass(String wrapperClass)        { this.wrapperClass = wrapperClass; }

  public ServletContext getServletContext() { return servletContext; }

  public void addApplicationListener(String whocares) {}
  public void addApplicationParameter(ApplicationParameter whocares) {}
  public void addConstraint(SecurityConstraint whocares) {}

  public void addEjb(ContextEjb parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method addEjb() not yet implemented.");
  }
  public void addEnvironment(ContextEnvironment parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method addEnvironment() not yet implemented.");
  }
  public void addErrorPage(ErrorPage parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method addErrorPage() not yet implemented.");
  }
  public void addFilterDef(FilterDef parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method addFilterDef() not yet implemented.");
  }
  public void addFilterMap(FilterMap parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method addFilterMap() not yet implemented.");
  }
  public void addInstanceListener(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method addInstanceListener() not yet implemented.");
  }
  public void addLocalEjb(ContextLocalEjb parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method addLocalEjb() not yet implemented.");
  }
  public void addMimeMapping(String parm1, String parm2) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method addMimeMapping() not yet implemented.");
  }
  public void addParameter(String parm1, String parm2) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method addParameter() not yet implemented.");
  }
  public void addResource(ContextResource parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method addResource() not yet implemented.");
  }
  public void addResourceEnvRef(String parm1, String parm2) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method addResourceEnvRef() not yet implemented.");
  }
  public void addResourceLink(ContextResourceLink parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method addResourceLink() not yet implemented.");
  }
  public void addRoleMapping(String parm1, String parm2) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method addRoleMapping() not yet implemented.");
  }
  public void addSecurityRole(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method addSecurityRole() not yet implemented.");
  }
  public void addServletMapping(String parm1, String parm2) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method addServletMapping() not yet implemented.");
  }
  public void addTaglib(String parm1, String parm2) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method addTaglib() not yet implemented.");
  }
  public void addWelcomeFile(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method addWelcomeFile() not yet implemented.");
  }
  public void addWrapperLifecycle(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method addWrapperLifecycle() not yet implemented.");
  }
  public void addWrapperListener(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method addWrapperListener() not yet implemented.");
  }
  public Wrapper createWrapper() {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method createWrapper() not yet implemented.");
  }
  public String[] findApplicationListeners() {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findApplicationListeners() not yet implemented.");
  }
  public ApplicationParameter[] findApplicationParameters() {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findApplicationParameters() not yet implemented.");
  }
  public SecurityConstraint[] findConstraints() {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findConstraints() not yet implemented.");
  }
  public ContextEjb findEjb(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findEjb() not yet implemented.");
  }
  public ContextEjb[] findEjbs() {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findEjbs() not yet implemented.");
  }
  public ContextEnvironment findEnvironment(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findEnvironment() not yet implemented.");
  }
  public ContextEnvironment[] findEnvironments() {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findEnvironments() not yet implemented.");
  }
  public ErrorPage findErrorPage(int parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findErrorPage() not yet implemented.");
  }
  public ErrorPage findErrorPage(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findErrorPage() not yet implemented.");
  }
  public ErrorPage[] findErrorPages() {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findErrorPages() not yet implemented.");
  }
  public FilterDef findFilterDef(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findFilterDef() not yet implemented.");
  }
  public FilterDef[] findFilterDefs() {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findFilterDefs() not yet implemented.");
  }
  public FilterMap[] findFilterMaps() {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findFilterMaps() not yet implemented.");
  }
  public String[] findInstanceListeners() {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findInstanceListeners() not yet implemented.");
  }
  public ContextLocalEjb findLocalEjb(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findLocalEjb() not yet implemented.");
  }
  public ContextLocalEjb[] findLocalEjbs() {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findLocalEjbs() not yet implemented.");
  }
  public String findMimeMapping(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findMimeMapping() not yet implemented.");
  }
  public String[] findMimeMappings() {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findMimeMappings() not yet implemented.");
  }
  public String findParameter(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findParameter() not yet implemented.");
  }
  public String[] findParameters() {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findParameters() not yet implemented.");
  }
  public ContextResource findResource(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findResource() not yet implemented.");
  }
  public String findResourceEnvRef(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findResourceEnvRef() not yet implemented.");
  }
  public String[] findResourceEnvRefs() {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findResourceEnvRefs() not yet implemented.");
  }
  public ContextResourceLink findResourceLink(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findResourceLink() not yet implemented.");
  }
  public ContextResourceLink[] findResourceLinks() {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findResourceLinks() not yet implemented.");
  }
  public ContextResource[] findResources() {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findResources() not yet implemented.");
  }
  public String findRoleMapping(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findRoleMapping() not yet implemented.");
  }
  public boolean findSecurityRole(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findSecurityRole() not yet implemented.");
  }
  public String[] findSecurityRoles() {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findSecurityRoles() not yet implemented.");
  }
  public String findServletMapping(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findServletMapping() not yet implemented.");
  }
  public String[] findServletMappings() {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findServletMappings() not yet implemented.");
  }
  public String findStatusPage(int parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findStatusPage() not yet implemented.");
  }
  public int[] findStatusPages() {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findStatusPages() not yet implemented.");
  }
  public String findTaglib(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findTaglib() not yet implemented.");
  }
  public String[] findTaglibs() {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findTaglibs() not yet implemented.");
  }
  public boolean findWelcomeFile(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findWelcomeFile() not yet implemented.");
  }
  public String[] findWelcomeFiles() {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findWelcomeFiles() not yet implemented.");
  }
  public String[] findWrapperLifecycles() {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findWrapperLifecycles() not yet implemented.");
  }
  public String[] findWrapperListeners() {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method findWrapperListeners() not yet implemented.");
  }
  public void reload() {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method reload() not yet implemented.");
  }
  public void removeApplicationListener(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method removeApplicationListener() not yet implemented.");
  }
  public void removeApplicationParameter(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method removeApplicationParameter() not yet implemented.");
  }
  public void removeConstraint(SecurityConstraint parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method removeConstraint() not yet implemented.");
  }
  public void removeEjb(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method removeEjb() not yet implemented.");
  }
  public void removeEnvironment(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method removeEnvironment() not yet implemented.");
  }
  public void removeErrorPage(ErrorPage parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method removeErrorPage() not yet implemented.");
  }
  public void removeFilterDef(FilterDef parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method removeFilterDef() not yet implemented.");
  }
  public void removeFilterMap(FilterMap parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method removeFilterMap() not yet implemented.");
  }
  public void removeInstanceListener(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method removeInstanceListener() not yet implemented.");
  }
  public void removeLocalEjb(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method removeLocalEjb() not yet implemented.");
  }
  public void removeMimeMapping(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method removeMimeMapping() not yet implemented.");
  }
  public void removeParameter(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method removeParameter() not yet implemented.");
  }
  public void removeResource(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method removeResource() not yet implemented.");
  }
  public void removeResourceEnvRef(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method removeResourceEnvRef() not yet implemented.");
  }
  public void removeResourceLink(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method removeResourceLink() not yet implemented.");
  }
  public void removeRoleMapping(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method removeRoleMapping() not yet implemented.");
  }
  public void removeSecurityRole(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method removeSecurityRole() not yet implemented.");
  }
  public void removeServletMapping(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method removeServletMapping() not yet implemented.");
  }
  public void removeTaglib(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method removeTaglib() not yet implemented.");
  }
  public void removeWelcomeFile(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method removeWelcomeFile() not yet implemented.");
  }
  public void removeWrapperLifecycle(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method removeWrapperLifecycle() not yet implemented.");
  }
  public void removeWrapperListener(String parm1) {
    /**@todo Implement this org.apache.catalina.Context method*/
    throw new java.lang.UnsupportedOperationException("Method removeWrapperListener() not yet implemented.");
  }
}