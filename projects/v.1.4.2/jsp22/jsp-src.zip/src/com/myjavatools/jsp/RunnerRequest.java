package com.myjavatools.jsp;

import javax.servlet.http.Cookie;
import java.util.Enumeration;
import java.security.Principal;
import javax.servlet.http.HttpSession;
import java.io.UnsupportedEncodingException;
import javax.servlet.ServletInputStream;
import java.io.IOException;
import java.util.Map;
import java.io.BufferedReader;
import java.util.Locale;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import java.util.Set;
import java.util.HashSet;
import java.util.Collections;
import java.util.HashMap;
import java.text.MessageFormat;
import java.io.File;

/**
 * <p>Title: Command Line Interface to JSP</p>
 * <p>Description: Runs JSP in command-line context, sending output to stdout</p>
 * <p>Copyright: Copyright (c) 2003 Vlad Patryshev</p>
 * <p>Company: </p>
 * @author Vlad Patryshev
 * @version 2.0
 */

public class RunnerRequest implements HttpServletRequest {
  Map parameters;
  HttpSession session;
  String servletPath;
  Map attributes = new HashMap();

  public RunnerRequest(String servletPath, Map parameters, HttpSession session) {
    this.servletPath = servletPath;
    this.parameters = new HashMap(parameters);
    this.session = session;
  };

  public String getAuthType() {
    return null;
  }
  public Cookie[] getCookies() {
    return null;
  }
  public long getDateHeader(String parm1) {
    /**@todo Implement this javax.servlet.http.HttpServletRequest method*/
    throw new NotImplementedException("getDateHeader");
  }
  public String getHeader(String parm1) {
    /**@todo Implement this javax.servlet.http.HttpServletRequest method*/
    throw new NotImplementedException("getHeader");
  }
  public Enumeration getHeaders(String parm1) {
    /**@todo Implement this javax.servlet.http.HttpServletRequest method*/
    throw new NotImplementedException("getHeaders");
  }
  public Enumeration getHeaderNames() {
    /**@todo Implement this javax.servlet.http.HttpServletRequest method*/
    throw new NotImplementedException("getHeaderNames");
  }
  public int getIntHeader(String parm1) {
    /**@todo Implement this javax.servlet.http.HttpServletRequest method*/
    throw new NotImplementedException("getIntHeader");
  }
  public String getMethod() {
    /**@todo Implement this javax.servlet.http.HttpServletRequest method*/
    throw new NotImplementedException("getMethod");
  }
  public String getPathInfo() {
    /**@todo Implement this javax.servlet.http.HttpServletRequest method*/
    throw new NotImplementedException("getPathInfo");
  }
  public String getPathTranslated() {
    /**@todo Implement this javax.servlet.http.HttpServletRequest method*/
    throw new NotImplementedException("getPathTranslated");
  }
  public String getContextPath() {
    /**@todo Implement this javax.servlet.http.HttpServletRequest method*/
    throw new NotImplementedException("getContextPath");
  }
  public String getQueryString() {
    return null;
    /**@todo Implement this javax.servlet.http.HttpServletRequest method*/
//    throw new NotImplementedException("getQueryString");
  }
  public String getRemoteUser() {
    /**@todo Implement this javax.servlet.http.HttpServletRequest method*/
    throw new NotImplementedException("getRemoteUser");
  }
  public boolean isUserInRole(String parm1) {
    /**@todo Implement this javax.servlet.http.HttpServletRequest method*/
    throw new NotImplementedException("isUserInRole");
  }
  public Principal getUserPrincipal() {
    /**@todo Implement this javax.servlet.http.HttpServletRequest method*/
    throw new NotImplementedException("getUserPrincipal");
  }
  public String getRequestedSessionId() {
    return session.getId();
  }
  public String getRequestURI() {
    /**@todo Implement this javax.servlet.http.HttpServletRequest method*/
    throw new NotImplementedException("getRequestURI");
  }
  public StringBuffer getRequestURL() {
    /**@todo Implement this javax.servlet.http.HttpServletRequest method*/
    throw new NotImplementedException("getRequestURL");
  }
  public String getServletPath() {
    return servletPath;
  }
  public HttpSession getSession(boolean parm1) {
    return session;
  }
  public HttpSession getSession() {
    return session;
  }
  public boolean isRequestedSessionIdValid() {
    return true;
  }
  public boolean isRequestedSessionIdFromCookie() {
    return false;
  }
  public boolean isRequestedSessionIdFromURL() {
    return false;
  }
  public boolean isRequestedSessionIdFromUrl() {
    return false;
  }
  public Object getAttribute(String parm1) {
    return attributes.get(parm1);
  }
  public Enumeration getAttributeNames() {
    return Collections.enumeration(attributes.keySet());
  }
  public String getCharacterEncoding() {
    /**@todo Implement this javax.servlet.ServletRequest method*/
    throw new NotImplementedException("getCharacterEncoding");
  }
  public void setCharacterEncoding(String parm1) throws java.io.UnsupportedEncodingException {
    /**@todo Implement this javax.servlet.ServletRequest method*/
    throw new NotImplementedException("setCharacterEncoding");
  }
  public int getContentLength() {
    /**@todo Implement this javax.servlet.ServletRequest method*/
    throw new NotImplementedException("getContentLength");
  }
  public String getContentType() {
    /**@todo Implement this javax.servlet.ServletRequest method*/
    throw new NotImplementedException("getContentType");
  }
  public ServletInputStream getInputStream() throws java.io.IOException {
    /**@todo Implement this javax.servlet.ServletRequest method*/
    throw new NotImplementedException("getInputStream");
  }
  public String getParameter(String parm1) {
    return (String)parameters.get(parm1);
  }
  public Enumeration getParameterNames() {
    return Collections.enumeration (parameters.keySet());
  }
  public String[] getParameterValues(String parm1) {
    /**@todo Implement this javax.servlet.ServletRequest method*/
    throw new NotImplementedException("getParameterValues");
  }
  public Map getParameterMap() {
    /**@todo Implement this javax.servlet.ServletRequest method*/
    throw new NotImplementedException("getParameterMap");
  }
  public String getProtocol() {
    /**@todo Implement this javax.servlet.ServletRequest method*/
    throw new NotImplementedException("getProtocol");
  }
  public String getScheme() {
    /**@todo Implement this javax.servlet.ServletRequest method*/
    throw new NotImplementedException("getScheme");
  }
  public String getServerName() {
    return "jsp22";
    /**@todo Implement this javax.servlet.ServletRequest method*/
//    throw new NotImplementedException("getServerName");
  }
  public int getServerPort() {
    return 0;
    /**@todo Implement this javax.servlet.ServletRequest method*/
//    throw new NotImplementedException("getServerPort");
  }
  public BufferedReader getReader() throws java.io.IOException {
    /**@todo Implement this javax.servlet.ServletRequest method*/
    throw new NotImplementedException("getReader");
  }
  public String getRemoteAddr() {
    /**@todo Implement this javax.servlet.ServletRequest method*/
    throw new NotImplementedException("getRemoteAddr");
  }
  public String getRemoteHost() {
    return "localhost";
  }
  public void setAttribute(String parm1, Object parm2) {
    attributes.put(parm1, parm2);
  }
  public void removeAttribute(String parm1) {
    attributes.remove(parm1);
  }
  public Locale getLocale() {
    /**@todo Implement this javax.servlet.ServletRequest method*/
    throw new NotImplementedException("getLocale");
  }
  public Enumeration getLocales() {
    /**@todo Implement this javax.servlet.ServletRequest method*/
    throw new NotImplementedException("getLocales");
  }
  public boolean isSecure() {
    return true;
  }
  public RequestDispatcher getRequestDispatcher(String parm1) {
    /**@todo Implement this javax.servlet.ServletRequest method*/
    throw new NotImplementedException("getRequestDispatcher");
  }
  public String getRealPath(String parm1) {
    try {
      return new File(parm1).getCanonicalPath();
    }
    catch (IOException ex) {
      return null;
    }
  }

  private class NotImplementedException extends UnsupportedOperationException {
    NotImplementedException(String methodName) {
      super((new MessageFormat("Method {0}() not yet implemented")).format(new String[] {methodName}));
    }
  }
}