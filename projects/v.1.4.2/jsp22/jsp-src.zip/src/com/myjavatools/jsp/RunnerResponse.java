package com.myjavatools.jsp;

import javax.servlet.http.Cookie;
import java.io.IOException;
import javax.servlet.ServletOutputStream;
import java.io.PrintWriter;
import java.util.Locale;
import javax.servlet.http.HttpServletResponse;
import java.text.MessageFormat;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class RunnerResponse implements HttpServletResponse {

  ServletOutputStream sos = new ServletOutputStream() {
    public void write(int b) throws IOException {
      System.out.write(b);
    }
  };

  PrintWriter writer = new PrintWriter(sos);
  String contentType = null;

  public RunnerResponse() {}

  public void addCookie(Cookie parm1) {
    /**@todo Implement this javax.servlet.http.HttpServletResponse method*/
    throw new NotImplementedException("addCookie");
  }
  public boolean containsHeader(String parm1) {
    /**@todo Implement this javax.servlet.http.HttpServletResponse method*/
    throw new NotImplementedException("containsHeader");
  }
  public String encodeURL(String parm1) {
    /**@todo Implement this javax.servlet.http.HttpServletResponse method*/
    throw new NotImplementedException("encodeURL");
  }
  public String encodeRedirectURL(String parm1) {
    /**@todo Implement this javax.servlet.http.HttpServletResponse method*/
    throw new NotImplementedException("encodeRedirectURL");
  }
  public String encodeUrl(String parm1) {
    /**@todo Implement this javax.servlet.http.HttpServletResponse method*/
    throw new NotImplementedException("encodeUrl");
  }
  public String encodeRedirectUrl(String parm1) {
    /**@todo Implement this javax.servlet.http.HttpServletResponse method*/
    throw new NotImplementedException("encodeRedirectUrl");
  }
  public void sendError(int parm1, String parm2) throws java.io.IOException {
    throw new IOException("Error " + parm1 + ": " + parm2);
//    System.err.println("Error " + parm1 + ": " + parm2);
//    System.exit(1);
  }
  public void sendError(int parm1) throws java.io.IOException {
    throw new IOException("Error " + parm1);
//    System.err.println("Error " + parm1);
//    System.exit(1);
  }
  public void sendRedirect(String parm1) throws java.io.IOException {
    /**@todo Implement this javax.servlet.http.HttpServletResponse method*/
    throw new NotImplementedException("sendRedirect");
  }
  public void setDateHeader(String parm1, long parm2) {
    /**@todo Implement this javax.servlet.http.HttpServletResponse method*/
    throw new NotImplementedException("setDateHeader");
  }
  public void addDateHeader(String parm1, long parm2) {
    /**@todo Implement this javax.servlet.http.HttpServletResponse method*/
    throw new NotImplementedException("addDateHeader");
  }
  public void setHeader(String parm1, String parm2) {
    /**@todo Implement this javax.servlet.http.HttpServletResponse method*/
    throw new NotImplementedException("setHeader");
  }
  public void addHeader(String parm1, String parm2) {
    /**@todo Implement this javax.servlet.http.HttpServletResponse method*/
    throw new NotImplementedException("addHeader");
  }
  public void setIntHeader(String parm1, int parm2) {
    /**@todo Implement this javax.servlet.http.HttpServletResponse method*/
    throw new NotImplementedException("setIntHeader");
  }
  public void addIntHeader(String parm1, int parm2) {
    /**@todo Implement this javax.servlet.http.HttpServletResponse method*/
    throw new NotImplementedException("addIntHeader");
  }
  public void setStatus(int parm1) {
    /**@todo Implement this javax.servlet.http.HttpServletResponse method*/
    throw new NotImplementedException("setStatus");
  }
  public void setStatus(int parm1, String parm2) {
    /**@todo Implement this javax.servlet.http.HttpServletResponse method*/
    throw new NotImplementedException("setStatus");
  }
  public String getCharacterEncoding() {
    /**@todo Implement this javax.servlet.ServletResponse method*/
    throw new NotImplementedException("getCharacterEncoding");
  }
  public PrintWriter getWriter() {
    return writer;
  }
  public ServletOutputStream getOutputStream() {
    return sos;
  }
  public void setContentLength(int parm1) {
    /**@todo Implement this javax.servlet.ServletResponse method*/
    throw new NotImplementedException("setContentLength");
  }
  public void setContentType(String parm1) {
    contentType = parm1;
  }
  public void setBufferSize(int parm1) {
    /**@todo Implement this javax.servlet.ServletResponse method*/
    throw new NotImplementedException("setBufferSize");
  }
  public int getBufferSize() {
    /**@todo Implement this javax.servlet.ServletResponse method*/
    throw new NotImplementedException("getBufferSize");
  }
  public void flushBuffer() throws java.io.IOException {
    sos.flush();
  }
  public void resetBuffer() {
    /**@todo Implement this javax.servlet.ServletResponse method*/
    throw new NotImplementedException("resetBuffer");
  }
  public boolean isCommitted() {
    return true;
  }
  public void reset() {
    /**@todo Implement this javax.servlet.ServletResponse method*/
    throw new NotImplementedException("reset");
  }
  public void setLocale(Locale parm1) {
    /**@todo Implement this javax.servlet.ServletResponse method*/
    throw new NotImplementedException("setLocale");
  }
  public Locale getLocale() {
    /**@todo Implement this javax.servlet.ServletResponse method*/
    throw new NotImplementedException("getLocale");
  }

  private class NotImplementedException extends UnsupportedOperationException {
    NotImplementedException(String methodName) {
      super((new MessageFormat("Method {0}() not yet implemented")).format(new String[] {methodName}));
    }
  }
}