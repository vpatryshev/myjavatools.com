package com.myjavatools.jsp;

import java.io.*;
import java.net.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

import org.apache.catalina.*;
import org.apache.catalina.connector.*;
import org.apache.catalina.session.*;
import org.apache.jasper.servlet.*;

public class Runner {
  final static boolean DEBUG = false;

  public static void runJsp(String jspName, Properties requestParameters) throws
      IOException, ServletException {
    runJsp(jspName, ".", getEnv(), requestParameters);
  }

  public static void runJsp(String jspName, String resourceBase, Properties requestParameters) throws
      IOException, ServletException {
    runJsp(jspName, resourceBase, getEnv(), requestParameters);
  }

  public static void runJsp(String jspName, Properties sessionAttributes, Properties requestParameters) throws
      IOException, ServletException {
    runJsp(jspName, ".", sessionAttributes, requestParameters);
  }

  public static void runJsp(String jspName, String resourceBase, Properties sessionAttributes, Properties requestParameters) throws
      IOException, ServletException {
    File base = new File(resourceBase);
    if (!base.isDirectory()) throw new IOException("Error: directory \"" + resourceBase + "\" not found.");

    String here = base.getAbsolutePath() + "/";

    File jspFile = new File(here, jspName);
    if (!jspFile.exists())  throw new IOException("Error: file \"" + jspName + "\" not found in " + here);
    if (!jspFile.isFile())  throw new IOException("Error: \"" + jspName + "\" is not a file.");
    if (!jspFile.canRead()) throw new IOException("Error: cannot read file " + jspName);

    if (!jspName.startsWith("/")) jspName = "/" + jspName;
    URL resourceBaseURL = new URL("file", "localhost", here.replace('\\', '/'));

    JspServlet jasper = new JspServlet();
    jasper.init(getServletConfig("jsp",
                                 new JspCServletContext(new PrintWriter(System.err),
                                                        resourceBaseURL),
                                 new Properties()));

    HttpServletRequest request   = new RunnerRequest(jspName,
                                                     requestParameters,
                                                     new RunnerSession(sessionAttributes));
    HttpServletResponse response = new RunnerResponse();
    jasper.service(request, response);
  }

  public static void main(String[] args) {
    try {
      Properties argmap = new Properties();
      String servletPath = null;
      String resourceBase = ".";

      for (int i = 0; i < args.length; i++) {
        if (DEBUG) System.out.println("" + i + "] " + args[i]);
        int equalsPos = args[i].indexOf('=');

        if (args[i].startsWith("-D") &&
                   equalsPos > 0) {
          argmap.put(args[i].substring(2, equalsPos), args[i].substring(equalsPos + 1));
        } else if (args[i].startsWith("-") &&
                   i < args.length - 1) {
          resourceBase = args[++i];
        } else {
          servletPath = args[i];
        }
      }

      runJsp(servletPath, resourceBase, argmap);

    } catch(Exception e) {
      System.err.println(e);
      System.exit(1);
    }
  }

  static ServletConfig getServletConfig(final String servletName,
                                        final ServletContext servletContext,
                                        final Properties initParameters) {
    return new ServletConfig() {
      public String getServletName() {
        return servletName;
      };
      public ServletContext getServletContext() {
        return servletContext;
      }
      public String getInitParameter(String name) {
        return (String)initParameters.get(name);
      }
      public Enumeration getInitParameterNames() {
        return initParameters.propertyNames();
      }
    };
  }

  public static Properties getargs(String[]args) {
    Properties result = new Properties();

    for (int i = 0; i < args.length; i++) {
      if (DEBUG) System.out.println("" + i + "] " + args[i]);
      int equalsPos = args[i].indexOf('=');

      if (args[i].startsWith("-D") &&
                 equalsPos > 0) {
        result.put(args[i].substring(2, equalsPos), args[i].substring(equalsPos + 1));
      } else {
        String servletPath = args[i];
        result.put(".", servletPath);
      }
    }
    return result;
  }

  static Properties getEnv() {
    Properties result = new Properties();
    String output = runCommand("env");

    if (output == null || output.startsWith("Error")) {
      output = runCommand("cmd /c set");
    }
    if (output == null) return result;
    output = output.replaceAll("\r\n", "\n");
    output = output.replaceAll("\r", "\n");
    String[] env = output.split("\n");

    for (int i = 0; i < env.length; i++) {
      String[] nv = env[i].split("=");
      if (nv.length > 1) {
        result.put(nv[0].trim(), nv[1].trim());
      }
    }
    return result;
  }

  static String runCommand(String command) {
    int exitValue = 0;

    try {
      Process process = Runtime.getRuntime().exec(command);
      StringWriter w = new StringWriter();

      while (true) {
        try {
          exitValue = process.exitValue();
          break;
        } catch (IllegalThreadStateException ie) {}

        try {
          if (process.getErrorStream().available() > 0) {
            pipe(process.getErrorStream(), w);
            return "Error_" + w.toString();
          }
          pipe(process.getInputStream(), w);
          Thread.sleep(500);
        } catch(Exception e) {}
      }
      if (w.getBuffer().length() > 0) {
        return w.toString();
      } else if (exitValue != 0) {
        return "Error_" + exitValue;
      } else {
        return null;
      }
    } catch (Exception e) {
      return "Error_" + e;
    }
//      return null;
  }

  static void pipe(InputStream in, Writer out) throws IOException {
    int c = 0;
    synchronized (in) {
      while(in.available() > 0) {
        c = in.read();
        out.write(c);
      }
    }
  }
}