package com.myjavatools.lib;

import junit.framework.*;
import java.io.*;
import java.util.*;
import java.util.regex.Pattern;

public class TestFiles
    extends TestCase {
  private Files files = null;

  public TestFiles(String name) {
    super(name);
  }

  protected void setUp() throws Exception {
    super.setUp();
    /**@todo verify the constructors*/
    files = new Files();
  }

  protected void tearDown() throws Exception {
    files = null;
    super.tearDown();
  }


      public static void assertEquals(String message, Object[] expectedArray, Object[] actualArray) {
        if (expectedArray == null) {
          assertNull(message + ": actual must be null", actualArray);
        }
        assertNotNull(message + ": ctual must not be null", actualArray);

        for (int i = 0; i < Math.max(expectedArray.length, actualArray.length); i++) {
          assertEquals(message + ": #" + i, expectedArray[i], actualArray[i]);
        }
      }

      public static void assertEquals(String message, byte[] expectedArray, byte[] actualArray) {
        if (expectedArray == null) {
          assertNull(message + ": actual must be null", actualArray);
        }
        assertNotNull(message + ": ctual must not be null", actualArray);

        for (int i = 0; i < Math.max(expectedArray.length, actualArray.length); i++) {
          assertEquals(message + ": #" + i, expectedArray[i], actualArray[i]);
        }
      }

      public static void assertEquals(String message, char[] expectedArray, char[] actualArray) {
        if (expectedArray == null) {
          assertNull(message + ": actual must be null", actualArray);
        }
        assertNotNull(message + ": ctual must not be null", actualArray);

        for (int i = 0; i < Math.max(expectedArray.length, actualArray.length); i++) {
          assertEquals(message + ": #" + i, expectedArray[i], actualArray[i]);
        }
      }


  public void testRelPath_1() {
    String expectedReturn = "src\\java";
    String actualReturn = files.relPath("c:\\MyHome\\dev", "c:\\MyHome\\dev\\src\\java");
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testRelPath_2() {
    String expectedReturn = "jbuilder8/samples/welcome";
    String actualReturn = files.relPath("/home/zaphod", "/home/zaphod/jbuilder8/samples/welcome");
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testRelPath_3() {
    String expectedReturn = "/home/ford/jbuilder8";
    String actualReturn = files.relPath("/home/zaphod", "/home/ford/jbuilder8");
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testSplitPath_1() {
    String[] expectedReturn = new String[] {".", "src.java"};
    String[] actualReturn = files.splitPath("src.java");
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testSplitPath_2() {
    String[] expectedReturn = new String[] {"/home/zaphod/jbuilder8/samples", "welcome"};
    String[] actualReturn = files.splitPath("/home/zaphod/jbuilder8/samples/welcome");
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testSplitPath_3() {
    String[] expectedReturn = new String[] {"MyHome", "dev"};
    String[] actualReturn = files.splitPath("MyHome\\dev");
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testDirname_1() {
    assertEquals("return value", "/home/zaphod/jbuilder8/samples", files.dirname("/home/zaphod/jbuilder8/samples/welcome"));
  }


  public void testDirname_2() {
    assertEquals("return value", "MyHome", files.dirname("MyHome\\dev"));
  }

  public void testDirname_3() {
    assertEquals("return value", ".", files.dirname("src.java"));
  }

  public void testFilename() {
    String path = "/home/zaphod/jbuilder8/samples/welcome";
    String expectedReturn = "welcome";
    String actualReturn = files.filename(path);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testPath_1() {
    assertEquals("return value", "c:\\MyHome\\dev\\src\\java", files.path("c:\\MyHome\\dev", "src\\java"));
  }

  public void testPath_2() {
    assertEquals("return value", "/home/zaphod/jbuilder8/samples/welcome", files.path("/root/inetd", "/home/zaphod/jbuilder8/samples/welcome"));
  }

  public void testPath_3() {
    assertEquals("return value", "c:\\MyHome\\dev", files.path("\\Program Files", "c:\\MyHome\\dev"));
  }

  public void testFind() {
    try {
      List expectedReturn = Arrays.asList(new String[] {new File("src\\com\\myjavatools\\lib\\Files.java").getCanonicalPath()});
      List actualReturn = files.find(new File("."), Pattern.compile("src.*les\\.java$"));
      assertEquals("return value", expectedReturn, actualReturn);
    } catch (Exception ex) {
      fail("problems: " + ex);
    }
  }

  public void testFind1() {
    try {
      List expectedReturn = Arrays.asList(new String[] {new File("src\\com\\myjavatools\\lib\\Files.java").getCanonicalPath()});
      List actualReturn = files.find(new File("."), Pattern.compile("src.*les\\.java$"));
      assertEquals("return value", expectedReturn, actualReturn);
    }
    catch (Exception ex) {
      fail("problems: " + ex);
    }
  }

  public void testFind2() {
    List expectedReturn = Arrays.asList(new String[] {new File("src\\com\\myjavatools\\lib\\Files.java").getAbsolutePath()});
    List actualReturn = files.find(".", "src.*les\\.java$");
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testLastModified() {
    File file = new File("src/com/myjavatools/lib/Objects.java");
    String expectedReturn = "Thu Mar 18 10:00:18 PST 2004";
    String actualReturn = files.lastModified(file);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testReadStringFromFile() {
    String filename = "src/com/myjavatools/lib/Objects.java";
    String expectedReturn = "/**\r\n * <p>Title: MyJavaTools: Objects Handling</p>\r\n *";
    String actualReturn = files.readStringFromFile(filename);
    int i = Strings.findDiff(expectedReturn, actualReturn);
    assertTrue(i == expectedReturn.length());
    assertTrue(actualReturn.startsWith(expectedReturn));
  }

  public void testReadBytesFromStream() {
    InputStream is = new ByteArrayInputStream(new byte[] {1, 2, 3, 4, 5});
    byte[] expectedReturn = new byte[] {1, 2, 3, 4, 5};
    byte[] actualReturn = files.readBytesFromStream(is);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testReadBytesFromFile() {
    String filename = "src/com/myjavatools/lib/Files.java";
    byte[] expectedReturn = new byte[] {47, 42, 42, 13, 10, 32, 42};
    byte[] actualReturn = new byte[7];
    System.arraycopy(files.readBytesFromFile(filename), 0, actualReturn, 0, 7);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testGetPackage() {
    String basePath = null;
    String currentPath = null;
    String expectedReturn = "com.myjavatools.util";
    String actualReturn = files.getPackageName("c:\\home\\myjavatools\\src", "c:\\home\\myjavatools\\src\\com\\myjavatools\\util");
    assertEquals("return value", expectedReturn, actualReturn);
    actualReturn = files.getPackageName("c:\\home\\myjavatools\\src\\java", "c:\\home\\myjavatools\\src\\com\\myjavatools\\util");
    assertNull("must be null", actualReturn);
  }

  public void testPipe() {
    try {
      InputStream is = new FileInputStream("src/com/myjavatools/lib/Files.java");
      ByteArrayOutputStream baos = new ByteArrayOutputStream();
      files.pipe(is, baos, true, new Files.ByteFilter() {
        public byte[] filter(byte[]data, int size) {
          byte[] result = new byte[(size+1)/2];
          for (int i = 0; i < size; i+=2) {
            result[i/2] = data[i];
          }

          return result;
        }
      });
      byte[] expectedReturn = new byte[] {47, 42, 10, 42, 60, 62, 105};
      byte[] actualReturn = new byte[7];
      System.arraycopy(baos.toByteArray(), 0, actualReturn, 0, 7);
      assertEquals("return value", expectedReturn, actualReturn);
    }
    catch (Exception ex) {
      fail("got exception " + Strings.toString(ex));
    }
  }

  public void testPipe1() {
    String sample =
        "Mare bella donna,\n" +
        "Che un bel canzone,\n" +
        "Sai, che ti amo, sempre amo.\n" +
        "Donna bella mare,\n" +
        "Credere, cantare,\n" +
        "Dammi il momento,\n" +
        "Che mi piace piu'!\n" +
        "\n\n" +
        "Uno, uno, uno, un momento,\n" +
        "Uno, uno, uno sentimento,\n" +
        "Uno, uno, uno complimento\n" +
        "E sacramento, sacramento, sacramento�";

    StringWriter w = new StringWriter();

    files.pipe(new StringReader(sample), w);
    assertEquals("output data", sample, w.toString());
  }

  public void testCopy1() {
    String expectedReturn = "/**\r\n * <p>Title: MyJavaTools: Objects Handling</p>\r\n *";
    files.copy("src/com/myjavatools/lib", "/tmp", "Objects.java");
    String actualReturn = files.readStringFromFile("/tmp/Objects.java");
    int i = Strings.findDiff(expectedReturn, actualReturn);
    assertTrue(i == expectedReturn.length());
    assertTrue(actualReturn.startsWith(expectedReturn));
  }

  public void testCopy2() {
    String expectedReturn = "/**\r\n * <p>Title: MyJavaTools: Objects Handling</p>\r\n *";
    files.copy(new File("src/com/myjavatools/lib"), new File("/tmp"), "Objects.java");
    String actualReturn = files.readStringFromFile("/tmp/Objects.java");
    int i = Strings.findDiff(expectedReturn, actualReturn);
    assertTrue(i == expectedReturn.length());
    assertTrue(actualReturn.startsWith(expectedReturn));
  }

  public void testCopyCompare() {
    try {
      String expectedReturn =
          "/**\r\n * <p>Title: MyJavaTools: Objects Handling</p>\r\n *";
      String filename1 = "src/com/myjavatools/lib/Objects.java";
      String filename2 = "/tmp/Objects.java";
      File file1 = new File(filename1);
      File file2 = new File(filename2);
      files.writeToFile(expectedReturn, filename2);
      assertEquals( -1, files.compare(file1, file2));
      assertEquals(1, files.compare(file2, file1));
      files.copy(filename1, filename2);
      assertEquals(0, files.compare(file1, file2));
      String actualReturn = files.readStringFromFile(filename2);
      int i = Strings.findDiff(expectedReturn, actualReturn);
      assertTrue(i == expectedReturn.length());
      assertTrue(actualReturn.startsWith(expectedReturn));
    }
    catch (IOException ex) {
      fail("got " + ex);
    }
  }

  public void testCopyAndCompare() {
    files.copy("src/com/myjavatools/lib", "/tmp/myjavatools/lib");
    String list1 = Strings.join(",", new File("src/com/myjavatools/lib", "myjavatools/lib").list());
    String list2 = Strings.join(",", new File("/tmp/myjavatools/lib",    "myjavatools/lib").list());
    assertEquals(list1, list2);
  }

  public void testSynchronize() {
    File folder1 = new File("src/com");
    File folder2 = new File("/tmp/myjavatools/tmp" + new Date().getTime());
    folder2.mkdirs();
    files.synchronize(folder1, folder2);
    String list1 = Strings.join(",", new File(folder1, "myjavatools/lib").list());
    String list2 = Strings.join(",", new File(folder2, "myjavatools/lib").list());
    assertEquals(list1, list2);
    files.deleteFile(folder2);
    assertFalse(folder2.isDirectory());
  }
}
