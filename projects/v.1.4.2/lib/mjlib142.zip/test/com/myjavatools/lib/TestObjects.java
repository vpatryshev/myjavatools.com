package com.myjavatools.lib;

import junit.framework.*;
import java.util.*;

public class TestObjects
    extends TestCase {
  private Objects objects = null;

  public TestObjects(String name) {
    super(name);
  }

  protected void setUp() throws Exception {
    super.setUp();
    /**@todo verify the constructors*/
    objects = null;
  }

  protected void tearDown() throws Exception {
    objects = null;
    super.tearDown();
  }

  public static void assertEquals(String message, Object[] expectedArray, Object[] actualArray) {
    if (expectedArray == null) {
      assertNull(message + ": actual must be null", actualArray);
    }
    assertNotNull(message + ": ctual must not be null", actualArray);

    for (int i = 0; i < Math.max(expectedArray.length, actualArray.length); i++) {
      assertEquals(message + ": #" + i, expectedArray[i], actualArray[i]);
    }
  }

  public static void assertEquals(String message, byte[] expectedArray, byte[] actualArray) {
    if (expectedArray == null) {
      assertNull(message + ": actual must be null", actualArray);
    }
    assertNotNull(message + ": ctual must not be null", actualArray);

    for (int i = 0; i < Math.max(expectedArray.length, actualArray.length); i++) {
      assertEquals(message + ": #" + i, expectedArray[i], actualArray[i]);
    }
  }

  public static void assertEquals(String message, char[] expectedArray, char[] actualArray) {
    if (expectedArray == null) {
      assertNull(message + ": actual must be null", actualArray);
    }
    assertNotNull(message + ": ctual must not be null", actualArray);

    for (int i = 0; i < Math.max(expectedArray.length, actualArray.length); i++) {
      assertEquals(message + ": #" + i, expectedArray[i], actualArray[i]);
    }
  }

  public void testAsMap() {
    Object[] pairs = new String[] {"1", "one", "2", "two", "3", "three"};
    java.util.Map expectedReturn = new HashMap();
    expectedReturn.put("1", "one");
    expectedReturn.put("2", "two");
    expectedReturn.put("3", "three");
    java.util.Map actualReturn = objects.asMap(pairs);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testCrc32() {
    byte[] data = new byte[] {1, 2, 3};
    long expectedReturn = 1438416925l;
    long actualReturn = objects.crc32(data);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testCrc321() {
    byte[] data = new byte[] {0, 1, 2, 3, 4};
    long expectedReturn = 1438416925l;
    int off = 1;
    int len = 3;
    long actualReturn = objects.crc32(data, off, len);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testIsEmpty() {
    assertTrue("return value", objects.isEmpty(null));
    assertTrue("return value", objects.isEmpty(new Long[]{}));
    assertTrue("return value", objects.isEmpty(new HashMap()));
    assertTrue("return value", objects.isEmpty(""));
    assertFalse("return value", objects.isEmpty(" "));
  }

  public void testMap() {
    java.util.Map m = new HashMap();
    m.put("a", "ValueOfA"); m.put("b", "ValueOfB"); m.put("c", "ValueOfC");
    List domain = Arrays.asList(new String[] {"b", "x", "b"});
    List expectedReturn = Arrays.asList(new String[] {"ValueOfB", null, "ValueOfB"});
    List actualReturn = objects.map(m, domain);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testMap1() {
    java.util.Map m = new HashMap();
    m.put("a", "ValueOfA"); m.put("b", "ValueOfB"); m.put("c", "ValueOfC");
    Collection domain = Arrays.asList(new String[] {"b", "x", "b"});
    Collection expectedReturn = Arrays.asList(new String[] {"ValueOfB", null, "ValueOfB"});
    Collection actualReturn = objects.map(m, domain);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testMap2() {
    Map m = new HashMap();
    m.put("a", "ValueOfA"); m.put("b", "ValueOfB"); m.put("c", "ValueOfC");
    String[] domain = new String[] {"b", "x", "b"};
    Object[] expectedReturn = new Object[] {"ValueOfB", null, "ValueOfB"};
    Object[] actualReturn = objects.map(m, domain);
    assertEquals("Return value", expectedReturn, actualReturn);
  }

  public void testMap3() {
    Map m = new HashMap();
    m.put("a", "ValueOfA"); m.put("b", "ValueOfB"); m.put("c", "ValueOfC");
    String[] domain = new String[] {"b", "x", "b"};
    Object defaultValue = "Johnny Doe";
    Object[] expectedReturn = new Object[] {"ValueOfB", "Johnny Doe", "ValueOfB"};
    Object[] actualReturn = objects.map(m, domain, defaultValue);
    assertEquals("Return value", expectedReturn, actualReturn);
  }

  public void testMap4() {
    Map m = new HashMap();
    m.put("a", "ValueOfA"); m.put("b", "ValueOfB"); m.put("c", "ValueOfC");
    String[] domain = new String[] {"b", "x", "b"};
    Object[] defaultValues = new String[] {"Johnny A", "Johnny Bee", "Johnny Doe"};
    Object[] expectedReturn = new Object[] {"ValueOfB", "Johnny Bee", "ValueOfB"};
    Object[] actualReturn = objects.map(m, domain, defaultValues);
    assertEquals("Return value", expectedReturn, actualReturn);
  }

  public void testCompose() {
    Map f = objects.toMap(new String[] {"1", "one", "2", "two", "3", "three"});
    Map g = objects.toMap(new String[] {"one", "uno", "two", "dos", "three", "tres"});
    Map composition = objects.compose(f, g);
    Map expected = objects.toMap(new String[] {"1", "uno", "2", "dos", "3", "tres"});
    assertEquals("Return value", expected, composition);
  }

  public void testInverse() {
    Map f = objects.toMap(new String[] {"1", "one", "2", "two", "3", "three"});
    Map expected = objects.toMap(new String[] {"one", "1", "two", "2", "three", "3"});
    try {
      Map inverse = objects.inverse(f);
      assertEquals("Return value", expected, inverse);
    } catch (InstantiationException e) {
      fail("got " + e + " - but must be invertible");
    }
    Map g = objects.toMap(new String[] {"John", "Doe", "Jack", "Rabbit", "Jane", "Doe"});
    try {
      objects.inverse(g);
      fail("Inverse does not exist");
    } catch (InstantiationException e) {
      // Correct, must throw this exception
    }
  }

  public void testToBytes() {
    char[] from = new char[] {0x0123, 0x4567, 0x89ab, 0xcdef};
    byte[] expectedReturn = new byte[]{0x23, 0x67, (byte)0xab, (byte)0xef};
    byte[] actualReturn = objects.toBytes(from);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testToBytes1() {
    long from = 0x0123456789abcdefl;
    byte[] expectedReturn = new byte[] {(byte)0xef, (byte)0xcd, (byte)0xab, (byte)0x89, 0x67, 0x45, 0x23, 0x01};
    byte[] actualReturn = objects.toBytes(from);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testToChars() {
    byte[] from = new byte[] {0x23, 0x67, (byte)0xab, (byte)0xef};
    char[] expectedReturn = new char[] {0x23, 0x67, 0xab, 0xef};
    char[] actualReturn = objects.toChars(from);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testIndexOf() {
    assertEquals("must be 1", 1, objects.indexOf("abc", new String[] {"123", "abc", "xyz"}));
    assertEquals("must be 2", 2, objects.indexOf(null,  new String[] {"123", "abc", null}));
  }

  public void testIndexOf1() {
    assertEquals("must be 1", 1, objects.indexOf("abc", new String[] {"abc", "abc", "xyz"}, 1));
    assertEquals("must be 2", 2, objects.indexOf(null,  new String[] {"123", "abc", null},  1));
  }

  public void testIndexOf2() {
    List list = new ArrayList();
    list.add("abc"); list.add("abc"); list.add("xyz"); list.add(null);
    assertEquals("must be 0", 0, objects.indexOf("abc", list));
    assertEquals("must be 3", 3, objects.indexOf(null, list));
    assertEquals("must be 1", 1, objects.indexOf("abc", list, 1));
    assertEquals("must be 3", 3, objects.indexOf(null,  list,  1));
  }

  public void testToMap1() {
    Map result = objects.toMap("first", "primero", "second", "segundo", "third", "tercero");
    assertEquals("must be three elements", 3, result.size());
    assertEquals("must be segundo", "segundo", result.get("second"));
  }

  public void testToMap2() {
    Map result = objects.toMap(new String[] {"1", "US", "7", "Russia", "49", "Germany", "1", "US"});
    assertEquals("must be three elements", 3, result.size());
    assertEquals("must be Germany", "Germany", result.get("49"));
  }
}
