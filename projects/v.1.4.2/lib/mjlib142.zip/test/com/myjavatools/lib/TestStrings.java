package com.myjavatools.lib;

import junit.framework.*;
import java.io.*;
import java.util.*;
import java.util.regex.PatternSyntaxException;
import java.util.regex.Pattern;
//import gnu.regexp.*;

public class TestStrings
    extends TestCase {
  private Strings strings = null;

  public TestStrings(String name) {
    super(name);
  }

  protected void setUp() throws Exception {
    super.setUp();
    /**@todo verify the constructors*/
    strings = null;
  }

  protected void tearDown() throws Exception {
    strings = null;
    super.tearDown();
  }

    public static void assertEquals(String message, Object[] expectedArray, Object[] actualArray) {
      if (expectedArray == null) {
        assertNull(message + ": actual must be null", actualArray);
      }
      assertNotNull(message + ": actual must not be null", actualArray);

      for (int i = 0; i < Math.max(expectedArray.length, actualArray.length); i++) {
        assertEquals(message + ": #" + i, expectedArray[i], actualArray[i]);
      }
    }

    public static void assertEquals(String message, byte[] expectedArray, byte[] actualArray) {
      if (expectedArray == null) {
        assertNull(message + ": actual must be null", actualArray);
      }
      assertNotNull(message + ": ctual must not be null", actualArray);

      for (int i = 0; i < Math.max(expectedArray.length, actualArray.length); i++) {
        assertEquals(message + ": #" + i, expectedArray[i], actualArray[i]);
      }
    }

    public static void assertEquals(String message, char[] expectedArray, char[] actualArray) {
      if (expectedArray == null) {
        assertNull(message + ": actual must be null", actualArray);
      }
      assertNotNull(message + ": ctual must not be null", actualArray);

      for (int i = 0; i < Math.max(expectedArray.length, actualArray.length); i++) {
        assertEquals(message + ": #" + i, expectedArray[i], actualArray[i]);
      }
    }



  public void testCountTrailingSpaces() {
    String s = null;
    int expectedReturn = 3;
    int actualReturn = strings.countTrailingSpaces(" this is a string   ");
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testToSgmlEncoding() {
    String s = "<i>Feliz A�o Nuevo</i>\n";
    String expectedReturn = "&lt;i&gt;Feliz A&#241;o Nuevo&lt;/i&gt;\n";
    String actualReturn = strings.toSgmlEncoding(s);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testHtmlEncode() {
    String s = "<i>Feliz A�o Nuevo</i>\n";
    String expectedReturn = "&lt;i&gt;Feliz A&#241;o Nuevo&lt;/i&gt;\n";
    String actualReturn = strings.toSgmlEncoding(s);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testUnpack() {
    String string = "\u2367\uabef";
    byte[] expectedReturn = new byte[] {0x23, 0x67, (byte)0xab, (byte)0xef};
    byte[] actualReturn = strings.unpack(string);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testDecode() throws IOException, UnsupportedEncodingException {
    byte[] bytes = new byte[] {0x41, (byte)0xc3, (byte)0xb1, 0x6f, 0x20, 0x4e, 0x75, 0x65, 0x76, 0x6f};
    String expectedReturn = "A�o Nuevo";
    String actualReturn = strings.decode(bytes, "UTF8");
    assertEquals("return value", expectedReturn, actualReturn);
    bytes = new byte[] {0x41, (byte)0x96, 0x6f, 0x20, 0x4e, 0x75, 0x65, 0x76, 0x6f};
    actualReturn = strings.decode(bytes, "MacRoman");
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testToHex() {
    char ch = '\u00af';
    String expectedReturn = "00af";
    String actualReturn = strings.toHex(ch);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testToReadable() {
    String s = "\t�Hola se�or!\n";
    String expectedReturn = "..Hola se.or!.";
    String actualReturn = strings.toReadable(s);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testToReadable1() {
    String s = "\t�Hola se�or!\n";
    String expectedReturn = "Hola se.or";
    String actualReturn = strings.toReadable(s.toCharArray(), 2, 12);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testUnzip() throws IOException, UnsupportedEncodingException {
    String zippedString = "\u78da\uf348\ucdc9\uc957\u08cf\u2fca\u4901\u0018\u0b04\u1d00";
    String expectedReturn = "Hello World";
    String actualReturn = strings.unzip(zippedString);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testToHexReadable() {
        byte[] data = new byte[] {1, 2, 48};
    String expectedReturn = "01 02 30 \r\n";
    String actualReturn = strings.toHexReadable(data);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testAsProperties() {
        String[] pairs = new String[] {"1", "one", "2", "two", "3", "three"};
    Properties expectedReturn = new Properties();
    expectedReturn.setProperty("1", "one");
    expectedReturn.setProperty("2", "two");
    expectedReturn.setProperty("3", "three");
    Properties actualReturn = strings.asProperties(pairs);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testFormat2() {
    String expectedReturn = "Life is struggle";
    String actualReturn = strings.format("{0} is {1}", "Life", "struggle");
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testGrep() throws PatternSyntaxException {
    String[] source = new String[] {"good", "bad", "ugly"};
    String regexp = "g.";
    List expectedReturn = new ArrayList();
    expectedReturn.add("good");
    expectedReturn.add("ugly");
    List actualReturn = strings.grep(source, regexp);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testToPropertiesEncoding() {
    assertEquals("return value", strings.toPropertiesEncoding('\u00af', false), "\\u00af");
    assertEquals("return value", strings.toPropertiesEncoding('\u00af', true), "\\u00AF");
    assertEquals("return value", strings.toPropertiesEncoding('a', false), "a");
  }

  public void testTextHeight() {
    assertEquals("return value", 3, strings.textHeight("One\nTwo\nThree"));
    assertEquals("return value", 5, strings.textHeight("\nOne\nTwo\nThree\n"));
  }

  public void testJoin() {
    assertEquals("return value", "1, 555", strings.join(", ", new Long[] {new Long(1), new Long(555)}));
    assertEquals("return value", "Here and there and everywhere", strings.join(" and ", new String[] {"Here", "there", "everywhere"}));
  }

  public void testHasAlpha() {
    assertTrue("return value", strings.hasAlpha("2OO2"));
    assertTrue("return value", strings.hasAlpha("This is a string"));
    assertFalse("return value", strings.hasAlpha("+"));
    assertFalse("return value", strings.hasAlpha("1900"));
    assertFalse("return value", strings.hasAlpha("|1!*"));
  }

  public void testSplit() {
    String source = "a:ab:abcde:";
    String separator = ":";
    List expectedReturn = new ArrayList();
    expectedReturn.add("a");
    expectedReturn.add("ab");
    expectedReturn.add("abcde");
    expectedReturn.add("");

    List actualReturn = strings.split(separator, source);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testToCEncoding() {
    assertEquals("return value", "\\nFeliz A\\xf1o Nuevo\\n", strings.toCEncoding("\nFeliz A�o Nuevo\n"));
  }

  public void testToJavaEncoding() {
    assertEquals("return value", "\\nFeliz A\\u00f1o Nuevo\\n\\0", strings.toJavaEncoding("\nFeliz A�o Nuevo\n\0"));
  }

  public void testDecodeJavaString() {
    assertEquals("return value", "This is a string", strings.decodeJavaString("This is a string"));
    String expected = strings.decodeJavaString("\\nFeliz A\\u00F1o Nuevo\\n");
    assertEquals("return value", "\nFeliz A�o Nuevo\n", expected);
  }

  public void testZip() throws IOException, UnsupportedEncodingException {
    String source = "Hello World";
    String expectedReturn = "\u78da\uf348\ucdc9\uc957\u08cf\u2fca\u4901\u0018\u0b04\u1d00";
    String actualReturn = strings.zip(source);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testCrc32() throws IOException, UnsupportedEncodingException {
    String string = "Hello World";
    long expectedReturn = 2178450716l;
    long actualReturn = strings.crc32(string);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testHexDump() {
        char[] data = new char[] {1, 'a', 'b', '\n', 'c'};
        String expectedReturn = "\r\n0000: 0001 0061 0062 000a 0063                                                        | .ab.c\r\n";
    String actualReturn = strings.hexDump(data);
    int diffidx = strings.findDiff(expectedReturn, actualReturn);
    assertEquals("difference", -1, diffidx);
  }

  public void testFormat3() {
        assertEquals("return value", "2 + 2 = 5",
                     strings.format("{0} + {1} = {2}", new Byte((byte)2), new Byte((byte)2), new Long(5)));
  }

  public void testCountLeadingSpaces() {
    assertEquals("return value", 1, strings.countLeadingSpaces(" this is a string   "));
  }

  public void testToJavaEncoding1() {
    assertEquals("return value", "\\nFeliz A\\u00f1o Nuevo\\n\\16", strings.toJavaEncoding("\nFeliz A�o Nuevo\n\u000e"));
  }

  public void testToJavaHexEncoding() {
    assertEquals("return value", "\\u00af", strings.toJavaHexEncoding('\u00af', false));
  }

  public void testToJavaHexEncoding1() {
    assertEquals("return value", "\\u00af", strings.toJavaHexEncoding('\u00af'));
  }

  public void testToJavaOctalEncoding() {
    assertEquals("return value", "\\1", strings.toJavaOctalEncoding('\u0001'));
    assertEquals("return value", "\\14", strings.toJavaOctalEncoding('\u000c'));
    assertEquals("return value", "\\377", strings.toJavaOctalEncoding('\u00ff'));
  }

  public void testExtractValue1() {
    String expectedReturn = "abcd";
    String actualReturn = strings.extractValue("java.home=\"c:\\java\\jdk1.4.1\"\nx=\"abcd\"", "x");
    assertEquals("return value", expectedReturn, actualReturn);
  }
  public void testExtractValue2() {
    String expectedReturn = "c:\\java\\jdk1.4.1";
    String actualReturn = strings.extractValue(
          "java.home=\"c:\\java\\jdk1.4.1\"\nx=\"abcd\"", "java.home");
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testJoin1() {
    assertEquals("return value", "", strings.join(", ", (Collection)null));
    assertEquals("return value", "", strings.join(":", new HashSet()));
  }

  public void testJoin2() {
    String separator = ", ";
    List list = new ArrayList(); list.add("entry1"); list.add("entry2");
    String expectedReturn = "entry1, entry2";
    String actualReturn = strings.join(separator, list);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testToHexReadable1() {
    String actual = strings.toHexReadable(new char[] {1, 'a', 'b', '\n', 'c'});
    String expected = "0001 0061 0062 000a 0063 \r\n";
    int diffidx = strings.findDiff(actual, expected);
    assertEquals("return value", expected, actual);
  }

  public void testHexDump1() {
    String data = "\u0001ab\nc";
    String expectedReturn = "\r\n0000: 0001 0061 0062 000a 0063                                                        | .ab.c\r\n";
    String actualReturn = strings.hexDump(data);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testToHexReadable2() {
    byte[] data = new byte[] {1, 2, 48};
    String expectedReturn = "02 30 \r\n";
    String actualReturn = strings.toHexReadable(data, 1, 3);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testToJavaEncoding2() {
    assertEquals("return value", "\\u00af", strings.toJavaEncoding('\u00af', false));
    assertEquals("return value", "\\u00AF", strings.toJavaEncoding('\u00af', true));
    assertEquals("return value", "\\n",     strings.toJavaEncoding('\n', true));
    assertEquals("return value", "\\16",     strings.toJavaEncoding('\16', true));
    assertEquals("return value", "\\0",     strings.toJavaEncoding('\0', true));
    assertEquals("return value", "a",       strings.toJavaEncoding('a',      true));
  }

  public void testCountChar() {
    assertEquals("return value", 3, strings.countChar("Goodness me, a clock has struck", 'o'));
  }

  public void testToJavaEncoding3() {
    String actual;
    assertEquals("return value", "\\u00af", strings.toJavaEncoding('\u00af', false, false));
    actual = strings.toJavaEncoding('\u00af', true, true);
    assertEquals("return value", "\\u00AF", actual);
    assertEquals("return value", "\\12",    strings.toJavaEncoding('\n',     false, false));
    assertEquals("return value", "\\n",     strings.toJavaEncoding('\n',     true,  true));
    assertEquals("return value", "a",       strings.toJavaEncoding('a',      true));
  }

  public void testSgmlEntity() {
    assertEquals("return value", "&#24747;",    strings.sgmlEntity('\u60ab'));
    assertEquals("return value", "&amp;",    strings.sgmlEntity('&'));
    assertEquals("return value", "&lt;",     strings.sgmlEntity('<'));
    assertEquals("return value", null,       strings.sgmlEntity('X'));
    assertEquals("return value", null,       strings.sgmlEntity('\n'));
  }

  public void testHexDump2() {
    byte[] data = new byte[] {1, 'a', 'b', '\n', 'c'};
    String expectedReturn = "\r\n0000: 01 61 62 0a 63                                  | \u00b7 a b \u00b7 c \r\n";
    String actualReturn = strings.hexDump(data);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testToHex1() {
    assertEquals("return value", "4d2", strings.toHex(1234));
  }

  public void testToStrings() {
    Object object = new Object[] { new Integer(22), new Boolean(false), "wow"};
    String[] expectedReturn =  new String[] {"22", "false", "wow"};
    String[] actualReturn = strings.toStrings(object);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testPack() {
    String expectedReturn = "\u2367\uabef";
    String actualReturn = strings.pack(new byte[] {0x23, 0x67, (byte)0xab, (byte)0xef});
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testGrep1() {
    String[] source = new String[] {"good", "bad", "ugly"};

    Pattern regexp = null;
    try {
      regexp = Pattern.compile("g.");
    }
    catch (PatternSyntaxException ex) {
      fail(ex.toString());
    }
    List expectedReturn = new ArrayList();
    expectedReturn.add("good");
    expectedReturn.add("ugly");
    List actualReturn = strings.grep(source, regexp);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testToHexReadable3() {
    String s = "\u0001ab\nc";
    String expectedReturn = "0001 0061 0062 000a 0063 \r\n";
    String actualReturn = strings.toHexReadable(s);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testNeedsEncoding() {
    assertTrue("return value", strings.needsEncoding('\u00af'));
    assertFalse("return value", strings.needsEncoding('a'));
  }

  public void testFill() {
    String actualReturn = strings.fill('*', 10);
    assertEquals("return value", "**********", actualReturn);
  }

  public void testOneOf3() {
    assertEquals("return value", "xyz", strings.oneOf(null, "", "xyz"));
    assertEquals("return value", "abc", strings.oneOf("abc", null, "xyz"));
    assertEquals("return value", "def", strings.oneOf("", "def", null));
    assertEquals("return value", "",    strings.oneOf("", null, ""));
  }

  public void testToJavaEncoding4() {
    assertEquals("return value", "\\u00af", strings.toJavaEncoding('\u00af'));
    assertEquals("return value", "\\n",     strings.toJavaEncoding('\n'));
    assertEquals("return value", "a",       strings.toJavaEncoding('a'));
  }

  public void testZip2bytes() throws IOException, UnsupportedEncodingException {
    String source = "Hello World";
    byte[] expectedReturn = new byte[] {0x78, (byte)0xda, (byte)0xf3, 0x48, (byte)0xcd, (byte)0xc9, (byte)0xc9, 0x57, (byte)0x08, (byte)0xcf, 0x2f, (byte)0xca, 0x49, 0x01, 0x00, 0x18, 0x0b, 0x04, 0x1d, 0x00};
    byte[] actualReturn = strings.zip2bytes(source);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testToHex2() {
    assertEquals("return value", "12BC", strings.toHex('\u12bc', true));
    assertEquals("return value", "00af", strings.toHex('\u00af', false));
  }

  public void testFormat1() {
    assertEquals("return value", "12 Monkeys", strings.format("{0} Monkeys", new Long(12)));
  }

  public void testToHex3() {
    assertEquals("return value", "9b", strings.toHex((byte)155));
  }

  public void testNeedsEncoding1() {
    assertTrue("return value", strings.needsEncoding("Feliz A�o Nuevo"));
    assertFalse("return value", strings.needsEncoding("Feliz Navedad"));
  }

  public void testOneOf4() {
    assertEquals("return value", "xyz", strings.oneOf(null, "", null, "xyz"));
    assertEquals("return value", "abc", strings.oneOf("abc", null, "pqr", "xyz"));
    assertEquals("return value", "def", strings.oneOf("", "def", null, "xyz"));
    assertEquals("return value", null,  strings.oneOf("", null, "", null));
  }

  public void testUnzip1() throws IOException, UnsupportedEncodingException {
    byte[] zippedBytes = new byte[] {0x78, (byte)0xda, (byte)0xf3, 0x48, (byte)0xcd, (byte)0xc9, (byte)0xc9, 0x57, 0x08, (byte)0xcf, 0x2f, (byte)0xca, 0x49, 0x01, 0x00, 0x18, 0x0b, 0x04, 0x1d, 0x00};
    String expectedReturn = "Hello World";
    String actualReturn = strings.unzip(zippedBytes);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testToHex4() {
    assertEquals("return value", "006B006C12BC", strings.toHex("kl\u12bc", true));
    assertEquals("return value", "006b006c12bc", strings.toHex("kl\u12bc", false));
  }

  public void testToCEncoding1() {
    assertEquals("return value", "\\xabcd", strings.toCEncoding('\uabcd'));
    assertEquals("return value", "\\xaf",   strings.toCEncoding('\u00af'));
    assertEquals("return value", "\\n",     strings.toCEncoding('\n'));
    assertEquals("return value", "a",       strings.toCEncoding('a'));
  }

  public void testIsAlpha() {
    assertTrue("must be alpha", strings.isAlpha('a'));
    assertTrue("must be alpha", strings.isAlpha('O'));
    assertTrue("must be alpha", strings.isAlpha('I'));
    assertTrue("must be alpha", strings.isAlpha('l'));
    assertFalse("can't be alpha", strings.isAlpha('+'));
    assertFalse("can't be alpha", strings.isAlpha('0'));
    assertFalse("can't be alpha", strings.isAlpha('|'));
    assertFalse("can't be alpha", strings.isAlpha('1'));
  }

  public void testOneOf2() {
    assertEquals("return value", "xyz", strings.oneOf(null, "xyz"));
    assertEquals("return value", "abc", strings.oneOf("abc", "xyz"));
    assertEquals("return value", null, strings.oneOf("", null));
    assertEquals("return value", "abc", strings.oneOf("abc", null));
  }

  public void testTextWidth() {
    assertEquals("return value", 5, strings.textWidth("One\nTwo\nThree"));
  }

  public void testToJavaEncoding5() {
    String actual = strings.toJavaEncoding("\nFeliz A�o Nuevo\n", true, false);
    assertEquals("return value", "\\12Feliz A\\u00F1o Nuevo\\12", actual);
    assertEquals("return value", "\\nFeliz A\\u00F1o Nuevo\\n", strings.toJavaEncoding("\nFeliz A�o Nuevo\n", true, true));
    assertEquals("return value", "\\nFeliz A\\u00f1o Nuevo\\n", strings.toJavaEncoding("\nFeliz A�o Nuevo\n", false, true));
  }

  public void testZip8bit() throws IOException, UnsupportedEncodingException {
    String expectedReturn = "x\u00da\u00f3H\u00cd\u00c9\u00c9W\b\u00cf/\u00caI\u0001\u0000\u0018\u000b\u0004\u001d\u0000";
    String actualReturn = strings.zip8bit("Hello World");
    assertEquals("return value", expectedReturn, actualReturn);
    /**@todo fill in the test code*/
  }

  public void testIsVowel() {
    assertFalse("can't be alpha", strings.isVowel('x'));
    assertTrue("must be alpha", strings.isVowel('U'));
  }

  public void testEncode() throws IOException, UnsupportedEncodingException {
    String s = "A�o Nuevo";
    String encoding = null;
    byte[] expectedReturn =  new byte[] {0x41, (byte)0xc3, (byte)0xb1, 0x6f, 0x20, 0x4e, 0x75, 0x65, 0x76, 0x6f};
    byte[] actualReturn = strings.encode(s, "UTF8");
    assertEquals("return value", expectedReturn, actualReturn);
    expectedReturn = new byte[] {0x41, (byte)0x96, 0x6f, 0x20, 0x4e, 0x75, 0x65, 0x76, 0x6f};
    actualReturn   = strings.encode("A�o Nuevo", "MacRoman");
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testWordCount() {
    assertEquals("return value", 3, strings.wordCount("This is life!"));
    assertEquals("return value", 4, strings.wordCount("C'est la vie !"));
  }

  public void testIndexOf1() {
    String t1 = "ABCDefghDB";
    assertEquals(strings.indexOf(t1, 'A', 0), t1.indexOf('A', 0));
    assertEquals(strings.indexOf(t1, 'A', 1), t1.indexOf('A', 1));
    for (int i = 0; i < 10; i++) {
      assertEquals(strings.indexOf(t1, 'B', i), t1.indexOf('B', i));
    }
  }

  public void testIndexOf2() {
    String t1 = "ABCDefghDB";
    String t2 = "ABCDefghijk";
    for (int i = 0; i < t2.length(); i++) {
      assertEquals(strings.indexOf(t1, t2.charAt(i)),
                        t1.indexOf(    t2.charAt(i)));
    }
  }

  public void testLastIndexOf() {
    String t1 = "ABCDefghDB";
    String t2 = "ABCDefghijk";
    for (int i = 0; i < t2.length(); i++) {
      assertEquals(strings.lastIndexOf(t1, t2.charAt(i)),
                        t1.lastIndexOf(    t2.charAt(i)));
    }
  }

  public void testIndexOf3() {
    String t1 = "ABCDefghDABCdefAB";
    String t2 = "ABC";
    for (int i = 0; i < 20; i++) {
      assertEquals(strings.indexOf(t1, t2, i),
                        t1.indexOf(    t2, i));
    }
  }

  public void testIndexOf4() {
    String t1 = "ABCDefghDABCdefAB";
    String t2 = 'x' + t1 + 'y';
    for (int i = 0; i < 20; i++) {
      for (int j = i; j < 20; j++) {
        if (strings.indexOf(t1, t2.subSequence(i, j)) !=
                     t1.indexOf(t2.substring(i, j))) {
                   int k = strings.indexOf(t1, t2.subSequence(i, j));
                   System.out.println("oops");
        }
        assertEquals(strings.indexOf(t1, t2.subSequence(i, j)),
                     t1.indexOf(t2.substring(i, j)));
      }
    }
  }

  public void testIsAlmostEmpty() {
    assertTrue("must be almost empty", strings.isAlmostEmpty(""));
    assertTrue("must be almost empty", strings.isAlmostEmpty(null));
    assertTrue("must be almost empty", strings.isAlmostEmpty("\n   \r \n"));
    assertFalse("must be non-empty",   strings.isAlmostEmpty("."));
    assertFalse("must be non-empty",   strings.isAlmostEmpty("Contains data!"));
  }

  public void testToSgmlEncoding1() {
    assertEquals("return value", "&#10;", strings.toSgmlEncoding('\n'));
  }

  public void testReplace() {
    String where = null;
    String oldSubstring = null;
    String newSubstring = null;
    boolean all = false;
    String expectedReturn = null;
    String actualReturn = strings.replace(where, oldSubstring, newSubstring,
                                          all);
    assertEquals("return value", expectedReturn, actualReturn);
    assertEquals("return value", "God hates you", strings.replace("God loves you", "love", "hate", true));
    assertEquals("return value", "All you need is me, love!", strings.replace("All you need is love, love!", "love", "me", false));
  }

  public void testToPropertiesEncoding1() {
    assertEquals("return value", strings.toPropertiesEncoding('\u00af'), "\\u00af");
    assertEquals("return value", strings.toPropertiesEncoding('a'), "a");
  }

  public void testToString() {
    String s = null;
    String expected = "java.lang.NullPointerException\r\n" +
    "\tat com.myjavatools.lib.TestStrings";

    try {
      s.toString();
      s = "?";
    } catch (Exception e) {
      String returned = strings.toString(e);
      assertTrue("returnValue is " + returned, returned.startsWith(expected));
    }
    assertNull(s);
  }
}
