/**
 *
 * <p>Title: MyJavaTools: String Tools</p>
 * <p>Description: String handling tools. Good for Java 1.3.1 and up.</p>
 * <p>Copyright: This is public domain;
 * The right of people to use, distribute, copy or improve the contents of the
 * following may not be restricted.</p>
 *
 * @author Vlad Patryshev
 * @version 1.3.1
 */

package com.myjavatools.lib;
import java.io.*;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.zip.*;
import gnu.regexp.*;

public class Strings extends Objects
{
  protected Strings() {}

  /**
   * Checks whether a string does not contain anything except whitespaces and the like.
   *
   * @param s the string to check
   * @return true if empty
   *
   * <br><br><b>Examples</b>:
   * <li><code>isAlmostEmpty(""), isAlmostEmpty(null), isAlmostEmpty("\n   \r \n")</code> all return <b>true</b>;</li>
   * <li><code>isAlmostEmpty("."), isAlmostEmpty("Contains data!")</code> returns <b>false</b>.</li>
   */
  public static final boolean isAlmostEmpty(Object o) {
    if (isEmpty(o)) return true;
    String s = o.toString();
    for (int i = 0; i < s.length(); i++) {
      if (s.charAt(i) > ' ') return false;
    }
    return true;
  }

  /**
   * Chooses a non-empty string out of two.
   *
   * @param s1 the first candidate string
   * @param s2 the second candidate string
   * @return the first one that is not empty
   *
   * <br><br><b>Examples</b>:
   * <li><code>oneOf(null, "xyz")</code> returns "xyz";</li>
   * <li><code>oneOf("abc", "xyz")</code> returns "abc";</li>
   * <li><code>oneOf("", null)</code> return null;</li>
   * <li><code>oneOf("abc", null)</code> returns "abc".</li>
   */
  public static final String oneOf(Object s1, Object s2) {
    return !isEmpty(s1) ? s1.toString() : s2 == null ? null : s2.toString();
  }

  /**
   * Chooses a non-empty string out of three.
   *
   * @param s1 the first candidate string
   * @param s2 the second candidate string
   * @param s3 the third candidate string
   * @return the first one that is not empty
   *
   * <br><br><b>Examples</b>:
   * <li><code>oneOf(null, "", "xyz")</code> returns "xyz";</li>
   * <li><code>oneOf("abc", null, "xyz")</code> returns "abc";</li>
   * <li><code>oneOf("", "def", null)</code> returns "def";</li>
   * <li><code>oneOf("", null, "")</code> returns "".</li>
   */
  public static final String oneOf(Object s1, Object s2, Object s3) {
    return !isEmpty(s1) ? s1.toString() :
           !isEmpty(s2) ? s2.toString() :
           s3   == null ? null : s3.toString();
  }

  /**
   * Chooses a non-empty string out of four.
   *
   * @param s1 the first candidate string
   * @param s2 the second candidate string
   * @param s3 the third candidate string
   * @param s4 the fourth candidate string
   * @return the first one that is not empty
   *
   * <br><br><b>Examples</b>:
   * <li><code>oneOf(null, "", null, "xyz")</code> returns "xyz";</li>
   * <li><code>oneOf("abc", null, "pqr", "xyz")</code> returns "abc";</li>
   * <li><code>oneOf("", "def", null, "xyz")</code> returns "def";</li>
   * <li><code>oneOf("", null, "", null)</code> returns null.</li>
   */
  public static final String oneOf(Object s1, Object s2, Object s3, Object s4) {
    return !isEmpty(s1) ? s1.toString() :
           !isEmpty(s2) ? s2.toString() :
           !isEmpty(s3) ? s3.toString() :
           s4   == null ? null : s4.toString();
  }

  private static final String ALPHA = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVXYZ";

  /**
   * Checks whether a character is a latin letter.
   *
   * @param c character to check
   * @return true if it is so
   *
   * <br><br><b>Examples</b>:
   * <li><code>isAlpha('a'), isAlpha('O'), isAlpha('I'), isAlpha('l')</code> return <b>true</b>;</li>
   * <li><code>isAlpha('+'), isAlpha('0'), isAlpha('|'), isAlpha('1')</code> return <b>false</b>.</li>
   */
  public static boolean isAlpha(char c) {
    return ALPHA.indexOf(c) >= 0;
  }

  /**
   * Checks whether a character is a latin vowel.
   *
   * @param c the char to tests
   * @return true if the character is one of "aeiaouAEIAOU"
   */
  public static boolean isVowel(char c) {
    return "aeiouAEIOU".indexOf(c) >= 0;
  }

  /**
   * Checks whether a string contains any latin letters.
   *
   * @param s string to check
   * @return true if it is so
   *
   * <br><br><b>Examples</b>:
   * <li><code>hasAlpha("a"), hasAlpha("2OO2"), hasAlpha("This is a string")</code> return <b>true</b>;</li>
   * <li><code>hasAlpha("+"), hasAlpha("1900"), hasAlpha("|1!*")</code> return <b>false</b>.</li>
   */
  public static boolean hasAlpha(String s) {
    for (int i = 0; i < s.length(); i++) {
      if (isAlpha(s.charAt(i))) return true;
    }
    return false;
  }

  /**
   * Counts the number of occurrences of char c in String s.
   *
   * @param s the string to scan
   * @param c the character to count
   * @return the number of occurrences
   *
   * <br><br><b>Example</b>:
   * <li><code>countChar("Goodness me, a clock has struck", 'o')</code> returns 3.</li>
   */
  public static final int countChar(String s, char c) {
    int n = 0;
    for (int i = s.indexOf(c); i >= 0; i=s.indexOf(c, i+1)) n++;
    return n;
  }

  /**
   * Calculates how many lines the text contains.
   * Lines are supposed to be separated by '\n' character.
   *
   * @param s the string with text
   * @return number of lines in the string (separated by '\n')
   *
   * <br><br><b>Examples</b>:
   * <li><code>textHeight("One\nTwo\nThree")</code> returns 3;</li>
   * <li><code>textHeight("\nOne\nTwo\nThree\n")</code> returns 5.</li>
   */
  public static final int textHeight(String s) {
    return countChar(s, '\n') + 1;
  }

  /**
   * Calculates how many horizontal positions will the text take in a textarea.
   * This is the maximum line length for all lines in the text.
   * Lines are separated by '\n' character.
   *
   * @param s the string with text
   * @return maximum line length in the text
   *
   * <br><br><b>Example</b>:
   * <li><code>textWidth("One\nTwo\nThree")</code> returns 5.</li>
   */
  public static final int textWidth(String s) {
    int n = 1;
    int curPos = 0;
    while (curPos < s.length()) {
      int nextPos = s.indexOf('\n', curPos);
      if (nextPos < 0) nextPos = s.length();
      if (n < nextPos - curPos) n = nextPos - curPos;
      curPos = nextPos+1;
    }
    return n;
  }

  /**
   * Calculates the number of words in the string.
   * This is just the number of tokens separated by default separators.
   *
   * @param s the string to analyze
   * @return number of words
   *
   * <br><br><b>Examples</b>:
   * <li><code>wordCount("This is life!")</code> returns 3;</li>
   * <li><code>wordCount("C'est la vie !")</code> returns 4, but for a wrong reason.</li>
   */
  public static final int wordCount(String s) {
    return (new StringTokenizer(s)).countTokens();
  }

  /**
   * "fast int to string hex" conversion array
   */
  private static final String[] HEX = {
      "00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "0a", "0b", "0c", "0d", "0e", "0f",
      "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "1a", "1b", "1c", "1d", "1e", "1f",
      "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "2a", "2b", "2c", "2d", "2e", "2f",
      "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "3a", "3b", "3c", "3d", "3e", "3f",
      "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "4a", "4b", "4c", "4d", "4e", "4f",
      "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "5a", "5b", "5c", "5d", "5e", "5f",
      "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "6a", "6b", "6c", "6d", "6e", "6f",
      "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "7a", "7b", "7c", "7d", "7e", "7f",
      "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "8a", "8b", "8c", "8d", "8e", "8f",
      "90", "91", "92", "93", "94", "95", "96", "97", "98", "99", "9a", "9b", "9c", "9d", "9e", "9f",
      "a0", "a1", "a2", "a3", "a4", "a5", "a6", "a7", "a8", "a9", "aa", "ab", "ac", "ad", "ae", "af",
      "b0", "b1", "b2", "b3", "b4", "b5", "b6", "b7", "b8", "b9", "ba", "bb", "bc", "bd", "be", "bf",
      "c0", "c1", "c2", "c3", "c4", "c5", "c6", "c7", "c8", "c9", "ca", "cb", "cc", "cd", "ce", "cf",
      "d0", "d1", "d2", "d3", "d4", "d5", "d6", "d7", "d8", "d9", "da", "db", "dc", "dd", "de", "df",
      "e0", "e1", "e2", "e3", "e4", "e5", "e6", "e7", "e8", "e9", "ea", "eb", "ec", "ed", "ee", "ef",
      "f0", "f1", "f2", "f3", "f4", "f5", "f6", "f7", "f8", "f9", "fa", "fb", "fc", "fd", "fe", "ff",
  };

  /**
   * Converts a byte to hex string.
   *
   * @param b the byte
   * @return b representation as a two-character hex string
   *
   * <br><br><b>Example</b>:
   * <li><code>toHex(155)</code> returns "9b".</li>
   */
  public static String toHex(byte b) {
    int i = b;
    return HEX[(i&255)];
  }

  /**
   * Converts an integer to hex string. It is the same as Integer.toHexString().
   *
   * @param i the integer
   * @return i representation as a hex string
   *
   * <br><br><b>Example</b>:
   * <li><code>toHex(1234)</code> returns "4d2".</li>
   */
  public static String toHex(int i) {
    return Integer.toHexString(i);
  }

  /**
   * Converts a char to hex string
   *
   * @param ch the char
   * @param up if true, use upper case, otherwise lower
   * @return i representation as a four-character hex string
   *
   * <br><br><b>Examples</b>:
   * <li><code>toHex('\u005cu12bc', true)</code> returns "12BC";</li>
   * <li><code>toHex('\u005cu00af', false)</code> returns "00af".</li>
   */
  public static String toHex(char ch, boolean up) {
    String hex = "0000" + Integer.toHexString(ch);
    if (up) hex = hex.toUpperCase();
    return hex.substring(hex.length() - 4);
  }

  /**
   * Converts a char to hex string
   *
   * @param ch the char
   * @return a four-character string (lower case)
   *
   * <br><br><b>Example</b>:
   * <li><code>toHex('\u005cu00af')</code> returns "00af".</li>
   */
  public static String toHex(char ch) {
    return toHex(ch, false);
  }

  /**
   * Converts a string to hex string (character by character)
   *
   * @param s the string
   * @param up if true, use upper case, otherwise lower
   * @return s representation as a hex string
   *
   * <br><br><b>Examples</b>:
   * <li><code>toHex("kl\u005cu12bc", true)</code> returns "006B006C12BC";</li>
   * <li><code>toHex("kl\u005cu12bc", true)</code> returns "006b006c12bc".</li>
   */
  public static String toHex(String s, boolean up) {
    StringBuffer b = new StringBuffer();
    for (int i = 0; i < s.length(); i++) {
      b.append(toHex(s.charAt(i), up));
    }
    return b.toString();
  }


  /**
   * Converts a character to its Java octal encoding format: \\o[o][o]
   *
   * @param c the character
   * @return a string
   *
   * <br><br><b>Example</b>:
   * <li><code>toJavaOctalEncoding('\n')</code> returns "\\12".</li>
   */
  public static String toJavaOctalEncoding(char c) {
    return "\\" + Integer.toString(c, 8);
  }

  /**
   * Converts a character to its Java hex encoding format: \\uxxxx
   *
   * @param c the character
   * @return a string, encoded c representation
   *
   * <br><br><b>Example</b>:
   * <li><code>toJavaHexEncoding('\u005cu00af')</code> returns "\\u00af".</li>
   */
  public static String toJavaHexEncoding(char c) {
    return "\\u" + toHex(c);
  }

  /**
   * Converts a character to its Java hex encoding format: \\uxxxx
   *
   * @param c the character
   * @param up if true, use upper case, otherwise lower
   * @return a string, encoded c representation
   *
   * <br><br><b>Example</b>:
   * <li><code>toJavaHexEncoding('\u005cu00af', false)</code> returns "\\u00af".</li>
   */
  public static String toJavaHexEncoding(char c, boolean up) {
    return "\\u" + toHex(c, up);
  }

  /**
   * Converts a character to how it should be represented in properties files
   *
   * @param c the character
   * @param up if true, use upper case, otherwise lower
   * @return a string, encoded c representation
   *
   * <br><br><b>Examples</b>:
   * <li><code>toPropertiesEncoding('\u005cu00af', false)</code> returns "\\u00af";</li>
   * <li><code>toPropertiesEncoding('\u005cu00af', true)</code> returns "\\u00AF";</li>
   * <li><code>toPropertiesEncoding('a', false)</code> returns "a".</li>
   */
  public static String toPropertiesEncoding(char c, boolean up) {
    return (c > 0x7f || c < ' ') ? toJavaHexEncoding(c, up) : ("" + c);
  }

  /**
   * Converts a character to how it should be represented in properties files
   *
   * @param c the character
   * @return a string, encoded c representation
   *
   * <br><br><b>Examples</b>:
   * <li><code>toPropertiesEncoding('\u005cu00af')</code> returns "\\u00af";</li>
   * <li><code>toPropertiesEncoding('a')</code> returns "a".</li>
   */
  public static String toPropertiesEncoding(char c) {
    return toPropertiesEncoding(c, false);
  }

  /**
   * Characters that should be escaped in Java or C code
   */
  public static final String ESCAPEE = "\\\"\'\n\r\t\f\b";
  /**
   * Characters used in escapes
   */
  public static final String ESCAPED = "\\\"'nrtfb";

  /**
   * Checks whether a character needs encoding in Java
   *
   * @param c the character
   * @return true if so
   *
   * <br><br><b>Examples</b>:
   * <li><code>needsEncoding('\u005cu00af')</code> returns <b>true</b>;</li>
   * <li><code>needsEncoding('a')</code> returns <b>false</b>.</li>
   */
  public static boolean needsEncoding(char c) {
    return ESCAPEE.indexOf(c) >= 0 || c < ' ' || c > 0x7f;
  }

  /**
   * Converts a character to its Java encoding (hex or escaped or intact)
   *
   * @param c the character
   * @param up if true, use upper case, otherwise lower
   * @param escape if true, escape escapable characters
   * @return a string with a proper Java representation of the character c
   *
   * <br><br><b>Examples</b>:
   * <li><code>toJavaEncoding('\u005cu00af', false, false)</code> returns "\\u00af";</li>
   * <li><code>toJavaEncoding('\u005cu000a', true, true)</code> returns "\\n";</li>
   * <li><code>toJavaEncoding('\u005cu000e', true, true)</code> returns "\\16";</li>
   * <li><code>toJavaEncoding('a', true, true)</code> returns "a".</li>
   */
  public static String toJavaEncoding(char c, boolean up, boolean escape) {
    int i = escape ? ESCAPEE.indexOf(c) : -1;
    return (i >= 0)    ? ("\\" + ESCAPED.charAt(i)) :
           (c < ' ')   ? toJavaOctalEncoding(c)     :
           (c > 0x7f)  ? toJavaHexEncoding(c, up)   :
                         ("" + c);
  }

  /**
   * Converts a character to its Java encoding (hex or escaped or intact)
   *
   * @param c the character
   * @param up if true, use upper case, otherwise lower
   * @return a string with a proper Java representation of the character c
   *
   * <br><br><b>Examples</b>:
   * <li><code>toJavaEncoding('\u005cu00af', false)</code> returns "\\u00af";</li>
   * <li><code>toJavaEncoding('\u005cu00af', true)</code> returns "\\u00AF";</li>
   * <li><code>toJavaEncoding('\u005cu000a', true)</code> returns "\\n";</li>
   * <li><code>toJavaEncoding('\u005cu000e', true)</code> returns "\\16";</li>
   * <li><code>toJavaEncoding('a', true)</code> returns "a".</li>
   */
  public static String toJavaEncoding(char c, boolean up) {
    return toJavaEncoding(c, up, true);
  }

  /**
   * Converts a character to its Java encoding (hex or escaped or intact)
   *
   * @param c the character
   * @return a string with a proper Java representation of the character c
   *
   * <br><br><b>Examples</b>:
   * <li><code>toJavaEncoding('\u005cu00af')</code> returns "\\u00af";</li>
   * <li><code>toJavaEncoding('\u005cu000a')</code> returns "\\n";</li>
   * <li><code>toJavaEncoding('\u005cu000e')</code> returns "\\16";</li>
   * <li><code>toJavaEncoding('a')</code> returns "a".</li>
   */
  public static String toJavaEncoding(char c) {
    return toJavaEncoding(c, false);
  }

  /**
   * Converts a character to its C encoding (hex or escaped or intact)
   *
   * @param c the character
   * @return a string with a proper C language representation of the character c
   *
   * <br><br><b>Examples</b>:
   * <li><code>toCEncoding('\u005cuabcd')</code> returns "\\xabcd";</li>
   * <li><code>toCEncoding('\u005cu00af')</code> returns "\\xaf";</li>
   * <li><code>toCEncoding('\u005cu000a')</code> returns "\\n";</li>
   * <li><code>toCEncoding('a')</code> returns "a".</li>
   */
  public static String toCEncoding(char c) {
    int i = ESCAPEE.indexOf(c);
    return (i >= 0)    ? ("\\" + ESCAPED.charAt(i)) :
           (c < ' ' || c > 0x7f) ? ("\\x" + Long.toHexString(c)) :
           ("" + c);
  }

  /**
   * Checks whether a string needs encoding in Java
   *
   * @param s the string
   * @return true if so
   *
   * <br><br><b>Examples</b>:
   * <li><code>needsEncoding("Feliz A�o Nuevo")</code> returns <b>true</b>;</li>
   * <li><code>needsEncoding("Feliz Navedad")</code> returns <b>false</b>.</li>
   */
  public static boolean needsEncoding(String s) {
    if (s == null) return false;
    for (int i = 0; i < s.length(); i++) {
      if (needsEncoding(s.charAt(i))) return true;
    }
    return false;
  }

  /**
   * Converts a string to its Java encoding (hex or escaped or intact, per char)
   *
   * @param s the string
   * @param up if true, use upper case, otherwise lower
   * @param escape if true, escape escapable characters
   * @return the encoded string
   *
   * <br><br><b>Examples</b>:
   * <li><code>toJavaEncoding("\nFeliz A�o Nuevo\n", true, false)</code>
   * returns "\u005cu000AFeliz \u005cu00A4o Nuevo\u005cu000A";</li>
   * <li><code>toJavaEncoding("\nFeliz A�o Nuevo\n", true, true)</code>
   * returns "\\nFeliz \u005cu00A4o Nuevo\\n";</li>
   * <li><code>toJavaEncoding("\nFeliz A�o Nuevo\n\0", false, true)</code>
   * returns "\\nFeliz \u005cu00a4o Nuevo\\n\\0".</li>
   */
  public static String toJavaEncoding(String s, boolean up, boolean escape) {
    if (!needsEncoding(s)) return s;

    StringBuffer buf = new StringBuffer();

    for (int i = 0; i < s.length(); i++) {
      buf.append(toJavaEncoding(s.charAt(i), up, escape));
    }

    return buf.toString();
  }

  /**
   * Converts a string to its Java encoding (hex or escaped or intact, per char)
   *
   * @param s the string
   * @param up if true, use upper case, otherwise lower
   * @return the encoded string
   *
   * <br><br><b>Examples</b>:
   * <li><code>toJavaEncoding("\nFeliz A�o Nuevo\n", true)</code>
   * returns "\nFeliz \u005cu00A4o Nuevo\n";</li>
   * <li><code>toJavaEncoding("\nFeliz A�o Nuevo\n\0", false)</code>
   * returns "\\nFeliz \u005cu00a4o Nuevo\\n\\0".</li>
   */
  public static String toJavaEncoding(String s, boolean up) {
    return toJavaEncoding(s, up, true);
  }

  /**
   * Converts a string to its Java encoding (hex or escaped or intact, per char)
   *
   * @param s the string
   * @return the encoded string
   *
   * <br><br><b>Example</b>:
   * <li><code>toJavaEncoding("\nFeliz A�o Nuevo\n\0")</code>
   * returns "\\nFeliz A\u005cu00f1o Nuevo\\n\\0".</li>
   */
  public static String toJavaEncoding(String s) { return toJavaEncoding(s, false); }

  /**
   * Converts a string to its C encoding
   *
   * @param s the string
   * @return the encoded string
   *
   * <br><br><b>Example</b>:
   * <li><code>toCEncoding("\nFeliz A�o Nuevo\n")</code>
   * returns "\\nFeliz A\\x00f1o Nuevo\\n".</li>
   */
  public static String toCEncoding(String s) {
    if (!needsEncoding(s)) return s;

    StringBuffer buf = new StringBuffer();

    for (int i = 0; i < s.length(); i++) {
      buf.append(toCEncoding(s.charAt(i)));
    }

    return buf.toString();
  }

  /**
   * Converts a character to its SGML numeric encoding
   *
   * @param c the character
   * @return a string with the representation of c as
   * "Numeric Character Reference" in SGMLese
   *
   * <br><br><b>Example</b>:
   * <li><code>toSgmlEncoding('\n')</code>
   * returns "&amp;#10;".</li>
   */
  public static String toSgmlEncoding(char c) {
  return c > 0x20 || c == 0x9 || c == 0xa || c == 0xd ? "&#" + (int)c + ";" : "?";
  }

  /**
   * Encodes a character by SGML rules
   * It can be a hex representation
   * @param c the character
   * @return the string with either Predefined Entity, Numeric Character Reference,
   * or null if no entity could be found
   *
   * <br><br><b>Examples</b>:
   * <li><code>sgmlEntity('\u005c60ab')</code> returns "&amp;#24747;" (that is, Numeric Character Reference);</li>
   * <li><code>sgmlEntity('<')</code> returns "&amp;lt;" (that is, Predefined Entity);</li>
   * <li><code>sgmlEntity('&')</code> returns "&amp;lt;" (that is, Predefined Entity);</li>
   * <li><code>sgmlEntity('X')</code> returns <b>null</b>";</li>
   * <li><code>sgmlEntity('\n')</code> returns <b>null</b>".</li>
   */
  public static String sgmlEntity(char c) {
    return (c == '<') ? "&lt;" :
           (c == '>') ? "&gt;" :
           (c == '\'') ? "&apos;" :
           (c == '\"') ? "&quot;" :
           (c == '&') ? "&amp;" :
           (c == ']') ? "&#93;" :
           (c < '\u0020' && c != '\n' && c != '\r' && c != '\t') || c > '\u0080' ?
              toSgmlEncoding(c) :
           null;
  }

  /**
   * Encodes a string by SGML rules
   * (using predefined entities and numeric character encodings when necessary)
   * @param s the original string
   * @return the encoded string
   *
   * <br><br><b>Example</b>:
   * <li><code>toSgmlEncoding("<i>Feliz A�o Nuevo</i>\n")</code>
   * returns "&amp;lt;i&amp;gt;Feliz A&amp;#164;o Nuevo&amp;lt;/i&amp;gt;\n".</li>
   */
  public static String toSgmlEncoding(String s) {
    if (isEmpty(s)) return s;

    char[] chars = s.toCharArray();
    StringBuffer buffer = new StringBuffer(chars.length * 2);

    for (int i = 0; i < s.length(); i++) {
      char c = chars[i];
      String entity = sgmlEntity(c);
      if (entity == null) {
        buffer.append(c);
      } else {
        buffer.append(entity);
      }
    }
    return buffer.toString();
  }

   /**
    * html-encode all non-ascii chars
    * @param s String non-encoded
    * @return String encoded for html
    */
   public static final String htmlEncode(String s) {
   if (isEmpty(s)) return "";

    StringBuffer out = new StringBuffer();
    for (int i = 0; i < s.length(); i++) {
      char c = s.charAt(i);
      int k = c;
      if (c > 0x100) {
        out.append("&#" + k);
      } else {
        out.append(c);
      }
    }

    return out.toString();
  }

  /**
   * Converts a string to a readable string.
   * (By Replacing potentially unreadables characters with '.')
   *
   * @param s original string
   * @param beginIndex where to start
   * @param endIndex where to end (before this position)
   * @return the string with unreadable chars replaced
   *
   * <br><br><b>Example</b>:
   * <li><code>toReadable("\t�Hola se�or!\n".toCharArray(), 2, 12)</code>
   * will return "Hola se.or".</li>
   */
  public static final String toReadable(char[] data, int beginIndex, int endIndex) {
    StringBuffer buf = new StringBuffer(data.length);
    for (int i = beginIndex; i < data.length && i < endIndex; i++) {
      char c = data[i];
      if (c < ' ' || c > 127) c = '.';
      buf.append(c);
    }
    return buf.toString();
  }

    /**
     * Converts a string to a readable string.
     * (By Replacing potentially unreadables characters with '.')
     *
     * @param s original string
     * @return the string with unreadable chars replaced
     *
     * <br><br><b>Example</b>:
     * <li><code>toReadable("\t�Hola se�or!\n")</code> will return "..Hola se.or!.".</li>
     */
    public static final String toReadable(String s) {
      return toReadable(s.toCharArray(), 0, s.length());
    }

  /**
   * Hexadecimal dump of a byte array.
   * Produces neatly arranged lines of bot hex and ascii representation of bytes
   * from the array.
   *
   * @param data the data array
   * @return the hex dump string
   *
   * <br><br><b>Example</b>:
   * <li><code>hexDump(new byte[] {1, 'a', 'b', '\n', 'c'})</code> will return
   * "\r\n01 61 62 0a 63             | . a b . c\r\n".</li>
   */
  public static final String hexDump(byte[] data) {
    if (data == null || data.length == 0) return "";
    StringBuffer out = new StringBuffer();

    for (int i = 0; i < data.length; i+= 16) {
      out.append("\r\n");
      out.append(toHex((byte)(i >> 8)));
      out.append(toHex((byte)(i     )));
      out.append(": ");

      for (int j = i; j < i + 16; j++) {
        out.append(j < data.length ? toHex(data[j]) : "  ");
        out.append(" ");
      }
      out.append("| ");

      for (int j = i; j < i + 16 && j < data.length; j++) {
        byte b = data[j];
        out.append(b >= ' ' ? (char)b : '\u00b7');
        out.append(" ");
      }
    }
    out.append("\r\n");

    return out.toString();
  }

  /**
   * Hexadecimal dump of a char array
   * Produces neatly arranged lines of bot hex and ascii representation of bytes
   * from the array.
   *
   * @param data the data array
   * @return a string containing both hex and ascii representation of the data
   *
   * <br><br><b>Example</b>:
   * <li><code>hexDump(new char[] {1, 'a', 'b', '\n', 'c'})</code> will return<br>
   * "\r\n0000: 0001 0061 0062 000a 0063                                                        | .ab.c\r\n".</li>
   */
  public static final String hexDump(char[] data) {
    if (data == null || data.length == 0) return "";
    StringBuffer out = new StringBuffer();

    for (int i = 0; i < data.length; i+= 16) {
      out.append("\r\n");
      out.append(i < 16 ? "000" : i < 256 ? "00" : i < 4096 ? "0" : "");
      out.append(toHex(i));
      out.append(": ");

      for (int j = i; j < i + 16; j++) {
        out.append(j >= data.length ? "    " : toHex(data[j]));
        out.append(" ");
      }
      out.append("| ");
      out.append(toReadable(data, i, Math.min(i+16, data.length)));
    }
    out.append("\r\n");

    return out.toString();
  }

  /**
   * Hexadecimal dump of a string
   * Produces neatly arranged lines of bot hex and ascii representation of bytes
   * from the array.
   *
   * @param data the string
   * @return a string containing both hex and ascii representation of the data
   *
   * <br><br><b>Example</b>:
   * <li><code>hexDump("\u0001ab\nc")</code> will return
   * "\r\n0001 0061 0062 000a 0063             | .ab.c".</li>
   */
  public static final String hexDump(String data) {
    return hexDump(data.toCharArray());
  }

  /**
   * Converts an array of chars to a readable hexadecimal form
   *
   * @param data the data array
   * @return a string that is basically a hex dump of the data
   *
   * <br><br><b>Example</b>:
   * <li><code>toHexReadable(new char[] {1, 'a', 'b', '\n', 'c'})</code> will return
   * "0001 0061 0062 000a 0063 \r\n".</li>
   */
  public static final String toHexReadable(char[] data) {
    if (data == null || data.length == 0) return "";
    StringBuffer out = new StringBuffer();

    for (int i = 0; i < data.length; i+=16) {
      for (int j = i; j < i + 16 && j < data.length; j++) {
        out.append(toHex(data[j]));
        out.append(" ");
      }

      out.append("\r\n");
    }
    return out.toString();
  }

  /**
   * Converts an array of chars to a readable hexadecimal form
   *
   * @param data the data array
   * @param from beginning index
   * @param to ending index (not included)
   * @return a string that is basically a hex dump of the data
   *
   * <br><br><b>Example</b>:
   * <li><code>toHexReadable(new byte[] {1, 2, 48}, 1, 3)</code> will return
   * "02 30 \r\n".</li>
   */
  public static final String toHexReadable(byte[] data, int from, int to) {
    if (data == null || data.length == 0) return "";
    StringBuffer out = new StringBuffer();

    for (int i = from; i < Math.min(to, data.length); i+=16) {
      for (int j = i; j < i + 16 && j < Math.min(to, data.length); j++) {
        out.append(toHex(data[j]));
        out.append(" ");
      }

      out.append("\r\n");
    }
    return out.toString();
  }

  /**
   * Converts an array of bytes to a readable hexadecimal form
   *
   * @param data the data array
   * @return a string that is basically a hex dump of the data
   *
   * <br><br><b>Example</b>:
   * <li><code>toHexReadable(new byte[] {1, 2, 48})</code> will return
   * "01 02 30 ".</li>
   */
  public static final String toHexReadable(byte[] data) {
    if (data == null || data.length == 0) return "";
    StringBuffer out = new StringBuffer();

    for (int i = 0; i < data.length; i+=16) {
      for (int j = i; j < i + 16 && j < data.length; j++) {
        out.append(toHex(data[j]));
        out.append(" ");
      }

      out.append("\r\n");
    }
    return out.toString();
  }

  /**
   * Converts a string to a readable hexadecimal form
   *
   * @param s the data string
   * @return a string that is basically a hex dump of the data
   *
   * <br><br><b>Example</b>:
   * <li><code>toHexReadable("\u0001ab\nc")</code> will return
   * "0001 0061 0062 000a 0063 \r\n".</li>
   */
  public static final String toHexReadable(String s) {
    if (isEmpty(s)) return "";
    StringBuffer out = new StringBuffer();

    for (int i = 0; i < s.length(); i+=16) {
      String chunk = s.substring(i, Math.min(i + 16, s.length()));

      for (int j = 0; j < chunk.length(); j++) {
        out.append(toHex(chunk.charAt(j)));
        out.append(" ");
      }

      out.append("\r\n");
    }
    return out.toString();
  }

  /**
   * Perl operation join.
   *   Concatenates a collection of (string representations of) objects
   *   using a separator string to separate
   *
   * @param separator the separator string
   * @param collection the collection of objects to join
   * @return resulting string
   *
   * <br><br><b>Examples</b>:<br>
   * <code>
   * HashSet   a = new HashSet();<br>
   * List b = new ArrayList(); b.add("entry1"); b.add("entry2");<br>
   * <li><code>join(", ", a)</code> returns "";</li>
   * <li><code>join(", ", b)</code> returns "entry1, entry2".</li>
   */
  public static final String join(String separator, Collection collection) {
    if (separator == null || collection == null) return "";

    StringBuffer buf = new StringBuffer();

    for (Iterator i = collection.iterator(); i.hasNext();) {
      Object ith = i.next();
      if (ith != null) buf.append(ith);

      if (i.hasNext()) {
        buf.append(separator);
      }
    }

    return buf.toString();
  }

  /**
   * Perl operation join.
   *   Concatenates an array of (string representations of) objects
   *   using a separator to separate
   *
   * @param separator the separator string
   * @param what the array of objects to join
   * @return resulting string
   *
   * <br><br><b>Examples</b>:<br>
   * <li><code>join(", ", new Long[] {new Long(1), new Long(555)})</code>
   * returns "1, 555";</li>
   * <li><code>join(" and ", new String[] {"Here", "there", "everywhere"})</code>
   * returns "Here and there and everywhere".</li>
   */
  public static final String join(String separator, Object[] what) {
    if (separator == null || what == null) return "";

    StringBuffer buf = new StringBuffer();

    for (int i = 0; i < what.length; i++) {
      Object ith = what[i];
      if (ith != null) buf.append(ith.toString());

      if (i <what.length - 1) {
        buf.append(separator);
      }
    }

    return buf.toString();
  }

  /**
   * Perl operation split.
   *   splits a source string into a collection of strings
   *
   * @param source source string
   * @param separator separator character
   * @return a collection of extracted strings
   *
   * <br><br><b>Example</b>:<br>
   * <code>
   * <li><code>split(":", "a:ab:abcde:")</code>
   * returns a list containing four elements, "a", "ab", "abcde", "".</li>
   */
  public static List split(String separator, String source) {

    ArrayList stringList = new ArrayList();
    boolean found = false;
    for (int pos = 0;
         source != null && separator != null && pos < source.length();) {
      int last = source.indexOf(separator, pos);
      if (last < 0) {
        last = source.length();
      } else {
        found = true;
      }
      stringList.add(source.substring(pos, last));
      pos = last + separator.length();
    }
    if (found) stringList.add("");
    stringList.trimToSize();
    return stringList;
  }

  /**
   * Perl operation grep.
   *   Extracts from a string array the strings that match a regexp
   *
   * @param source source array
   * @param regexp expression to match
   * @return a collection of matching strings
   *
   * <br><br><b>Example</b>:<br>
   * <code>
   * <li><code>grep(new String[] {"good", "bad", "ugly"}, "g."))</code>
   * returns a list containing two elements: "good", "ugly".</li>
   */
  public static List grep(String[] source, String regexp) throws REException {
    return grep(source, new RE(regexp));
  }

 /**
  * Perl operation grep.
  *   Extracts from a string array the strings that match a regexp
  *
  * @param source source array
  * @param regexp expression to match
  * @return a collection of matching strings
  *
  * <br><br><b>Example</b>:<br>
  * <code>
  * <li><code>grep(new String[] {"good", "bad", "ugly"}, Pattern.compile("g.")))</code>
  * returns a list containing two elements: "good", "ugly".</li>
  */
 public static List grep(String[] source, RE regexp) {
   ArrayList result = new ArrayList();
   for (int i = 0; i < source.length; i++) {
     if (regexp.isMatch(source[i])) {
       result.add(source[i]);
     }
   }
   result.trimToSize();
   return result;
 }

  /**
   * Replaces a substring in a string with another substring
   *
   * @param where the string containing the substrings to replace
   * @param oldSubstring what to replace
   * @param newSubstring with what to replace
   * @param all if true, all (nonintersecting) substrings are replaced,
   *        otherwise only one
   * @return resulting string
   *
   * <br><br><b>Examples</b>:
   * <li><code>replace("God loves you", "love", "hate", true)</code>
   * returns "God hates you";</li>
   * <li><code>replace("All you need is love, love!", "me", false)</code>
   * returns "All you need is me, love!".</li>
   */
  public static final String replace(String where,
                                     String oldSubstring,
                                     String newSubstring,
                                     boolean all) {
    if (oldSubstring == null || newSubstring == null || where == null)
      return where;

    StringBuffer out = new StringBuffer();
    int pos = 0;
    do {
      int newPos = where.indexOf(oldSubstring, pos);

      if (newPos < 0) break;
      out.append(where.substring(pos, newPos));
      out.append(newSubstring);

      pos = newPos + oldSubstring.length();
    } while (all);

    out.append(where.substring(pos));
    return out.toString();
  }

  /**
   * Extracts value from a string of format NAME="VALUE"
   *
   * @param input string of the aforementioned format
   * @param name the name on the left side of '='
   * @return the string value inside the quotes (quotes omitted) if the string
   *         has the specified format; null utherwise
   *
   * <br><br><b>Examples</b>:
   * <li><code>extractValue("java.home=\"c:\\java\\jdk1.4.1\"\nx=\"abcd\"", "x")</code>
   * returns "abcd";</li>
   * <li><code>extractValue("java.home=\|c:\\java\\jdk1.4.1\"\nx=\"abcd\"", "java.home")</code>
   * returns "c:\\java\\jdk1.4.1".</li>
   */
  public static final String extractValue(String input, String name) {
    int iname = input.indexOf(name + "=\"");
    if (iname < 0) return null;

    int ivalue = iname + name.length() + 2;
    int ievalu = input.indexOf('"', ivalue);
    if (ievalu < 0) return null;

    return input.substring(ivalue, ievalu);
  }

  /**
   * Packs bytes into a string
   *
   * @param from byte array
   * @return a string that consists of the same bytes, packed two per character
   *
   * <br><br><b>Example</b>:
   * <li><code>pack(new byte[] {0x23, 0x67, (byte)0xab, (byte)0xef})</code>
   * returns "\u2367\uabef".</li>
   */
  public static final String pack(byte[] from) {
    StringBuffer buffer = new StringBuffer((from.length + 1) / 2);
    char previous = 0;

    for (int i = 0; i < from.length; i++) {
      char byteValue = (char)(0xff & from[i]);

      if (i % 2 != 0) {
        buffer.append((char)(previous + byteValue));
      } else {
        previous = (char)(byteValue << 8);
      }
    }

    if (from.length % 2 != 0) {
      buffer.append(previous);
    }
    return buffer.toString();
  }

  /**
   * Unpacks bytes packed in the string
   *
   * @see pack
   * @param string the packed data
   * @return the unpacked data
   *
   * <br><br><b>Example</b>:
   * <li><code>unpack("\u2367\uabef")</code>
   * returns new byte[] {0x23, 0x67, (byte)0xab, (byte)0xef}.</li>
   */
  public static final byte [] unpack(String string) {
// The following method does not work for JDK 1.4; it seems like it replaces
// "bad" characters with ff fe sequences.
//    return encode(string, "UTF-16BE");
    byte[] result = new byte[string.length() * 2];
    for (int i = 0; i < string.length(); i++) {
      int c = string.charAt(i);
      result[i * 2]     = (byte)(c >> 8);
      result[i * 2 + 1] = (byte) c;
    }
    return result;
  }

  /**
   * Decodes (and unescapes) a Java string.
   * Replaces escape sequences with their corresponding character values
   *
   * @param string as presented in the source code
   * @return decoded string in "internal form"
   *
   * <br><br><b>Examples</b>:
   * <li><code>decodeJavaString("This is a string")</code> returns "This is a string";</li>
   * <li><code>decodeJavaString("\\nFeliz \\u00A4o Nuevo\\n")</code>
   * returns "\nFeliz A�o Nuevo\n".</li>
   */
  public static final String decodeJavaString(String string) {
    StringBuffer output = new StringBuffer(string.length() * 2);

    if (string.indexOf('\\') < 0) {
      return string;
    }

    for (int i=0; i < string.length(); i++) {
      char ch = string.charAt(i);
      if (ch == '\\' && i < string.length() - 1) { // So, we have a backslash...
        int escapeIdx = ESCAPED.indexOf(string.charAt(i+1));
        if (escapeIdx >= 0) {
          i++;
          ch = ESCAPEE.charAt(escapeIdx);
        } else
        if (i < string.length() - 5 &&
            string.charAt(i + 1) == 'u') { //possible escape
          try {
            ch = (char)Integer.parseInt(string.substring(i+2, i+6), 16);
            i += 5;
          } catch (NumberFormatException nfe) {
//          Okay, okay, not a hex number...
          }
        }
      }
      output.append(ch);
    }
    return output.toString();
  }

  /**
   * Encodes a string using specified encoding
   *
   * @see http://java.sun.com/j2se/1.3/docs/guide/intl/encoding.doc.html
   * @see http://java.sun.com/j2se/1.4/docs/guide/intl/encoding.doc.html
   *
   * @param s string to encode
   * @param encoding the name of encoding
   * @return encoded string
   * @throws IOException when something goes wrong with bytearray streams
   * @throws UnsupportedEncodingException when encoding is unknown
   *
   * <br><br><b>Examples</b>:
   * <li><code>encode("A�o Nuevo", "UTF8")</code>
   * returns new byte[] {0x41, (byte)0xc3, (byte)0xb1, 0x6f, 0x20, 0x4e, 0x75, 0x65, 0x76, 0x6f};</li>
   * <li><code>encode("A�o Nuevo", "MacRoman")</code>
   * returns new byte[] {0x41, (byte)0x96, 0x6f, 0x20, 0x4e, 0x75, 0x65, 0x76, 0x6f}.</li>
   */
  public static final byte[] encode(String s, String encoding)
               throws IOException, UnsupportedEncodingException {
    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    Writer osw = new OutputStreamWriter(bos, encoding);
    osw.write(s);
    osw.close();
    return bos.toByteArray();
  }

  /**
   * Decodes a stream using specified encoding
   *
   * @see http://java.sun.com/j2se/1.3/docs/guide/intl/encoding.doc.html
   * @see http://java.sun.com/j2se/1.4/docs/guide/intl/encoding.doc.html
   *
   * @param is stream to decode
   * @param encoding the name of encoding
   * @return data decoded from the stream
   * @throws IOException when something goes wrong with bytearray streams
   * @throws UnsupportedEncodingException when encoding is unknown
   *
   */
  public static final String decode(InputStream is, String encoding)
               throws IOException, UnsupportedEncodingException {
    Reader isr               = new InputStreamReader(is, encoding);
    StringBuffer result      = new StringBuffer();
    char[] readBuffer        = new char[4096];

    while (isr.ready()) {
      int l = isr.read(readBuffer);
      result.append(readBuffer, 0, l);
    }

    return result.toString();
  }

  /**
   * Decodes an array of bytes using specified encoding
   *
   * @see http://java.sun.com/j2se/1.3/docs/guide/intl/encoding.doc.html
   * @see http://java.sun.com/j2se/1.4/docs/guide/intl/encoding.doc.html
   *
   * @param bytes byte array
   * @param encoding the name of encoding
   * @return decoded string
   * @throws IOException when something goes wrong with bytearray streams
   * @throws UnsupportedEncodingException when encoding is unknown
   *
   * <br><br><b>Examples</b>:
   * <li><code>decode(new byte[] {0x41, (byte)0xc3, (byte)0xb1, 0x6f, 0x20, 0x4e, 0x75, 0x65, 0x76, 0x6f}, "UTF8")</code>
   * returns "A�o Nuevo";</li>
   * <li><code>encode( new byte[] {0x41, (byte)0x96, 0x6f, 0x20, 0x4e, 0x75, 0x65, 0x76, 0x6f}, "MacRoman")</code>
   * returns "A�o Nuevo".</li>
   */
  public static final String decode(byte[] bytes, String encoding)
               throws IOException, UnsupportedEncodingException {
    return decode(new ByteArrayInputStream(bytes), encoding);
  }

  /**
   * zip (like in zip files) a string producing an array of bytes
   *
   * @param source the string to zip
   * @return bytes representing zipped data
   * @throws IOException when something goes wrong with streams
   * @throws UnsupportedEncodingException when JDK forgets that it knows UTF8
   *
   * <br><br><b>Example</b>:
   * <li><code>zip2bytes("Hello World")</code>
   * returns new byte[] {0x78, (byte)0xda, (byte)0xf3, 0x48, (byte)0xcd, (byte)0xc9, (byte)0xc9, 0x57, (byte)0x08, (byte)0xcf, 0x2f, (byte)0xca, 0x49, 0x01, 0x00, 0x18, 0x0b, 0x04, 0x1d, 0x00}.</li>
   */
  public static final byte[] zip2bytes(String source)
               throws IOException, UnsupportedEncodingException {
    if (source == null) return null;
    ByteArrayOutputStream bos = new ByteArrayOutputStream();
    DeflaterOutputStream dos  = new DeflaterOutputStream(bos,
                                new Deflater(Deflater.BEST_COMPRESSION));
    Writer osw                = new OutputStreamWriter(dos, "UTF-8");
    osw.write(source);
    osw.flush();
    dos.finish();
    bos.write(0); // Just to pad in case of, you know, odd number of bytes.
    osw.close();
    byte[] result = bos.toByteArray();
    return result;
  }

  /**
   * zips a string to a string of lower-byte chars.
   * Does this: String -> UTF8 bytes -> zip -> bytes -> String
   * @param source string to zip
   * @return string with zipped data
   * @throws IOException when something goes wrong with streams
   * @throws UnsupportedEncodingException when JDK forgets that it knows UTF8
   *
   * <br><br><b>Example</b>:
   * <li><code>zip8bit("Hello World")</code>
   * returns "x\u00da\u00f3H\u00cd\u00c9\u00c9W\b\u00cf/\u00caI\u0001\u0000\u0018\u000b\u0004\u001d\u0000".</li>
   */

   public static final String zip8bit(String source)
               throws IOException, UnsupportedEncodingException {
    return new String(zip2bytes(source));
  }

  /**
   * zips a string to a string.
   * Does this: String -> UTF8 bytes -> zip -> bytes -> High Unicode -> String
   *
   * @param source string to zip
   * @return string with zipped data
   * @throws IOException when something goes wrong with streams
   * @throws UnsupportedEncodingException when JDK forgets that it knows UTF8
   *
   * <br><br><b>Example</b>:
   * <li><code>zip("Hello World")</code>
   * returns "\u78da\uf348\ucdc9\uc957\u08cf\u2fca\u4901\u0018\u0b04\u1d00".</li>
   */
  public static final String zip(String source)
               throws IOException, UnsupportedEncodingException {
    return pack(zip2bytes(source));
  }

  /**
   * Unzips a stream.
   * Does this: stream -> unzip -> bytes -> UTF8 -> String
   *
   * @param zippedStream
   * @return string with unzipped data
   * @throws IOException when something goes fishy
   * @throws UnsupportedEncodingException when JDK forgets that it knows UTF8
   */

      public static final String unzip(InputStream zippedStream)
               throws IOException, UnsupportedEncodingException {
    return decode(new InflaterInputStream(zippedStream), "UTF-8");
  }

  /**
   * Unzips an array of bytes.
   * Does this: bytes -> unzip -> bytes -> UTF8 -> String
   *
   * @param zippedBytes
   * @return string with unzipped data
   * @throws IOException when something goes fishy
   * @throws UnsupportedEncodingException when JDK forgets that it knows UTF8
   *
   * <br><br><b>Example</b>:
   * <li><code>unzip(new byte[] {0x78, (byte)0xda, (byte)0xf3, 0x48, (byte)0xcd, (byte)0xc9, (byte)0xc9, 0x57, 0x08, (byte)0xcf, 0x2f, (byte)0xca, 0x49, 0x01, 0x00, 0x18, 0x0b, 0x04, 0x1d, 0x00})</code>
   * returns "Hello World".</li>
   */
  public static final String unzip(byte[] zippedBytes)
               throws IOException, UnsupportedEncodingException {
    return unzip(new ByteArrayInputStream(zippedBytes));
  }

  /**
   * Unzips a string.
   * Does this: String -> High Unicode bytes -> unzip -> bytes -> UTF8 -> String
   *
   * @param zippedString
   * @return string with unzipped data
   * @throws IOException when something goes fishy
   * @throws UnsupportedEncodingException when JDK forgets that it knows UTF8
   *
   * <br><br><b>Example</b>:
   * <li><code>unzip("\u78da\uf348\ucdc9\uc957\u08cf\u2fca\u4901\u0018\u0b04\u1d00")</code>
   * returns "Hello World".</li>
   */
  public static final String unzip(String zippedString)
               throws IOException, UnsupportedEncodingException {
    return unzip(unpack(zippedString));
  }

  /**
   * Calculates crc32 on a string
   * @param string source string
   * @return its crc32
   * @throws IOException when something goes wrong with streams
   * @throws UnsupportedEncodingException when JDK forgets that it knows UTF8
   *
   * <br><br><b>Example</b>:
   * <li><code>crc32("Hello World")</code>
   * returns 2178450716l.</li>
   */
  public static final long crc32(String string)
      throws IOException, UnsupportedEncodingException {
    return crc32(unpack(string));
  }

  /**
   * Returns a crc report on a byte array: a set of partial crc on chunks of data
   *
   * @param data source bytes
   * @param off offset in the array
   * @param len length of the area to crc
   * @param step chunk size
   * @return formatted report
   */
  public static final String crcreport(byte[] data, int off, int len, int step) {
    StringBuffer buffer = new StringBuffer();
    int lastplus1 = Math.min(data.length, off + len);
    for (int i = off; i <= lastplus1; i+= step) {
      buffer.append("[" + i + "]" + Long.toHexString(crc32(data, i, Math.min(lastplus1 - i, step))) + " ");
    }
    return buffer.toString();
  }

  /**
   * Returns a crc report on a byte array: a set of partial crc on chunks of data
   *
   * @param data source bytes
   * @param step chunk size
   * @return formatted report
   */
  public static final String crcreport(byte[] data, int step) {
    StringBuffer buffer = new StringBuffer();
    for (int i = 0; i <= data.length; i+= step) {
      buffer.append("[" + i + "]" + Long.toHexString(crc32(data, i, Math.min(data.length - i, step))) + " ");
    }
    return buffer.toString();
  }

  /**
   * Converts an array to string array, per element
   *
   * @param object the expected array
   * @return array of strings, or null if input is not what expected
   *
   * <br><br><b>Example</b>:
   * <li><code>toStrings(new Object[] { new Integer(22), new Boolean(false), "wow"})</code>
   * returns new String[] {"22", "false", "wow"}.</li>
   *
   */
  public static final String[] toStrings(Object object) {
    if (object == null) return null;
    if (!(object instanceof Object[])) return null;
    Object[] array = (Object[])object;
    String[] result = new String[array.length];
    for (int i = 0; i < array.length; i++) {
      result[i] = array[i].toString();
    }
    return result;
  }

  /**
   * Stringifies a Throwable, together with is stack trace.
   * @param e the throwable to convert to string
   * @return the string representation
   *
   * <br><br><b>Example</b>:
   * <p><code>
   * try {<br>
   * &nbsp;&nbsp;String s = null;<br>
   * &nbsp;&nbsp;s.toString();<br>
   * } catch (Exception e) {<br>
   * &nbsp;&nbsp;System.out.println(toString(e));<br>
   * }<br></code> prints
   * <p><code>java.lang.NullPointerException<br>
   * &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;at com.myjavatools.util.TestStrings</code>
   */
  public static final String toString(Throwable e) {
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    PrintStream ps = new PrintStream(baos);
    e.printStackTrace(ps);
    return baos.toString();
  }

  /**
   * Formats string with one parameter
   *
   * @param fmtString
   * @param param1
   * @return formatted string
   *
   * <br><br><b>Example</b>:
   * <li><code>format("{0} Monkeys", new Long(12))</code> returns "12 Monkeys".</li>
   *
   */
  public static String format(String fmtString, Object param1)
  {
    return( MessageFormat.format(fmtString, new Object[] {param1}));
  }

  /**
   * Formats string with two parameters
   *
   * @param fmtString
   * @param param1
   * @param param2
   * @return formatted string
   *
   * <br><br><b>Example</b>:
   * <li><code>format("{0} is {1}", "Life", "struggle")</code> returns "Life is struggle".</li>
   *
   */
  public static String format(String fmtString, Object param1, Object param2)
  {
    return(MessageFormat.format(fmtString, new Object[]{param1, param2}));
  }

  /**
   * Formats string with three parameters
   * @param fmtString
   * @param param1
   * @param param2
   * @param param3
   * @return formatted string
   *
   * <br><br><b>Example</b>:
   * <li><code>format("{0} + {1} = {2}", new Byte(2), new Byte(2), new Long(5))</code> returns "2 + 2 = 5".</li>
   *
   */
  public static String format(String fmtString,
                              Object param1,
                              Object param2,
                              Object param3)
  {
    return(MessageFormat.format(fmtString, new Object[]{param1, param2, param3}));
  }

  /**
   * Counts leading spaces in a string
   *
   * @param s
   * @return number of leading spaces
   *
   * <br><br><b>Example</b>:
   * <li><code>countLeadingSpaces(" this is a string   ")</code> returns 1.</li>
   */
  public static int countLeadingSpaces(String s) {
    int l = s.length();
    int n = 0;
    while (n < l && s.charAt(n) == ' ') n++;
    return n;
  }

  /**
   * Counts trailing spaces in a string
   * @param s
   * @return number of trailing spaces
   *
   * <br><br><b>Example</b>:
   * <li><code>countTrailingSpaces(" this is a string   ")</code> returns 3.</li>
   */
  public static int countTrailingSpaces(String s) {
    int l = s.length();
    int n = 0;
    while (n < l && s.charAt(l - n - 1) == ' ') n++;
    return n == s.length() ? 0 : n;
  }

  /**
   * Fills a string with a character
   *
   * @param c
   * @param n
   * @return a new string consisting of character c repeated n times
   *
   * <br><br><b>Example</b>:
   * <li><code>fill("*", 10)</code> returns "**********".</li>
   */
  public static String fill(char c, int n) {
    char[] data = new char[n];
    int i;
    for (i = 0; i < n; i++) {
      data[i] = c;
    }
    return new String(data);
  }

  /**
   * Create Properties from an array of key-value pairs
   *
   * @param pairs the source array
   * @return new Properties
   *
   * <br><br><b>Example</b>:
   * <li><code>asProperties(new String[] {"1", "one", "2", "two", "3", "three"})<code>
   * returns properties with three keys ("1", "2", "3"), and guess which values.</li>
   */
  public static Properties asProperties(String[]pairs) {
    if (pairs == null) return null;
    Properties result = new Properties();
    for (int i = 0; i < pairs.length-1; i+=2) {
      result.setProperty(pairs[i], pairs[i+1]);
    }
    return result;
  }

  /**
   * Finds index of the first difference between two strings
   *
   * @param string1
   * @param string2
   * @return the first index at which strings differ, -1 if the strings are equal
   *
   * <br><br><b>Examples</b>:
   * <li><code>findDiff("abcd", "abec")</code> returns 2;</li>
   * <li><code>findDiff("abc", "abc")</code> returns -1;</li>
   * <li><code>findDiff("ab", null)</code> returns 0.</li>
   * <li><code>findDiff("", " ")</code> returns 0.</li>
   */
  public static int findDiff(String string1, String string2) {
    if (isEmpty(string1) && isEmpty(string2)) return -1;
    if (isEmpty(string1) || isEmpty(string2)) return 0;
    int i;
    for (i = 0; i < Math.min(string1.length(), string2.length()); i++) {
      if (string1.charAt(i) != string2.charAt(i)) return i;
    }
    return string1.length() == string2.length() ? -1 : i;
  }

  /**
   * Three "fuzzy logical" values, _TRUE_, _FALSE_, _UNDEF_
   * ("Intuitionistic" would be a more correct scientific term for these).
   *
   */
  public static final int _TRUE_  = 3;
  public static final int _FALSE_ = 0;
  public static final int _UNDEF_ = 1;

  /**
   * Extracts logical value from a string
   *
   * @param string
   * @return _TRUE_  if it is 'true', 'yes', '1' or '+' (case-insensitive),
   *         _FALSE_ if it is 'false', 'no', '-' or '-' (case-insensitive),
   *         _UNDEF_ in all other cases.
   *
   * <br><br><b>Examples</b>:
   * <li><code>isItTrue("YeS")</code> returns _TRUE_;</li>
   * <li><code>isItTrue("false")</code> returns _FALSE_;</li>
   * <li><code>isItTrue(null)</code> returns _UNDEF_.</li>
   *
   */

  public int isItTrue(String string) {
    return ("true" .equalsIgnoreCase(string) ||
            "yes"  .equalsIgnoreCase(string) ||
            "1"    .equals          (string) ||
            "+"    .equals          (string))    ? _TRUE_ :

           ("false".equalsIgnoreCase(string) ||
            "no"   .equalsIgnoreCase(string) ||
            "not"  .equalsIgnoreCase(string) ||
            "0"    .equals          (string) ||
            "-"    .equals          (string))    ? _FALSE_
                                                : _UNDEF_;
  }

  /**
   * Extracts Boolean value from a string
   *
   * @param string
   * @param defaultValue
   * @return <b>true</b>  if it is 'true', 'yes', '1' or '+' (case-insensitive),
   *         <b>false</b> if it is 'false', 'no', '-' or '-' (case-insensitive),
   *         defaultValue in all other cases.
   *
   * <br><br><b>Examples</b>:
   * <li><code>toBoolean("YeS", false)</code> returns true;</li>
   * <li><code>toBoolean("false", false)</code> returns false;</li>
   * <li><code>toBoolean(null, true)</code> returns true.</li>
   */

  public boolean toBoolean(String string, boolean defaultValue) {
    int result = isItTrue(string);
    return result == _UNDEF_ ? defaultValue : result == _TRUE_;
  }
}
