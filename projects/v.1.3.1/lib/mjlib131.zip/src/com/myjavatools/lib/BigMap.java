package com.myjavatools.lib;

/**
 * <p>Title: My Java Tools Library</p>
 * <p>Description: This is a mixture of useful Java Tools</p>
 * <p>Copyright: Copyright (c) 2003 Vlad Patryshev</p>
 * <p>Company: My Java Tools</p>
 * @author vlad@myjavatools.com
 * @version 1.0
 */

public interface BigMap extends java.util.Map {
  public Object get(Object x, Object y);
  public Object get(Object x, Object y, Object z);
  public Object get(Object x, Object y, Object z, Object t);
  public Object get(Object[]args);
  public void put(Object x, Object y, Object value);
  public void put(Object x, Object y, Object z, Object value);
  public void put(Object x, Object y, Object z, Object t, Object value);
  public void put(Object[]args);
}