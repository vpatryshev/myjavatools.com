package com.myjavatools.lib;

import junit.framework.*;
import java.io.*;
import gnu.regexp.*;
import java.util.*;
//import java.util.regex.Pattern;

public class TestFiles
    extends TestCase {
  private Files files = null;

  public TestFiles(String name) {
    super(name);
  }

  protected void setUp() throws Exception {
    super.setUp();
    /**@todo verify the constructors*/
    files = new Files();
  }

  protected void tearDown() throws Exception {
    files = null;
    super.tearDown();
  }


      public static void assertEquals(String message, Object[] expectedArray, Object[] actualArray) {
        if (expectedArray == null) {
          assertNull(message + ": actual must be null", actualArray);
        }
        assertNotNull(message + ": ctual must not be null", actualArray);

        for (int i = 0; i < Math.max(expectedArray.length, actualArray.length); i++) {
          assertEquals(message + ": #" + i, expectedArray[i], actualArray[i]);
        }
      }

      public static void assertEquals(String message, byte[] expectedArray, byte[] actualArray) {
        if (expectedArray == null) {
          assertNull(message + ": actual must be null", actualArray);
        }
        assertNotNull(message + ": ctual must not be null", actualArray);

        for (int i = 0; i < Math.max(expectedArray.length, actualArray.length); i++) {
          assertEquals(message + ": #" + i, expectedArray[i], actualArray[i]);
        }
      }

      public static void assertEquals(String message, char[] expectedArray, char[] actualArray) {
        if (expectedArray == null) {
          assertNull(message + ": actual must be null", actualArray);
        }
        assertNotNull(message + ": ctual must not be null", actualArray);

        for (int i = 0; i < Math.max(expectedArray.length, actualArray.length); i++) {
          assertEquals(message + ": #" + i, expectedArray[i], actualArray[i]);
        }
      }


  public void testRelPath_1() {
    String expectedReturn = "src\\java";
    String actualReturn = files.relPath("c:\\MyHome\\dev", "c:\\MyHome\\dev\\src\\java");
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testRelPath_2() {
    String expectedReturn = "jbuilder8/samples/welcome";
    String actualReturn = files.relPath("/home/zaphod", "/home/zaphod/jbuilder8/samples/welcome");
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testRelPath_3() {
    String expectedReturn = "/home/ford/jbuilder8";
    String actualReturn = files.relPath("/home/zaphod", "/home/ford/jbuilder8");
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testSplitPath_1() {
    String[] expectedReturn = new String[] {".", "src.java"};
    String[] actualReturn = files.splitPath("src.java");
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testSplitPath_2() {
    String[] expectedReturn = new String[] {"/home/zaphod/jbuilder8/samples", "welcome"};
    String[] actualReturn = files.splitPath("/home/zaphod/jbuilder8/samples/welcome");
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testSplitPath_3() {
    String[] expectedReturn = new String[] {"MyHome", "dev"};
    String[] actualReturn = files.splitPath("MyHome\\dev");
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testDirname_1() {
    assertEquals("return value", "/home/zaphod/jbuilder8/samples", files.dirname("/home/zaphod/jbuilder8/samples/welcome"));
  }


  public void testDirname_2() {
    assertEquals("return value", "MyHome", files.dirname("MyHome\\dev"));
  }

  public void testDirname_3() {
    assertEquals("return value", ".", files.dirname("src.java"));
  }

  public void testFilename() {
    String path = "/home/zaphod/jbuilder8/samples/welcome";
    String expectedReturn = "welcome";
    String actualReturn = files.filename(path);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testPath_1() {
    assertEquals("return value", "c:\\MyHome\\dev\\src\\java", files.path("c:\\MyHome\\dev", "src\\java"));
  }

  public void testPath_2() {
    assertEquals("return value", "/home/zaphod/jbuilder8/samples/welcome", files.path("/root/inetd", "/home/zaphod/jbuilder8/samples/welcome"));
  }

  public void testPath_3() {
    assertEquals("return value", "c:\\MyHome\\dev", files.path("\\Program Files", "c:\\MyHome\\dev"));
  }

  public void testFind() {
    try {
      List expectedReturn = Arrays.asList(new String[] {new File("src\\com\\myjavatools\\lib\\Files.java").getCanonicalPath()});
      List actualReturn = files.find(new File("."), new RE(".*src.*les\\.java$"));
      assertEquals("return value", expectedReturn, actualReturn);
    } catch (Exception ex) {
      fail("problems: " + ex);
    }
  }

  public void testFind1() {
    try {
      List expectedReturn = Arrays.asList(new String[] {new File("src\\com\\myjavatools\\lib\\Files.java").getCanonicalPath()});
      List actualReturn = files.find(new File("."), new RE(".*src.*les\\.java$"));
      assertEquals("return value", expectedReturn, actualReturn);
    }
    catch (Exception ex) {
      fail("problems: " + ex);
    }
  }

  public void testFind2() {
    List expectedReturn = Arrays.asList(new String[] {new File("src\\com\\myjavatools\\lib\\Files.java").getAbsolutePath()});
    List actualReturn = files.find(".", ".*src.*les\\.java$");
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testLastModified() {
    File file = new File("src/com/myjavatools/lib/Objects.java");
    String expectedReturn = "Thu Aug 07 20:31:43 PDT 2003";
    String actualReturn = files.lastModified(file);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testReadStringFromFile() {
    String filename = "src/com/myjavatools/lib/Objects.java";
    String expectedReturn = "/**\r\n * <p>Title: MyJavaTools: Objects Handling</p>\r\n *";
    String actualReturn = files.readStringFromFile(filename);
    int i = Strings.findDiff(expectedReturn, actualReturn);
    assertTrue(i == expectedReturn.length());
    assertTrue(actualReturn.startsWith(expectedReturn));
  }

  public void testReadBytesFromStream() {
    InputStream is = new ByteArrayInputStream(new byte[] {1, 2, 3, 4, 5});
    byte[] expectedReturn = new byte[] {1, 2, 3, 4, 5};
    byte[] actualReturn = files.readBytesFromStream(is);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testReadBytesFromFile() {
    String filename = "src/com/myjavatools/lib/Files.java";
    byte[] expectedReturn = new byte[] {47, 42, 42, 13, 10, 32, 42};
    byte[] actualReturn = new byte[7];
    System.arraycopy(files.readBytesFromFile(filename), 0, actualReturn, 0, 7);
    assertEquals("return value", expectedReturn, actualReturn);
  }

  public void testGetPackage() {
    String basePath = null;
    String currentPath = null;
    String expectedReturn = "com.myjavatools.util";
    String actualReturn = files.getPackageName("c:\\home\\myjavatools\\src", "c:\\home\\myjavatools\\src\\com\\myjavatools\\util");
    assertEquals("return value", expectedReturn, actualReturn);
    actualReturn = files.getPackageName("c:\\home\\myjavatools\\src\\java", "c:\\home\\myjavatools\\src\\com\\myjavatools\\util");
    assertNull("must be null", actualReturn);
  }
}
