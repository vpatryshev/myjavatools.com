package com.myjavatools.lib;

import static com.myjavatools.lib.S.*;

public class TestS
{
//  public static String toString(Throwable e) {
//    e.getMessage();
//  }



  public void testToString() {

    try {
      ((String)null).toString();
    } catch (Exception e) {
      String returned = toString(e); //!!! does not compile
      String returnee = toStringy(e);
      String returnef = S.toString(e);
    }
  }
}
