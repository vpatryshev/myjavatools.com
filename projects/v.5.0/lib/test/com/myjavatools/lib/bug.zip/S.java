package com.myjavatools.lib;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

public class S
{
  public static String toString(Throwable e) {
    return e.getMessage();
  }


  public static String toStringy(Throwable e) {
    return e.getMessage();
  }
}
