package math.cat;

import static math.cat.Base.*;
import static math.cat.Category.*;
import static math.cat.Pair.*;
import static math.cat.PoSet.*;

import java.util.Set;
import java.util.Map;

/**
 * Sample Implementation of category.
 * All code is <a href="http://myjavatools.com/projects/Category/source.zip">here</a>
 */
public class Categories {

}
