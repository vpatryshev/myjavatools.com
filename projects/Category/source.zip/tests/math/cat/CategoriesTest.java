package math.cat;

import junit.framework.TestCase;
import static math.cat.Pair.Pair;

public class CategoriesTest extends TestCase {
}